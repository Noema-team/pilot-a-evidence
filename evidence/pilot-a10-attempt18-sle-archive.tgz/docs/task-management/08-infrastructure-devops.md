---
tags:
  - TaskManagement
---
# Document system with BMAD method
#ToDo
Document the entire system architecture and workflows using the BMAD method.

---
# Define document roles
#ToDo
Every document in the project should have a clear role and description. Similar to how `rules.md` describes how `TODO.md` is used — apply this to all docs from task management to monorepo files.

---
# Review and update restored web documentation
#ToDo
The three docs in `docs/documentation/web/` were restored by hand after the monorepo migration (they were gitignored in the old repo) and may be outdated. Verify each against the current `apps/web` code and update or archive: `logging.md`, `refactor-to-independent-resources.md` (implementation plan — check whether it was completed), `resource-status-v2-schema-contract.md` (schema contract — check it matches the actual Firestore layout).

---
# AppCheck implementation
#ToDo
Implement Firebase AppCheck to verify that requests to the backend come from the legitimate app.

---
