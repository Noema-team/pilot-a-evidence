import os
import sys
from unittest.mock import MagicMock

os.environ.setdefault("GCP_PROJECT", "test-project")
os.environ.setdefault("GOOGLE_APPLICATION_CREDENTIALS", "/tmp/fake-creds.json")
os.environ.setdefault("SHARED_INTERNAL_TOKEN", "test-token")

# If rag-api-service/main.py gains new cloud dependencies,
# add them to this list so direct imports work in integration tests.
required_mocks = [
    "firebase_admin",
    "firebase_admin.firestore",
    "firebase_admin.credentials",
    "firebase_admin.auth",
    "google.cloud",
    "google.cloud.firestore",
    "google.cloud.firestore_v1",
    "google.cloud.pubsub_v1",
    "google.oauth2",
    "google.oauth2.service_account",
    "structlog",
]

for mod in required_mocks:
    if mod not in sys.modules:
        sys.modules[mod] = MagicMock()

sys.path.insert(
    0,
    os.path.abspath(
        os.path.join(os.path.dirname(__file__), "..", "..", "rag-api-service")
    ),
)
