The verified evidence is sufficient to author the contract tests. Summary of what I'm delivering and why it's shaped this way:

- **Worker side is exercised behaviorally**: the real `process_document` failure handler runs and publishes through the real `_publish_status_update`; Pub/Sub and Firestore are fakes, so the captured JSON is exactly what would land on the status topic. Early-stage and late-stage failures pin the stage-tracker mechanism on representative stages (per the Definition's test strategy) without ossifying every step; `retryable` is asserted against the real `classify_error` (requirement 4), and the legacy `error` key retention (F11 hedge) is pinned.
- **rag-api side is exercised through `run_transactional_update`** (the Definition-pinned failed-branch entry point) against an in-memory fake Firestore, asserting persisted `error`/`error_stage`/`retryable` equal the worker's published values, plus the `processing/summary` subdocument (`message`/`stage`/`error_code == "UNKNOWN"`). The permanent-error case proves `retryable` is not the silent `True` default and `error` is not the `"Processing failed"` fallback.
- **AST drift guards** (the established house pattern from `tests/integration/test_api_contracts.py`) pin the payload key sets on both sides so future key drift fails the build.
- Import isolation: the worker module is loaded by path under a unique module name with gap-filling mocks for heavy optional deps (the shared conftest already mocks the Google/Firebase stack); rag-api is fresh-imported with an identity `firestore.transactional` so the real transactional body stays callable instead of being swallowed by the shared conftest's mocks.
- The worker-side behavioral and round-trip persistence tests are intentionally red until the worker publishes `error_message`/`stage`/`retryable`; the rag-api drift guards pin the reader contract that already exists so it cannot drift while the worker is being aligned.

<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path="apps/ai-server/tests/integration/test_failure_payload_contract.py">>>
"""Worker → rag-api failure payload contract tests.

Contract under test (WorkItem wi-define-108-a8, artifact definition:obj-108):

    A failed RAG processing job must persist the worker's actual error message,
    the failing pipeline stage, and a deliberately derived retryable flag —
    locked in by a contract test on the worker→rag-api failure path.

Requirement traceability (Definition requirements → tests):

    R1  worker failed payload includes error_message / stage / retryable and
        never relies on rag-api's fallback defaults
            → TestWorkerFailurePayload
    R2  stage tracked through process_document; names reuse the progress-stage
        vocabulary (starting, text_retrieved, tagging_complete,
        summary_generated, chunking_complete, embeddings_complete) with
        "processing" as the safe value when the stage is genuinely unknown
            → TestWorkerFailurePayload (early/late representative stages)
    R3  rag-api persists worker values unchanged (error ← error_message,
        error_stage ← stage, retryable ← retryable) and mirrors message/stage
        into the processing/summary subdocument
            → TestRagApiFailedBranchPersistence
    R4  retryable derived explicitly from classify_error (transient → True;
        permanent, including unclassified-unknown, → False)
            → TestRetryableDerivation
    R5  the contract test exercises the worker's failure-payload construction
        through rag-api's failed-branch persistence and fails if either
        side's payload keys drift
            → round-trip persistence tests + TestFailurePayloadDriftGuard
              (AST key-set drift guards on both services)

How the seam is exercised (per the Definition's test strategy — import both
sides rather than restate the contract in a fixture):

  * Worker side: the real ``process_document`` failure handler runs and
    publishes through the real ``_publish_status_update``; Pub/Sub and
    Firestore are fakes, so the captured JSON message is exactly what would
    be published to the status topic.
  * rag-api side: ``run_transactional_update`` is imported from
    rag-api-service/main.py and driven against an in-memory fake Firestore;
    the persisted main document and the processing/summary subdocument are
    asserted field-by-field against the worker's published values.
  * Drift guards: AST checks pin the payload key sets on both sides so a
    future edit to either side's keys fails the build instead of silently
    re-creating the mismatch.

The worker-side behavioral tests and the round-trip persistence tests are
expected to fail (red) until the worker publishes error_message/stage/
retryable; the rag-api drift guards pin the reader contract that already
exists so it cannot drift while the worker is being aligned.
"""

import ast
import asyncio
import concurrent.futures
import importlib
import importlib.util
import inspect
import itertools
import json
import os
import sys
import types
import uuid
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

# ========================================
# Layout and contract constants (from the Definition, not from code)
# ========================================

HERE = os.path.dirname(os.path.abspath(__file__))
AI_SERVER_DIR = os.path.abspath(os.path.join(HERE, "..", ".."))
WORKER_DIR = os.path.join(AI_SERVER_DIR, "rag-worker-service")
RAG_API_DIR = os.path.join(AI_SERVER_DIR, "rag-api-service")
WORKER_MAIN_PATH = os.path.join(WORKER_DIR, "main.py")
RAG_API_MAIN_PATH = os.path.join(RAG_API_DIR, "main.py")

# Requirement 1: the worker's failed payload must carry these keys.
REQUIRED_PAYLOAD_KEYS = {"error_message", "stage", "retryable"}
# F11 hedge: the legacy key is retained alongside error_message.
LEGACY_RETAINED_KEY = "error"

# Requirement 2: stage vocabulary (progress-stage names + safe unknown value).
ALLOWED_STAGES = {
    "starting",
    "text_retrieved",
    "tagging_complete",
    "summary_generated",
    "chunking_complete",
    "embeddings_complete",
    "processing",
}
# Representative-stage pinning: an early pipeline failure must report an
# early-phase stage (or the safe unknown value); a late pipeline failure must
# report a late-phase stage — never the safe unknown value, which would mean
# the stage tracker was removed or bypassed.
EARLY_STAGE_OK = {"starting", "text_retrieved", "processing"}
LATE_STAGE_OK = ALLOWED_STAGES - EARLY_STAGE_OK

# rag-api's fallback defaults (Definition facts F4/F5): a worker failure must
# never land as these values.
API_FALLBACK_ERROR = "Processing failed"
UNKNOWN_ERROR_CODE = "UNKNOWN"

WORKER_MOD_NAME = "rag_worker_main_failure_contract"
RAG_API_MOD_NAME = "rag_api_main_failure_contract"

_WORKER_MODULE = None
_RAG_API_MODULE = None
_RID_SEQ = itertools.count(1)


# ========================================
# Module import helpers
# ========================================

def _seed_mock(name):
    """Put `name` in sys.modules: real if importable, MagicMock otherwise."""
    if name in sys.modules:
        return
    try:
        importlib.import_module(name)
    except Exception:
        sys.modules[name] = MagicMock()


def _ensure_httpx():
    """
    classify_error() does isinstance checks against httpx exception classes,
    so httpx must provide real classes (a MagicMock in an isinstance tuple
    raises TypeError). Import the real httpx; if unavailable, synthesize a
    minimal shim with real exception classes.
    """
    try:
        importlib.import_module("httpx")
        return
    except Exception:
        pass
    shim = types.ModuleType("httpx")

    class RequestError(Exception):
        pass

    class ConnectError(RequestError):
        pass

    class ConnectTimeout(ConnectError):
        pass

    class ReadTimeout(RequestError):
        pass

    class WriteTimeout(RequestError):
        pass

    class PoolTimeout(RequestError):
        pass

    class HTTPStatusError(RequestError):
        pass

    class AsyncClient:  # pragma: no cover - never constructed in these tests
        pass

    for cls in (RequestError, ConnectError, ConnectTimeout, ReadTimeout,
                WriteTimeout, PoolTimeout, HTTPStatusError, AsyncClient):
        setattr(shim, cls.__name__, cls)
    sys.modules["httpx"] = shim


def _import_worker_main():
    """Load rag-worker-service/main.py by path under a unique module name.

    The shared conftest already mocks the Google/Firebase stack; here we fill
    the remaining gaps (langchain/openai/langfuse/spacy/sklearn/tiktoken/
    tenacity) so the worker module imports in the integration environment.
    Loading by path avoids the `main` module-name collision with rag-api.
    """
    global _WORKER_MODULE
    if _WORKER_MODULE is not None:
        return _WORKER_MODULE

    _ensure_httpx()
    for name in [
        "langchain",
        "langchain.text_splitter",
        "langchain.schema",
        "openai",
        "langfuse",
        "spacy",
        "sklearn",
        "sklearn.feature_extraction",
        "sklearn.feature_extraction.text",
        "tiktoken",
        "tenacity",
        "google.cloud.firestore_v1.base_query",
        "google.auth",
        "google.auth.credentials",
        "google.cloud.storage",
    ]:
        _seed_mock(name)

    # ProcessingConfig subclasses BaseSettings at class-definition time, so a
    # MagicMock module would explode on subclassing. Shim with a real class.
    try:
        importlib.import_module("pydantic_settings")
    except Exception:
        shim = types.ModuleType("pydantic_settings")
        try:
            import pydantic as _pydantic

            shim.BaseSettings = _pydantic.BaseModel
        except Exception:  # pragma: no cover - pydantic is a hard dep
            class _BaseSettings:
                pass

            shim.BaseSettings = _BaseSettings
        sys.modules["pydantic_settings"] = shim

    os.environ.setdefault("GCP_PROJECT", "test-project")
    os.environ.setdefault("GOOGLE_APPLICATION_CREDENTIALS", "/tmp/fake-creds.json")
    os.environ.setdefault("OPENROUTER_API_KEY", "test-key")
    os.environ.setdefault("OPENROUTER_BASE_URL", "https://openrouter.test/api/v1")
    os.environ.setdefault("OPENROUTER_MODEL", "test-model")
    os.environ.setdefault("FIREBASE_STORAGE_BUCKET", "test-bucket")
    os.environ.setdefault("FIREBASE_PROJECT_ID", "test-project")
    os.environ.setdefault("RAG_PROCESS_SUB", "test-process-sub")
    os.environ.setdefault("RAG_STATUS_TOPIC", "test-status-topic")
    os.environ.setdefault("SHARED_INTERNAL_TOKEN", "test-token")
    os.environ.setdefault("WEAVIATE_SERVICE_URL", "http://weaviate.test")

    spec = importlib.util.spec_from_file_location(WORKER_MOD_NAME, WORKER_MAIN_PATH)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    _WORKER_MODULE = mod
    return mod


def _import_rag_api_main_fresh():
    """
    Import rag-api-service/main.py under a unique module name with a fake
    google.cloud.firestore whose `transactional` is an identity decorator.

    The shared conftest mocks google.cloud.firestore with a plain MagicMock,
    which would turn `@firestore.transactional` decorations into dead mocks
    and make the real failed-branch body unreachable. The identity decorator
    keeps the real function bodies callable so they can be driven against the
    in-memory fake Firestore below. The shared sys.modules state is restored
    afterwards so other test modules are unaffected.
    """
    global _RAG_API_MODULE
    if _RAG_API_MODULE is not None:
        return _RAG_API_MODULE

    fake_fs = MagicMock(name="fake google.cloud.firestore")
    fake_fs.transactional = lambda fn: fn  # identity: keep real bodies callable
    fake_fs.SERVER_TIMESTAMP = "SERVER_TIMESTAMP"
    fake_fs.Increment = lambda n: n
    fake_fs.ArrayUnion = lambda *vals: list(vals)
    fake_fs.ArrayRemove = lambda *vals: []
    fake_fs.DELETE_FIELD = "DELETE_FIELD"

    saved_mains = {
        k: sys.modules.pop(k)
        for k in list(sys.modules)
        if k == "main" or k.startswith("main.")
    }
    saved_fs = sys.modules.get("google.cloud.firestore")
    gc = sys.modules.get("google.cloud")
    saved_gc_attr = getattr(gc, "firestore", None) if gc is not None else None
    sys.modules["google.cloud.firestore"] = fake_fs
    if gc is not None:
        try:
            gc.firestore = fake_fs
        except Exception:
            pass
    try:
        spec = importlib.util.spec_from_file_location(RAG_API_MOD_NAME, RAG_API_MAIN_PATH)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = mod
        spec.loader.exec_module(mod)
    finally:
        if saved_fs is not None:
            sys.modules["google.cloud.firestore"] = saved_fs
        elif "google.cloud.firestore" in sys.modules:
            del sys.modules["google.cloud.firestore"]
        if gc is not None and saved_gc_attr is not None:
            try:
                gc.firestore = saved_gc_attr
            except Exception:
                pass
        sys.modules.update(saved_mains)
    _RAG_API_MODULE = mod
    return mod


# ========================================
# Fakes for the worker harness
# ========================================

class FakePublisher:
    """Captures every status-topic publish; resolves futures immediately."""

    def __init__(self):
        self.published = []

    def topic_path(self, project, topic):
        return f"projects/{project}/topics/{topic}"

    def publish(self, topic_path, data):
        self.published.append((topic_path, bytes(data)))
        future = concurrent.futures.Future()
        future.set_result("fake-message-id")
        return future


class _LeaseSnapshot:
    exists = False

    def to_dict(self):
        return {}


class _LeaseDocRef:
    def __init__(self, db, path):
        self.db = db
        self.path = path

    def get(self, transaction=None):
        return _LeaseSnapshot()

    def set(self, data, merge=False):
        self.db.updates.append((self.path, dict(data)))

    def update(self, data):
        self.db.updates.append((self.path, dict(data)))

    def collection(self, name):
        return _LeaseDocRef(self.db, f"{self.path}/{name}")


class FakeLeaseDb:
    """Minimal Firestore stand-in for the worker's lease/status writes."""

    def __init__(self):
        self.updates = []

    def document(self, path):
        return _LeaseDocRef(self, path)


def _async_return(value):
    async def _fn(*args, **kwargs):
        return value

    return _fn


def _async_raiser(err):
    async def _fn(*args, **kwargs):
        raise err

    return _fn


def _make_processor(worker):
    """Build an EnhancedDocumentProcessor without running __init__.

    Only the attributes the failure path touches are injected: the real
    process_document and _publish_status_update run against fake Pub/Sub and
    fake Firestore.
    """
    processor = object.__new__(worker.EnhancedDocumentProcessor)
    processor.langfuse = None
    processor.logger = MagicMock()
    processor.config = SimpleNamespace(
        gcp_project="test-project",
        rag_status_topic="test-status-topic",
    )
    processor.pubsub_publisher = FakePublisher()
    processor.db = FakeLeaseDb()
    processor.embedding_cost_per_token = 0.00002
    return processor


def _latest_failed_message(publisher):
    for _topic, data in reversed(publisher.published):
        message = json.loads(data.decode("utf-8"))
        if message.get("status") == "failed":
            return message
    statuses = [
        json.loads(d.decode("utf-8")).get("status") for _t, d in publisher.published
    ]
    raise AssertionError(
        "no failed status message was published; published statuses: "
        f"{statuses}"
    )


def _run_worker_failure(worker, err, fail_at):
    """
    Drive the real process_document into a failure at the requested point and
    return (published failed message, resource_id).

    fail_at="text"       → failure inside _get_extracted_text (early stage)
    fail_at="embeddings" → failure inside _generate_embeddings_with_openrouter
                           (late stage; tagging/summary/chunking stubbed green)
    """
    processor = _make_processor(worker)
    resource_id = f"contract-rid-{next(_RID_SEQ)}"
    processor._validate_processing_request = _async_return(None)

    if fail_at == "text":
        processor._get_extracted_text = _async_raiser(err)
    elif fail_at == "embeddings":
        processor._get_extracted_text = _async_return(
            ("contract markdown text", {"title": "Contract Spec", "filename": "contract-spec.pdf"})
        )
        processor.content_tagger = SimpleNamespace(generate_tags=_async_return(([], {})))
        processor.generate_document_summary = _async_return(
            {"overview": "overview", "bulletPoints": ["point"]}
        )
        processor._create_enhanced_chunks = _async_return([])
        processor._generate_embeddings_with_openrouter = _async_raiser(err)
    else:
        raise AssertionError(f"unsupported fail_at: {fail_at!r}")

    asyncio.run(
        processor.process_document("contract-user", "__ungrouped__", resource_id, "contract-job")
    )
    return _latest_failed_message(processor.pubsub_publisher), resource_id


# ========================================
# Fakes for the rag-api failed-branch persistence
# ========================================

class FakeSnapshot:
    def __init__(self, ref, data):
        self.ref = ref
        self._data = dict(data) if data is not None else None

    @property
    def exists(self):
        return self._data is not None

    def to_dict(self):
        return dict(self._data) if self._data is not None else {}

    def get(self, key):
        if self._data is None:
            raise KeyError(key)
        return self._data[key]

    @property
    def reference(self):
        return self.ref


class FakeDocRef:
    def __init__(self, db, path):
        self.db = db
        self.path = path
        self.id = path.rsplit("/", 1)[-1]

    def collection(self, name):
        return FakeCollectionRef(self.db, f"{self.path}/{name}")

    def get(self, transaction=None):
        return FakeSnapshot(self, self.db.store.get(self.path))

    def set(self, data, merge=False):
        self.db._apply(self.path, data, merge)

    def update(self, data):
        self.db._apply(self.path, data, merge=True)

    def delete(self):
        self.db.store.pop(self.path, None)


class FakeCollectionRef:
    def __init__(self, db, base):
        self.db = db
        self.base = base

    def document(self, doc_id=None):
        if doc_id is None:
            doc_id = f"auto-{uuid.uuid4().hex[:8]}"
        return FakeDocRef(self.db, f"{self.base}/{doc_id}")


class FakeTransaction:
    def __init__(self, db):
        self.db = db

    def get(self, ref, **kwargs):
        if not isinstance(ref, FakeDocRef):
            raise AssertionError(
                "fake transaction can only get FakeDocRef references — "
                f"got {type(ref)!r}; run_transactional_update must be driven "
                "with the injected fake db (module-global or parameter)"
            )
        return ref.get(transaction=self)

    def set(self, ref, data, merge=False):
        if not isinstance(ref, FakeDocRef):
            raise AssertionError(
                f"fake transaction can only set FakeDocRef references, got {type(ref)!r}"
            )
        ref.set(data, merge=merge)

    def update(self, ref, data):
        if not isinstance(ref, FakeDocRef):
            raise AssertionError(
                f"fake transaction can only update FakeDocRef references, got {type(ref)!r}"
            )
        ref.update(data)

    def delete(self, ref):
        ref.delete()


class FakeFirestore:
    """In-memory Firestore: records every write, supports the transaction
    protocol (transaction()/get/set/update) the failed branch uses."""

    def __init__(self):
        self.store = {}
        self.writes = []

    def document(self, path):
        return FakeDocRef(self, path)

    def collection(self, path):
        return FakeCollectionRef(self, path)

    def transaction(self):
        return FakeTransaction(self)

    def collection_group(self, name):
        raise NotImplementedError("not needed for the failed branch")

    def _apply(self, path, data, merge):
        payload = dict(data)
        self.writes.append((path, payload, merge))
        if merge:
            base = self.store.get(path) or {}
            self.store[path] = {**base, **payload}
        else:
            self.store[path] = payload


def _seed_resource(db, envelope):
    user_id = envelope["user_id"]
    resource_id = envelope["resource_id"]
    course_id = envelope.get("course_id", "__ungrouped__")
    seed = {
        "resource_id": resource_id,
        "filename": "contract-spec.pdf",
        "userId": user_id,
        "status": "processing",
    }
    # Seed both the canonical (V2) and legacy course-centric paths so the
    # failed branch resolves the resource regardless of its path strategy.
    db.store[f"users/{user_id}/resources/{resource_id}"] = dict(seed)
    db.store[f"users/{user_id}/courses/{course_id}/courseResources/{resource_id}"] = dict(seed)


def _failure_write_present(db):
    for path, data, _merge in db.writes:
        if isinstance(data, dict) and (
            "error_stage" in data or path.endswith("/processing/summary")
        ):
            return True
    return False


def _persist_envelope(api, envelope):
    """
    Drive rag-api's run_transactional_update with the worker's published
    failure envelope against a fresh FakeFirestore, and return the fake db.

    The function's exact signature is an implementation detail; the entry
    point name is pinned by the Definition (fact F4). We discover the
    signature and try the plausible call shapes, requiring that a failure
    write actually happened.
    """
    fn = getattr(api, "run_transactional_update", None)
    assert fn is not None, (
        "rag-api must expose run_transactional_update — the Definition-pinned "
        "failed-branch entry point (definition:obj-108, fact F4)"
    )
    assert not isinstance(fn, MagicMock), (
        "run_transactional_update resolved to a MagicMock — the contract test "
        "needs the real function body (firestore.transactional must not "
        "swallow it)"
    )
    try:
        sig = inspect.signature(inspect.unwrap(fn))
    except (TypeError, ValueError):
        sig = None

    dataish_names = (
        "data", "message", "payload", "msg", "event", "envelope",
        "status_message", "status_data", "message_data", "update",
    )
    attempts = []

    if sig is not None:
        params = list(sig.parameters)

        def _ids_kwargs(subset):
            kwargs = {}
            for p in ("user_id", "course_id", "resource_id", "job_id"):
                if p in subset:
                    kwargs[p] = envelope.get(p)
            return kwargs

        if "db" in params:
            dataish = [p for p in params if p in dataish_names]
            if dataish:
                name = dataish[0]
                attempts.append((
                    f"run_transactional_update(db, {name}=envelope)",
                    lambda db, _name=name: fn(db=db, **{_name: envelope}),
                ))
            if "details" in params:
                def _split(db):
                    kwargs = {"db": db, "details": envelope.get("details", {})}
                    if "status" in params:
                        kwargs["status"] = envelope.get("status")
                    kwargs.update(_ids_kwargs(params))
                    return fn(**kwargs)

                attempts.append((
                    "run_transactional_update(db, status=..., details=...)",
                    _split,
                ))
            if params and params[0] in ("transaction", "txn", "tx", "t"):
                rest = params[1:]

                def _txn_first(db):
                    kwargs = {}
                    dataish_rest = [p for p in rest if p in dataish_names]
                    if dataish_rest:
                        kwargs[dataish_rest[0]] = envelope
                    elif "details" in rest:
                        kwargs["details"] = envelope.get("details", {})
                        if "status" in rest:
                            kwargs["status"] = envelope.get("status")
                        kwargs.update(_ids_kwargs(rest))
                    if "db" in rest:
                        kwargs["db"] = db
                    return fn(db.transaction(), **kwargs)

                attempts.append(("run_transactional_update(transaction, ...)", _txn_first))

    attempts.append((
        "run_transactional_update(db, envelope) [positional fallback]",
        lambda db: fn(db, envelope),
    ))

    last_error = None
    for desc, call in attempts:
        db = FakeFirestore()
        _seed_resource(db, envelope)
        # If the failed branch resolves the db from a module global, point it
        # at the fake for this attempt (module instance is test-private).
        for attr in ("db", "DB", "_db", "firestore_db", "firestore_client"):
            if hasattr(api, attr):
                try:
                    setattr(api, attr, db)
                except Exception:
                    pass
        try:
            result = call(db)
            if inspect.iscoroutine(result):
                asyncio.run(result)
        except TypeError as exc:
            last_error = exc
            continue
        if _failure_write_present(db):
            return db
        last_error = AssertionError(
            f"attempt {desc!r} produced no failure write; writes={db.writes!r}"
        )
    raise AssertionError(
        "Could not drive rag-api run_transactional_update with the worker "
        f"failure envelope. Discovered signature: {sig}. Last error: {last_error!r}"
    )


def _find_main_failure_doc(db, resource_id):
    candidates = [
        path
        for path in db.store
        if path.endswith(f"/{resource_id}")
        and "/processing/" not in path
        and isinstance(db.store[path], dict)
        and "error_stage" in db.store[path]
    ]
    assert len(candidates) == 1, (
        f"expected exactly one main-document failure write for resource "
        f"{resource_id!r}, found: {candidates}"
    )
    return candidates[0], db.store[candidates[0]]


def _summary_doc(db, main_path):
    path = f"{main_path}/processing/summary"
    doc = db.store.get(path)
    assert doc is not None, (
        f"processing/summary subdocument missing at {path}; store keys: "
        f"{sorted(db.store)}"
    )
    return doc


# ========================================
# R1/R2 — worker failed payload shape and stage tracking
# ========================================

class TestWorkerFailurePayload:
    def test_failed_payload_carries_error_message_stage_and_retryable(self):
        worker = _import_worker_main()
        err = worker.TransientError("weaviate read timed out after 30s")
        message, resource_id = _run_worker_failure(worker, err, "text")

        assert message["status"] == "failed"
        assert message["resource_id"] == resource_id

        details = message["details"]
        for key in REQUIRED_PAYLOAD_KEYS:
            assert key in details, (
                f"worker failed payload missing required key {key!r}; "
                f"payload details: {details}"
            )
        # The actual exception message, never rag-api's fallback string.
        assert details["error_message"] == "weaviate read timed out after 30s"
        assert details["error_message"] != API_FALLBACK_ERROR
        # Deliberately derived, explicitly typed — not a defaulted value.
        assert isinstance(details["retryable"], bool)
        assert isinstance(details["stage"], str)
        assert details["stage"] in ALLOWED_STAGES, (
            f"stage {details['stage']!r} is outside the required progress-stage "
            f"vocabulary {sorted(ALLOWED_STAGES)}"
        )

    def test_early_failure_reports_early_stage(self):
        worker = _import_worker_main()
        err = worker.TransientError("text retrieval failed")
        message, _ = _run_worker_failure(worker, err, "text")
        stage = message["details"]["stage"]
        assert stage in EARLY_STAGE_OK, (
            f"early pipeline failure reported stage {stage!r}; expected one of "
            f"{sorted(EARLY_STAGE_OK)}"
        )

    def test_late_failure_reports_late_stage_not_processing(self):
        worker = _import_worker_main()
        err = worker.PermanentError("embedding model rejected input")
        message, _ = _run_worker_failure(worker, err, "embeddings")
        stage = message["details"]["stage"]
        assert stage in LATE_STAGE_OK, (
            f"late pipeline failure reported stage {stage!r}; a functioning "
            f"stage tracker must report a late-stage value from "
            f"{sorted(LATE_STAGE_OK)}, not the safe unknown value"
        )

    def test_failed_payload_retains_legacy_error_key(self):
        # F11 compatibility hedge: the legacy `error` key stays alongside
        # error_message so unknown consumers of the status topic keep working.
        worker = _import_worker_main()
        err = worker.PermanentError("legacy consumer hedge")
        message, _ = _run_worker_failure(worker, err, "text")
        assert message["details"].get("error") == "legacy consumer hedge", (
            "the worker must retain the legacy 'error' key alongside "
            "error_message in the failed payload"
        )


# ========================================
# R4 — retryable derivation aligned with classify_error / ACK-NACK
# ========================================

class TestRetryableDerivation:
    def test_classify_error_conservative_defaults(self):
        # Baseline the derivation source (Definition fact F7): transient →
        # True; permanent and unclassified-unknown → False.
        worker = _import_worker_main()
        assert worker.classify_error(worker.TransientError("x")) is True
        assert worker.classify_error(worker.PermanentError("x")) is False
        assert worker.classify_error(ValueError("x")) is False
        assert worker.classify_error(ConnectionError("x")) is True

    @pytest.mark.parametrize(
        "exc_kind, expected_retryable",
        [
            ("transient", True),
            ("permanent", False),
            ("unknown", False),
            ("builtin_connection", True),
        ],
    )
    def test_payload_retryable_is_derived_from_classify_error(
        self, exc_kind, expected_retryable
    ):
        worker = _import_worker_main()
        if exc_kind == "transient":
            err = worker.TransientError("embedding provider rate limited (429)")
        elif exc_kind == "permanent":
            err = worker.PermanentError("document has neither extracted text nor a source URL")
        elif exc_kind == "unknown":
            err = ValueError("unclassified unknown failure")
        else:
            err = ConnectionError("connection reset by peer")

        message, _ = _run_worker_failure(worker, err, "text")
        retryable = message["details"]["retryable"]
        assert retryable is expected_retryable, (
            f"retryable for {type(err).__name__} must be {expected_retryable} "
            f"(classify_error alignment with ACK/NACK behavior), got {retryable!r}"
        )
        assert retryable == worker.classify_error(err), (
            "payload retryable must equal the worker's own classify_error "
            "verdict — the same classification that drives ACK/NACK"
        )


# ========================================
# R3/R5 — worker failure → rag-api persistence round trip
# ========================================

class TestRagApiFailedBranchPersistence:
    def test_permanent_worker_failure_persists_worker_values(self):
        worker = _import_worker_main()
        err = worker.PermanentError("embedding model rejected input: unsupported file type")
        message, resource_id = _run_worker_failure(worker, err, "embeddings")
        api = _import_rag_api_main_fresh()
        db = _persist_envelope(api, message)

        details = message["details"]
        main_path, doc = _find_main_failure_doc(db, resource_id)

        # Main document: worker values persisted unchanged — not the fallbacks.
        assert doc["error"] == details["error_message"] == str(err), (
            f"persisted error {doc.get('error')!r} must equal the worker's "
            f"error_message {details['error_message']!r}"
        )
        assert doc["error"] != API_FALLBACK_ERROR, (
            "persisted error must never be rag-api's 'Processing failed' fallback"
        )
        assert doc["error_stage"] == details["stage"], (
            f"persisted error_stage {doc.get('error_stage')!r} must equal the "
            f"worker's stage {details['stage']!r}"
        )
        assert doc["error_stage"] is not None
        assert doc["retryable"] is False, (
            "permanent-classified failure must persist the worker-derived "
            "retryable=False — the silent details.get('retryable', True) "
            "default must not be the operative mechanism"
        )
        assert details["retryable"] is False
        assert doc.get("status") == "failed"

        # processing/summary subdocument: same message and stage as the main
        # document, error_code defaulting to UNKNOWN.
        summary = _summary_doc(db, main_path)
        assert summary["message"] == details["error_message"]
        assert summary["stage"] == details["stage"]
        assert summary["message"] == doc["error"], (
            "processing/summary message must match the main document error"
        )
        assert summary["stage"] == doc["error_stage"], (
            "processing/summary stage must match the main document error_stage"
        )
        assert summary["error_code"] == UNKNOWN_ERROR_CODE, (
            "error_code must default to UNKNOWN — no structured error-code "
            "taxonomy is introduced by this fix"
        )

    def test_transient_worker_failure_persists_retryable_true(self):
        worker = _import_worker_main()
        err = worker.TransientError("weaviate storage unavailable")
        message, resource_id = _run_worker_failure(worker, err, "text")
        api = _import_rag_api_main_fresh()
        db = _persist_envelope(api, message)

        details = message["details"]
        main_path, doc = _find_main_failure_doc(db, resource_id)

        assert doc["error"] == details["error_message"] == str(err)
        assert doc["error"] != API_FALLBACK_ERROR
        assert doc["error_stage"] == details["stage"]
        assert doc["error_stage"] is not None
        assert doc["retryable"] is True, (
            "transient-classified failure must persist the worker-derived "
            "retryable=True"
        )
        assert details["retryable"] is True
        assert doc.get("status") == "failed"

        summary = _summary_doc(db, main_path)
        assert summary["message"] == details["error_message"] == doc["error"]
        assert summary["stage"] == details["stage"] == doc["error_stage"]
        assert summary["error_code"] == UNKNOWN_ERROR_CODE


# ========================================
# R5 — key-set drift guards (AST, house pattern from test_api_contracts.py)
# ========================================

def _worker_source():
    with open(WORKER_MAIN_PATH) as f:
        return f.read()


def _api_source():
    with open(RAG_API_MAIN_PATH) as f:
        return f.read()


def _failed_publish_calls(tree):
    calls = []
    for node in ast.walk(tree):
        if (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr == "_publish_status_update"
        ):
            status = None
            if len(node.args) >= 4 and isinstance(node.args[3], ast.Constant):
                status = node.args[3].value
            for kw in node.keywords:
                if kw.arg == "status" and isinstance(kw.value, ast.Constant):
                    status = kw.value.value
            if status == "failed":
                calls.append(node)
    return calls


def _innermost_function(tree, lineno):
    best = None
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            end = getattr(node, "end_lineno", node.lineno)
            if node.lineno <= lineno <= end:
                if best is None or (
                    end - node.lineno
                    < getattr(best, "end_lineno", best.lineno) - best.lineno
                ):
                    best = node
    return best


def _find_dict_with(node, required):
    """Return the key set of the first Dict literal inside `node` whose keys
    are a superset of `required`, or None."""
    for sub in ast.walk(node):
        if isinstance(sub, ast.Dict):
            keys = {
                k.value
                for k in sub.keys
                if isinstance(k, ast.Constant) and isinstance(k.value, str)
            }
            if required <= keys:
                return keys
    return None


def _has_call_to(node, name):
    for sub in ast.walk(node):
        if isinstance(sub, ast.Call):
            fn = sub.func
            if (isinstance(fn, ast.Name) and fn.id == name) or (
                isinstance(fn, ast.Attribute) and fn.attr == name
            ):
                return True
    return False


def _find_function(tree, name):
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name:
            return node
    return None


def _api_key_usage(fn_node):
    """Collect string keys read (details.get("k") / subscript constants) and
    written (dict-literal keys) anywhere inside the failed-branch function."""
    reads, writes = set(), set()
    for sub in ast.walk(fn_node):
        if isinstance(sub, ast.Dict):
            for k in sub.keys:
                if isinstance(k, ast.Constant) and isinstance(k.value, str):
                    writes.add(k.value)
        if (
            isinstance(sub, ast.Call)
            and isinstance(sub.func, ast.Attribute)
            and sub.func.attr == "get"
        ):
            if sub.args and isinstance(sub.args[0], ast.Constant) and isinstance(
                sub.args[0].value, str
            ):
                reads.add(sub.args[0].value)
        if isinstance(sub, ast.Subscript):
            sl = sub.slice
            if isinstance(sl, ast.Constant) and isinstance(sl.value, str):
                reads.add(sl.value)
    return reads, writes


class TestFailurePayloadDriftGuard:
    def test_worker_failed_handler_publishes_contract_keys(self):
        tree = ast.parse(_worker_source())
        failed_calls = _failed_publish_calls(tree)
        assert failed_calls, (
            "worker must publish a 'failed' status via _publish_status_update"
        )
        for call_node in failed_calls:
            scope = _innermost_function(tree, call_node.lineno)
            assert scope is not None, (
                "failed _publish_status_update call must live inside a function"
            )
            # A single dict literal in the failure path must carry the whole
            # contract key set; progress dicts (stage/progress only) cannot
            # satisfy this, so the guard is precise without ossifying
            # construction style.
            payload_keys = _find_dict_with(scope, REQUIRED_PAYLOAD_KEYS)
            assert payload_keys is not None, (
                f"worker failure payload keys drifted: no dict literal in "
                f"{scope.name!r} carries {sorted(REQUIRED_PAYLOAD_KEYS)}"
            )
            assert LEGACY_RETAINED_KEY in payload_keys, (
                "legacy 'error' key must be retained alongside error_message "
                "in the failure payload (compatibility hedge, fact F11)"
            )
            assert _has_call_to(scope, "classify_error"), (
                "retryable must be derived via classify_error inside the "
                "failure path — never silently defaulted"
            )

    def test_rag_api_failed_branch_reads_and_persists_contract_keys(self):
        tree = ast.parse(_api_source())
        fn = _find_function(tree, "run_transactional_update")
        assert fn is not None, (
            "rag-api must keep the Definition-pinned run_transactional_update "
            "failed-branch entry point"
        )
        reads, writes = _api_key_usage(fn)

        missing_reads = REQUIRED_PAYLOAD_KEYS - (reads | writes)
        assert not missing_reads, (
            f"rag-api failed branch no longer reads worker payload keys: "
            f"{missing_reads} — the worker→rag-api failure contract drifted"
        )

        persisted = {"error", "error_stage", "retryable"}
        missing_writes = persisted - writes
        assert not missing_writes, (
            f"rag-api failed branch no longer persists the established "
            f"failure schema fields: {missing_writes}"
        )

        summary_keys = {"message", "stage", "error_code"}
        missing_summary = summary_keys - writes
        assert not missing_summary, (
            f"rag-api processing/summary error write drifted: missing "
            f"{missing_summary}"
        )
<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>