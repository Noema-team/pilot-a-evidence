# Requirements — rag-worker → rag-api failure payload contract alignment

- **Cycle intent:** rag-worker → rag-api: failure payload contract mismatch — failures persist without message or stage
- **Run:** 79e8a2e6-4caa-40de-8f8d-9d7160fc5b1e (iteration 1, step: design)
- **Authoritative source:** define-work WorkItem `wi-define-108-a8`, artifact `definition:obj-108`, sha256 `71f1c39c97ecea575b1195b63de510fa403dad4fecaa1df0c774d04fae89cac5`. This document elaborates that Definition; where wording differs, the Definition is binding.

---

## 1. Problem statement

The rag-worker's failure publisher and rag-api's failure consumer were written against different contracts, and no test covers the seam.

- The worker's exception handler in `process_document` publishes a failed status whose details carry a single key: `{"error": str(e)}` (Definition fact F3).
- rag-api's failed branch in `run_transactional_update` reads three keys from the same details mapping — `error_message`, `stage`, `retryable` — and persists them as `error`, `error_stage`, and `retryable` on the main resource document, plus `message`/`stage` (with `error_code` defaulting to `"UNKNOWN"`) into the processing/summary error subdocument (F4).

Because of the key mismatch, every worker-originated failure currently persists:

| Persisted field | Value today | Why |
|---|---|---|
| `error` | fallback string `"Processing failed"` | `error_message` key absent → fallback |
| `error_stage` | `None` | `stage` key absent → fallback |
| `retryable` | `True` | `retryable` key absent → silent `details.get("retryable", True)` default |

The processing/summary error subdocument inherits the same fallbacks, with `error_code` always `"UNKNOWN"`. Users and support cannot disambiguate failures (F1), and the persisted `retryable` flag is fabricated rather than derived.

The `error`/`error_stage`/`retryable` schema is already established across three other write paths — the worker's stale-lease sweep (`_fail_if_still_stale`), rag-api's enqueue-failure paths (`/process`, `POST /resources`) — and is exposed by `ResourceResponse` and the `Resource` model (F6). The worker's status publisher is the only writer that does not speak it.

## 2. Goal

Align the rag-worker's failure status payload with rag-api's failed-branch contract so that a failed RAG processing job persists the worker's **actual error message**, the **failing pipeline stage**, and a **deliberately derived retryable flag** — locked in by a contract test on the worker→rag-api failure path.

## 3. Scope

### 3.1 In scope

- rag-worker failure-payload construction in `process_document`'s exception handler (keys, stage tracking, retryable derivation).
- A contract test covering the worker failure → rag-api persistence path, including a key-drift guard.
- Verification (not modification) that rag-api's failed branch persists worker-provided values unchanged.

### 3.2 Out of scope (non-goals, from the Definition)

- Changing the stale-lease sweep's direct failure write — it already persists `error`/`error_stage`/`retryable` consistently with this contract.
- Changing retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals — only the *reporting* of retryability changes.
- Frontend or mobile changes — `ResourceResponse` already exposes `error` and `error_stage` to clients.
- Introducing structured error codes or a failure taxonomy — the processing/summary `error.code` remains `"UNKNOWN"` unless a code is actually sent.
- Any scope the companion D3 issue covers beyond this worker→rag-api failure payload alignment (its content is unavailable in this context; deferred — F12).
- Reconciling this analysis with the original D4 deviation note in `plans/upload-flow.md` (that file is not present in the current tree; the reference comes from the Objective text).

## 4. Functional requirements

### FR-1 — Failure payload carries the contract keys (MUST)

When document processing fails, the worker's failed status payload must include:

- `error_message` — the actual exception message (`str(e)`),
- `stage` — the pipeline stage executing at failure time,
- `retryable` — deliberately derived (see FR-4).

The payload must never rely on rag-api's fallback defaults for these keys; every worker-originated failure payload must carry `retryable` explicitly, and the API-side `details.get("retryable", True)` fallback must not be the operative mechanism for worker failures.

### FR-2 — Stage tracking through `process_document` (MUST)

The worker must track the currently executing pipeline stage through `process_document` so the failure handler reports the true failing stage.

- Stage names must reuse the existing progress-stage vocabulary: `starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`.
- `processing` is the safe value when the stage is genuinely unknown (e.g., failure before the first transition) — the same value the stale-lease sweep uses for `error_stage`, so the field never regresses to null.
- `completed` is excluded from the failure vocabulary: a job that reaches `completed` does not fail.

### FR-3 — rag-api persists worker-provided values unchanged (MUST)

rag-api's failed branch must persist the worker-provided values unchanged:

| Payload key | Main document field | Processing/summary subdocument |
|---|---|---|
| `error_message` | `error` | `message` |
| `stage` | `error_stage` | `stage` |
| `retryable` | `retryable` | — |
| *(absent)* | — | `error_code` defaults to `"UNKNOWN"` |

The processing/summary error subdocument must carry the same message and stage as the main document. rag-api's reads and persisted schema are **not** modified (see C-1, C-2).

### FR-4 — Explicit retryable derivation aligned with ACK/NACK behavior (MUST)

The retryable derivation must be explicit and aligned with the worker's ACK/NACK behavior, using the worker's existing `classify_error()` (F7):

| `classify_error(e)` outcome | Payload `retryable` | Rationale |
|---|---|---|
| Transient | `true` | Pub/Sub will redeliver (NACK path) |
| Permanent — including unclassified-unknown, per `classify_error`'s conservative default | `false` | Message is acked; manual reprocess via `POST /process` remains |

The persisted record must tell the truth about what the retry machinery actually does. The stale-lease sweep's separate `retryable=true` write stays correct and unchanged: a dead worker is a transient condition by nature (adopted assumption F8).

### FR-5 — Contract test on the worker failure → rag-api persistence path (MUST)

A contract test must:

- exercise the worker's failure-payload construction **and** rag-api's failed-branch persistence (via the Firestore emulator or fakes),
- assert the persisted `error`, `error_stage`, and `retryable` equal the worker's values,
- assert the processing/summary error subdocument carries the same message and stage,
- **fail if either side's payload keys drift** (worker emission keys or rag-api read keys),
- pin the stage-tracking mechanism on representative stages (an early-stage failure and a late-stage failure), enough to catch the tracker being removed or bypassed without ossifying every pipeline step.

### FR-6 — Retain the legacy `error` key (SHOULD, prefer-constraint)

The worker's failure payload retains the legacy `error` key alongside `error_message`, with the same value, for continuity with any existing consumers of the status topic and log tooling (F11 hedge). Dropping it later is trivial cleanup pending a consumer audit.

### FR-7 — No error-code taxonomy (SHOULD NOT)

No structured error-code taxonomy is introduced in this fix; the processing/summary `error.code` remains `"UNKNOWN"` unless a code is actually sent.

## 5. Constraints (from the Definition; binding)

| ID | Type | Constraint |
|---|---|---|
| C-1 | must | The worker is aligned to rag-api's existing contract — publishing `error_message`/`stage`/`retryable` — rather than changing rag-api's reads or persisted schema. |
| C-2 | must_not | No Firestore migration, field rename, or backfill of existing documents; the persisted fields (`error`, `error_stage`, `retryable`) keep their names and semantics. |
| C-3 | must | Every worker-originated failure payload carries `retryable` explicitly (deliberately derived); the API-side fallback must not be operative for worker failures. |
| C-4 | prefer | Retain the legacy `error` key in the worker's failure payload alongside `error_message`. |
| C-5 | prefer_not | Do not introduce a structured error-code taxonomy. |

## 6. Non-functional requirements

- **NFR-1 — No migration.** No schema migration, field rename, or backfill; existing documents remain valid as-is (C-2).
- **NFR-2 — Deterministic, hermetic tests.** Tests must be deterministic (house rule from `docs/TESTING-STRATEGY.md`) and run hermetically — fakes or the Firestore emulator, never live GCP. Both services already support hermetic modes (F10; verified stub `conftest.py` files in both services' test trees).
- **NFR-3 — Retry mechanics untouched.** ACK/NACK policy, leases, heartbeats, and backoff are unchanged; only failure *reporting* changes.
- **NFR-4 — Performance-neutral.** The failure payload grows by two small string/bool fields; negligible.
- **NFR-5 — Build-time drift guard.** A key change on either side of the contract must fail the test suite, not silently re-create the bug.
- **NFR-6 — House test conventions.** Files `test_<module>.py`; functions `test_<thing>_<condition>_<expected>`; the method under test is never mocked (house lesson encoded in `rag-api-service/tests/unit/test_service_contracts.py`).

## 7. Acceptance criteria (from the Definition)

| ID | Criterion | Verified by |
|---|---|---|
| AC-1 | A failed job's status message published by the worker contains `error_message` (actual exception message), `stage` (failing pipeline stage), and `retryable` (deliberately derived) — none relying on rag-api's fallback defaults. | Worker-side payload tests + contract-test payload assertions + drift guard (FR-1, FR-2, FR-4) |
| AC-2 | After a failed job, the persisted resource document has `error` = the worker's actual error message (not `"Processing failed"`), `error_stage` = the failing stage (not `None`), and `retryable` = the worker's derived value. | Contract-test persistence assertions (FR-3, FR-5) |
| AC-3 | The processing/summary error subdocument for the failed job carries the same message and stage as the main document. | Contract-test subdocument assertions (FR-3, FR-5) |
| AC-4 | A contract test covering the worker failure → rag-api persistence path exists and passes: it exercises the worker's failure-payload construction through rag-api's failed-branch persistence and asserts the persisted `error`, `error_stage`, and `retryable` equal the worker's values, failing if either side's payload keys drift. | The contract test itself, including the drift guard (FR-5, NFR-5) |

## 8. Assumptions and adopted defaults

- **A-1 (adopted, from F8):** `retryable` derives from `classify_error(e)` — transient → `true`, permanent (including unclassified-unknown) → `false`. This is the adopted default; widening `classify_error` itself is out of scope.
- **A-2 (from F11):** No consumer other than rag-api's status subscriber is known to parse the worker's failure payload keys; the legacy `error` key is retained as a hedge.
- **A-3 (from F10):** Contract-test infrastructure exists (`apps/ai-server/tests/integration/test_api_contracts.py`, fixture- and AST-based static contract tests) and both services support hermetic Firestore-emulator mode, so the contract test is implementable with existing patterns.

## 9. Deferred / open items

- **D-1:** Companion D3 issue referenced by the Objective — content unavailable in this context; anything it covers beyond this payload alignment is deferred (F12).
- **D-2:** Reconciliation with deviation D4 in `plans/upload-flow.md` — file not present in the current tree; deferred.
- **D-3:** Consumer audit of the status topic — if it confirms the worker is the only publisher and rag-api the only consumer, dropping the legacy `error` key is trivial follow-up cleanup (FR-6).
- **D-4:** CI wiring for the Python test suites (see architecture §8, risk R-5) — recommended follow-up outside this cycle's bounded scope.

## 10. Traceability

| Definition requirement | This doc | Acceptance |
|---|---|---|
| Payload keys requirement | FR-1 | AC-1 |
| Stage tracking requirement | FR-2 | AC-1 |
| rag-api persistence requirement | FR-3 | AC-2, AC-3 |
| retryable derivation requirement | FR-4 | AC-1, AC-2 |
| Contract test requirement | FR-5 | AC-4 |
| Retain legacy `error` key (prefer) | FR-6 | AC-1 (key-set assertion includes it) |
| No error-code taxonomy (prefer_not) | FR-7 | AC-3 (`error_code` stays `"UNKNOWN"`) |