---
tags:
  - Documentation/Internal
  - Development
---

# Dev Framework

The `dev/` framework is the primary development and testing tool for this monorepo. It runs checks across all three apps, captures the results into a structured artifact folder, and compiles a `context-pack.md` — a single file that gives an AI session (or a developer) immediate, correlated visibility into what is failing and why.

---

## Quick Start

```bash
# Run everything and get a context pack
./dev/run

# Run one app only
./dev/run web
./dev/run mobile
./dev/run ai-server        # requires Docker Compose running
./dev/run integration      # requires dev/collectors/integration/.env

# Set an active task for this work session
./dev/run --task my-task-id

# Recompile context-pack.md without re-running tests
./dev/run --pack-only

# Read the AI context
cat .devloop/context-pack.md
```

---

## How It Works

Every run goes through three stages:

1. **Collectors** — thin scripts, one per app, each outputting a standard JSON schema to stdout
2. **Artifact folder** — run output is assembled into `.devloop/runs/{timestamp}/`
3. **context-pack** — a Python compiler reads all collector output and writes `context-pack.md`

The framework is **interface-agnostic**: artifacts are plain JSON and Markdown files. Any tool that can read files can consume them — Claude, Obsidian, a CI reporter, or a shell script. Nothing is coupled to any specific consumer.

---

## Directory Structure

```
dev/
  run                              # bash entrypoint
  context-pack                     # Python: assembles context-pack.md
  redact                           # Python: strips credentials from log output
  collectors/
    web.sh                         # TypeScript check (tsc --noEmit)
    mobile.sh                      # flutter test --machine
    ai-server.sh                   # Docker health checks + log capture
    integration/
      runner.py                    # HTTP scenario runner
      requirements.txt
      scenarios/
        01-health.yaml             # Gateway health check
        02-auth.yaml               # Auth service reachable via gateway
        03-chat.yaml               # Basic chat flow (requires Firebase creds)
  config/
    redact.patterns                # Regex rules for credential scrubbing
    log.filters                    # Regex rules for log noise removal

.devloop/
  active-task                      # One-line file: current task ID (tracked in git)
  context-pack.md                  # Latest context pack (gitignored, regenerated each run)
  runs/                            # Run artifacts (gitignored)
    {timestamp}/
      manifest.json
      web.json
      mobile.json
      ai-server.json
      integration.json
      context-pack.md
```

---

## `dev/run` — Command Reference

```
Usage: dev/run [OPTIONS] [APPS...]

APPS (default: all four):
  web           TypeScript type check
  mobile        Flutter unit tests
  ai-server     Docker service health + log capture
  integration   HTTP scenario tests against the running gateway

OPTIONS:
  --task TASK_ID    Write TASK_ID to .devloop/active-task, then run
  --no-pack         Run collectors but skip context-pack compilation
  --pack-only       Recompile context-pack.md from the latest run, no re-run
  --scenario NAME   Filter integration scenarios by name (repeatable)
  -h, --help        Show help
```

**Examples:**

```bash
# Full run, setting the active task
./dev/run --task chat-fix-001

# Only the backend (health checks + integration tests)
./dev/run ai-server integration

# Re-generate context-pack.md after a code change (no re-run needed)
./dev/run --pack-only

# Run one specific integration scenario
./dev/run --scenario health_gateway integration
```

---

## The Context Pack

`context-pack.md` is the product the framework exists to produce. It contains:

- **Active task** — from `.devloop/active-task`
- **Overall pass/fail** and per-app summary table
- **Failing tests only** — name, file, line, assertion message
- **Error and warn logs** — top 20 per service, credential-redacted
- **Trace links** — Grafana/Tempo deep links correlated by `x-request-id` (when integration tests run against a live stack with OTel enabled)
- **Artifact paths** — direct links to the raw JSON files for deeper inspection

An AI session can orient to the full picture with a single read of this file.

---

## Collectors

Each collector is a standalone script that writes one JSON object to stdout:

```json
{
  "app": "web",
  "status": "PASS",
  "duration_ms": 4200,
  "tests": [
    { "name": "...", "status": "pass|fail|skip", "file": "...", "line": 0, "message": "..." }
  ],
  "logs": [
    { "ts": "ISO8601Z", "level": "info|warn|error", "service": "...", "message": "...", "request_id": "..." }
  ],
  "metadata": {}
}
```

This contract is the interface. Collectors never need to know about each other, and the framework never needs to know what runs inside a collector.

### `web.sh`
Runs `npm run check` (TypeScript compiler, `noEmit: true`) in `apps/web/`. Parses TSC error lines into test entries. Attempts ESLint if available, skips gracefully if not.

### `mobile.sh`
Runs `flutter test --machine` in `apps/mobile/`. Parses the NDJSON event stream (`testStart`, `testDone`, `done`) into test entries. Handles the "no tests found" case as a passing result.

### `ai-server.sh`
Checks Docker Compose health for four core services: `api-gateway` (:3001), `auth-service` (:3002), `rag-api-service` (:8000), `agent-graph-service` (:8003). Captures the last 200 log lines from each, filters noise, redacts credentials. If Docker is not running, produces an `ERROR` result with a descriptive message.

### `integration/runner.py`
Reads YAML scenario files and executes them as HTTP requests against the running gateway. Supports three auth modes:
- `none` — no headers
- `internal_token` — `x-internal-token` header (service-to-service)
- `firebase_token` — generates a Firebase ID token via the Admin SDK (see configuration below)

Captures `x-request-id` and `traceparent` response headers. Builds Grafana trace links when `traceparent` is present.

---

## Integration Runner Configuration

Create `dev/collectors/integration/.env` (gitignored):

```env
API_GATEWAY_URL=http://localhost:3001
FIREBASE_WEB_API_KEY=your_firebase_web_api_key
GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
SHARED_INTERNAL_TOKEN=your_shared_internal_token
```

| Variable | Required for | Notes |
|---|---|---|
| `API_GATEWAY_URL` | all scenarios | defaults to `http://localhost:3001` |
| `FIREBASE_WEB_API_KEY` | `firebase_token` auth | Firebase console → Project Settings → Web API Key |
| `GOOGLE_APPLICATION_CREDENTIALS` | `firebase_token` auth | path to service account JSON |
| `SHARED_INTERNAL_TOKEN` | `internal_token` auth | matches the gateway's `SHARED_INTERNAL_TOKEN` |

Scenarios `01-health` and `02-auth` run without any credentials. `03-chat` is automatically skipped (not failed) if Firebase credentials are absent.

Install Python dependencies once:

```bash
cd dev/collectors/integration
pip install -r requirements.txt
```

---

## Adding Scenarios

Add a YAML file to `dev/collectors/integration/scenarios/`. Files are run in alphabetical order.

```yaml
name: my_scenario              # unique name, used by --scenario filter
description: "What this tests"
endpoint: "POST /api/my-endpoint"
auth: none                     # none | internal_token | firebase_token
body:                          # optional request body
  key: value
assertions:
  - status: 200                # HTTP status code
  - body.field.nested: value   # dot-notation JSON path assertion
capture:
  - header: x-request-id      # response headers to capture and correlate
  - header: traceparent
```

---

## Credential Redaction

All log output is piped through `dev/redact` before being written to artifacts. The rules live in `dev/config/redact.patterns` (tab-separated `REGEX → REPLACEMENT`).

Current rules strip:
- Firebase JWTs (`eyJ...`) → `[JWT_REDACTED]`
- Bearer tokens → `Bearer [REDACTED]`
- OpenAI-style API keys (`sk-...`) → `[API_KEY_REDACTED]`
- Password/secret/private_key values → `[REDACTED]`

To add a rule, append a line to `dev/config/redact.patterns`.

---

## Active Task

`.devloop/active-task` is a one-line file tracked in git. It records the current task ID, which is embedded in every `context-pack.md` header.

```bash
# Set via flag (recommended)
./dev/run --task T-042

# Or write directly
echo "T-042" > .devloop/active-task
```

This is the only coupling between the framework and your task/docs system. If a doc exists at a known path for the task, the AI can follow it independently — the framework only stores the ID.

---

## Noise Filters

`dev/config/log.filters` lists regexes for log lines to drop before writing to artifacts. The defaults suppress Flutter rendering noise (Skia, Observatory, DevTools) and verbose Docker output. Add lines to tune for your stack.
