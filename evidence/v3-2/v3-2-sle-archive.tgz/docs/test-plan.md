# Test Plan — worker failure payload → rag-api persistence contract

Run: 58232065-c773-4179-bfbd-de9348344b7e · Companion to `docs/plan.md`

## 1. Strategy

Two new suites plus existing regression coverage. The contract test **imports both sides rather than restating the contract in a fixture**: it builds the failure payload through the worker's real code path and feeds it through rag-api's real `run_transactional_update`, asserting the persisted `error`, `error_stage`, and `retryable`. Fakes (not the Firestore emulator) are the primary mechanism — hermetic, fast, no emulator binary in CI, and the established house pattern (`rag-worker-service/tests/unit/test_processing_lease.py` fakes). Both services' `FIRESTORE_EMULATOR_HOST` branches remain available for a manual hermetic run if ever needed; they are not required for this plan.

## 2. Infrastructure

### 2.1 Fakes (defined locally in Suite A's file, modeled on `test_processing_lease.py`)
- `FakeTx` — records `update(ref, data)` and `set(ref, data, merge=...)` writes as tuples; `get()` semantics via the ref.
- `FakeSnap` — `exists=True`, `to_dict()` returns seeded doc state.
- `FakeRef` — `.id` attribute (read by `run_transactional_update`'s logging), `get(transaction=None)`, `collection(name)` → `FakeCollection.document(name)` chain so `doc_ref.collection("processing").document("summary")` resolves to a distinct recorded ref.
- `FakeDb` — `transaction()` returns the `FakeTx`; `document(path)` returns the seeded `FakeRef`.
- Stub logger: `types.SimpleNamespace(info=..., warning=...)` (structlog is MagicMock'd by the suite conftest; a stub keeps assertions independent of it).

### 2.2 Monkeypatches (per test, the proven `_tx_identity` pattern)
- `rag_api_main.firestore.transactional` → identity decorator (otherwise the MagicMock'd decorator no-ops the inner function and nothing is written).
- `rag_api_main.firestore.SERVER_TIMESTAMP` → sentinel string `"TS"`.
- Seeded doc state: `{"status": "processing", "filename": "x.pdf", ...}` so the `processing → failed` transition is allowed by `ALLOWED_TRANSITIONS` (a wrong seed hits the `new_status == current_status` early return or the invalid-transition no-op — both would silently produce zero writes and fail the assertions, which is itself a useful guard).

### 2.3 Importing the worker side from the integration suite
The integration conftest puts rag-api on `sys.path` as module `main`; the worker's module is also named `main` and pulls heavier deps. Suite A therefore:
- loads `rag-worker-service/main.py` via `importlib.util.spec_from_file_location("rag_worker_main", ...)` (no `sys.modules["main"]` collision);
- stubs missing heavy third-party deps locally at the top of the test file (openai, langfuse, langchain, spacy, tiktoken, tenacity — mirroring `rag-worker-service/tests/conftest.py`'s stub map, guarded by "only if not already in `sys.modules`");
- uses only the worker's pure surface: `classify_error` and `build_failure_details`.
Shared `tests/integration/conftest.py` is **not** modified, so existing contract tests are unaffected. If worker `main.py` exhibits import-time side effects beyond the stub map, extend the stubs additively (verify at implementation time — exact import-time behavior of worker `main.py` was not fully re-verified in this pass).

## 3. Suite A — cross-service contract test (new)
File: `apps/ai-server/tests/integration/test_worker_failure_contract.py`

Shared driver: `persist(worker_details)` → seeds a FakeDb with `status: "processing"`, calls the real `rag_api_main.run_transactional_update(db, ref, "failed", worker_details, stub_logger, "u1")`, returns `(tx, resource_ref, summary_ref)` where writes are separated by recorded ref.

| ID | Case | Given / When / Then |
|---|---|---|
| TC-A1 | Transient failure end-to-end (the acceptance path) | Worker: `build_failure_details(TransientError("Embedding timeout after 3 attempts"), "embeddings_complete")` → feed dict as `details` → persist. Then: main doc `error == "Embedding timeout"`, `error_stage == "embeddings_complete"`, `retryable is True`, `status == "failed"`; summary doc `error.message == "Embedding timeout"`, `error.stage == "embeddings_complete"`, `error.code == "UNKNOWN"`, top-level `stage == "embeddings_complete"`. |
| TC-A2 | Permanent failure | `build_failure_details(PermanentError("Invalid PDF structure"), "text_retrieved")` → persisted `retryable is False`, `error`/`error_stage` equal worker values. |
| TC-A3 | Unclassified-unknown exception (pins the deliberate behavior change) | `build_failure_details(RuntimeError("boom"), "chunking_complete")` → `classify_error` → `False` → persisted `retryable is False`; asserts the silent `True` default is no longer operative. |
| TC-A4 | Empty-message guard | `build_failure_details(Exception())` → `error_message == "Exception"` (class-name fallback, never an empty string). |
| TC-A5 | Worker payload key-set drift guard | `set(build_failure_details(e, "s").keys()) == {"error_message", "stage", "retryable", "error"}` — exact equality; any key added/removed/renamed on the worker side fails the build. |
| TC-A6 | API read-key drift guard (implicit in TC-A1/A2, made explicit) | Assert persisted main-doc write contains `error`, `error_stage`, `retryable` and that `error != "Processing failed"` — if rag-api renames any `details.get(...)` read, the fallback string or `None` appears and the equality assertions fail. |

Note: Pub/Sub envelope parsing (`_process_status_message`) is unchanged code and out of the broken seam; the contract targets payload keys ↔ persisted fields, per the Definition.

## 4. Suite B — worker stage-tracker tests (new)
File: `apps/ai-server/rag-worker-service/tests/integration/` (`test_failure_stage_tracking.py`; the worker's pytest.ini already runs `tests/` with `asyncio_mode = auto`).

Mechanism: drive the real `process_document` with monkeypatched pipeline collaborators so a stubbed step raises; capture the `details` dict passed to `_publish_status_update` via monkeypatch; assert payload contents. The exact collaborator names for "an early text-extraction step" and "the embeddings step" are taken from `main.py` at implementation time (function internals were not re-verified in this pass; the tracker convention, stage vocabulary, and handler location are pinned by the Definition F3/F7/F9).

| ID | Case | Then |
|---|---|---|
| TC-B1 | Early-stage failure (first named pipeline step raises `TransientError`) | captured `details["stage"]` is that step's progress token (e.g. `text_retrieved`), `retryable is True`, `error_message == str(exc)`, legacy `error` key present and equal |
| TC-B2 | Late-stage failure (embeddings step raises `PermanentError`) | `details["stage"] == "embeddings_complete"`, `retryable is False` |
| TC-B3 | Unknown exception type mid-pipeline | `retryable is False` (classify_error conservative default) |
| TC-B4 | Failure before any named step | `details["stage"] == "starting"` (tracker init); helper-level falsy-stage fallback to `"processing"` is covered in Suite A (D1/D2) |
| TC-B5 | Payload built by the helper | captured details key set matches TC-A5's set — proves the handler routes through `build_failure_details`, not an inline dict |

## 5. Existing coverage leveraged (unchanged, listed as guards)
- `rag-worker-service/tests/unit/test_processing_lease.py::test_genuinely_stale_lease_is_failed` — sweep still persists `retryable is True` (D6 non-regression).
- `rag-api-service/tests/unit/test_models_resource.py` — `Resource` model `error`/`error_stage`/`retryable` defaults.
- `tests/integration/test_api_contracts.py` — `ResourceResponse` still exposes `error`/`error_stage` to clients (no API-side change to break it).

## 6. Drift-guard specification (what fails, and why)
- Worker adds/renames/removes a payload key → TC-A5 exact key-set equality fails.
- Worker stops deriving `retryable` (hardcodes or omits) → TC-A1/A2/A3 value assertions fail.
- Worker tracker removed/bypassed → TC-B1/B2 stage assertions fail.
- rag-api renames a `details.get(...)` read key → persisted value becomes the fallback (`"Processing failed"` / `None` / `True`) → TC-A1/A2/A6 equality assertions fail.
- rag-api changes summary error subdocument shape → TC-A1 summary assertions fail.

## 7. Run commands
```
cd apps/ai-server/rag-worker-service && pytest            # Suites B + existing worker units
cd apps/ai-server/rag-api-service && pytest               # existing API units (must stay green)
cd apps/ai-server && pytest tests/integration -q          # Suite A + existing contract tests
```
All three green = step done. No emulator, credentials, or network required.

## 8. Acceptance ↔ test traceability

| Acceptance criterion | Tests |
|---|---|
| Payload carries error_message/stage/retryable, no fallback reliance | TC-A1, TC-A3, TC-A5, TC-B1–B5 |
| Persisted error/error_stage/retryable equal worker values | TC-A1, TC-A2, TC-A3, TC-A6 |
| Summary subdocument carries same message and stage | TC-A1 |
| Contract test exists, passes, fails on either side's key drift | TC-A5, TC-A6 (+ TC-B5) |

## 9. Limitations & notes
- Fakes exercise `run_transactional_update`'s logic, not Firestore's transaction semantics (snapshot isolation is approximated by the single-tx fake, as in the existing worker fakes). Sufficient for the payload-key seam this Definition targets.
- Suite B pins representative stages only (early + late), per the Definition's explicit choice not to ossify every pipeline step.
- Worker `main.py` import-time behavior under the integration stub set is to be confirmed during implementation (§2.3); any gap is closed with additive local stubs, never shared-conftest edits.