Plan is ready — verified against `rag-worker-service/main.py` (`process_document` handler, `classify_error`, sweep writes), `rag-api-service/main.py` (`run_transactional_update` failed branch), the shared contract-test infrastructure, and both services' test stubs.

<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path=".sle/work/wi-define-108-a8/plan.md">>>
# Implementation Plan — rag-worker → rag-api failure payload contract alignment

WorkItem: `wi-define-108-a8` (authoritative Definition pinned at sha256 `71f1c39c…`)
Run: `2cd54a61-1e1e-4969-af1b-f5639cf54b28` · Iteration 1 · Step: plan

---

## 1. Problem (verified against the current tree)

- **Producer** — `apps/ai-server/rag-worker-service/main.py`, `process_document` exception handler:
  ```python
  await self._publish_status_update(user_id, course_id, resource_id, "failed", {"error": str(e)}, job_id)
  ```
- **Consumer** — `apps/ai-server/rag-api-service/main.py`, `run_transactional_update`, failed branch:
  ```python
  main_update["error"]       = details.get("error_message", "Processing failed")
  main_update["error_stage"] = details.get("stage")
  main_update["retryable"]   = details.get("retryable", True)
  # summary subdocument:
  "error": {"code": details.get("error_code", "UNKNOWN"),
            "message": details.get("error_message", "Processing failed"),
            "stage": details.get("stage")}
  ```
- Key mismatch ⇒ every worker-originated failure persists the fallback string `"Processing failed"`, `error_stage: None`, and a fabricated `retryable: true`. The `processing/summary` error subdocument inherits the same fallbacks with `error_code` always `"UNKNOWN"`.
- The persisted failure schema `error` / `error_stage` / `retryable` is already used consistently by three other write paths (worker stale-lease sweep `_fail_if_still_stale`, rag-api `/process` and `POST /resources` enqueue-failure paths) and exposed by `Resource` (`models/resource.py`, `retryable` defaults `True`) and `ResourceResponse`.
- The worker already classifies every exception via `classify_error()` (transient → True; permanent and unclassified-unknown → False, conservative) and uses it for ACK/NACK in `run_worker` — the classification exists but is not reported in the payload.
- `process_document` is one large try block with no stage tracking; failure time has no notion of the executing step. Progress publishes use the stage vocabulary: `starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`, `completed`.

## 2. Design decisions

### 2.1 The worker aligns to the API; rag-api does not change
Per constraint (must): the worker publishes `error_message` / `stage` / `retryable`. **rag-api-service receives zero code changes.** No Firestore migration, rename, or backfill (must-not). The contract test proves the binding by executing rag-api's real `run_transactional_update`.

### 2.2 Named payload builder: `build_failure_details(error, stage)`
A pure module-level function in the worker is the single point where the failure payload is constructed. This gives the contract test something real to import on the worker side (the Definition requires the test to "exercise the worker's failure-payload construction"), keeps the exception handler thin, and gives the drift guard a stable seam to pin via AST.

```python
def build_failure_details(error: Exception, stage: str) -> Dict[str, Any]:
    """Build the failed-status details payload (worker → rag-api contract).

    Consumed by rag-api run_transactional_update's failed branch:
      error_message -> main doc `error` + processing/summary error.message
      stage         -> main doc `error_stage` + summary stage / error.stage
      retryable     -> main doc `retryable` (deliberately derived, never defaulted)
      error         -> legacy duplicate of error_message, retained for unknown
                       consumers of the status topic; rag-api must NOT read it.
    Stage uses the progress-update vocabulary; "processing" is the safe value
    when the failing stage is genuinely unknown.
    """
    message = str(error)
    return {
        "error_message": message,
        "stage": stage or "processing",
        "retryable": classify_error(error),
        "error": message,   # legacy key retained as a compatibility hedge (F11)
    }
```

### 2.3 Stage tracking: update-before-await convention
`process_document` gains a local `current_stage: str = "processing"` initialized **before** the try block (safe value when genuinely unknown), and the tracker is assigned immediately before each pipeline `await`:

| Pipeline step (in order) | tracker value |
|---|---|
| entry → `_validate_processing_request` (claim/validate) | `starting` |
| `_get_extracted_text` (incl. inline PDF extraction) | `text_retrieved` |
| `content_tagger.generate_tags` | `tagging_complete` |
| `generate_document_summary` + main-doc `ragDescription` update | `summary_generated` |
| `_create_enhanced_chunks` | `chunking_complete` |
| `_generate_embeddings_with_openrouter` | `embeddings_complete` |
| `delete_old_vectors_via_service`, `store_chunks_via_service`, `_save_processing_metadata_to_subcollection`, `_update_user_usage`, `_generate_resource_map` | `embeddings_complete` (retained — the vocabulary has no post-embedding storage milestone; "failed after embeddings, during storage" reads correctly) |

Semantics: the tracker holds the progress-milestone name of the step currently executing. A failure in tagging reports `tagging_complete`, a failure in retrieval reports `text_retrieved` — the stage reads naturally next to the progress timeline clients already see. The only code path that can report the literal safe value `"processing"` is a failure before the first assignment (defensive; also matches the sweep's `error_stage: "processing"` so the field never regresses to null).

### 2.4 retryable: derive from `classify_error`, never default
- transient-classified (`TransientError`, httpx connect/timeout types, `ConnectionError`, `TimeoutError`, HTTP 429/5xx) → `retryable: true` — Pub/Sub will redeliver.
- permanent-classified and **unclassified-unknown** (`PermanentError`, other 4xx, everything else per `classify_error`'s conservative default) → `retryable: false` — the message is acked; manual reprocess via `POST /process` remains.

Accepted behavior change: unclassified-unknown failures flip from persisted `true` (silent API default) to `false`. This is the conservatism `classify_error` was written for and aligns the persisted record with actual ACK/NACK behavior. The stale-lease sweep's separate `retryable: true` write is untouched and stays correct (a dead worker is transient by nature). No error-code taxonomy is introduced; summary `error.code` remains `"UNKNOWN"`.

### 2.5 Legacy `error` key retained
The worker payload carries both `error_message` and `error` (same string). rag-api must not read `error` — this invariant is pinned by the drift guard (§4.3), so a future "cleanup" that makes rag-api depend on the legacy key fails CI instead of silently re-coupling the seam.

## 3. Changes by file

### 3.1 `apps/ai-server/rag-worker-service/main.py` — the only production change

1. Add `build_failure_details(error, stage)` at module level, adjacent to `classify_error` (sketch in §2.2).
2. In `EnhancedDocumentProcessor.process_document`:
   - Declare `current_stage: str = "processing"` immediately before the `try:`.
   - Insert the tracker assignments from the §2.3 table immediately before each corresponding `await` (the update-before-await convention; add a one-line comment stating the convention so future steps keep it).
   - Replace the exception handler:
     ```python
     except Exception as e:
         metrics.error_message, metrics.end_time = str(e), time.time()
         failure_details = build_failure_details(e, current_stage)
         self.logger.error(
             "document_processing_failed",
             user_id=user_id, course_id=course_id, resource_id=resource_id,
             stage=failure_details["stage"], retryable=failure_details["retryable"],
             error=str(e),
         )
         await self._publish_status_update(
             user_id, course_id, resource_id, "failed", failure_details, job_id
         )
         if trace: trace.update(output={"success": False, "error": str(e)})
         return metrics
     ```
3. **No changes** to `_publish_status_update` (jobId injection and sequence numbering keep working; note `_publish_status_update` mutates the details dict to add `jobId` when a job_id is supplied — harmless, rag-api ignores it on the failed branch), `classify_error`, the sweep, or retry mechanics.

### 3.2 `apps/ai-server/rag-worker-service/tests/unit/test_failure_payload.py` — new unit tests

Pure-logic coverage, fast, using the existing worker conftest stubs:

- `build_failure_details` derivation matrix: `TransientError` → True; `PermanentError` → False; `httpx.ConnectError` → True; `httpx.HTTPStatusError` with 500 → True, with 404 → False; `ValueError`/`RuntimeError` (unclassified) → False; message passthrough (`error_message == error == str(e)`); stage passthrough; `stage=""` → `"processing"`.
- Key-set pin: `set(result.keys()) == {"error_message", "stage", "retryable", "error"}` — exact; adding or removing a key must fail here (this is the drift guard doing its job).

### 3.3 `apps/ai-server/tests/integration/test_worker_failure_contract.py` — new contract test (the Definition's acceptance anchor)

A new sibling of `test_api_contracts.py`, reusing the shared `conftest.py` (which stubs GCP modules and puts rag-api-service on `sys.path`, making `import main as rag_api_main` resolve to rag-api).

**Worker import (module load):** load the worker's `main.py` under an aliased module name to avoid the `main` name collision with rag-api:
```python
import importlib.util
spec = importlib.util.spec_from_file_location(
    "rag_worker_main",
    os.path.join(REPO_ROOT, "apps/ai-server/rag-worker-service/main.py"),
)
rag_worker_main = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rag_worker_main)
```
Before `exec_module`, install stubs for worker-only top-level imports — **only if not already in `sys.modules`** (conditional, mirroring `rag-worker-service/tests/conftest.py`): `langchain`, `langchain.text_splitter` (`RecursiveCharacterTextSplitter`), `langchain.schema` (`Document`), `openai` (`AsyncOpenAI`, `APIError`, `APIConnectionError`), `langfuse` (`Langfuse`), `spacy`, `sklearn.feature_extraction.text` (`TfidfVectorizer`, plus parent stubs), `tiktoken` (`get_encoding`), `tenacity` (`retry`, `stop_after_attempt`, `wait_exponential`). Also required because the shared conftest does not stub them and worker main imports them at top level: `google.cloud.firestore_v1.base_query` (with `FieldFilter` — `from X.Y import Z` cannot fall back to attribute access), `google.auth`, `google.auth.credentials` (`AnonymousCredentials`). Worker main's module-level `os.environ["GCP_PROJECT"]` / `GOOGLE_APPLICATION_CREDENTIALS` reads are already satisfied by the shared conftest; mocked `pubsub_v1`/`service_account` make the module-level subscriber construction inert.

**Worker-side scenario fixture:** build a processor without touching `_init_services` / `ProcessingConfig` (heavy, env-coupled, irrelevant to the contract):
```python
processor = object.__new__(rag_worker_main.EnhancedDocumentProcessor)
processor.logger = rag_worker_main.logger
processor.langfuse = None
processor.db = MagicMock()          # only touched by the (replaced) publisher
processor.embedding_cost_per_token = 0.0
```
Replace pipeline steps with `unittest.mock.AsyncMock`/plain async functions **assigned as instance attributes** — this also bypasses real `tenacity` decorators if present in the environment (a failing `store_chunks_via_service` would otherwise retry 3× with seconds-long waits). Replace `_publish_status_update` with a capture stub recording `(status, details, job_id)`; pass `job_id=None` in scenarios so the captured details dict is exactly the builder output (no injected `jobId` key).

**API-side fixture:** mirror the fake-transaction pattern proven in `rag-worker-service/tests/unit/test_processing_lease.py` (`FakeTx`/`FakeSnap`/`FakeRef`/`FakeCollection`/`FakeDb`, `_tx_identity`). Seed a doc at `users/u1/resources/r1` with `status: "processing"` (processing → failed is an allowed transition in `ALLOWED_TRANSITIONS`). Patch per-test via `monkeypatch`:
```python
monkeypatch.setattr(rag_api_main.firestore, "transactional", _tx_identity, raising=False)
monkeypatch.setattr(rag_api_main.firestore, "SERVER_TIMESTAMP", "TS", raising=False)
```
Without the `transactional` patch, the conftest's MagicMock would swallow `update_logic` entirely. `run_transactional_update(fake_db, doc_ref, "failed", details, rag_api_main.logger, "u1")` then executes the real failed-branch code against the fakes.

### 3.4 `apps/ai-server/rag-api-service/` — **no changes**
Constraint (must): the worker aligns to rag-api. The test suite in §4 exercises rag-api's real failed branch; its assertions are the proof that requirement 3 ("persist the worker-provided values unchanged") already holds once the keys arrive.

## 4. Test plan (scenarios)

### 4.1 Worker-side scenarios (run `process_document` on the §3.3 fixture, capture the failed publish)
1. **Early-stage failure** — `_validate_processing_request` raises `PermissionError("User u1 does not own document r1")` → payload: `stage == "starting"`, `retryable is False` (unclassified → conservative permanent), `error_message == "User u1 does not own document r1"`, legacy `error` equal to `error_message`.
2. **Mid-stage failure** — `_get_extracted_text` raises `ValueError("Failed to extract PDF text and no existing text found: …")` → `stage == "text_retrieved"`, `retryable is False`.
3. **Late-stage failure** — fake pipeline runs through embeddings; `store_chunks_via_service` raises `RuntimeError("partial vector write: 2/5 chunks stored …")` → `stage == "embeddings_complete"`, `retryable is False`.
4. **Transient failure** — `_generate_embeddings_with_openrouter` raises `httpx.ConnectError("openrouter unreachable")` → `stage == "embeddings_complete"`, `retryable is True`.

### 4.2 Seam assertions (for each captured payload above, feed it through rag-api)
- Main document after `run_transactional_update`: `status == "failed"`, `error == details["error_message"]` (never `"Processing failed"`), `error_stage == details["stage"]` (never `None`), `retryable == details["retryable"]` (equal for **both** boolean values — see drift note below).
- `processing/summary` subdocument: `error.message == details["error_message"]`, `error.stage == details["stage"]`, `error.code == "UNKNOWN"`, `stage == details["stage"]`.

**Why the retryable=False cases are mandatory:** if rag-api's `details.get("retryable", True)` read were ever dropped, a True payload would still persist True (default masks the drift). Scenarios 1–3 persist False, so a lost read fails the assertion. Scenario 4 guards the worker's transient mapping end-to-end.

### 4.3 Drift guards
- **Worker key set (dynamic):** `set(build_failure_details(exc, "processing").keys()) == {"error_message", "stage", "retryable", "error"}` — any key added/removed on the worker fails CI (intentional ossification).
- **Worker seam (AST):** parse worker `main.py`; assert `build_failure_details` is called inside `process_document`'s except handler — catches someone hand-rolling a failure payload and bypassing the builder.
- **API reads (AST):** parse rag-api `main.py`; within `run_transactional_update` collect keys read via `details.get("…")` / `details["…"]`; assert `{"error_message", "stage", "retryable", "error_code"} ⊆ reads` and `"error" ∉ reads` — pins that rag-api reads the contract keys and never the legacy hedge key.

### 4.4 Regression coverage
- Full worker unit suite (e.g. `test_processing_lease.py`) still green — sweep behavior untouched.
- Full rag-api test suite + existing `tests/integration/test_api_contracts.py` still green — no API changes, no model drift.

## 5. Implementation order

1. **Worker payload + stage tracking** (`main.py`, §3.1) with unit tests (§3.2). Accept: unit tests pass; no other worker behavior changed.
2. **Contract test** (`tests/integration/test_worker_failure_contract.py`, §3.3/§4). Accept: all scenarios and drift guards pass; deliberately reverting either side's keys in a scratch run makes the suite fail (one-time negative check during development, not committed).
3. **Validation + review** (§6). Accept: commands green; acceptance criteria §7 all met.

Workflow note: single PR `fix/rag-worker-failure-payload-contract` → `main` (small-change path: no schema/migration, mobile/web-facing shapes unchanged — `ResourceResponse` is untouched, and the additive payload keys are internal to the status topic; legacy key retained). The change touches two services' *seam*, but only one service's production code plus shared contract tests; if a maintainer prefers the feature path, phases 1–3 map 1:1 onto a feature plan. Agents never merge; human review per AGENTS.md.

## 6. Validation commands

```bash
# worker unit tests (stubbed env, no services needed)
cd apps/ai-server/rag-worker-service && python -m pytest tests/unit -v

# contract test (shared integration dir; conftest provides mocks)
cd apps/ai-server && python -m pytest tests/integration/test_worker_failure_contract.py -v
cd apps/ai-server && python -m pytest tests/integration/test_api_contracts.py -v   # no regressions

# full gate (requires Docker Compose hermetic stack up, per AGENTS.md)
./dev/run ai-server
```
Optional manual hermetic check (if the stack with `FIRESTORE_EMULATOR_HOST` is running): enqueue a resource that fails early (missing extracted text and source URL), then verify the Firestore document shows `error` = the real exception message, `error_stage` = `"starting"`, `retryable == false`, and `processing/summary.error` carries the same message and stage.

## 7. Acceptance criteria traceability

| Definition acceptance criterion | Where satisfied |
|---|---|
| Failed job's published payload contains `error_message`/`stage`/`retryable`, none relying on rag-api fallbacks | `build_failure_details` + handler rewrite (§3.1); scenarios §4.1 assert payload fields directly |
| Persisted doc has real `error`, non-null `error_stage`, worker-derived `retryable` | Seam assertions §4.2 run rag-api's real failed branch and assert equality with the worker's values |
| `processing/summary` error subdocument carries the same message and stage | Seam assertions §4.2 (summary subdocument checks) |
| Contract test covers worker failure → rag-api persistence path, fails on key drift on either side | §4.1–4.3 in `test_worker_failure_contract.py`: both sides exercised through their real code paths; dynamic key-set pin + AST guards on both producer and consumer |

## 8. Risks and mitigations

- **Unknown consumers of the status topic** reading only the old `error` key → legacy key retained in the payload (constraint: prefer); drift guard forbids rag-api from adopting it, so the hedge stays removable.
- **Stage-tracker drift** as the pipeline evolves → update-before-await convention documented in code; representative early/late-stage scenarios (§4.1) pin the mechanism without ossifying every step.
- **retryable=false for unclassified errors** may reduce auto-retry affordances → accepted per Definition F8; widening `classify_error` is out of scope; `POST /process` manual reprocess unaffected.
- **Test-env import hazards** (heavy worker deps, `main` name collision, mocked `firestore.transactional` swallowing the API logic, real `tenacity` retries slowing failure scenarios) → conditional stubs mirroring `rag-worker-service/tests/conftest.py`; importlib alias; explicit `transactional`/`SERVER_TIMESTAMP` monkeypatch (pattern proven in `test_processing_lease.py`); instance-attribute fakes that bypass decorators.
- **Contract test ossifies the payload** → intentional (Definition); adding a key later means touching the test, which is the point.

## 9. Out of scope (per Definition nonGoals)

- Stale-lease sweep behavior (already writes `error`/`error_stage`/`retryable` consistently).
- Retry/backoff mechanics: ACK/NACK policy, leases, heartbeats — only the *reporting* of retryability changes.
- Frontend/mobile changes (`ResourceResponse` already exposes `error`/`error_stage`).
- Structured error codes / failure taxonomy (`error.code` stays `"UNKNOWN"` unless a code is actually sent).
- Anything the companion D3 issue covers beyond this payload alignment (content unavailable; deferred), and reconciling with the D4 deviation note in `plans/upload-flow.md` (file absent from the tree).
<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>