---
tags:
  - TaskManagement
---
# Retry logic & error handling
#ToDo
Full history sync strategy, failure scenarios (network error vs backend crash), idempotency support. See [[retry-logic]] for detailed design.

---
# AI Chat error handling — failed message flow
#ToDo
Frontend saves failed chats to Firestore with a failed parameter. Retry UX: ghost message turns red with retry icon. Deduplication logic when a failed message is successfully re-sent. See [[ai-chat-error-handling]] for full flow.

---
# AI Backend Firestore cleanup
#ToDo
Investigate and fix unwanted writes to `chat_checkpoints` in Firestore. The AI backend appears to store checkpoint data that duplicates what already exists under `user/{userId}/aiChatHistory/{threadId}`.

---
# Historic AI Chat loading
#ToDo
Revise how the frontend fetches and displays historical chats from Firestore. Revise how the frontend resumes an old `threadId` and sends a request to the AI backend.

---
