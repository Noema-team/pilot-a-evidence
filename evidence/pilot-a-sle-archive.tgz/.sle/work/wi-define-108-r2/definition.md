---
schemaVersion: 1
goal: >-
  Make rag-worker's failure status payload match the keys rag-api's persistence path consumes (error_message / stage /
  retryable), so a failed job persists the worker's real error message, its failing stage, and a deliberate retryability
  flag — enforced by a contract test on the worker failure → rag-api persistence path.
facts:
  - id: F1
    statement: >-
      A failed job must persist the worker's actual error message and the pipeline stage where it failed, so users and
      support can disambiguate failures from the persisted record.
    status: KNOWN
    source: human
    kind: product-intent
  - id: F2
    statement: retryable must be either sent by the worker or derived deliberately — never fabricated by a silent default.
    status: KNOWN
    source: human
    kind: product-intent
  - id: F3
    statement: A contract test must cover the worker failure → rag-api persistence path so the two sides cannot drift again.
    status: KNOWN
    source: human
    kind: product-intent
  - id: F4
    statement: >-
      The human's stated fix direction is worker-side alignment (worker adopts error_message/stage), because it matches
      rag-api's persisted fields and avoids a migration.
    status: KNOWN
    source: human
    kind: product-intent
  - id: F5
    statement: >-
      The worker's process_document exception handler publishes the failed status with details {"error": str(e)} — no
      error_message, stage, or retryable key.
    status: KNOWN
    source: repository
    kind: repository-claim
    evidenceRef: >-
      apps/ai-server/rag-worker-service/main.py — process_document exception handler publishing
      _publish_status_update(..., "failed", {"error": str(e)}, job_id) (~line 1097)
  - id: F6
    statement: >-
      rag-api's run_transactional_update failed branch reads details.get("error_message", "Processing failed"),
      details.get("stage"), and details.get("retryable", True) into the main doc fields error / error_stage / retryable.
    status: KNOWN
    source: repository
    kind: repository-claim
    evidenceRef: apps/ai-server/rag-api-service/main.py — run_transactional_update, failed branch (~lines 223-226)
  - id: F7
    statement: >-
      The worker's _publish_status_update wraps details inside the envelope {user_id, course_id, resource_id, status,
      details, timestamp, sequence, jobId}, and rag-api's _process_status_message routes payload["details"] into
      run_transactional_update.
    status: KNOWN
    source: repository
    kind: repository-claim
    evidenceRef: >-
      apps/ai-server/rag-worker-service/main.py _publish_status_update; apps/ai-server/rag-api-service/main.py
      _process_status_message
  - id: F8
    statement: >-
      On failure rag-api additionally writes processing/summary.error as {code: details.get("error_code", "UNKNOWN"),
      message: details.get("error_message", "Processing failed"), stage: details.get("stage")} — the same consumed keys.
    status: KNOWN
    source: repository
    kind: repository-claim
    evidenceRef: apps/ai-server/rag-api-service/main.py — run_transactional_update, failed-branch summary_update
  - id: F9
    statement: >-
      The worker already ships error-classification machinery — classify_error() returning transient-vs-permanent, plus
      TransientError/PermanentError exception classes — suitable for deriving retryable at the failure site.
    status: KNOWN
    source: repository
    kind: repository-claim
    evidenceRef: apps/ai-server/rag-worker-service/main.py — classify_error, TransientError, PermanentError
  - id: F10
    statement: >-
      The stale-lease sweeper (_fail_if_still_stale) writes failures directly to Firestore with error /
      error_stage="processing" / retryable=True — already conforming to the persisted field contract, no Pub/Sub message
      involved.
    status: KNOWN
    source: repository
    kind: repository-claim
    evidenceRef: apps/ai-server/rag-worker-service/main.py — _fail_if_still_stale
  - id: F11
    statement: >-
      The persisted Resource dataclass carries error, error_stage, and retryable (default True); ResourceResponse
      exposes error and error_stage to clients; the mobile contract tests assert those response fields.
    status: KNOWN
    source: repository
    kind: repository-claim
    evidenceRef: >-
      apps/ai-server/rag-api-service/models/resource.py; apps/ai-server/rag-api-service/main.py ResourceResponse;
      apps/ai-server/tests/integration/test_api_contracts.py
  - id: F12
    statement: >-
      The worker publishes named stages on its processing updates ("starting", "text_retrieved", "tagging_complete",
      "summary_generated", "chunking_complete", "embeddings_complete", "completed"), but the failure handler currently
      carries no stage value.
    status: KNOWN
    source: repository
    kind: repository-claim
    evidenceRef: apps/ai-server/rag-worker-service/main.py — process_document stage publications
  - id: F13
    statement: >-
      Hermetic integration test infrastructure exists (apps/ai-server/tests/integration, cloud SDKs mocked in conftest,
      cross-service pipeline tests) where a worker-failure → rag-api-persistence contract test can live.
    status: KNOWN
    source: repository
    kind: repository-claim
    evidenceRef: apps/ai-server/tests/integration/conftest.py; apps/ai-server/tests/integration/test_search_pipeline.py
  - id: F14
    statement: >-
      Repo workflow treats cross-client contract changes as feature-scale (not small changes); the worker→rag-api
      Pub/Sub payload is an internal service contract, while the client-facing ResourceResponse shape stays untouched
      here.
    status: KNOWN
    source: repository
    kind: repository-claim
    evidenceRef: "AGENTS.md — \"Which Path: Small Change or Feature?\""
  - id: F15
    statement: >-
      rag-api's subscription is assumed to be the only consumer of the rag-status-updates topic; no other subscriber was
      found in the services inspected, but other services were not exhaustively searched. Worker-side key changes are
      only safe if this holds — verified during implementation.
    status: ASSUMED
    source: investigation
  - id: F16
    statement: >-
      Working design default: track the current pipeline stage in process_document and include it in the failure
      payload, and derive retryable at the failure site from classify_error(e). Rationale: reuses existing machinery
      (F9, F12), is reversible, and instantiates the Objective's stated worker-side direction without changing what is
      being authorized.
    status: ASSUMED
    source: investigation
  - id: F17
    statement: >-
      The Objective's citations — #57's task cards, the D3 issue filed alongside, and plans/upload-flow.md deviation D4
      — are not resolvable in this working tree (plans/ contains no upload-flow.md). The historical analysis they hold
      is acknowledged but not needed to define this bounded contract fix.
    status: DEFERRED
    source: investigation
constraints:
  - description: >-
      The worker's failed-status details must carry the error message, failing stage, and retryable flag under exactly
      the keys rag-api's persistence path already reads (error_message / stage / retryable) — no Firestore migration.
      (Fact F4)
    type: must
  - description: >-
      The persisted resource field names (error, error_stage, retryable) and the client-facing ResourceResponse shape
      mobile/web already consume must not change. (Facts F11, F4)
    type: must
  - description: >-
      The Pub/Sub status envelope's top-level keys (user_id, course_id, resource_id, status, details, timestamp,
      sequence, jobId) and the sequence/lease-heartbeat behavior must not change. (Fact F7)
    type: must
  - description: >-
      No silent fallback may supply retryable on the worker→rag-api failure path: the worker must always send it, even
      if rag-api's defensive default remains. (Fact F2)
    type: must_not
  - description: >-
      Retryability should be derived from the worker's existing error-classification machinery (classify_error /
      TransientError / PermanentError) rather than new heuristics. (Fact F9)
    type: prefer
  - description: >-
      Prefer not to change rag-api's failed-branch read semantics — its fallback strings should survive only as defense
      for genuinely empty messages, keeping the blast radius worker-side. (Fact F4)
    type: prefer_not
requirements:
  - >-
    When document processing fails, the worker's failed status update must publish details with error_message set to the
    actual exception message, stage set to the pipeline stage in progress, and retryable set to a deliberate boolean
    derived from the existing error classification (Facts F5, F9, F12, F16).
  - >-
    After rag-api processes a failed-status message, the resource document must persist the worker's actual message in
    error and the failing stage in error_stage; the "Processing failed" fallback may apply only when the payload carries
    no usable message (Fact F6).
  - >-
    The persisted retryable value must equal the worker-reported flag for every failure that carries it, never rag-api's
    silent default (Fact F2).
  - >-
    The processing/summary subdocument's error object (code/message/stage) must reflect the same actual message and
    stage on failure (Fact F8).
  - >-
    A contract test must push a worker-shaped failure payload through rag-api's status-processing path and assert the
    persisted resource fields and summary error object, failing if either side's payload keys drift (Facts F3, F13).
  - >-
    The fix must leave rag-api's status-transition guardrails and the status envelope's ordering/lease-heartbeat
    behavior intact — the processing→failed transition and every other status continue to flow as before (Facts F7,
    F11).
nonGoals:
  - >-
    Changing retry/reprocessing policy itself — what happens after a retryable failure is marked — is out of scope; this
    fixes only the reporting contract.
  - No changes to the completed or processing status payload contracts — only the failed path is realigned.
  - No new API exposure of retryable (no ResourceResponse field, no client changes).
  - No Firestore migration or backfill of historically failed documents.
  - >-
    Not modifying the stale-lease sweep's direct Firestore failure write, which already conforms to the persisted field
    contract.
  - "Not addressing the sibling D3 issue or #57's task cards beyond this contract mismatch."
acceptance:
  - description: >-
      A contract test simulates a worker failure payload through rag-api's status-processing path and asserts the
      persisted resource fields (error, error_stage, retryable) and the processing/summary error object; the test fails
      if either side's keys drift again.
    met: false
  - description: >-
      A failed job's persisted record shows the worker's actual exception message and the failing pipeline stage — not
      the "Processing failed" fallback and not a null error_stage.
    met: false
  - description: >-
      The persisted retryable value equals the worker-reported, classification-derived flag, and the contract test
      asserts the worker always sends it (absence of the key fails the test).
    met: false
  - description: >-
      Repo validation for ai-server passes with the change, and the existing contract/integration suites remain green
      (no transition-guard or envelope regressions).
    met: false
---

## Why the record lies

Every failure today travels the same road and loses everything on the way. The worker catches a pipeline exception and publishes `details = {"error": str(e)}`. rag-api's failed branch then reads that dict looking for `error_message`, `stage`, and `retryable` — none of which exist — so three `.get()` defaults fire at once: the message becomes the generic "Processing failed", the stage becomes `None`, and `retryable` silently becomes `True` even though nobody ever decided the failure was retryable. The persisted record therefore cannot distinguish an auth failure from an embedding outage, and the retry flag is fabricated rather than reported.

## Chosen shape: worker adopts the consumer's keys

rag-api's failed branch reads `error_message` / `stage` / `retryable` and persists them into the main-doc fields `error` / `error_stage` / `retryable` — the same names the `Resource` dataclass carries and the same names mobile's contract tests already pin on `ResourceResponse`. Renaming on the worker side costs two services a one-line contract; renaming on the rag-api side would ripple into the persisted document shape (and near a client contract). The human's acceptance criteria already point this way, so the fix is worker-side key alignment with rag-api untouched except, at most, comment-level clarification. No Firestore migration is needed because the persisted fields don't change — only the values landing in them become real.

Three things the worker must now send:

1. **`error_message`** — the actual `str(e)` it already has.
2. **`stage`** — the pipeline stage in flight when the exception fired. The worker already publishes stage names on every processing heartbeat (`text_retrieved`, `chunking_complete`, …); the failure handler just never carried one. The natural design is a small "current stage" local in `process_document`, set before each step, included in the failure details. Its name should match the existing stage vocabulary so the persisted `error_stage` reads consistently with the progress trail.
3. **`retryable`** — derived, not defaulted. The worker already owns a classifier (`classify_error`, plus `TransientError`/`PermanentError`) whose entire purpose is "should this be retried", and the message-level ack/nack logic already uses it. Calling it in the failure handler costs nothing new and makes the persisted flag agree with the transport-level retry behavior — a property worth having, since today a permanent poison-pill failure is persisted as retryable.

## Fallbacks after the fix

rag-api's `"Processing failed"` fallback stays as defense for genuinely empty messages (some exceptions stringify to `""`). The distinction after the fix: the fallback fires only when the payload carries no usable message, never because the keys didn't match. The contract test enforces exactly that line.

## The second failure writer

There are two failure paths and only one is broken. The stale-lease sweeper (`_fail_if_still_stale`) writes failures straight to Firestore with `error` / `error_stage: "processing"` / `retryable: True` — it already conforms to the persisted contract, and its values are honest (a dead worker genuinely is a retryable processing-stage failure). It bypasses Pub/Sub entirely, so it is out of scope; touching it here would only widen the diff.

## Test strategy

The contract test lives in the hermetic integration suite (`apps/ai-server/tests/integration`), which already mocks Firebase/Pub/Sub and runs cross-service pipeline tests. The test builds a failed-status message shaped like the worker's publication, pushes it through `_process_status_message` → `run_transactional_update`, and asserts the persisted main-doc fields and the `processing/summary.error` object. It asserts positively on the worker's three keys — so a future worker edit that reverts to `{"error": ...}` fails the build — and, conversely, an assertion on rag-api's consumed keys pins the reader side. That two-sided pinning is the point: this bug existed because the contract lived only in two `main.py` files that no test looked at together. It is also the cheapest guard against the classic drift pattern this repo has already been burned by once (the duplicated-algorithms divergence).

## Risks and tradeoffs

- **Other consumers of the status topic.** The key rename is only safe if rag-api is the topic's sole subscriber. Only one subscription is configured and none was found elsewhere, but this is a working assumption to be verified during implementation — recorded as such, and the check is a cheap read before merging.
- **Stage accuracy.** A "current stage" tracker can be off-by-one if set lazily (e.g., exception in `_create_enhanced_chunks` reporting `chunking_complete` instead of `chunking`). Setting it *before* each step names the stage in progress, which matches what an operator wants to know. Minor cosmetic risk, safe default, no human call needed.
- **retryable flipping some persisted values from `True` to `False`.** That is the intended correction, not a regression: permanent failures were mislabeled retryable. If a future retry UI consumes the flag, it will now read truth.
- **Workflow routing.** `AGENTS.md` reserves feature plans for cross-client contract changes; the client-facing `ResourceResponse` shape is untouched here and the Pub/Sub payload is an internal service contract, so a small-change branch (`fix/`) with its tests is the presumptive route — the escalation rule still applies if implementation reveals otherwise.

## Explicitly out of scope

Retry/reprocessing policy itself (what happens *after* a retryable failure), the completed/processing status contracts, backfilling historical failed documents, exposing `retryable` through any API, and the sibling D3 issue. The Objective's citations (#57, the D3 issue, `plans/upload-flow.md` deviation D4) aren't present in this tree; the original analysis they reference would be nice context but isn't needed to define or land this fix.
