# Web App Overview

## Tech stack

- **Frontend:** React 18, Wouter (routing), TanStack React Query, Zustand, Tailwind CSS, shadcn/ui
- **Backend:** Express, Firebase Admin SDK, Firestore
- **Auth:** Firebase Auth (client-side only — `firebase/auth` is the only Firebase import allowed in client code)
- **Validation:** Zod schemas shared between client and server
- **AI:** Mistral AI for OCR and chat features

## Key constraint: API-first data access

**Client code must NEVER import `firebase/firestore` or `firebase/storage` directly.** All data operations go through the Express API server. Only `firebase/auth` is allowed in client code. This is enforced by ESLint.

## Structure

```
apps/web/
├── client/src/
│   ├── components/ui/       ← shadcn/ui components
│   ├── pages/               ← route components
│   ├── hooks/useDataQueries.ts ← React Query hooks for all API calls
│   ├── lib/api.ts           ← typed API wrapper functions
│   └── lib/queryClient.ts   ← HTTP client with auth token injection
└── server/
    ├── routes/              ← REST endpoints (users, courses, resources, chat, ocr)
    └── services/            ← business logic layer
```

## Dev commands

```bash
npm run dev      # Start development server (Express + Vite HMR on port 5000)
npm run build    # Build for production
npm run check    # TypeScript type checking
```
