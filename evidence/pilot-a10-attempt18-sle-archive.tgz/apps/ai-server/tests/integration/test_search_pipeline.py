import sys
import os
import pytest
from unittest.mock import MagicMock, AsyncMock, patch

import httpx
from fastapi.testclient import TestClient

RAG_API_DIR = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "..", "rag-api-service"))
WEAVIATE_DIR = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "..", "weaviate-service"))

for _mod in [
    "firebase_admin", "firebase_admin.credentials", "firebase_admin.firestore",
    "firebase_admin.auth", "firebase_admin._apps",
    "google", "google.cloud", "google.cloud.firestore", "google.cloud.firestore_v1",
    "google.cloud.pubsub_v1", "google.oauth2", "google.oauth2.service_account",
    "google.api_core", "google.api_core.exceptions", "structlog",
]:
    if _mod not in sys.modules:
        sys.modules[_mod] = MagicMock()
sys.modules["firebase_admin"]._apps = {}

os.environ.setdefault("SHARED_INTERNAL_TOKEN", "test-token")
os.environ.setdefault("WEAVIATE_SERVICE_URL", "http://test-weaviate:8002")
os.environ.setdefault("GOOGLE_APPLICATION_CREDENTIALS", "/dev/null")
os.environ.setdefault("GCP_PROJECT", "test-project")
os.environ.setdefault("GCS_BUCKET_NAME", "test-bucket")
os.environ.setdefault("WEAVIATE_API_KEY", "test-key")
os.environ.setdefault("FIREBASE_PROJECT_ID", "test-project")

if RAG_API_DIR not in sys.path:
    sys.path.insert(0, RAG_API_DIR)

from main import app, app_state, authenticate_s2s

AUTH_HEADERS = {"x-internal-token": "test-token", "x-authenticated-user-id": "user1"}


@pytest.fixture(autouse=True)
def setup_mocks():
    mock_db = MagicMock()
    mock_publisher = MagicMock()
    mock_publisher.topic_path.return_value = "projects/test/topics/vector-process"
    mock_httpx = MagicMock()
    mock_httpx.post = AsyncMock()
    mock_httpx.delete = AsyncMock()

    mock_auth_httpx = MagicMock()
    mock_auth_httpx.get = AsyncMock(return_value=MagicMock(
        status_code=200,
        json=lambda: {"uid": "user1", "isServiceAccount": True},
    ))

    app_state.db = mock_db
    app_state.pubsub_publisher = mock_publisher
    app_state.httpx_client = mock_httpx
    app_state.auth_httpx_client = mock_auth_httpx

    async def _mock_auth():
        return "user1"

    app.dependency_overrides[authenticate_s2s] = _mock_auth

    yield mock_db, mock_publisher, mock_httpx

    app.dependency_overrides.clear()


@pytest.fixture
def client():
    return TestClient(app)


def _mock_weaviate_response(query="test", results=None):
    if results is None:
        results = []
    return MagicMock(
        status_code=200,
        json=lambda: {
            "query": query,
            "results": results,
            "contexts_markdown": [r["content"] for r in results] if results else [],
            "combined_context": " ".join(r["content"] for r in results) if results else "",
        },
        raise_for_status=MagicMock(),
    )


def _mock_resolver(resource_ids=None):
    if resource_ids is None:
        resource_ids = ["r1"]
    resolver = MagicMock()
    resolution = MagicMock(
        resource_ids=resource_ids,
        resolution_time_ms=10,
        source="cache",
    )
    resolver.resolve_context = AsyncMock(return_value=resolution)
    return resolver


class TestSearchPipelineRagToWeaviate:
    def test_search_forwards_query_and_resource_ids(self, client, setup_mocks):
        _, _, mock_httpx = setup_mocks
        mock_httpx.post.return_value = _mock_weaviate_response("test query", [
            {"id": "c1", "chunk_id": "c1", "content": "text", "score": 0.95, "distance": 0.05, "resource_id": "r1"},
        ])

        with patch("main.get_query_resolver", return_value=_mock_resolver(["r1", "r2"])):
            response = client.post("/search", json={"query": "test query", "course_id": "c1", "limit": 5}, headers=AUTH_HEADERS)

        assert response.status_code == 200
        data = response.json()
        assert len(data["results"]) == 1
        assert data["results"][0]["chunk_id"] == "c1"

        call_args = mock_httpx.post.call_args
        assert call_args[0][0] == "/search"
        body = call_args[1]["json"]
        assert body["query"] == "test query"
        assert body["user_id"] == "user1"
        assert body["resource_ids"] == ["r1", "r2"]
        headers = call_args[1]["headers"]
        assert headers["x-internal-token"] == "test-token"
        assert headers["x-authenticated-user-id"] == "user1"

    def test_search_general_mode_no_course_id(self, client, setup_mocks):
        _, _, mock_httpx = setup_mocks
        mock_httpx.post.return_value = _mock_weaviate_response("general")

        with patch("main.get_query_resolver", return_value=_mock_resolver([])):
            response = client.post("/search", json={"query": "general", "limit": 5}, headers=AUTH_HEADERS)

        assert response.status_code == 200
        call_body = mock_httpx.post.call_args[1]["json"]
        assert call_body["query"] == "general"

    def test_search_propagates_weaviate_connection_error(self, client, setup_mocks):
        _, _, mock_httpx = setup_mocks
        mock_httpx.post.side_effect = httpx.ConnectError("Connection refused")

        with patch("main.get_query_resolver", return_value=_mock_resolver()):
            response = client.post("/search", json={"query": "test", "limit": 5}, headers=AUTH_HEADERS)

        assert response.status_code in (500, 502, 503)

    def test_search_propagates_weaviate_500_error(self, client, setup_mocks):
        _, _, mock_httpx = setup_mocks
        err = httpx.HTTPStatusError(
            "500",
            request=MagicMock(),
            response=MagicMock(status_code=500, text="Internal error"),
        )
        mock_httpx.post.return_value = MagicMock(
            status_code=500,
            json=lambda: {"detail": "Internal error"},
            raise_for_status=MagicMock(side_effect=err),
        )

        with patch("main.get_query_resolver", return_value=_mock_resolver()):
            response = client.post("/search", json={"query": "test", "limit": 5}, headers=AUTH_HEADERS)

        assert response.status_code in (500, 502)

    def test_search_includes_min_score_in_weaviate_request(self, client, setup_mocks):
        _, _, mock_httpx = setup_mocks
        mock_httpx.post.return_value = _mock_weaviate_response()

        with patch("main.get_query_resolver", return_value=_mock_resolver()):
            response = client.post("/search", json={"query": "test", "min_score": 0.7, "limit": 5}, headers=AUTH_HEADERS)

        assert response.status_code == 200
        call_body = mock_httpx.post.call_args[1]["json"]
        assert call_body["min_score"] == 0.7

    def test_search_resolves_context_from_course_id(self, client, setup_mocks):
        _, _, mock_httpx = setup_mocks
        mock_httpx.post.return_value = _mock_weaviate_response()

        with patch("main.get_query_resolver", return_value=_mock_resolver(["r1"])) as mock_get_resolver:
            response = client.post("/search", json={"query": "test", "course_id": "c1", "limit": 5}, headers=AUTH_HEADERS)

        assert response.status_code == 200
        mock_get_resolver.assert_called_once_with(app_state.db)

    def test_search_uses_context_field_over_course_id(self, client, setup_mocks):
        _, _, mock_httpx = setup_mocks
        mock_httpx.post.return_value = _mock_weaviate_response()

        with patch("main.get_query_resolver", return_value=_mock_resolver(["r1", "r2", "r3"])) as mock_get_resolver:
            response = client.post(
                "/search",
                json={"query": "test", "course_id": "c1", "context": {"mode": "group", "additional_resource_ids": ["r2", "r3"]}, "limit": 5},
                headers=AUTH_HEADERS,
            )

        assert response.status_code == 200
        resolver = mock_get_resolver.return_value
        call_args = resolver.resolve_context.call_args
        assert call_args[0][0] == "user1"

    def test_search_adds_resolution_metadata(self, client, setup_mocks):
        _, _, mock_httpx = setup_mocks
        mock_httpx.post.return_value = _mock_weaviate_response()

        with patch("main.get_query_resolver", return_value=_mock_resolver(["r1", "r2"])):
            response = client.post("/search", json={"query": "test", "limit": 5}, headers=AUTH_HEADERS)

        assert response.status_code == 200
        data = response.json()
        assert "results" in data
        call_body = mock_httpx.post.call_args[1]["json"]
        assert call_body["resource_ids"] == ["r1", "r2"]


class TestResourceCreationPipeline:
    def test_create_resource_success(self, client, setup_mocks):
        from services.resource_service import ResourceService
        from models.resource import Resource, ResourceStatus
        from datetime import datetime, timezone
        mock_resource = Resource(
            resource_id="res-123",
            filename="test.pdf",
            status=ResourceStatus.UPLOADED,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
            owner_id="user1",
        )
        with patch.object(ResourceService, "create_resource", new_callable=AsyncMock, return_value=mock_resource):
            response = client.post(
                "/resources",
                headers=AUTH_HEADERS,
                json={"filename": "test.pdf", "storage_url": "gs://bucket/test.pdf", "storage_bucket": "my-bucket"},
            )
        if response.status_code in (200, 201):
            _, mock_pubsub, _ = setup_mocks
            data = response.json()
            assert data["resource_id"] == "res-123"

    def test_process_endpoint_validates_missing_params(self, client, setup_mocks):
        response = client.post("/process", json={}, headers=AUTH_HEADERS)
        assert response.status_code in (400, 422)

    def test_status_endpoint_queries_firestore(self, client, setup_mocks):
        mock_db, _, _ = setup_mocks
        mock_doc = MagicMock()
        mock_doc.exists = True
        mock_doc.to_dict.return_value = {"status": "completed", "details": "Done"}
        mock_db.collection.return_value.document.return_value.collection.return_value.document.return_value.get.return_value = mock_doc

        response = client.get("/status/res-123", params={"course_id": "c1"}, headers=AUTH_HEADERS)
        assert response.status_code in (200, 404, 500)


class TestAuthChain:
    def test_search_rejects_missing_internal_token(self, client):
        app.dependency_overrides.clear()
        response = client.post("/search", json={"query": "test", "limit": 5}, headers={"x-authenticated-user-id": "user1"})
        assert response.status_code in (401, 403)

    def test_search_rejects_wrong_internal_token(self, client, setup_mocks):
        _, _, _ = setup_mocks
        app.dependency_overrides.clear()
        app_state.auth_httpx_client.get = AsyncMock(return_value=MagicMock(
            status_code=401,
            json=lambda: {"detail": "Invalid token"},
            text="Invalid token",
        ))
        response = client.post(
            "/search",
            json={"query": "test", "limit": 5},
            headers={"x-internal-token": "wrong-token", "x-authenticated-user-id": "user1"},
        )
        assert response.status_code in (401, 403)

    def test_search_requires_authenticated_user_id_header(self, client):
        response = client.post("/search", json={"query": "test", "limit": 5}, headers={"x-internal-token": "test-token"})
        assert response.status_code in (400, 422)


class TestHeaderPropagation:
    def test_rag_api_sends_internal_token_to_weaviate(self, client, setup_mocks):
        _, _, mock_httpx = setup_mocks
        mock_httpx.post.return_value = _mock_weaviate_response()

        with patch("main.get_query_resolver", return_value=_mock_resolver()):
            client.post("/search", json={"query": "test", "limit": 5}, headers=AUTH_HEADERS)

        fwd_headers = mock_httpx.post.call_args[1]["headers"]
        assert fwd_headers["x-internal-token"] == "test-token"
        assert fwd_headers["x-authenticated-user-id"] == "user1"

    def test_rag_api_propagates_different_user_id(self, client, setup_mocks):
        _, _, mock_httpx = setup_mocks
        mock_httpx.post.return_value = _mock_weaviate_response()

        other_headers = {"x-internal-token": "test-token", "x-authenticated-user-id": "other-user-456"}
        with patch("main.get_query_resolver", return_value=_mock_resolver()):
            client.post("/search", json={"query": "test", "limit": 5}, headers=other_headers)

        fwd_headers = mock_httpx.post.call_args[1]["headers"]
        assert fwd_headers["x-authenticated-user-id"] == "other-user-456"

    def test_rag_api_uses_config_token_for_weaviate(self, client, setup_mocks):
        _, _, mock_httpx = setup_mocks
        mock_httpx.post.return_value = _mock_weaviate_response()
        app_state.config = MagicMock()
        app_state.config.shared_internal_token = "custom-service-token"

        with patch("main.get_query_resolver", return_value=_mock_resolver()):
            client.post("/search", json={"query": "test", "limit": 5}, headers=AUTH_HEADERS)

        fwd_headers = mock_httpx.post.call_args[1]["headers"]
        assert fwd_headers["x-internal-token"] == "custom-service-token"
