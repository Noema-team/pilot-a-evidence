# System Overview — File Map

- `system-overview/README.md` — hub entry point: structure, pinned files, when to load
- `system-overview/map.md` — this file: index of all system-overview files
- `system-overview/general/overview.md` — cross-cutting: auth, Firebase, data flow, monorepo design rules
- `system-overview/ai-server/overview.md` — AI server microservices, service breakdown, endpoints
- `system-overview/mobile/overview.md` — Flutter mobile app: structure, navigation, state management
- `system-overview/web/overview.md` — Next.js/Express web app: routing, components, API-first constraint
