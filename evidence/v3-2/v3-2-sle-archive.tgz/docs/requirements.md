# Requirements — rag-worker → rag-api failure payload contract alignment

- Run: 58232065-c773-4179-bfbd-de9348344b7e (iteration 1, step: design)
- Authoritative source: Definition artifact `definition:obj-108` (WorkItem `wi-define-108-a8`, sha256 `71f1c39c97ecea575b1195b63de510fa403dad4fecaa1df0c774d04fae89cac5`). Binding; not widened, narrowed, or reinterpreted below.
- Evidence marks: **[V]** = directly verified in repository this cycle; **[D]** = pinned by the authoritative Definition (facts F1–F12).

## 1. Problem statement

A failed RAG processing job loses the worker's actual error information. The worker's exception handler in `process_document` publishes a failed status with details `{"error": str(e)}` **[V]**; rag-api's failed branch reads `error_message`, `stage`, and `retryable` from details **[D, F4]** and persists `error`/`error_stage`/`retryable` on the main resource document plus `message`/`stage` (with `error_code` defaulting to `"UNKNOWN"`) into the `processing/summary` subdocument **[D, F4]**. Because of the key mismatch, every worker-originated failure persists `error = "Processing failed"` (fallback), `error_stage = None`, and `retryable = True` (silent default) **[D, F5]**. The established persisted failure schema is `error`/`error_stage`/`retryable`: the worker's stale-lease sweep writes it directly (`error_stage: "processing"`, `retryable: True`) **[V]**, rag-api's enqueue-failure paths write it **[D, F6]**, and the `Resource` model exposes it (`retryable` defaults `True`) **[V]**. The worker's status publisher is the only writer that does not speak it.

## 2. Scope

In scope:
- Worker failure-payload construction in `process_document`'s exception handler.
- Stage tracking through `process_document` so the failing stage is reported.
- Deliberate derivation of `retryable` from the worker's existing `classify_error()`.
- A contract test covering the worker failure → rag-api persistence path, with key-drift guards.

Out of scope (non-goals, from the Definition):
- Changing the stale-lease sweep's direct failure write (already consistent) **[V]**.
- Changing retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals — only the *reporting* of retryability changes.
- Frontend or mobile changes (`ResourceResponse` already exposes `error`/`error_stage`) **[D, F6]**.
- Introducing structured error codes or a failure taxonomy (`processing/summary` `error.code` remains `"UNKNOWN"` unless a code is actually sent).
- Anything the companion D3 issue covers beyond this worker→rag-api payload alignment (its content is unavailable here; deferred), and reconciling this analysis with the D4 deviation note in `plans/upload-flow.md` (file not present in the current tree).

## 3. Functional requirements

### FR-1 (must) — Failure payload keys
When document processing fails, the worker's failed status payload must include:
- `error_message` — the actual exception message (`str(e)`),
- `stage` — the pipeline stage executing at failure time,
- `retryable` — deliberately derived (FR-4).

The payload must never rely on rag-api's fallback defaults for these keys. (Definition requirement 1; facts F1, F3, F4.)

### FR-2 (must) — Stage tracking and stage vocabulary
The worker must track the currently executing pipeline stage through `process_document` so the failure handler reports the true failing stage. Stage names must reuse the existing progress-stage vocabulary **[V — exact strings verified in `process_document`'s `_publish_status_update` calls]**:

| Stage value | Pipeline step it labels |
|---|---|
| `starting` | request validation / start of processing |
| `text_retrieved` | text extraction/retrieval |
| `tagging_complete` | content tagging and analysis |
| `summary_generated` | summary generation + document update |
| `chunking_complete` | chunk creation |
| `embeddings_complete` | embedding generation |

`"processing"` is the safe value when the stage is genuinely unknown (e.g., failure before the first transition); it matches the stale-lease sweep's `error_stage` value **[V]**, so `error_stage` never regresses to null. (Definition requirement 2; fact F9.)

### FR-3 (must) — rag-api passthrough persistence
rag-api's failed branch must persist the worker-provided values unchanged:
- main document: `error` ← payload `error_message`; `error_stage` ← payload `stage`; `retryable` ← payload `retryable`;
- `processing/summary` error subdocument: same message and stage as the main document.

No changes to rag-api's reads or persisted schema; no Firestore migration, field rename, or backfill. (Definition requirement 3; facts F2, F4, F6; constraint must / must_not.)

### FR-4 (must) — Deliberate retryable derivation
The worker sets `retryable` from `classify_error(e)` **[V — verified classification logic]**:
- classified transient → `retryable: true`;
- classified permanent, including unclassified-unknown (classify_error's conservative default) → `retryable: false`.

Binding mapping **[V]**:

| Exception | classify_error verdict | retryable |
|---|---|---|
| `TransientError` | transient | `true` |
| `PermanentError` | permanent | `false` |
| `httpx.ConnectError/ConnectTimeout/ReadTimeout/WriteTimeout/PoolTimeout`, `ConnectionError`, `TimeoutError`, `asyncio.TimeoutError` | transient | `true` |
| `httpx.HTTPStatusError` with status 429, 500, 502, 503, 504 | transient | `true` |
| `httpx.HTTPStatusError` with other 4xx | permanent | `false` |
| any other (unclassified-unknown) | permanent (conservative) | `false` |

Accepted behavior change: unclassified-unknown exceptions previously persisted `retryable: true` via the silent default and will now persist `false` — this is the conservatism `classify_error` was written for; manual reprocess via `POST /process` is unaffected. (Definition requirement 4; facts F7, F8.)

### FR-5 (must) — Contract test with drift guard
A contract test must cover the worker failure → rag-api persistence path. It must:
- exercise the worker's failure-payload construction and rag-api's failed-branch persistence (via the Firestore emulator or fakes);
- assert the persisted `error`, `error_stage`, and `retryable` equal the worker's values;
- assert the `processing/summary` error subdocument carries the same message and stage;
- fail if either side's payload keys drift (see architecture §4.4 for the guard mechanism). (Definition requirement 5; facts F10.)

### FR-6 (prefer) — Legacy key retention
The worker retains the legacy `error` key alongside `error_message` in the failure payload, for continuity with any existing consumers of the status topic and log tooling. (Definition constraint prefer; fact F11.)

## 4. Constraints (from the Definition, binding)

- **must** — The worker is aligned to rag-api's existing contract (`error_message`/`stage`/`retryable`); rag-api's reads and persisted schema are not changed.
- **must_not** — No Firestore migration, field rename, or backfill of existing documents; persisted fields (`error`, `error_stage`, `retryable`) keep their names and semantics.
- **must** — Every worker-originated failure payload carries `retryable` explicitly; rag-api's `details.get("retryable", True)` fallback must not be the operative mechanism for worker failures.
- **prefer** — Retain the legacy `error` key in the worker's failure payload alongside `error_message`.
- **prefer_not** — Do not introduce a structured error-code taxonomy (`error_code` values).

## 5. Acceptance criteria

- **AC-1** — A failed job's status message published by the worker contains `error_message` (actual exception message), `stage` (failing pipeline stage), and `retryable` (deliberately derived) — none relying on rag-api's fallback defaults. *Verified by: FR-5 contract test, worker-side payload assertions.*
- **AC-2** — After a failed job, the persisted resource document has `error` = the worker's actual error message (not `"Processing failed"`), `error_stage` = the failing stage (not None), and `retryable` = the worker's derived value. *Verified by: FR-5 contract test, main-document assertions.*
- **AC-3** — The `processing/summary` error subdocument for the failed job carries the same message and stage as the main document. *Verified by: FR-5 contract test, subdocument assertions.*
- **AC-4** — A contract test covering the worker failure → rag-api persistence path exists and passes, exercising the worker's failure-payload construction through rag-api's failed-branch persistence and asserting persisted `error`/`error_stage`/`retryable` equal the worker's values, failing if either side's payload keys drift. *Verified by: FR-5.*

## 6. Traceability

| Requirement | Facts | Acceptance |
|---|---|---|
| FR-1 | F1, F3, F4 | AC-1 |
| FR-2 | F9 | AC-1, AC-2 |
| FR-3 | F2, F4, F6 | AC-2, AC-3 |
| FR-4 | F7, F8 | AC-1, AC-2 |
| FR-5 | F10 | AC-4 |
| FR-6 | F11 | (hedge; not acceptance-gated) |

## 7. Deferred / open

- Companion D3 issue referenced by the Objective: content unavailable in this context; anything beyond the worker→rag-api payload alignment is deferred (F12).
- Reconciliation with the D4 deviation note in `plans/upload-flow.md`: file not present in the current tree; deferred.
- Dropping the legacy `error` key after a consumer audit confirms rag-api is the only subscriber: future cleanup, explicitly out of scope now (F11).