Investigation closed. From the verified evidence — the authoritative Definition (requirements R1–R5, acceptance A1–A4), the two services' `pytest.ini`/conftest patterns, the shared integration conftest bootstrap, the verified `ProcessingMessage` model, and the verified `exceptions.py` — I derived the contract test suite below. Tests encode the **target** contract (they are intentionally red against the current buggy implementation; the red state is the drift guard firing). Signatures that could not be verified from this vantage (`process_document`, `_publish_status_update`, `run_transactional_update`) are handled by explicit, fail-loud invocation adapters rather than silent assumptions, and every such unknown is listed in the artifact's unknowns section.

<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path=".sle/work/wi-define-108-a8/test-scripts.md">>>
# Test Scripts — rag-worker → rag-api failure payload contract (wi-define-108-a8)

Executable test scripts derived **only** from the authoritative Definition (requirements R1–R5, acceptance A1–A4). Tests deliberately encode the **target** contract; against the current implementation they are expected to fail — that red state is the drift guard required by R5/A4, not a test defect.

## Files delivered

| Path | Covers |
|---|---|
| `apps/ai-server/rag-worker-service/tests/integration/test_failure_payload_contract.py` | Worker side: R1 (payload keys/values), R2 (stage tracking + vocabulary), R4 (retryable derivation), worker-side AST drift guard |
| `apps/ai-server/tests/integration/test_worker_failure_payload_contract.py` | The seam: R3 (failed-branch persistence unchanged), R5 (worker failure → rag-api persistence equality, anti-fallback guards, subdocument contract), API-side + worker-source AST drift guards |

## Why the seam test isolates the worker in a subprocess

The verified shared conftest (`apps/ai-server/tests/integration/conftest.py`) puts `rag-api-service` on `sys.path`; both services ship top-level packages named `models` (verified listings), so importing both `main` modules in one process collides on the cached `models` package. The seam test therefore exercises the worker's real `process_document` failure path in a subprocess (still the worker's code, never a restated fixture) and feeds the resulting payload to rag-api's real `run_transactional_update` in-process with the house MagicMock Firestore pattern (verified in `rag-api-service/tests/integration/test_endpoints.py`).

## How to run

```bash
# worker side
cd apps/ai-server/rag-worker-service && python -m pytest tests/integration/test_failure_payload_contract.py

# seam (bootstrap comes from the verified shared conftest in the same directory)
cd apps/ai-server && python -m pytest tests/integration/test_worker_failure_payload_contract.py
# fallback if no pytest config exists at apps/ai-server (rootdir config unverified):
python -m pytest apps/ai-server/tests/integration/test_worker_failure_payload_contract.py
```

Both services pin Python 3.11.9 and `asyncio_mode = auto` (verified `pytest.ini` files).

## Known unknowns and adaptation protocol (fail-loud, never silent)

1. **Signatures** of `process_document`, `_publish_status_update`, `run_transactional_update` are attested by name only (Definition F3/F4/F9). Invocation adapters try attested shapes and `pytest.fail` with an actionable message if none fit. Extend the adapter; never weaken assertions.
2. **Worker pipeline mock surface** for reaching the late-stage trigger: the soft-patch helper no-ops module-level async helpers; steps implemented as methods on client objects need `AsyncMock` fixtures added to the worker test conftest. The late-stage test's diagnostic prints the publish timeline + premature exception to make that obvious.
3. **`classify_error()` return representation** (bool / class / string — F7 attests TransientError/PermanentError): `_is_transient` adapters interpret all three and fail loudly on an unrecognized shape.
4. `exceptions.py`'s docstring references `RetryHandler.is_retryable_error`; the Definition pins **`classify_error`** (F7/F8) for the payload's retryable derivation. Tests use `classify_error` only.
5. **Initial expected state: RED** on payload/persistence tests until the fix lands (worker publishes only `{"error": ...}` today per F3/F5). A red run with the diagnostics below is the contract guard working.

## Requirement → test traceability

| Requirement / Acceptance | Tests |
|---|---|
| R1 payload keys, real values, no reliance on fallbacks (A1) | `test_early_failure_carries_real_message_stage_and_retryable`, `test_worker_publishes_contract_payload` |
| R2 stage tracking, vocabulary, safe `"processing"` | `test_early_failure...` (starting/processing), `test_late_failure_reports_embeddings_stage`, `test_stage_value_stays_inside_progress_vocabulary` |
| R3 API persists worker values unchanged; subdoc message/stage (A2, A3) | `test_failed_branch_persists_worker_values_unchanged`, `test_no_fallback_sentinels_survive`, `test_summary_subdocument_carries_message_stage_and_unknown_code` |
| R4 retryable from classify_error (transient→true, permanent/unknown→false) | `TestRetryableDerivation.*` |
| R5 contract test across both sides + key-drift guard (A4) | entire seam file + `TestWorkerKeyDriftGuard` + `test_api_failed_branch_reads_the_contract_keys` + `test_worker_source_constructs_contract_keys` |
| F11 hedge (legacy `error` key) — `prefer`, not pinned | `test_legacy_error_key_if_present_carries_the_same_message` (conditional, truth-only) |

---

## File 1: `apps/ai-server/rag-worker-service/tests/integration/test_failure_payload_contract.py`

```python
"""Worker-side contract tests: rag-worker failure status payload.

Derived from the authoritative Definition (wi-define-108-a8), NOT from the
current implementation — the current implementation is the bug under fix
(a one-key {"error": str(e)} payload, Definition F3/F5).

Requirements under test here:
  R1  Failure payload carries error_message (actual exception message),
      stage (pipeline stage at failure time), retryable (deliberately
      derived) — never reliant on rag-api's fallback defaults.
  R2  Stage tracked through process_document; values reuse the progress
      vocabulary {starting, text_retrieved, tagging_complete,
      summary_generated, chunking_complete, embeddings_complete};
      safe value "processing" when genuinely unknown.
  R4  retryable derives from classify_error(): transient -> True;
      permanent (incl. unclassified-unknown conservative default) -> False.

The rag-api persistence side of the seam lives in
apps/ai-server/tests/integration/test_worker_failure_payload_contract.py.
"""

import ast
import asyncio
import inspect
import sys
from unittest.mock import AsyncMock, MagicMock

import pytest

NEUTRAL_ERROR_MESSAGE = (
    "contract-test injected failure: the widgets refused to align"
)
REQUIRED_PAYLOAD_KEYS = {"error_message", "stage", "retryable"}
PROGRESS_STAGE_VOCABULARY = {
    "starting",
    "text_retrieved",
    "tagging_complete",
    "summary_generated",
    "chunking_complete",
    "embeddings_complete",
}
SAFE_UNKNOWN_STAGE = "processing"
ALLOWED_STAGE_VALUES = PROGRESS_STAGE_VOCABULARY | {SAFE_UNKNOWN_STAGE}
API_FALLBACK_ERROR = "Processing failed"

# Contract-critical worker symbols (attested names, Definition F3/F7/F9)
# that the pipeline soft-patch must never no-op.
_CONTRACT_KEEP = {
    "process_document",
    "_publish_status_update",
    "classify_error",
    "run_worker",
    "_fail_if_still_stale",
}


def _import_worker_main():
    """Import worker main.py, auto-mocking missing third-party modules
    (same pattern as the verified service conftests). Fails loudly."""
    for _ in range(60):
        try:
            import main as worker_main  # noqa: PLC0415
            return worker_main
        except ModuleNotFoundError as exc:
            root = (exc.name or "").split(".")[0]
            if not root or root in sys.modules or root == "main":
                raise
            sys.modules[root] = MagicMock()
    raise RuntimeError("unable to import rag-worker main.py")


worker_main = _import_worker_main()


def _build_processing_message():
    """Build the verified Pub/Sub trigger message (models/pubsub_messages.py)."""
    from models.pubsub_messages import ProcessingMessage, ProcessingMessageMetadata

    return ProcessingMessage(
        job_id="job-contract",
        user_id="u-1",
        course_id="c-1",
        resource_id="r-1",
        cloud_storage_path="gs://bucket/notes.pdf",
        firestore_path="users/u-1/courses/c-1/courseResources/r-1",
        metadata=ProcessingMessageMetadata(
            filename="notes.pdf",
            file_size=1024,
            mime_type="application/pdf",
            uploaded_at="2025-01-01T00:00:00Z",
        ),
    )


class _CapturingPublisher:
    """Stands in for _publish_status_update, records every call, and injects
    the failure at a chosen point:

      trigger="__first__"          -> raise on the very first publish call
                                      (early-stage failure)
      trigger=<stage token>        -> raise when asked to publish the
                                      progress update for that stage token
                                      (late-stage failure); earlier
                                      publishes pass through untouched so
                                      the handler's own failure publish is
                                      still captured.
    """

    def __init__(self, trigger, exc_message=NEUTRAL_ERROR_MESSAGE):
        self.trigger = trigger
        self.exc = RuntimeError(exc_message)
        self.calls = []
        self.raised = False

    async def __call__(self, *args, **kwargs):
        self.calls.append((args, kwargs))
        blob = repr(args) + repr(kwargs)
        should_raise = (
            (self.trigger == "__first__" and not self.raised)
            or (self.trigger != "__first__" and self.trigger in blob)
        )
        if should_raise:
            self.raised = True
            raise self.exc

    def failure_payload(self):
        """The recorded failure-status details dict (must carry the contract keys)."""
        for args, kwargs in self.calls:
            for candidate in list(args) + list(kwargs.values()):
                if isinstance(candidate, dict) and "error_message" in candidate:
                    return candidate
        pytest.fail(
            "No published payload contained 'error_message'. Either the failure "
            "handler did not run, or the payload keys drifted from the contract "
            f"{sorted(REQUIRED_PAYLOAD_KEYS)} (R1). Recorded publishes: "
            f"{self.calls!r}"
        )

    def timeline(self):
        tokens = []
        for args, kwargs in self.calls:
            blob = repr(args) + repr(kwargs)
            tokens.append(
                [t for t in sorted(ALLOWED_STAGE_VALUES) if f"'{t}'" in blob]
            )
        return tokens


def _soft_patch_pipeline(monkeypatch):
    """No-op every module-level async helper except the contract-critical
    ones, so the pipeline can advance to a late-stage trigger against mocked
    clients. Pipeline steps implemented as methods on client objects (or
    imported inside the function body) are NOT covered — if the late-stage
    test reports a premature natural failure, add AsyncMock fixtures for
    those clients in tests/conftest.py instead of weakening these tests."""
    for name, value in list(vars(worker_main).items()):
        if name in _CONTRACT_KEEP or name.startswith("__"):
            continue
        if asyncio.iscoroutinefunction(value):
            monkeypatch.setattr(worker_main, name, AsyncMock(return_value=MagicMock()))


async def _run_process_document(monkeypatch, capture, *, soft_patch_pipeline=False):
    """Run the real process_document with _publish_status_update replaced by
    the capturing publisher. Signature-tolerant invocation: the exact
    parameter name of process_document was not verifiable from this test's
    vantage, so try the attested message shapes and fail loudly if none fit."""
    fn = worker_main.process_document
    monkeypatch.setattr(worker_main, "_publish_status_update", capture)
    if soft_patch_pipeline:
        _soft_patch_pipeline(monkeypatch)

    sig = inspect.signature(fn)
    message = _build_processing_message()
    kwargs = {}
    for name in (
        "message", "msg", "data", "envelope", "processing_message", "pubsub_message",
    ):
        if name in sig.parameters:
            kwargs[name] = message
            break
    positional = ()
    if not kwargs:
        required = [
            p for p in sig.parameters.values()
            if p.default is inspect.Parameter.empty
            and p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD)
        ]
        if len(required) != 1:
            pytest.fail(
                "process_document signature not understood by this contract "
                f"test: {sig}. Extend the invocation adapter in this file — "
                "do not weaken the assertions."
            )
        positional = (message,)
    try:
        result = fn(*positional, **kwargs)
        if inspect.isawaitable(result):
            await result
    except Exception:
        # The injected exception may surface here or be swallowed by the
        # in-function handler; either way the handler must have published
        # the failure status, which capture.failure_payload() verifies.
        pass
    return capture


def _is_transient(classification) -> bool:
    """Interpret classify_error()'s verdict (R4/F7). Handles bool, the
    attested TransientError/PermanentError classes, strings, and enums.
    Fails loudly on an unrecognized representation — never guesses."""
    if isinstance(classification, bool):
        return classification
    transient = getattr(worker_main, "TransientError", None)
    permanent = getattr(worker_main, "PermanentError", None)
    if transient is not None and classification is transient:
        return True
    if permanent is not None and classification is permanent:
        return False
    if isinstance(classification, str):
        return classification.strip().lower() == "transient"
    name = getattr(classification, "name", None) or type(classification).__name__
    upper = str(name).upper()
    if "TRANSIENT" in upper:
        return True
    if "PERMANENT" in upper:
        return False
    pytest.fail(
        f"Cannot interpret classify_error() result {classification!r}; "
        "extend _is_transient rather than guessing."
    )


class TestWorkerFailurePayloadContract:
    """R1 + R2 (acceptance A1): payload contents on a worker-originated failure."""

    async def test_early_failure_carries_real_message_stage_and_retryable(self, monkeypatch):
        capture = _CapturingPublisher("__first__")
        await _run_process_document(monkeypatch, capture)
        payload = capture.failure_payload()

        assert REQUIRED_PAYLOAD_KEYS <= set(payload), (
            f"failure payload missing contract keys: {sorted(payload)} (R1)"
        )
        # The worker's ACTUAL exception message — never the API fallback.
        assert payload["error_message"] == str(capture.exc)
        assert payload["error_message"] != API_FALLBACK_ERROR
        # Stage: a non-empty string inside the required vocabulary. A failure
        # at the very first publish is legitimately "starting" or, if the
        # tracker was not yet armed, the safe value "processing" (R2).
        assert isinstance(payload["stage"], str) and payload["stage"]
        assert payload["stage"] in ALLOWED_STAGE_VALUES, payload["stage"]
        assert payload["stage"] in {"starting", SAFE_UNKNOWN_STAGE}
        # Explicitly derived, never silently defaulted (constraint: must).
        assert isinstance(payload["retryable"], bool)

    async def test_late_failure_reports_embeddings_stage(self, monkeypatch):
        """R2 representative late-stage pin: the tracker raised at the
        embeddings_complete progress publish must report that stage. Both
        plausible tracker placements (before the step's await, or at its
        completion publish) yield 'embeddings_complete' here, so this pin is
        convention-faithful without ossifying intra-step ordering."""
        capture = _CapturingPublisher("embeddings_complete")
        await _run_process_document(monkeypatch, capture, soft_patch_pipeline=True)
        payload = capture.failure_payload()
        assert payload["stage"] == "embeddings_complete", (
            "a failure raised at the embeddings_complete progress publish must "
            f"report that stage; got {payload['stage']!r}. Publish timeline: "
            f"{capture.timeline()!r}. If a natural exception fired first, the "
            "pipeline mock surface needs AsyncMock fixtures in tests/conftest.py."
        )
        assert payload["error_message"] == str(capture.exc)

    async def test_stage_value_stays_inside_progress_vocabulary(self, monkeypatch):
        capture = _CapturingPublisher("__first__")
        await _run_process_document(monkeypatch, capture)
        payload = capture.failure_payload()
        assert payload["stage"] in ALLOWED_STAGE_VALUES

    async def test_legacy_error_key_if_present_carries_the_same_message(self, monkeypatch):
        """F11 hedge is a 'prefer' constraint, not a must: retaining the
        legacy 'error' key is allowed but not required. If present, however,
        it must tell the truth — identical to error_message."""
        capture = _CapturingPublisher("__first__")
        await _run_process_document(monkeypatch, capture)
        payload = capture.failure_payload()
        if "error" in payload:
            assert payload["error"] == payload["error_message"]


class TestRetryableDerivation:
    """R4 (F7/F8): retryable aligns with the worker's ACK/NACK classification."""

    async def test_retryable_always_equals_classify_error_verdict(self, monkeypatch):
        exc = RuntimeError(NEUTRAL_ERROR_MESSAGE)
        capture = _CapturingPublisher("__first__")
        capture.exc = exc
        await _run_process_document(monkeypatch, capture)
        payload = capture.failure_payload()
        assert payload["retryable"] is _is_transient(worker_main.classify_error(exc)), (
            "payload retryable must be derived from classify_error(e), aligned "
            "with the ACK/NACK decision (R4)"
        )

    async def test_unclassified_unknown_maps_to_permanent_false(self, monkeypatch):
        """F7: unknown exceptions classify as permanent (conservative
        default); F8: therefore retryable false. This is also the strongest
        anti-fallback proof on the worker side: the old silent default was
        True, so a persisted/derived False can only come from the deliberate
        derivation."""
        assert _is_transient(worker_main.classify_error(RuntimeError(NEUTRAL_ERROR_MESSAGE))) is False, (
            "sentinel message unexpectedly classifies transient — pick a "
            "different neutral message instead of weakening this test"
        )
        capture = _CapturingPublisher("__first__")
        capture.exc = RuntimeError(NEUTRAL_ERROR_MESSAGE)
        await _run_process_document(monkeypatch, capture)
        payload = capture.failure_payload()
        assert payload["retryable"] is False

    async def test_transient_classified_maps_to_true(self, monkeypatch):
        transient_cls = getattr(worker_main, "TransientError", None)
        if transient_cls is None:
            pytest.fail(
                "Definition F7 attests TransientError in the worker module; "
                "not found — verify before touching this test."
            )
        exc = transient_cls("contract-test transient: queue hiccup")
        assert _is_transient(worker_main.classify_error(exc)) is True, (
            "TransientError instances must classify transient (F7)"
        )
        capture = _CapturingPublisher("__first__")
        capture.exc = exc
        await _run_process_document(monkeypatch, capture)
        payload = capture.failure_payload()
        assert payload["retryable"] is True


class TestWorkerKeyDriftGuard:
    """R5: a future edit to the worker's payload keys must fail the build.
    AST-based, matching the verified house style
    (apps/ai-server/tests/integration/test_api_contracts.py)."""

    def _process_document_ast(self):
        return ast.parse(inspect.getsource(worker_main.process_document))

    def test_failure_handler_constructs_contract_keys(self):
        tree = self._process_document_ast()
        keys = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Dict):
                keys |= {
                    k.value for k in node.keys
                    if isinstance(k, ast.Constant) and isinstance(k.value, str)
                }
            if (
                isinstance(node, ast.Subscript)
                and isinstance(node.slice, ast.Constant)
                and isinstance(node.slice.value, str)
            ):
                keys.add(node.slice.value)
            if (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute)
                and node.func.attr == "get"
                and node.args
                and isinstance(node.args[0], ast.Constant)
                and isinstance(node.args[0].value, str)
            ):
                keys.add(node.args[0].value)
        missing = REQUIRED_PAYLOAD_KEYS - keys
        assert not missing, (
            f"process_document no longer constructs contract keys {sorted(missing)} "
            "— the worker failure payload drifted from the contract (R5)."
        )
        uses_classify = any(
            isinstance(n, ast.Name) and n.id == "classify_error" for n in ast.walk(tree)
        )
        assert uses_classify, (
            "retryable must be derived from classify_error() inside the failure "
            "handler (R4) — the derivation was removed or bypassed."
        )
```

---

## File 2: `apps/ai-server/tests/integration/test_worker_failure_payload_contract.py`

```python
"""Worker -> rag-api failure-path CONTRACT test (the seam itself).

Derived from the authoritative Definition (wi-define-108-a8), requirements
R3 and R5, acceptance A2/A3/A4. Strategy (per the Definition's test
guidance): import/exercise BOTH sides rather than restate the contract —

  1. The worker's REAL process_document failure path runs in a subprocess
     (isolated because both services ship a top-level `models` package, so
     importing both mains in one process collides) and emits its actual
     failure payload as JSON.
  2. That payload is fed to rag-api's REAL run_transactional_update against
     MagicMock Firestore fakes (verified house pattern) and the persisted
     writes are asserted to equal the worker's values — with hard guards on
     the fallback sentinels ("Processing failed", None stage, silent
     retryable=True) that made this bug.
  3. AST drift guards on both sources fail the build if either side's
     payload keys drift (house style: AST-based contract tests).

Initial expected state: RED until the fix lands — that is the drift guard
required by R5, not a test defect.
"""

import ast
import asyncio
import inspect
import json
import os
import subprocess
import sys
from pathlib import Path
from unittest.mock import MagicMock

import pytest

THIS_DIR = Path(__file__).resolve().parent
AI_SERVER_DIR = THIS_DIR.parent.parent          # .../apps/ai-server
RAG_API_DIR = AI_SERVER_DIR / "rag-api-service"
WORKER_DIR = AI_SERVER_DIR / "rag-worker-service"

REQUIRED_PAYLOAD_KEYS = {"error_message", "stage", "retryable"}
PROGRESS_STAGE_VOCABULARY = {
    "starting", "text_retrieved", "tagging_complete",
    "summary_generated", "chunking_complete", "embeddings_complete",
}
ALLOWED_STAGE_VALUES = PROGRESS_STAGE_VOCABULARY | {"processing"}
API_FALLBACK_ERROR = "Processing failed"
CONTRACT_MARKER = "@@CONTRACT@@"

# The neutral message deliberately avoids words that error-classification
# heuristics typically match (timeout/unavailable/status codes/etc.).
NEUTRAL_ERROR_MESSAGE = (
    "contract-test injected failure: the widgets refused to align"
)


# --------------------------------------------------------------------------
# Worker side, in a subprocess: exercise the real failure-payload construction
# --------------------------------------------------------------------------

DRIVER_SOURCE = r'''
import asyncio
import inspect
import json
import os
import sys
import traceback
from unittest.mock import MagicMock

sys.path.insert(0, os.getcwd())


def _import_main():
    for _ in range(60):
        try:
            import main
            return main
        except ModuleNotFoundError as exc:
            root = (exc.name or "").split(".")[0]
            if not root or root in sys.modules or root == "main":
                raise
            sys.modules[root] = MagicMock()
    raise RuntimeError("unable to import rag-worker main.py")


worker_main = _import_main()

from models.pubsub_messages import ProcessingMessage, ProcessingMessageMetadata  # noqa: E402

NEUTRAL = "contract-test injected failure: the widgets refused to align"
VOCAB = {
    "starting", "text_retrieved", "tagging_complete",
    "summary_generated", "chunking_complete", "embeddings_complete",
}


def _is_transient(classification):
    if isinstance(classification, bool):
        return classification
    t = getattr(worker_main, "TransientError", None)
    p = getattr(worker_main, "PermanentError", None)
    if t is not None and classification is t:
        return True
    if p is not None and classification is p:
        return False
    if isinstance(classification, str):
        return classification.strip().lower() == "transient"
    name = getattr(classification, "name", None) or type(classification).__name__
    up = str(name).upper()
    if "TRANSIENT" in up:
        return True
    if "PERMANENT" in up:
        return False
    return None


class Capture:
    def __init__(self):
        self.calls = []
        self.raised = False
        self.exc = RuntimeError(NEUTRAL)

    async def __call__(self, *args, **kwargs):
        self.calls.append((args, kwargs))
        if not self.raised:  # early trigger: raise on the very first publish
            self.raised = True
            raise self.exc

    def failure_payload(self):
        for args, kwargs in self.calls:
            for candidate in list(args) + list(kwargs.values()):
                if isinstance(candidate, dict) and "error_message" in candidate:
                    return candidate
        return None

    def timeline(self):
        out = []
        for args, kwargs in self.calls:
            blob = repr(args) + repr(kwargs)
            out.append([t for t in sorted(VOCAB) if "'" + t + "'" in blob])
        return out


async def run_scenario():
    fn = worker_main.process_document
    cap = Capture()
    worker_main._publish_status_update = cap

    message = ProcessingMessage(
        job_id="job-contract",
        user_id="u-1",
        course_id="c-1",
        resource_id="r-1",
        cloud_storage_path="gs://bucket/notes.pdf",
        firestore_path="users/u-1/courses/c-1/courseResources/r-1",
        metadata=ProcessingMessageMetadata(
            filename="notes.pdf",
            file_size=1024,
            mime_type="application/pdf",
            uploaded_at="2025-01-01T00:00:00Z",
        ),
    )
    sig = inspect.signature(fn)
    kwargs = {}
    for name in ("message", "msg", "data", "envelope",
                 "processing_message", "pubsub_message"):
        if name in sig.parameters:
            kwargs[name] = message
            break
    try:
        result = fn(**kwargs) if kwargs else fn(message)
        if inspect.isawaitable(result):
            await result
    except Exception:
        pass  # handler may swallow; its publish is what matters

    classification = worker_main.classify_error(cap.exc)
    print(
        CONTRACT_MARKER + json.dumps({
            "payload": cap.failure_payload(),
            "timeline": cap.timeline(),
            "raised": repr(cap.exc),
            "classification_transient": _is_transient(classification),
        }),
        flush=True,
    )


if __name__ == "__main__":
    try:
        asyncio.run(run_scenario())
    except SystemExit:
        raise
    except Exception:
        traceback.print_exc()
        sys.exit(3)
'''


@pytest.fixture(scope="module")
def worker_failure_result(tmp_path_factory):
    driver_path = tmp_path_factory.mktemp("worker-driver") / "driver.py"
    driver_path.write_text(DRIVER_SOURCE)
    env = dict(os.environ)
    env.setdefault("GCP_PROJECT", "test-project")
    env.setdefault("GOOGLE_APPLICATION_CREDENTIALS", "/tmp/fake-creds.json")
    env.setdefault("SHARED_INTERNAL_TOKEN", "test-token")
    env["PYTHONPATH"] = str(WORKER_DIR) + os.pathsep + env.get("PYTHONPATH", "")
    proc = subprocess.run(
        [sys.executable, str(driver_path)],
        cwd=str(WORKER_DIR),
        env=env,
        capture_output=True,
        text=True,
        timeout=300,
    )
    if proc.returncode != 0:
        pytest.fail(
            "worker contract driver crashed while exercising process_document:\n"
            f"--- stderr (tail) ---\n{proc.stderr[-4000:]}"
        )
    markers = [
        line[len(CONTRACT_MARKER):]
        for line in proc.stdout.splitlines()
        if line.startswith(CONTRACT_MARKER)
    ]
    if not markers:
        pytest.fail(
            "driver produced no contract marker. stdout tail:\n"
            f"{proc.stdout[-2000:]}"
        )
    return json.loads(markers[-1])


# --------------------------------------------------------------------------
# rag-api side: real run_transactional_update against house-style fakes
# --------------------------------------------------------------------------

@pytest.fixture
def api_main():
    # Shared conftest (verified) already mocks cloud deps and put
    # rag-api-service on sys.path. The worker main is never imported in this
    # process (subprocess isolation), so `main` unambiguously resolves to
    # rag-api's.
    import main as api_main
    return api_main


@pytest.fixture
def fake_db():
    db = MagicMock()
    txn = MagicMock()
    db.transaction.return_value = txn
    return db, txn


def _invoke_failed_branch(api_main, db, payload):
    """Call rag-api's real run_transactional_update with the worker payload.
    Signature-tolerant (the exact signature was not verifiable from this
    test's vantage); fails loudly with an actionable message instead of
    guessing silently."""
    if hasattr(api_main, "app_state"):
        api_main.app_state.db = db  # cover the app_state-DI style too
    fn = api_main.run_transactional_update
    sig = inspect.signature(fn)
    resource_path = "users/u-1/resources/r-1"
    candidates = {
        "db": db, "firestore_db": db, "firestore_client": db, "client": db,
        "doc_path": resource_path, "resource_path": resource_path,
        "path": resource_path, "firestore_path": resource_path,
        "user_id": "u-1", "course_id": "c-1", "resource_id": "r-1",
        "status": "failed",
        "details": payload, "payload": payload, "data": payload,
    }
    kwargs = {k: v for k, v in candidates.items() if k in sig.parameters}
    if not {"details", "payload", "data"} & set(kwargs):
        pytest.fail(
            "run_transactional_update signature exposes no details-like "
            f"parameter: {sig}. Extend _invoke_failed_branch — do not "
            "restate the contract in a fixture."
        )
    result = fn(**kwargs)
    if inspect.isawaitable(result):
        result = asyncio.run(result)
    return result


def _collect_dict_writes(db_and_txn):
    """Scan the fake Firestore call tree for every dict passed to a write-style
    call (set/update/create on doc refs or transaction). Tolerates the write
    styles attested across the repo (transaction.set, doc_ref.update, etc.)."""
    dicts = []
    for mock in db_and_txn:
        for call in mock.mock_calls:
            _name, args, kwargs = call
            candidates = list(args) + list(kwargs.values())
            for obj in candidates:
                if isinstance(obj, dict):
                    dicts.append(obj)
                elif isinstance(obj, (list, tuple)):
                    dicts.extend(o for o in obj if isinstance(o, dict))
    return dicts


def _failed_branch_ast_node(tree):
    for node in ast.walk(tree):
        if (
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.name == "run_transactional_update"
        ):
            return node
    pytest.fail("run_transactional_update not found in rag-api main.py")


def _function_ast_node(tree, name, where):
    for node in ast.walk(tree):
        if (
            isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
            and node.name == name
        ):
            return node
    pytest.fail(f"{name} not found in {where}")


def _string_keys_used(node):
    keys = set()
    for sub in ast.walk(node):
        if isinstance(sub, ast.Dict):
            keys |= {
                k.value for k in sub.keys
                if isinstance(k, ast.Constant) and isinstance(k.value, str)
            }
        if (
            isinstance(sub, ast.Subscript)
            and isinstance(sub.slice, ast.Constant)
            and isinstance(sub.slice.value, str)
        ):
            keys.add(sub.slice.value)
        if (
            isinstance(sub, ast.Call)
            and isinstance(sub.func, ast.Attribute)
            and sub.func.attr == "get"
            and sub.args
            and isinstance(sub.args[0], ast.Constant)
            and isinstance(sub.args[0].value, str)
        ):
            keys.add(sub.args[0].value)
    return keys


# --------------------------------------------------------------------------
# The contract tests
# --------------------------------------------------------------------------

class TestWorkerFailurePayloadAcrossTheSeam:
    def test_worker_publishes_contract_payload(self, worker_failure_result):
        """R1/A1, worker side of the seam. Also the worker behavioral drift
        guard: any key rename on the worker side lands here first."""
        payload = worker_failure_result["payload"]
        assert payload is not None, (
            "worker failure payload carried no error_message key — the worker "
            "side of the contract drifted (R1/R5). Publish timeline: "
            f"{worker_failure_result['timeline']!r}"
        )
        assert REQUIRED_PAYLOAD_KEYS <= set(payload), (
            f"missing contract keys: {sorted(REQUIRED_PAYLOAD_KEYS - set(payload))}"
        )
        assert payload["error_message"] == NEUTRAL_ERROR_MESSAGE
        assert payload["error_message"] != API_FALLBACK_ERROR
        assert isinstance(payload["stage"], str)
        assert payload["stage"] in ALLOWED_STAGE_VALUES
        assert isinstance(payload["retryable"], bool)
        # Unclassified-unknown classifies permanent (F7) -> retryable False
        # (R4). A False here also proves the worker is not leaning on any
        # silent True default.
        if worker_failure_result["classification_transient"] is not False:
            pytest.fail(
                "neutral sentinel classified "
                f"{worker_failure_result['classification_transient']!r} — pick a "
                "different neutral message instead of weakening this test"
            )
        assert payload["retryable"] is False

    def test_failed_branch_persists_worker_values_unchanged(
        self, worker_failure_result, api_main, fake_db
    ):
        """R3/A2: main document error <- payload error_message,
        error_stage <- payload stage, retryable <- payload retryable —
        unchanged. If the worker's keys drift, this fails via the fallback
        sentinels; if rag-api's reads drift, it fails via equality."""
        payload = worker_failure_result["payload"]
        assert payload is not None, "worker side must pass before the seam can"
        db, txn = fake_db
        _invoke_failed_branch(api_main, db, payload)
        writes = _collect_dict_writes((db, txn))
        main_writes = [d for d in writes if "error_stage" in d]
        assert main_writes, (
            "no persisted write carried error_stage — unrecognized write shape? "
            f"writes seen: {writes!r}"
        )
        for write in main_writes:
            assert write["error"] == payload["error_message"], (
                f"persisted error {write['error']!r} != worker message — "
                "rag-api failed branch is falling back instead of persisting "
                "the worker's value (R3)"
            )
            assert write["error_stage"] == payload["stage"]
            assert write["retryable"] == payload["retryable"]
            assert isinstance(write["retryable"], bool)

    def test_no_fallback_sentinels_survive(
        self, worker_failure_result, api_main, fake_db
    ):
        """A2 hard guards: the exact failure mode that motivated this cycle —
        error persisted as 'Processing failed', stage persisted as None —
        must be impossible for worker-originated failures."""
        payload = worker_failure_result["payload"]
        assert payload is not None
        db, txn = fake_db
        _invoke_failed_branch(api_main, db, payload)
        for write in _collect_dict_writes((db, txn)):
            if "error" in write:
                assert write["error"] != API_FALLBACK_ERROR, (
                    "fallback error string persisted — the worker's "
                    "error_message did not survive the seam (R5 drift)"
                )
            if "error_stage" in write:
                assert write["error_stage"] is not None, (
                    "error_stage persisted as None — the worker's stage did "
                    "not survive the seam"
                )

    def test_summary_subdocument_carries_message_stage_and_unknown_code(
        self, worker_failure_result, api_main, fake_db
    ):
        """R3/A3 + bounded scope: the processing/summary error subdocument
        carries the same message and stage as the main document, and
        error_code defaults to 'UNKNOWN' (worker sends no code; structured
        taxonomy is out of scope)."""
        payload = worker_failure_result["payload"]
        assert payload is not None
        db, txn = fake_db
        _invoke_failed_branch(api_main, db, payload)
        writes = _collect_dict_writes((db, txn))
        sub_writes = [d for d in writes if "error_code" in d]
        assert sub_writes, (
            "no processing/summary subdocument write found (expected a write "
            f"carrying error_code) — writes seen: {writes!r}"
        )
        for write in sub_writes:
            assert write["message"] == payload["error_message"]
            assert write["stage"] == payload["stage"]
            assert write["error_code"] == "UNKNOWN"


class TestContractKeyDriftGuards:
    """R5: a future edit to either side's keys must fail the build instead of
    silently re-creating this bug. AST-based per verified house style."""

    def test_api_failed_branch_reads_the_contract_keys(self):
        tree = ast.parse((RAG_API_DIR / "main.py").read_text())
        fn = _failed_branch_ast_node(tree)
        keys = _string_keys_used(fn)
        missing = REQUIRED_PAYLOAD_KEYS - keys
        assert not missing, (
            f"rag-api failed branch stopped reading {sorted(missing)} from the "
            "failure details — API side of the contract drifted (R5)."
        )

    def test_worker_source_constructs_the_contract_keys(self):
        tree = ast.parse((WORKER_DIR / "main.py").read_text())
        fn = _function_ast_node(tree, "process_document", "worker main.py")
        keys = _string_keys_used(fn)
        missing = REQUIRED_PAYLOAD_KEYS - keys
        assert not missing, (
            f"worker process_document no longer constructs {sorted(missing)} "
            "— worker side of the contract drifted (R5)."
        )
        uses_classify = any(
            isinstance(n, ast.Name) and n.id == "classify_error"
            for n in ast.walk(fn)
        )
        assert uses_classify, (
            "retryable derivation from classify_error() vanished from "
            "process_document (R4)."
        )
```

---

## Notes for the implement step

1. **Run order**: fix the worker first (payload + stage tracker + retryable derivation), then the seam suite should go green without touching rag-api (constraint: align the worker; do not change rag-api's reads or persisted schema).
2. **Anti-ossification**: the late-stage pin uses `embeddings_complete` because both plausible tracker placements agree on it; the early pin accepts `{"starting", "processing"}` per R2's safe-value rule. Adding a pipeline step later requires no test change — only *removing or bypassing the tracker* does, which is the intended guard.
3. **Adapters are load-bearing seams, not assertions**: if a signature/mocking adapter fails, extend the adapter per its fail-loud message. Never replace a behavioral assertion with a restated fixture — that would defeat R5.
4. **Conditional legacy-key test** (`test_legacy_error_key_if_present_carries_the_same_message`) encodes the `prefer` constraint (F11) without mandating retention; dropping the hedge later is cleanup, not a contract break.
<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>