# Cycle Charter — rag-worker → rag-api: failure payload contract mismatch

Cycle: fix the worker→rag-api failure seam so failed RAG jobs persist the worker's actual error message, the failing pipeline stage, and a deliberately derived retryable flag — locked in by a contract test.

## Scope

The single seam between the rag-worker's failure publisher and rag-api's failed-branch consumer:

1. **rag-worker failure payload** (`apps/ai-server/rag-worker-service/main.py`, `process_document` exception handler and its `_publish_status_update` call): the failed status payload is rebuilt to carry `error_message` (the actual exception message), `stage` (the pipeline stage executing at failure time), and `retryable` (deliberately derived via `classify_error`). The legacy `error` key is retained alongside `error_message` as a compatibility hedge for any unknown consumer of the status topic.
2. **Worker stage tracking** (`process_document`): a stage tracker set immediately before each pipeline step, reported by the failure handler. Stage names reuse the existing progress-update vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown — the same value the stale-lease sweep uses for `error_stage`.
3. **retryable derivation**: the worker sets `retryable` from `classify_error(e)` — the same classification that drives ACK/NACK in `run_worker`. Transient-classified errors → `retryable: true`; permanent-classified errors (including unclassified-unknown, per `classify_error`'s conservative default) → `retryable: false`. This is a deliberate behavior change for unclassified-unknown exceptions (previously the API-side silent default persisted `true`).
4. **rag-api failed branch** (`apps/ai-server/rag-api-service/main.py`, `run_transactional_update`): pinned, not redesigned. Its existing reads (`error_message`, `stage`, `retryable`) and persisted writes (main document `error`/`error_stage`/`retryable`; `processing/summary` error subdocument with `message`/`stage`, `error_code` defaulting to `"UNKNOWN"`) are the contract the worker aligns to. No changes to rag-api's reads or persisted schema are in scope.
5. **Contract test** (`apps/ai-server/tests/integration/`, following the fixture/AST patterns of `test_api_contracts.py`): imports both sides rather than restating the contract in a fixture — builds the failure payload through the worker's code path, feeds it through rag-api's `run_transactional_update` against the Firestore emulator (or fakes — both services have hermetic `FIRESTORE_EMULATOR_HOST` branches), and asserts the persisted `error`, `error_stage`, and `retryable` equal the worker's values. Includes a key-set drift guard so an edit to either side's payload keys fails the build, and representative-stage coverage (an early-stage and a late-stage failure) sufficient to catch the stage tracker being removed or bypassed without ossifying every step.

## Purpose

Every worker-originated failure currently lands in Firestore as the fallback string `"Processing failed"`, a null `error_stage`, and a fabricated `retryable: true` (with the `processing/summary` error subdocument inheriting the same fallbacks and `error_code` always `"UNKNOWN"`), because the worker publishes `{"error": str(e)}` while rag-api reads `error_message`/`stage`/`retryable`. Users and support cannot disambiguate failures, and the persisted record contradicts the worker's actual ACK/NACK retry behavior. This cycle aligns the worker — the odd one out among four write paths — to the already-established persisted failure schema (`error`/`error_stage`/`retryable`, consistent across the stale-lease sweep, rag-api's enqueue-failure paths, `ResourceResponse`, and the `Resource` model), so a failed job persists the truth about what broke, where, and whether it will retry. No migration, no backfill, no reader changes.

## Requirements

- When document processing fails, the worker's failed status payload must include `error_message` (the actual exception message), `stage` (the pipeline stage executing at failure time), and `retryable` (deliberately derived) — the payload must never rely on rag-api's fallback defaults (`"Processing failed"`, `None`, `True`) for these keys.
- The worker must track the currently executing pipeline stage through `process_document` so the failure handler reports the true failing stage; stage names must reuse the existing progress-stage vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown.
- rag-api's failed branch must persist the worker-provided values unchanged: main document `error` ← payload `error_message`, `error_stage` ← payload `stage`, `retryable` ← payload `retryable`; the `processing/summary` error subdocument must carry the same message and stage.
- The `retryable` derivation must be explicit and aligned with the worker's ACK/NACK behavior: errors classified transient by `classify_error` → `retryable: true`; classified permanent (including unclassified-unknown, per `classify_error`'s conservative default) → `retryable: false`.
- A contract test must cover the worker failure → rag-api persistence path: it must exercise the worker's failure-payload construction and rag-api's failed-branch persistence (via the Firestore emulator or fakes) and assert the persisted `error`, `error_stage`, and `retryable` equal the worker's values; it must fail if either side's payload keys drift.

Acceptance:

- A failed job's published status message contains `error_message`, `stage`, and `retryable`, none relying on rag-api's fallback defaults.
- After a failed job, the persisted resource document has `error` = the worker's actual error message (not `"Processing failed"`), `error_stage` = the failing stage (not `None`), and `retryable` = the worker's derived value.
- The `processing/summary` error subdocument carries the same message and stage as the main document.
- The contract test exists and passes, exercising the worker's failure-payload construction through rag-api's failed-branch persistence and asserting the persisted values match, with a drift guard on either side's keys.

## Boundaries

Must constraints:

- The worker is aligned to rag-api's existing contract — publishing `error_message`/`stage`/`retryable` — rather than changing rag-api's reads or persisted schema.
- No Firestore migration, field rename, or backfill of existing documents; the persisted fields (`error`, `error_stage`, `retryable`) keep their names and semantics.
- Every worker-originated failure payload must carry `retryable` explicitly; the API-side `details.get("retryable", True)` fallback must not be the operative mechanism for worker failures.

Must-not constraints:

- No changes to rag-api's readers or persisted schema.

Preference constraints:

- Retain the legacy `error` key in the worker's failure payload alongside `error_message`, for continuity with any existing consumers of the status topic and log tooling.
- Do not introduce a structured error-code taxonomy (`error_code` values) in this fix; the `processing/summary` error `code` remains `"UNKNOWN"` unless a code is actually sent.

Out of scope (non-goals):

- Changing the stale-lease sweep's direct failure write — it already persists `error`/`error_stage`/`retryable` consistently with this contract (including its `retryable: true`, which stays correct: a dead worker is a transient condition).
- Changing retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, or heartbeat intervals — only the *reporting* of retryability in the payload changes.
- Frontend or mobile changes — `ResourceResponse` already exposes `error` and `error_stage` to clients.
- Introducing structured error codes or a failure taxonomy.
- Widening `classify_error`'s heuristics (accepted tradeoff: genuinely transient-but-unrecognized failures will now persist `retryable: false`; manual reprocess via `POST /process` remains).
- Any scope the companion D3 issue covers beyond this worker→rag-api failure payload alignment.

Known drift risk, by convention: a future pipeline step added without updating the stage tracker reports a stale stage. The convention is "set the tracker immediately before the await"; the contract test pins the mechanism on representative stages rather than ossifying every step.

## Version bump

None. This change adds no new runtime dependencies, changes no data-model/schema shape (persisted field names and semantics are unchanged by design), and alters no HTTP endpoint surface; the wire-payload fix aligns the worker to the already-persisted contract. The services in `apps/ai-server` are not independently versioned per change (rag-api's FastAPI metadata is static at `1.0.0`; the worker carries no version constant), so no version field is bumped in this cycle. It is a standard small-change branch (`fix/<slug>`) — if implementation reveals a criterion of the small-change path no longer holds, stop and escalate per `AGENTS.md`.

## Deferred items

- **Companion D3 issue** referenced by the Objective: its scope is not available in this context; anything it covers beyond the worker→rag-api failure payload alignment is deferred.
- **`plans/upload-flow.md` D4 reconciliation**: the original deviation note lives in a file not present in the current tree (the reference comes from the Objective text); reconciling this cycle's analysis with it is deferred.
- **Dropping the legacy `error` key**: after an audit confirms the worker is the only publisher and rag-api's status subscriber the only consumer of the status topic, removing the duplicate key is trivial follow-up cleanup — deferred, not part of this cycle.
- **Widening `classify_error`** to recognize more transient failure modes (to restore auto-retry affordances for unrecognized-transient failures) — explicitly out of scope for this fix.