# Documentation — File Map

- `documentation/README.md` — hub entry point: structure, rules, skill to load
- `documentation/map.md` — this file: index of all documentation files
- `documentation/ai-features/rag-agent-types.md` — multi-agent architecture spec (Teaching, Problem Solver, Search, Study Advice)
- `documentation/ai-features/flashcard-generation.md` — how flashcards are generated (section text → typed LLM prompts → dedup), quality determinants, and open improvement ideas
- `documentation/ai-features/ai-chat-error-handling.md` — failed message flow, retry UX, deduplication logic
- `documentation/ai-features/retry-logic.md` — full history sync, failure scenarios, idempotency design
- `documentation/ai-features/prepare-for-lecture.md` — AI-powered lecture prep feature spec and UX flow
- `documentation/compliance/gdpr-compliance.md` — GDPR privacy principles and implementation requirements
- `documentation/testing/testing-phases.md` — three-phase testing strategy (Logic, Usability, Production)
- `documentation/testing/audit-test-coverage-gap-analysis.md` — audit findings: test coverage and gaps across backend services, API gateway, mobile
- `documentation/testing/audit-testing-framework.md` — audit findings: testing framework and main system, priority items and resolution status
- `documentation/tooling/dev-framework.md` — the `dev/` framework: cross-app checks, artifact folders, context-pack.md
- `documentation/tooling/evaluation.md` — evaluation start-here: end-to-end workflow (profiles, seed, journeys vs eval, judge/card cassettes, record mechanics, baselines, compare loop, exit codes)
- `documentation/tooling/agent-mobile-debugging.md` — agent runbook: drive the Flutter app on a connected phone (ADB control, log streaming, adb reverse to local backends, fix loop, when to write a test instead)
- `documentation/tooling/self-hosted-runner-setup.md` — runbook for an agent: stand up a self-hosted GitHub Actions runner on the local server (user, systemd, labels, workflow `runs-on` PR, validation, security checklist, maintenance, rollback)
- `documentation/tooling/new-repo-ci-checklist.md` — replicate the CI + branch-protection stack on another repo: runner registration, which workflows/governance files to copy, protection API call, validation steps
- `documentation/tooling/ai-pr-review.md` — the advisory AI reviewer as installed here: wiring, trust model, semantics, upgrade procedure, known limits
- `documentation/web/README.md` — web app docs index: origin and contents
- `documentation/web/logging.md` — web app logging system and standards
- `documentation/web/refactor-to-independent-resources.md` — plan for restructuring resource management in Firestore
- `documentation/web/resource-status-v2-schema-contract.md` — resource status V2 schema contract (Phase 1)
- `documentation/plans/course-document-contract.md` — course doc unification plan: canonical field contract, 4 phases (mobile writer parity, dead-reader fixes, timestamp canonicalization, icon/color formats), known bugs table
- `documentation/plans/course-schema-v2-migration.md` — long-term canonical Firestore course schema, ownership rules, migration sequence, and verification requirements

Evaluation and tuning (outside this folder, referenced from here):

- `docs/README.md` — top-level documentation index: which doc answers which question, root-level docs, hub structure, layer discipline
- `docs/TUNING-GUIDE.md` — symptom → lever → loop: ranked levers, five-minute scorecard read, tuning loop with adopt/revert rules
- `eval/README.md` — what each scorer measures, tier table, dataset honesty rules, baselines
- `eval/TUNING-LOG.md` — every recorded baseline/tuning decision and why
- `docs/EVAL-AND-TUNING-SPEC.md` — original design spec (intent; predates wiring)
