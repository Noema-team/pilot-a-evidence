# Architecture — Worker → rag-api failure payload contract alignment

## 1. Current seam

```
rag-worker                                  rag-api
process_document (one large try)            _process_status_message
  └─ except Exception as e:                 └─ run_transactional_update
       _publish_status_update("failed",          failed branch reads:
         {"error": str(e)})  ✗ MISMATCH          details["error_message"],
                                                 details["stage"],
                                                 details["retryable"]
                                               persists:
                                                 doc.error, doc.error_stage,
                                                 doc.retryable
                                                 summary.error{code,message,stage}
```

All other write paths (stale-lease sweep `_fail_if_still_stale`, enqueue-failure branches in `/process` and `POST /resources`) and both response models (`ResourceResponse`, `Resource`) already use the `error`/`error_stage`/`retryable` schema. The worker's status publisher is the only writer that doesn't speak it.

## 2. Fix direction: worker aligns to API

The worker changes its payload keys to `error_message`/`stage`/`retryable`. rag-api's failed branch, persisted fields, models, and the mobile contract all stay untouched. Zero migration, zero backfill.

## 3. Changes — rag-worker-service/main.py

### 3.1 Stage tracker
A local variable (`current_stage`) initialized to `"processing"` at the top of `process_document`, set immediately before each pipeline step (convention: **set the tracker immediately before the `await`**):

| Assignment point | Value |
|---|---|
| Before `_validate_processing_request` / first publish | `"starting"` |
| Before `_get_extracted_text` completes → after | `"text_retrieved"` |
| Before `generate_tags` | `"tagging_complete"` |
| Before `generate_document_summary` | `"summary_generated"` |
| Before `_create_enhanced_chunks` | `"chunking_complete"` |
| Before `_generate_embeddings_with_openrouter` | `"embeddings_complete"` |

Failure before the first transition leaves `"processing"` — the same value the stale-lease sweep uses, so `error_stage` never regresses to null.

### 3.2 Failure handler
Replace the exception handler's publish:

```python
await self._publish_status_update(
    user_id, course_id, resource_id, "failed",
    {
        "error_message": str(e),        # actual message (R1)
        "stage": current_stage,          # tracker value (R2)
        "retryable": classify_error(e),  # explicit derivation (R4)
        "error": str(e),                 # legacy key retained (R6 hedge)
    },
    job_id,
)
```

`classify_error` already exists (TransientError/PermanentError, httpx type/status heuristics, unknown → permanent) and drives ACK/NACK in `run_worker`; the persisted `retryable` now matches what Pub/Sub actually does. No new machinery.

### 3.3 Untouched
`_fail_if_still_stale`, `_publish_status_update` mechanics (sequence numbers, lease heartbeat), `run_worker` ACK/NACK, all retry/lease/heartbeat configuration.

## 4. Changes — rag-api-service/main.py

None. `run_transactional_update`'s failed branch already reads the right keys and persists the right fields; the `details.get(...)` fallbacks become dead paths for worker-originated failures and remain as defensive defaults for other publishers. This is the explicit no-change boundary: any diff to rag-api's reader in this fix is out of contract.

## 5. Contract test

Location: `apps/ai-server/tests/integration/test_api_contracts.py` (existing fixture- and AST-based static contract test patterns) or a sibling module reusing its conventions.

Structure:

1. **Worker side (real code path).** Build the failure payload by invoking the worker's failure-payload construction — e.g. a small extractable helper (or the exception-handler branch of `process_document` via a stubbed processor) — with a forced exception at a chosen stage. Assert payload keys `{error_message, stage, retryable}` (plus retained legacy `error`) and the derived `retryable` for a transient-classified and a permanent-classified exception.
2. **API side (real code path).** Feed that payload as `details` into `run_transactional_update` with a resource document at status `"processing"` in the Firestore emulator (both services already branch on `FIRESTORE_EMULATOR_HOST`; fakes are acceptable where the emulator is unavailable).
3. **Assertions.** Persisted doc: `error == payload["error_message"]`, `error_stage == payload["stage"]`, `retryable == payload["retryable"]`. `processing/summary` `error.message` and `error.stage` equal the same values.
4. **Drift guard.** A static (AST- or fixture-based) assertion pinning the worker's published key set and rag-api's `details.get(...)` key set to the contract (`error_message`, `stage`, `retryable`); any edit to either side's keys fails the build.
5. **Coverage.** At least two scenarios: early-stage failure (tracker = `"starting"` or `"processing"`) and late-stage failure (e.g. `"embeddings_complete"`), plus one transient and one permanent classification.

Known drift risk — a future pipeline step added without updating the tracker — is mitigated by the update-before-await convention and the representative-stage coverage; the drift guard makes silent removal of the tracker a build failure.

## 6. Data flow after the fix

```
process_document exception at stage S
  → failed status details: {error_message, stage: S, retryable: classify_error(e), error (legacy)}
  → Pub/Sub rag-status-updates
  → rag-api _process_status_message
  → run_transactional_update failed branch
  → doc: status=failed, error=<message>, error_stage=S, retryable=<derived>
  → processing/summary.error: {code: "UNKNOWN", message: <message>, stage: S}
  → GET /resources/{id}/status (ResourceResponse) exposes error + error_stage
```

## 7. Risks and tradeoffs

- **Unknown consumers of the status topic** reading the old single-key payload — mitigated by retaining `error` alongside `error_message`; residual risk accepted as low.
- **Stage-tracker drift** as the pipeline evolves — mitigated by the update-before-await convention + representative-stage test.
- **`retryable=false` for unclassified-unknown errors** (was silently `true`) — accepted; this is `classify_error`'s intended conservatism against infinite retry loops, and manual reprocess via `POST /process` is unaffected. Widening `classify_error` is out of scope.
- **Contract test ossifies the payload** — intentional; it is the drift guard.

## 8. Deferred / out of scope

Structured error codes; retry/backoff mechanics; stale-lease sweep behavior; frontend work; the companion D3 issue's scope beyond this alignment; reconciliation with `plans/upload-flow.md` D4 (file not present in the current tree).