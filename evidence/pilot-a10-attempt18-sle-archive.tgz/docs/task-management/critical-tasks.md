# Critical & Active Tasks

> This file is AI-maintained. Do not edit manually.
> Updated automatically on every task status change.

---

## In Progress

_No tasks currently in progress._

---

## Critical (not yet started)

- [RAG Agent types] → `docs/task-management/01-ai-processing.md`
- [Retry logic & error handling] → `docs/task-management/02-frontend-backend.md`
- [AI Chat error handling — failed message flow] → `docs/task-management/02-frontend-backend.md`
- [GDPR & Compliance] → `docs/task-management/06-business.md`
- [AppCheck implementation] → `docs/task-management/08-infrastructure-devops.md`
