# New-repo CI checklist — replicating the student-platform stack

Outcome: a repo with the same protection and CI shape as
`student-platform` — self-hosted heavy suites, cloud fast lane,
protected `main` requiring green checks + one human approval.

Preconditions: the dev server's runner pool exists (see
`self-hosted-runner-setup.md` + its 2026-08-27 addendum); you hold the
repo owner's `gh` auth (admin).

## 1. Runner registration (per repo, ~2 min, same box)

Runners are repo-scoped on personal accounts; each repo needs its own
registration. Token via API (no web UI needed):

```bash
TOKEN=$(gh api -X POST repos/<owner>/<repo>/actions/runners/registration-token --jq .token)
sudo -u github-runner bash -c "cd /opt/actions-runner-N && ./config.sh \
  --url https://github.com/<owner>/<repo> --token $TOKEN \
  --name <repo>-ci-1 --labels ci --work _work --unattended"
cd /opt/actions-runner-N && sudo ./svc.sh install github-runner && sudo ./svc.sh start
```

Use a fresh `/opt/actions-runner-N` directory per registration
(extract the runner tarball; same `github-runner` user, label `ci`).
Copy `runner-maintenance.yml` into the new repo and dispatch it once to
provision the Python tool cache.

## 2. Workflows to copy in

**How repo-agnostic is each artifact?** Copy-verbatim is not the norm —
know what adapts:

| Artifact | Per-repo work |
|---|---|
| `plans/README.md`, `.github/PULL_REQUEST_TEMPLATE.md` | **Verbatim** — none |
| `plans/ROADMAP.md` | **Verbatim** — reset `Last reviewed:` to today |
| `roadmap-freshness.yml` | **Verbatim** — the anti-rot guard, works unchanged |
| `AGENTS.md` | Trim the orientation section to the repo; workflow rules unchanged (includes the roadmap session-start contract) |
| `runner-maintenance.yml` | Extend the `/opt/actions-runner*` list with the new repo's runner dirs (one line) |
| `backend-tests.yml` + `ci-pip-install.sh` | **Template, not copy**: service lists in the detector, path globs, working-directory, matrix legs — light edits for another Python monorepo, substantial for a different stack (the four rules below are the portable part; the YAML around them is this repo's shape) |
| `mobile-tests.yml` | Only for repos with a Flutter app; adjust path globs otherwise drop |
| Protection API call | Verbatim; only `contexts` change if a repo has different gates |

The public `magtheo/ci-toolkit` exists (see `plans/ai-pr-review.md`
and its README): the AI reviewer ships from it today; the general CI
patterns (gate, runner maintenance, installs) migrate in
adoption-triggered per the plan's Phase 4.

From `student-platform` (adjust paths/matrices to the repo's stack):

- `.github/workflows/backend-tests.yml` — the full pattern:
  filterless `pull_request` trigger, `changes` detector, per-service
  matrices on `[self-hosted, ci]`, venv-isolated installs
  (`.github/scripts/ci-pip-install.sh`), `backend-summary` always-gate,
  `concurrency: cancel-in-progress`.
- `.github/workflows/mobile-tests.yml` — `detect` job + conditional
  test + `mobile-summary` gate (the required-check-existence pattern).
- `.github/workflows/runner-maintenance.yml` — verbatim.

Rules that must survive adaptation (each is load-bearing, see the
workflow headers for the war stories):

1. Required checks must report on EVERY PR — no path filters on
   `pull_request` triggers.
2. Gates use `if: always()` + explicit result validation; only
   `success`/`skipped` acceptable.
3. Heavy jobs: `[self-hosted, ci]`. Fast jobs: `ubuntu-latest`.
4. Nothing on self-hosted installs into the ambient interpreter —
   per-requirements venvs.

## 3. Governance files to copy

Copy source for everything in this section and section 2: **this
repository** (`student-platform`) — copy the files across, then adapt
per the notes. The checklist is the recipe; these files are the
ingredients.

- `AGENTS.md` (trim the orientation section to the repo),
  `plans/README.md`, `.github/PULL_REQUEST_TEMPLATE.md` — verbatim.
- `plans/ROADMAP.md` — verbatim, reset `Last reviewed:` to today, empty
  the sections; it is the repo's Now / Next / Later / Parked / Done
  overview. Agents read it at session start (contract in its header).
- Milestone convention (from `AGENTS.md` + `plans/README.md`): every
  feature gets a milestone titled `<feature-slug>` at start; every
  phase-PR description carries `Parent: #<feature-PR>`. PR numbers are
  a flat counter — the milestone is the family view, the Parent line
  is the visible link.

## 3b. AI reviewer install (from ci-toolkit)

Copy `.github/workflows/ai-review.yml` from this repo verbatim, set
the `LLM_API_KEY` secret (OpenRouter), and update BOTH SHA pins to a
reviewed ci-toolkit commit if a newer one is chosen. Optional: add a
repo-local `.ai-review-rubric.md` (resolved from PR base = trusted
policy; must match the toolkit's assessment schema — copy from this
repo's and adapt). Full contract: `docs/documentation/tooling/ai-pr-review.md`
and the ci-toolkit README.

## 4. Branch protection (requires GitHub Pro for private repos)

Solo/director-led repo (the student-platform model since 2026-08-28 —
checks + AI review + human read; see AGENTS.md "Review Model"):

```bash
gh api -X PUT repos/<owner>/<repo>/branches/main/protection --input - <<'EOF'
{
  "required_status_checks": {"strict": true, "contexts": ["backend-summary", "mobile-summary"]},
  "enforce_admins": false,
  "required_pull_request_reviews": {"required_approving_review_count": 0, "dismiss_stale_reviews": true},
  "restrictions": null,
  "allow_force_pushes": false,
  "allow_deletions": false
}
EOF
```

Team repo variant: set `required_approving_review_count` to `1` (or
more) so human approvals gate merges; the rest is identical.

Order matters: set the contexts only AFTER the workflows merged to
`main` (a required context that cannot exist blocks every PR).

## 5. Validate

- Scratch red PR (failing test in a collected path) → checks red,
  merge refused by policy.
- Docs-only scratch PR → heavy legs skipped by the detectors, both
  summaries green, blocked ONLY by the missing human approval.

## Cost

Self-hosted minutes: $0 on every plan. Hosted fast lane: seconds per
PR against Pro's included minutes. The only real cost is runner-box
RAM while jobs run.
