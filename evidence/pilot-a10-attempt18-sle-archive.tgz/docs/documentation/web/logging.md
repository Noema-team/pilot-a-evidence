# Logging System Documentation

## Overview

The StudentApp uses a comprehensive logging system to track all API requests and external service calls throughout the application. This helps with debugging, performance monitoring, and understanding data flow.

### Key Concept: Request/Response Flow Tracking

Every log entry clearly indicates:
- **Direction**: Is data going OUT (→) or coming IN (←)?
- **Type**: Is this a REQUEST (REQ) being sent/received, or a RESPONSE (RES) being sent/received?

This creates a clear 2×2 matrix:
- `[→ OUT] [REQ]` = Sending a request to another system
- `[← IN ] [REQ]` = Receiving a request from another system
- `[→ OUT] [RES]` = Sending a response back
- `[← IN ] [RES]` = Receiving a response back

## Architecture

The logging system consists of three main components:

1. **Client-Side Logger** (`client/src/lib/logger.ts`) - Logs API calls from the browser
2. **Server-Side Request Logger** (`server/middleware/requestLogger.ts`) - Logs incoming requests and outgoing responses
3. **External Service Logger** (`server/lib/externalLogger.ts`) - Logs calls to Firestore, AI services, and OCR

## Data Flow with Logging

```
Client Browser
  ↓ [→ OUT] [REQ] Client → Server/API
Server API
  ↓ [← IN ] [REQ] Server/API ← Client
  ↓ [→ OUT] [REQ] Server/API → Firestore/AI/OCR
External Service
  ↓ [← IN ] [RES] Server/API ← Firestore/AI/OCR
Server API
  ↓ [→ OUT] [RES] Server/API → Client
Client Browser
  ↓ [← IN ] [RES] Client ← Server/API
```

---

## Log Format

All logs follow a consistent format for easy reading:

```
[Timestamp] [Direction] [Type] Source → Destination | Method Path/Operation | Status | Duration
```

### Components:

- **Timestamp**: `[HH:MM:SS.mmm]` - Precise time with milliseconds
- **Direction**:
  - `[→ OUT]` - Outgoing (leaving current system)
  - `[← IN ]` - Incoming (arriving at current system)
  - `[✖ ERR]` - Error occurred
- **Type**:
  - `[REQ ]` - Request being sent/received
  - `[RES ]` - Response being sent/received
- **Source → Destination**: Shows the flow of data
- **Method Path/Operation**: HTTP method + API endpoint, or operation name
- **Status**: HTTP status code (200, 404, 500, etc.)
- **Duration**: Time taken in milliseconds

### Request/Response Matrix:

| Type | Direction | Meaning |
|------|-----------|---------|
| `[→ OUT] [REQ]` | Outgoing Request | Sending a request to another system |
| `[← IN ] [REQ]` | Incoming Request | Receiving a request from another system |
| `[→ OUT] [RES]` | Outgoing Response | Sending a response back |
| `[← IN ] [RES]` | Incoming Response | Receiving a response back |

---

## Color Coding

Logs use ANSI color codes for easy visual scanning in the terminal:

### Directions:
- **Cyan** `[→ OUT]` - Outgoing (requests and responses leaving the system)
- **Green** `[← IN ]` - Incoming (requests and responses arriving)
- **Red** `[✖ ERR]` - Errors

### Type Indicators:
- **Bright/Bold** `[REQ]` - Request
- **Bright/Bold** `[RES]` - Response

### Status Codes:
- **Green** - 2xx (Success)
- **Cyan** - 3xx (Redirect)
- **Yellow** - 4xx (Client Error)
- **Red** - 5xx (Server Error)

### Systems:
- **Blue** - Client (browser/frontend)
- **Magenta** - Server/API (Express backend)
- **Yellow** - Firestore (database)
- **Magenta** - AI services (OpenAI, Claude)
- **Cyan** - OCR services (Mistral)

---

## Example Logs

### 1. Simple GET Request (Client → Server → Firestore → Server → Client)

**Client sends request:**
```
[10:23:45.123] [→ OUT] [REQ] Client → Server/API | GET /api/courses | 0 B
```

**Server receives request:**
```
[10:23:45.125] [← IN ] [REQ] Server/API ← Client | GET /api/courses | from ::1
```

**Server queries Firestore:**
```
[10:23:45.126] [→ OUT] [REQ] Server/API → Firestore | getCourses | userId: abc123
```

**Firestore responds:**
```
[10:23:45.178] [← IN ] [RES] Server/API ← Firestore | getCourses | 200 | 52ms | 3 courses
```

**Server sends response to client:**
```
[10:23:45.180] [→ OUT] [RES] Server/API → Client | GET /api/courses | 200 | 55ms
  Response: [3 courses, 1.2 KB]
```

**Client receives response:**
```
[10:23:45.182] [← IN ] [RES] Client ← Server/API | GET /api/courses | 200 | 59ms
  Response: [{"id":"c1","name":"Math"}...]
```

---

### 2. POST Request with Body (Create Resource)

**Client sends request:**
```
[11:15:30.456] [→ OUT] [REQ] Client → Server/API | POST /api/resources | 245 B
  Body: {"title":"Notes","courseId":"c1","type":"note"}
```

**Server receives request:**
```
[11:15:30.458] [← IN ] [REQ] Server/API ← Client | POST /api/resources | from ::1
  Body: {"title":"Notes","courseId":"c1","type":"note"}
```

**Server calls AI for processing:**
```
[11:15:30.460] [→ OUT] [REQ] Server/API → AI | processContent | model: gpt-4
```

**AI responds:**
```
[11:15:31.234] [← IN ] [RES] Server/API ← AI | processContent | 200 | 774ms
```

**Server creates document in Firestore:**
```
[11:15:31.235] [→ OUT] [REQ] Server/API → Firestore | createResource
```

**Firestore responds:**
```
[11:15:31.289] [← IN ] [RES] Server/API ← Firestore | createResource | 200 | 54ms
```

**Server sends response:**
```
[11:15:31.290] [→ OUT] [RES] Server/API → Client | POST /api/resources | 201 | 834ms
  Response: {"id":"r1","title":"Notes",...}
```

**Client receives response:**
```
[11:15:31.292] [← IN ] [RES] Client ← Server/API | POST /api/resources | 201 | 836ms
  Response: [new resource created]
```

---

### 3. Error Scenario (Failed Request)

**Client sends request:**
```
[12:05:10.789] [→ OUT] [REQ] Client → Server/API | DELETE /api/resources/invalid | 0 B
```

**Server receives request:**
```
[12:05:10.791] [← IN ] [REQ] Server/API ← Client | DELETE /api/resources/invalid | from ::1
```

**Server queries Firestore:**
```
[12:05:10.792] [→ OUT] [REQ] Server/API → Firestore | getResource | resourceId: invalid
```

**Firestore responds with not found:**
```
[12:05:10.845] [← IN ] [RES] Server/API ← Firestore | getResource | 404 | 53ms | resource not found
```

**Server sends error response:**
```
[12:05:10.846] [→ OUT] [RES] Server/API → Client | DELETE /api/resources/invalid | 404 | 57ms
  Response: {"message":"Resource not found"}
```

**Client receives error:**
```
[12:05:10.848] [✖ ERR] [RES] Client ← Server/API | DELETE /api/resources/invalid | 56ms
  Error: 404: Resource not found
```

---

## Configuration

### Client-Side Logging

Client-side logging is automatically **enabled in development** and **disabled in production**.

**How it works:**
- Uses Vite's `import.meta.env.DEV` flag
- Logs only appear in browser console during development
- Zero performance impact in production builds

**Location:** `client/src/lib/logger.ts`

### Server-Side Logging

Server-side logging is **always enabled** for all requests.

**How it works:**
- Express middleware intercepts all requests
- Logs appear in server console/logs
- Includes request/response bodies (truncated if >500 bytes)

**Location:** `server/middleware/requestLogger.ts`

### External Service Logging

External service logging is **always enabled** for debugging and monitoring.

**How it works:**
- Manual calls to `logExternalRequest()` and `logExternalResponse()`
- Used in service layer code (Firestore operations, AI calls, OCR)
- Tracks duration automatically

**Location:** `server/lib/externalLogger.ts`

---

## Usage Examples

### Client-Side (Automatic)

The client logger is automatically integrated into `apiRequest()` function in `client/src/lib/queryClient.ts`.

**No manual logging needed** - all API calls are logged automatically!

```typescript
// This call is automatically logged:
const courses = await getCourses();

// Produces logs like:
// [→ OUT] Client → Server/API | /api/courses
// [← IN ] Client ← Server/API | /api/courses | 200 | 45ms
```

### Server-Side (Automatic)

The server logger is Express middleware in `server/index.ts`.

**No manual logging needed** - all incoming requests are logged automatically!

```typescript
// All routes automatically logged:
router.get('/courses', async (req, res) => {
  const courses = await storage.getCourses();
  res.json(courses);
});

// Produces logs like:
// [← IN ] Server/API ← Client | /api/courses
// [→ OUT] Server/API → Client | /api/courses | 200 | 52ms
```

### External Service Logging (Manual)

When calling external services, wrap your code with logging:

```typescript
import { logExternalRequest, logExternalResponse, logExternalError } from '@/lib/externalLogger';

// Example: Firestore query
async function getResource(id: string) {
  const requestId = logExternalRequest('Firestore', 'getResource', `resourceId: ${id}`);

  try {
    const doc = await adminDb.collection('resources').doc(id).get();
    logExternalResponse('Firestore', 'getResource', true, requestId);
    return doc.data();
  } catch (error) {
    logExternalError('Firestore', 'getResource', error, requestId);
    throw error;
  }
}

// Example: AI API call
async function callAI(prompt: string) {
  const requestId = logExternalRequest('AI', 'chat', `model: gpt-4`);

  try {
    const response = await openai.chat.completions.create({...});
    logExternalResponse('AI', 'chat', 200, requestId, `tokens: ${response.usage.total_tokens}`);
    return response;
  } catch (error) {
    logExternalError('AI', 'chat', error, requestId);
    throw error;
  }
}

// Example: OCR service
async function scanDocument(imageUrl: string) {
  const requestId = logExternalRequest('OCR', 'scan', `url: ${imageUrl}`);

  try {
    const result = await mistralOcr.scan(imageUrl);
    logExternalResponse('OCR', 'scan', true, requestId, `${result.text.length} chars`);
    return result;
  } catch (error) {
    logExternalError('OCR', 'scan', error, requestId);
    throw error;
  }
}
```

---

## Reading Logs

### Quick Tips:

1. **Follow the flow**: Look for matching timestamps to trace a single request end-to-end
2. **Check duration**: High duration numbers (>500ms) may indicate performance issues
3. **Look for errors**: Red `[✖ ERR]` entries indicate failures
4. **Match request IDs**: Each outgoing request has a corresponding incoming response
5. **Body inspection**: Small request/response bodies are logged inline for debugging

### Debugging Workflow:

1. **Find the initial client request** - Look for `[→ OUT] Client → Server/API`
2. **Follow to server** - Next line should be `[← IN ] Server/API ← Client`
3. **Track external calls** - Look for `Server/API → Firestore/AI/OCR`
4. **Check responses** - Verify `OK` status and reasonable duration
5. **Trace back to client** - Final `[← IN ] Client ← Server/API`

### Performance Analysis:

- **Client → Server**: Network latency (typically 5-50ms local, 50-200ms remote)
- **Server → Firestore**: Database query time (typically 20-100ms)
- **Server → AI**: AI processing time (typically 500-3000ms)
- **Server → OCR**: OCR processing time (typically 1000-5000ms)
- **Total round trip**: Sum of all durations

---

## Files Reference

### Client-Side:
- **`client/src/lib/logger.ts`** - Client-side logging functions
- **`client/src/lib/queryClient.ts`** - Integrated with `apiRequest()` function
- **`client/src/lib/api.ts`** - All API wrapper functions (automatically logged)

### Server-Side:
- **`server/middleware/requestLogger.ts`** - Express middleware for request/response logging
- **`server/lib/externalLogger.ts`** - External service logging functions
- **`server/index.ts`** - Middleware integration point
- **`server/routes/firebase.ts`** - API routes (all automatically logged)
- **`server/firebaseStorageNew.ts`** - Storage layer (manually add external service logging here)

---

## Best Practices

### DO:
✅ Use the logging system for debugging production issues
✅ Check logs when requests seem slow
✅ Add external service logging for new integrations
✅ Keep log messages concise and informative
✅ Include relevant context (IDs, parameters) in external service logs

### DON'T:
❌ Log sensitive data (passwords, tokens, API keys)
❌ Log large binary data (images, files)
❌ Remove existing logging code
❌ Disable logging in development
❌ Add console.log() instead of using the logging system

---

## Troubleshooting

### "Logs not appearing in browser console"
- **Check**: Are you in development mode? (`npm run dev`)
- **Reason**: Client logging is disabled in production builds
- **Solution**: Run the app in development mode

### "Too many logs, hard to read"
- **Solution**: Filter by searching for specific terms:
  - Search for `[✖ ERR]` to find only errors
  - Search for specific endpoint like `/api/courses`
  - Search for specific service like `Firestore`

### "Can't match request to response"
- **Solution**: Look for matching timestamps (within ~100ms)
- **Tip**: Each log entry shows the operation and direction

### "Missing logs for external service calls"
- **Reason**: Manual logging not added yet
- **Solution**: Add `logExternalRequest/Response/Error` calls around service calls
- **Reference**: See "External Service Logging (Manual)" section above

---

## Summary

The logging system provides comprehensive visibility into your application's data flow:

1. **Client logs** show when the browser sends/receives API requests
2. **Server logs** show when the API receives/responds to requests
3. **External service logs** show when the API calls Firestore, AI, or OCR

All logs follow a consistent format with color coding, making it easy to:
- Debug issues
- Monitor performance
- Understand data flow
- Track down errors

The system is production-ready with automatic client-side disabling and comprehensive server-side tracking.
