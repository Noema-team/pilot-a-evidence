---
tags:
  - TaskManagement
---
# GDPR & Compliance
#ToDo
User uploaded content must only be accessible to the specific user who uploaded it — both in direct form and indirectly through AI. AI-generated content cannot be shared between users. Content uploaded by the user will never be used to train any AI. See [[gdpr-compliance]] for policy details.

---
