# Web app documentation

Documentation for `apps/web` (React 18 + Vite frontend, Express backend).

These files were carried over from the pre-monorepo web repo, where they lived
in `apps/web/Z_Documentation/`. That folder is listed in `apps/web/.gitignore`,
so it was never committed and did not survive the monorepo migration — the
contents had to be copied over by hand.

They live here instead so they are tracked by git.

## Contents

| Document | Covers |
|----------|--------|
| `logging.md` | Logging system and standards |
| `refactor-to-independent-resources.md` | Implementation plan for restructuring resource management |
| `resource-status-v2-schema-contract.md` | Phase 1 schema contract for resource status V2 |

## Related

- `apps/web/AGENTS.md` — working guidance for the web app.

> **Note:** `apps/web/AGENTS.md` also lists `NEW_ARCHITECTURE.md` and
> `AI_CHAT_FLOW_DOCUMENTATION.md`. Those were not carried over from the old
> repo — copy them in if they are still wanted, or drop them from that list.
