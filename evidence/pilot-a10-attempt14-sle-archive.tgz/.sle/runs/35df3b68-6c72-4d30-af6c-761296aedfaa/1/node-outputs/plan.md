<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path=".sle/work/wi-define-108-a8/plan.md">>>
# Implementation Plan: rag-worker → rag-api failure payload contract alignment

WorkItem: `wi-define-108-a8` (Definition artifact `definition:obj-108`, sha256 `71f1c39c…`)
Run: 35df3b68-6c72-4d30-af6c-761296aedfaa · Iteration 1 · Step: plan

---

## 1. Goal (from the authoritative Definition)

When a RAG processing job fails, the worker's failed status payload must carry `error_message` (actual exception message), `stage` (failing pipeline stage), and `retryable` (deliberately derived via `classify_error`), and rag-api's failed branch must persist those values unchanged as `error` / `error_stage` / `retryable` — including the `processing/summary` error subdocument. A contract test pins the worker→rag-api failure path so key drift on either side fails the build.

Direction of fix: **the worker aligns to rag-api's existing contract** (F2, constraint 1). No rag-api reader/persistence changes, no Firestore migration, no schema rename, no backfill (constraint 2).

## 2. Verified current state (evidence used)

From the Definition's repository claims (binding): worker publishes `{"error": str(e)}` from `process_document`'s exception handler via `_publish_status_update` (F3); rag-api's `run_transactional_update` failed branch reads `error_message`/`stage`/`retryable` and persists `error`/`error_stage`/`retryable` plus `message`/`stage`/`error_code` ("UNKNOWN" default) in the processing/summary subdocument (F4); worker classifies errors via `classify_error()` and uses that for ACK/NACK (F7); worker has no stage tracking today (F9); stale-lease sweep and rag-api enqueue-failure paths already write the target schema (F6).

Directly verified in the repository during investigation:

- `apps/ai-server/rag-api-service/models/resource.py` — `Resource` has `error: Optional[str]`, `error_stage: Optional[str]`, `retryable: bool = True`; serialized in `to_dict()`/`from_dict()`. Confirms F6's persisted schema; untouched by this work.
- `apps/ai-server/rag-worker-service/exceptions.py` — `PDFProcessingError` carries a `.retryable` **metadata attribute**. Note: the Definition pins `classify_error(e)` as the *only* source for the payload's `retryable` (requirement 4). The exception attribute is **not consulted** — one source of truth, aligned with ACK/NACK. Documented here so the implementer does not "helpfully" wire the attribute in.
- `apps/ai-server/rag-worker-service/tests/conftest.py` — stubs `firebase_admin`, `google.cloud.pubsub_v1`, `google.cloud.firestore` (with `Increment`/`SERVER_TIMESTAMP`), OpenAI, langchain, etc., so `import main` works hermetically in worker tests.
- `apps/ai-server/rag-worker-service/tests/unit/test_processing_lease.py` — house pattern for exercising `main`'s Firestore write paths with `FakeDb`/`FakeTx`/`FakeRef` fakes plus `monkeypatch.setattr(main.firestore, "SERVER_TIMESTAMP", "TS", raising=False)` and a `_tx_identity` stand-in for `firestore.transactional`. It also pins that the sweep writes `retryable is True` on stale-lease failure (must remain true after this work).
- `apps/ai-server/rag-worker-service/pytest.ini` — `testpaths = tests`, `asyncio_mode = auto`.
- `apps/ai-server/tests/fixtures/api-contracts/resource_response.json` — mobile↔backend `ResourceResponse` fixture exposes `error`/`error_stage` (notably it does not list `retryable`; that fixture is out of scope and untouched per non-goals).
- `apps/ai-server/tests/integration/` — `conftest.py`, `test_api_contracts.py` and related integration tests exist (F10: fixture- and AST-based static contract tests; both services support a `FIRESTORE_EMULATOR_HOST` hermetic mode).
- `AGENTS.md` — branch/review workflow; validation via `./dev/run ai-server` (requires Docker Compose up).

**Explicitly unverified — confirm during implementation, do not assume:**
- Exact signature of `_publish_status_update` and how `details` flows into the published message (F3 pins behavior, not the signature).
- `classify_error()`'s return convention (string vs bool vs enum) and which concrete exception types it marks transient (F7 pins semantics, not the API shape).
- Exact parameter list, transaction structure, and Firestore paths of rag-api's `run_transactional_update`, and the exact shape of the `processing/summary` subdocument (F4 pins keys/fields, not shapes).
- Contents of `apps/ai-server/tests/integration/conftest.py` and the concrete emulator activation pattern.

## 3. Scope

### In scope
1. `apps/ai-server/rag-worker-service/main.py` — failure payload construction + stage tracking.
2. Worker unit tests (`apps/ai-server/rag-worker-service/tests/unit/`).
3. Contract test under `apps/ai-server/tests/integration/` (or appended to `test_api_contracts.py` if suite convention requires).
4. Test fixtures/fakes needed by (2) and (3).

### Out of scope (non-goals, from the Definition)
- rag-api code changes of any kind (readers, persistence, models, `ResourceResponse`).
- The stale-lease sweep `_fail_if_still_stale` — not touched, not even cosmetically (its `retryable=true` write stays correct: a dead worker is transient).
- Retry/backoff mechanics: Pub/Sub ACK/NACK policy, leases, heartbeat intervals.
- Structured error codes / failure taxonomy — summary `error.code` stays `"UNKNOWN"` unless a code is actually sent (none is).
- Frontend/mobile and the `resource_response.json` fixture.
- Everything the companion D3 issue covers beyond this payload alignment (F12, deferred).

## 4. Design

### 4.1 Failure payload builder (worker, new)

Add one module-level function in `rag-worker-service/main.py` (house style: underscore-prefixed module functions, cf. `_fail_if_still_stale`, `_claim_resource_if_queued`):

```python
UNKNOWN_STAGE = "processing"  # safe value when the failing stage is genuinely unknown;
                              # same value the stale-lease sweep uses for error_stage

def _build_failure_payload(exc: BaseException, stage: str | None) -> dict:
    message = str(exc)
    retryable = _is_transient(exc)   # thin adapter over classify_error, see 4.2
    return {
        "error_message": message,
        "stage": stage if stage else UNKNOWN_STAGE,
        "retryable": retryable,
        "error": message,  # legacy key retained for unknown status-topic consumers (F11 hedge)
    }
```

Decisions pinned here:

- **Key set is exactly `{error_message, stage, retryable, error}`.** The legacy `error` key duplicates `error_message` verbatim (compatibility hedge, constraint 4). The contract test asserts this exact key set — a deliberate drift guard.
- **`message = str(e)` literal.** No fabrication (no class-name substitution when the message is empty): the Definition requires persisting the worker-provided value unchanged, and a fabricated fallback on the worker side would recreate the very bug being fixed. Empty-string messages persist as empty strings.
- **`stage` fallback only when genuinely unknown** (`None`/empty → `"processing"`). The tracker initialization (4.3) means this fallback is defensive, not routine.
- `PDFProcessingError.retryable` is deliberately ignored (see §2).

### 4.2 retryable derivation (worker)

`retryable` maps 1:1 onto `classify_error()`'s classification, which already drives ACK/NACK in `run_worker` (F7, F8):

- transient-classified → `retryable: true` (Pub/Sub will redeliver);
- permanent-classified, including unclassified-unknown (`classify_error`'s conservative default) → `retryable: false` (acked; manual reprocess via `POST /process` remains).

Implement a tiny predicate next to `classify_error`:

```python
def _is_transient(exc: BaseException) -> bool:
    # Map classify_error(exc)'s actual return convention to bool:
    # transient → True, permanent/unknown → False.
```

The exact comparison depends on `classify_error`'s return convention — **to confirm at implementation time** (§2). Known deliberate behavior change (per Definition): unclassified-unknown exceptions previously persisted `retryable: true` via rag-api's silent default and will now persist `false`. This is accepted; widening `classify_error` is out of scope.

### 4.3 Stage tracking in `process_document` (worker)

`process_document` is one large try block with no stage state (F9). Fix:

1. Declare `current_stage = "starting"` at function entry, **before** the try, so the variable is always bound in the handler.
2. Set the tracker immediately before the first `await` of each pipeline phase, using the existing progress-stage vocabulary (F9): `starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`. Mapping rule: each phase gets the vocabulary name its completion progress-update already publishes for that phase; `starting` covers message receipt through pre-extraction setup.
3. Update convention (for this change and future editors): **assign the tracker immediately before the await** — one assignment per phase, no assignment inside retry loops within a phase.
4. In the exception handler, replace the `{"error": str(e)}` details with `_build_failure_payload(e, current_stage)` passed through `_publish_status_update` unchanged.
5. Success-path progress payloads are untouched — only the failure branch changes.

The failure stages therefore read naturally next to the progress timeline clients already see. Drift risk (a future pipeline step added without a tracker assignment) reports a stale-but-valid stage, never `None`; representative-stage contract coverage (§5.3) pins the mechanism without ossifying every step.

### 4.4 rag-api side

**No changes.** The failed branch already reads `error_message`/`stage`/`retryable` and persists them (F4). Once the worker speaks that contract: main document `error ← payload["error_message"]`, `error_stage ← payload["stage"]`, `retryable ← payload["retryable"]`; processing/summary error subdocument carries the same `message`/`stage` with `error_code` defaulting to `"UNKNOWN"` (no code is sent). Constraint 3 is satisfied because the worker now always sends all three keys — `details.get(..., default)` fallbacks remain in rag-api as harmless dead defaults for non-worker writers, which is out of scope to change.

## 5. Test plan

### 5.1 Worker unit tests — `apps/ai-server/rag-worker-service/tests/unit/test_failure_payload.py` (new)

Run under the existing worker conftest stubbing; import `main` hermetically (pattern proven by `test_processing_lease.py`).

| Case | Input | Assert |
|---|---|---|
| transient-classified error | exception type `classify_error` marks transient (pick a representative once the convention is confirmed) | `payload["retryable"] is True` |
| permanent-classified error | exception type classified permanent | `payload["retryable"] is False` |
| unclassified-unknown error | plain `Exception("boom")` | `payload["retryable"] is False` (conservative default; pins the deliberate behavior change) |
| message fidelity | `Exception("boom")` | `payload["error_message"] == "boom"` and `payload["error"] == payload["error_message"]` |
| stage passthrough | `stage="embeddings_complete"` | `payload["stage"] == "embeddings_complete"` |
| stage fallback | `stage=None` | `payload["stage"] == "processing"` |
| exact key set (drift guard A) | any input | `set(payload) == {"error_message", "stage", "retryable", "error"}` |

Plus one handler-invocation test where cheap: monkeypatch `_publish_status_update` to capture calls, monkeypatch one pipeline dependency to raise, invoke `process_document`, assert the published failure details equal `_build_failure_payload`'s output and carry the expected stage. Adapt to the actual call graph; if the pipeline's dependency surface makes this disproportionate, cover it instead at the contract level (§5.3) and note the substitution in the PR description.

### 5.2 Contract test — `apps/ai-server/tests/integration/test_rag_failure_contract.py` (new; or appended to `test_api_contracts.py` if that suite's convention requires)

Requirement 5 and acceptance criterion 4: the test must exercise the **worker's failure-payload construction through rag-api's failed-branch persistence** and fail if either side's keys drift. It imports both sides rather than restating the contract in a fixture.

**Mode A (default): fakes.** Import worker `main` (hermetic via the worker conftest stubbing pattern) and call `_build_failure_payload`; feed the returned dict into rag-api's `run_transactional_update` failed branch against fakes. Reuse the `FakeDb`/`FakeTx`/`FakeRef` transaction-recording pattern from `test_processing_lease.py` (extend as needed to support whatever read/write surface `run_transactional_update` actually uses — its signature and Firestore paths are to be confirmed, §2), including the `SERVER_TIMESTAMP` monkeypatch on the appropriate module reference. If fakes cannot express the transactional semantics the failed branch needs, fall back to Mode B.

**Mode B (fallback): Firestore emulator.** Use the services' existing `FIRESTORE_EMULATOR_HOST` branches (F10) following whatever activation pattern `apps/ai-server/tests/integration/conftest.py` already establishes (contents to be confirmed, §2). Seed a resource document, run the failed-branch update with the worker's payload, read back and assert.

**Cases and assertions (both modes):**

1. **Transient failure, late stage** — `_build_failure_payload(transient_exc, "embeddings_complete")` fed through the failed branch. Persisted main document: `error == payload["error_message"]` (assert it is the actual message, not rag-api's `"Processing failed"` fallback), `error_stage == "embeddings_complete"` (not `None`), `retryable is True`, status `"failed"`. Processing/summary error subdocument: `message` and `stage` equal the main document's values; `error_code == "UNKNOWN"`.
2. **Permanent/unknown failure, early stage** — plain `Exception`, stage `"starting"`. Persisted: `error` equals the message, `error_stage == "starting"`, `retryable is False`. This pins the deliberate `retryable: true → false` change for unclassified errors.
3. **Worker-side drift guard** — runtime key-set equality: `set(payload) == {"error_message", "stage", "retryable", "error"}`.
4. **API-side drift guard** — AST-based static check consistent with the existing pattern in `test_api_contracts.py` (F10): parse `apps/ai-server/rag-api-service/main.py`, locate `run_transactional_update`, and assert its failed branch reads the keys `error_message`, `stage`, and `retryable` from the details mapping (adapt the match to the actual variable naming). Complement with a static check that `rag-worker-service/main.py`'s exception handler references `_build_failure_payload` (guards the handler being bypassed and the tracker going unused).

If a key is renamed or dropped on either side, cases 1–4 fail the build instead of silently re-creating the fallback bug. That ossification is intentional — adding a key later means touching this test (Definition, §Risks).

### 5.3 Representative-stage coverage

The contract test's two cases double as the stage-tracker pins: an early-stage failure and a late-stage failure exercise tracker initialization and at least one mid/late assignment, enough to catch the tracker being removed or bypassed without asserting every pipeline step.

### 5.4 Regression guard

Existing worker unit tests — in particular `test_processing_lease.py`'s `test_genuinely_stale_lease_is_failed` asserting the sweep writes `retryable is True` — must keep passing untouched, proving the sweep path is unaffected.

## 6. Implementation steps

**Step 1 — Worker: payload builder + retryable derivation.**
In `rag-worker-service/main.py`: read `classify_error()` and the `process_document` exception handler and `_publish_status_update` call to confirm signatures (§2); add `UNKNOWN_STAGE`, `_is_transient`, `_build_failure_payload` per §4.1–4.2. Add `tests/unit/test_failure_payload.py` (§5.1).

**Step 2 — Worker: stage tracking.**
In `process_document`: initialize `current_stage = "starting"` before the try; insert tracker assignments immediately before each phase's first await using the §4.3 vocabulary (confirm the phase layout by reading the function — the exact step sequence inside `process_document` was not line-verified in this planning context); switch the handler to publish `_build_failure_payload(e, current_stage)`. Add the handler-invocation unit test if proportionate (§5.1).

**Step 3 — Contract test.**
Implement `test_rag_failure_contract.py` per §5.2: read rag-api's `run_transactional_update` failed branch and the integration `conftest.py` first; choose Mode A fakes (default) or Mode B emulator; implement the four cases.

**Step 4 — Verification and PR.**
Confirm zero code diffs under `rag-api-service/` (tests only live outside it) and zero diffs to `_fail_if_still_stale`, progress-payload code, models, and fixtures. Run validation (§7). Open one PR.

Branch guidance (per `AGENTS.md`): code changes touch one app (`ai-server`) — rag-worker code plus shared ai-server integration tests; no schema/migration, no security behavior, no new runtime dependencies, and `ResourceResponse` (the client-facing shape) is unchanged. This qualifies as a **small change**: `fix/rag-failure-payload-contract` → single PR to `main`. If a maintainer judges the inter-service status-topic payload a "cross-client contract change," escalate to the feature workflow instead — stop and ask rather than deciding unilaterally.

## 7. Validation

```bash
cd apps/ai-server/rag-worker-service && python -m pytest     # unit + hermetic worker tests
./dev/run ai-server                                          # app gates (requires Docker Compose up)
./dev/run --pack-only                                        # regenerate context pack, optional
```

If the contract test uses the emulator, also run the ai-server integration suite in the environment where the emulator is available (same precondition as the existing integration tests). rag-api's own suite (`apps/ai-server/rag-api-service/pytest.ini`) should still pass unchanged — it must, since rag-api code is untouched.

## 8. Acceptance criteria → coverage map

| Acceptance criterion (Definition) | Satisfied by |
|---|---|
| 1. Worker payload carries `error_message`/`stage`/`retryable`, no reliance on rag-api fallbacks | §4.1–4.3 worker change; §5.1 unit tests; §5.2 case 3 |
| 2. Persisted `error` = actual message (not "Processing failed"), `error_stage` = failing stage (not None), `retryable` = worker-derived | §4.4 (rag-api persists unchanged); §5.2 cases 1–2 |
| 3. processing/summary error subdocument carries same message and stage | §5.2 cases 1–2 subdocument assertions; `error_code` stays "UNKNOWN" |
| 4. Contract test on worker failure → rag-api persistence exists, passes, fails on key drift | §5.2 (both modes), §5.1 drift guard A + §5.2 case 4 drift guard B |

Constraints check: worker aligns to API (§4.4: zero rag-api code changes); no migration/rename/backfill (§3); `retryable` always explicit from the worker, API fallback no longer operative for worker failures (§4.2); legacy `error` retained (§4.1); no error-code taxonomy introduced (§3 non-goals).

## 9. Risks and tradeoffs

- **Unknown status-topic consumers reading the old key set** — mitigated by retaining `error` alongside `error_message`; residual risk accepted as low (F11 assumption; only rag-api's subscriber is verified).
- **Stage-tracker drift as the pipeline evolves** — mitigated by the assign-before-await convention and representative early/late-stage contract coverage.
- **`retryable=false` for unclassified-unknown errors** reduces auto-retry affordances for unrecognized-but-transient failures — accepted per the Definition; `classify_error` widening is out of scope; `POST /process` manual reprocess unaffected.
- **Contract test ossifies the payload** — intentional drift guard; adding a key means touching the test.
- **Implementation risks:** hermetically importing rag-api's `main` into integration tests may pull heavy dependencies (FastAPI/Firebase) — follow the existing integration conftest's approach; if import cost is prohibitive, prefer the emulator mode. Fakes must be extended to whatever `run_transactional_update` actually reads/writes — confirmed only after reading the failed branch (§2).

## 10. Open items to resolve during implementation (stop-and-ask if they contradict the Definition)

1. `classify_error` return convention and the concrete transient-representative exception type for tests.
2. `_publish_status_update` signature and details plumbing.
3. `run_transactional_update` parameter list, transaction structure, Firestore paths, and the `processing/summary` subdocument shape.
4. Emulator activation pattern in `apps/ai-server/tests/integration/conftest.py`; Mode A vs Mode B final choice.
5. Branch path confirmation (small change vs feature workflow) if the maintainers view the topic payload as a cross-client contract.

## 11. Definition of done

- [ ] Worker failure payload: `error_message`, `stage`, `retryable`, legacy `error`; exact key set pinned by tests.
- [ ] Stage tracker initialized and assigned before every phase await; handler reports it; fallback `"processing"` only when unknown.
- [ ] `retryable` derived solely from `classify_error` (transient → true, permanent/unknown → false).
- [ ] Zero code changes under `rag-api-service/`; zero changes to `_fail_if_still_stale`, progress payloads, models, fixtures.
- [ ] Worker unit tests + contract test (4 cases incl. both drift guards) implemented and green.
- [ ] Existing suites pass; `./dev/run ai-server` green.
- [ ] PR scoped to this plan; any deviation recorded and reviewed, never silent.
<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>