I've verified the Definition's claims against the repository: the worker's failure handler in `process_document` publishes only `{"error": str(e)}` while rag-api's `run_transactional_update` failed branch reads `error_message`/`stage`/`retryable` and persists `error`/`error_stage`/`retryable`; `classify_error()` exists with the conservative permanent-by-default semantics; the progress-stage vocabulary is `starting`/`text_retrieved`/`tagging_complete`/`summary_generated`/`chunking_complete`/`embeddings_complete`/`completed`; the stale-lease sweep already writes `error`/`error_stage: "processing"`/`retryable: True`; and the contract-test patterns plus emulator branches exist as described. The charter below scopes exactly this alignment.

<<<SLE-OUTPUT>>>
### docs/cycle-charter.md
# Cycle Charter

Cycle: 1c8e5995-97d1-4609-8272-38cebaab2195 (iteration 1)
Intent: "rag-worker → rag-api: failure payload contract mismatch — failures persist without message or stage"
Authoritative source: define-work WorkItem `wi-define-108-a8` (artifact `definition:obj-108`, sha256 `71f1c39c97ecea575b1195b63de510fa403dad4fecaa1df0c774d04fae89cac5`).

## Scope

Align the rag-worker's failure status payload with rag-api's failed-branch contract so that a failed RAG processing job persists the worker's actual error message, the failing pipeline stage, and a deliberately derived retryable flag — locked in by a contract test on the worker→rag-api failure path.

In scope (all within `apps/ai-server/`):

- **rag-worker-service/main.py — failure payload.** The `process_document` exception handler currently publishes `{"error": str(e)}` via `_publish_status_update`. Change it to publish `error_message` (the actual exception message), `stage` (the failing pipeline stage), and `retryable` (deliberately derived). Retain the legacy `error` key alongside `error_message` as a compatibility hedge for unverified consumers of the status topic.
- **rag-worker-service/main.py — stage tracking.** `process_document` is one large try block, so the failure handler cannot know where processing failed. Add a stage tracker (local variable or equivalent) set immediately before each pipeline await, using the existing progress-stage vocabulary: `starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`. When the stage is genuinely unknown (failure before the first transition), report `"processing"` — the same safe value the stale-lease sweep uses for `error_stage`.
- **rag-worker-service/main.py — retryable derivation.** Derive `retryable` from the existing `classify_error(e)`: transient-classified errors → `true`; permanent-classified errors, including unclassified-unknown exceptions (classify_error's conservative default) → `false`. This aligns the persisted record with the worker's actual ACK/NACK behavior in `run_worker` (transient = Pub/Sub redelivers; permanent = acked, manual reprocess via `POST /process` remains available).
- **rag-api-service/main.py — verification only.** The failed branch of `run_transactional_update` already reads `error_message`/`stage`/`retryable` and persists `error`/`error_stage`/`retryable` on the main document plus `message`/`stage` (with `error_code` defaulting to `"UNKNOWN"`) in the `processing/summary` error subdocument. No reader or schema changes are required; implementation verifies the worker-provided values persist unchanged.
- **Contract test.** A new contract test in `apps/ai-server/tests/integration/` (following the fixture- and AST-based patterns of `test_api_contracts.py`) covering the worker failure → rag-api persistence path: it must exercise the worker's failure-payload construction and feed it through rag-api's `run_transactional_update` (via the Firestore emulator or fakes — both services have hermetic `FIRESTORE_EMULATOR_HOST` branches), assert the persisted `error`, `error_stage`, and `retryable` equal the worker's values, and include a key-set drift guard so a future edit to either side's payload keys fails the build. Coverage must include at least an early-stage failure and a late-stage failure (representative stages), enough to catch the stage tracker being removed or bypassed without ossifying every pipeline step.

## Purpose

Every worker-originated processing failure currently persists garbage: the worker's one-key payload (`{"error": str(e)}`) misses all three keys rag-api's failed branch reads, so Firestore stores the fallback string `"Processing failed"` as `error`, `None` as `error_stage`, and a silently defaulted `retryable: true`. Users and support cannot disambiguate failures, and the persisted retryable flag misrepresents the worker's actual retry behavior.

The worker is the odd one out: the stale-lease sweep (`_fail_if_still_stale`), rag-api's enqueue-failure paths (`/process`, `POST /resources`), the `Resource` model, and `ResourceResponse` all already use the `error`/`error_stage`/`retryable` schema. Aligning the worker to that established contract requires no Firestore migration, field rename, or backfill, and no reader changes — fixing the API side instead would be the change that ripples.

Two deliberate behavior changes are accepted as part of this fix: (1) unclassified-unknown exceptions will persist `retryable: false` instead of the silent default `true` — that is the conservatism `classify_error` was written for and prevents infinite retry loops, with manual reprocess unaffected; (2) the failure payload grows a redundant legacy `error` key as insurance against unknown consumers of the status topic. Both are conscious tradeoffs recorded in the Definition, not accidents.

## Requirements

1. **Failure payload completeness.** When document processing fails, the worker's failed status payload must include `error_message` (the actual exception message), `stage` (the pipeline stage executing at failure time), and `retryable` (deliberately derived). The payload must never rely on rag-api's fallback defaults (`"Processing failed"`, `None`, `True`) for these keys.
2. **Stage tracking.** The worker must track the currently executing pipeline stage through `process_document` so the failure handler reports the true failing stage. Stage names must reuse the existing progress-stage vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown. Convention: set the tracker immediately before the await of each pipeline step.
3. **Persistence passthrough.** rag-api's failed branch must persist the worker-provided values unchanged: main document `error` ← payload `error_message`, `error_stage` ← payload `stage`, `retryable` ← payload `retryable`; the `processing/summary` error subdocument must carry the same message and stage (its `code` remains `"UNKNOWN"` unless a code is actually sent — no code is sent in this fix).
4. **Retryable derivation.** The retryable derivation must be explicit and aligned with the worker's ACK/NACK behavior: errors classified transient by `classify_error` → `retryable: true`; classified permanent (including unclassified-unknown, per `classify_error`'s conservative default) → `retryable: false`.
5. **Contract test.** A contract test covering the worker failure → rag-api persistence path must exist and pass: it exercises the worker's failure-payload construction through rag-api's failed-branch persistence (via the Firestore emulator or fakes, importing both sides rather than restating the contract in a fixture) and asserts the persisted `error`, `error_stage`, and `retryable` equal the worker's values. It must fail if either side's payload keys drift, and it must cover representative early- and late-stage failures.

Acceptance criteria (from the Definition, all currently unmet):

- A failed job's published status message contains `error_message`, `stage`, and `retryable` — none relying on rag-api's fallback defaults.
- After a failed job, the persisted resource document has `error` = the worker's actual error message (not `"Processing failed"`), `error_stage` = the failing stage (not `None`), and `retryable` = the worker's derived value.
- The `processing/summary` error subdocument for the failed job carries the same message and stage as the main document.
- The contract test described in requirement 5 exists and passes.

## Boundaries

Must:

- Align the worker to rag-api's existing contract (`error_message`/`stage`/`retryable`) rather than changing rag-api's reads or persisted schema.
- Send `retryable` explicitly on every worker-originated failure payload; rag-api's `details.get("retryable", True)` fallback must not be the operative mechanism for worker failures.

Must not:

- Require a Firestore migration, field rename, or backfill of existing documents; the persisted fields (`error`, `error_stage`, `retryable`) keep their names and semantics.
- Change the stale-lease sweep's direct failure write — it already persists `error`/`error_stage`/`retryable` consistently with this contract (its `retryable: true` stays correct: a dead worker is a transient condition).
- Change retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, or heartbeat intervals — only the *reporting* of retryability in the payload changes.
- Change frontend or mobile code — `ResourceResponse` already exposes `error` and `error_stage` to clients.
- Introduce structured error codes or a failure taxonomy — the `processing/summary` error `code` remains `"UNKNOWN"` unless a code is actually sent.

Prefer:

- Retain the legacy `error` key in the worker's failure payload alongside `error_message`, for continuity with any existing consumers of the status topic and log tooling.

Prefer not:

- Introducing a structured error-code taxonomy (`error_code` values) in this fix.

Risks and accepted tradeoffs: unknown consumers of the status topic (mitigated by retaining `error`; residual risk low); stage-tracker drift as the pipeline evolves (mitigated by the update-before-await convention and representative-stage test coverage); `retryable: false` for unclassified errors may reduce auto-retry for genuinely transient-but-unrecognized failures (accepted; widening `classify_error` is out of scope; manual reprocess remains); the contract test intentionally ossifies the payload — adding a key later means touching the test, which is the drift guard doing its job.

## Version bump

**Patch.** No data-model, schema, or migration changes; no cross-client contract changes (the persisted fields and `ResourceResponse` shape are unchanged — the worker's Pub/Sub payload keys are internal service-to-service surface); no security or permission behavior changes; no CI/workflow or build-config changes; no new runtime dependencies. Touches two services plus their shared tests, which is why this runs as a cycle under its charter rather than as a single-app small change. If implementation reveals otherwise (e.g. the contract test requires new test-only dependencies or workflow changes), stop and escalate per AGENTS.md before proceeding.

## Deferred items

- **Companion D3 issue (F12).** The Objective references a companion D3 issue filed alongside this one. Its scope is not available in this context; anything it covers beyond the worker→rag-api failure payload alignment is outside this Definition's bounded scope and deferred.
- **Reconciling with the original D4 deviation note.** `plans/upload-flow.md` (where deviation D4 was originally analyzed) is not present in the current tree; the reference comes from the Objective text only. Deferred.
- **Dropping the legacy `error` key.** If a later audit confirms the worker is the only publisher and rag-api the only consumer of the status topic, removing the duplicate key is trivial cleanup — deliberately out of scope here.
- **Widening `classify_error` coverage.** Genuinely transient-but-unrecognized failure types currently classify permanent. Widening the classifier is a separate change.
- **Structured error codes / failure taxonomy.** `processing/summary` error `code` stays `"UNKNOWN"`; introducing real codes is a separate effort.
- **Stale-lease sweep, retry/backoff, and lease mechanics.** Any change to the sweep's behavior, ACK/NACK policy, lease durations, or heartbeat intervals.
- **Frontend/mobile work.** None required; `ResourceResponse` already exposes `error` and `error_stage`.
<<<END-SLE-OUTPUT>>>