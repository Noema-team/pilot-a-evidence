"""
Guard: Python base images name their Debian release explicitly.

`FROM python:3.11-slim` does not pin an OS. It follows whichever Debian the
Python image maintainers consider current, so the distribution under a service
changes with no diff to review and no commit to point at — two services here
had silently moved from bullseye to bookworm that way, and would move again
when trixie takes over.

Naming the release makes an OS bump a deliberate change, which is what it is:
a different glibc, different apt package versions, and for this stack
different tesseract and poppler builds feeding PDF extraction.

Static check — reads the Dockerfiles, needs no Docker daemon.
"""

import re
from pathlib import Path

import pytest

AI_SERVER = Path(__file__).resolve().parents[2]
REPO_ROOT = AI_SERVER.parents[1]

# Service images, plus the hermetic test stack's own images — the same drift
# applies to anything the stack builds.
SEARCH_GLOBS = ("apps/ai-server/*/Dockerfile*", "dev/env/*/Dockerfile*")

# Debian releases the python images publish variants for. Add to this when
# moving forward; the point is that the choice is written down.
KNOWN_RELEASES = {"bookworm", "bullseye", "trixie"}

PYTHON_FROM = re.compile(r"^\s*FROM\s+(python:\S+)", re.MULTILINE)


def _all_dockerfiles() -> list[Path]:
    return sorted(
        p
        for glob in SEARCH_GLOBS
        for p in REPO_ROOT.glob(glob)
        if p.is_file()
    )


def _python_from_lines() -> list[tuple[Path, str]]:
    found = []
    for dockerfile in _all_dockerfiles():
        for image in PYTHON_FROM.findall(dockerfile.read_text()):
            found.append((dockerfile, image))
    assert found, "no python base images found — has the layout moved?"
    return found


@pytest.mark.parametrize(
    "dockerfile,image",
    _python_from_lines(),
    ids=lambda v: v if isinstance(v, str) else v.parent.name,
)
def test_python_base_image_names_its_debian_release(dockerfile: Path, image: str):
    if "alpine" in image:
        pytest.skip("alpine images are not Debian-based")

    assert any(release in image for release in KNOWN_RELEASES), (
        f"{dockerfile.relative_to(REPO_ROOT)} uses {image!r}, which does not name "
        f"a Debian release. Pin one (e.g. python:3.11-slim-bookworm) so the OS "
        f"under this service only changes when someone changes it."
    )


def test_multi_stage_builds_use_one_debian_release():
    """
    Builder and final stage must agree. Wheels compiled against one glibc and
    installed onto another is the classic way to get a green build and an image
    that fails at import.
    """
    for dockerfile in _all_dockerfiles():
        images = [i for i in PYTHON_FROM.findall(dockerfile.read_text()) if "alpine" not in i]
        releases = {r for image in images for r in KNOWN_RELEASES if r in image}

        assert len(releases) <= 1, (
            f"{dockerfile.relative_to(REPO_ROOT)} mixes Debian releases across "
            f"stages: {sorted(releases)} in {images}."
        )
