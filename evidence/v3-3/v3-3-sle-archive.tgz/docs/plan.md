# Implementation Plan — rag-worker → rag-api failure payload contract alignment

Run: 79e8a2e6-4caa-40de-8f8d-9d7160fc5b1e · Iteration 1 · Step: plan
Authoritative scope: WorkItem `wi-define-108-a8` (definition artifact `definition:obj-108`, sha256 `71f1c39c…`). Everything below implements that definition exactly; nothing outside it is in scope.

## 1. Problem (verified against the repository)

- `rag-worker-service/main.py` — `process_document`'s exception handler publishes the failed status with a one-key payload: `await self._publish_status_update(user_id, course_id, resource_id, "failed", {"error": str(e)}, job_id)`.
- `rag-api-service/main.py` — `run_transactional_update`'s failed branch reads three keys and persists them:
  - main doc: `error ← details.get("error_message", "Processing failed")`, `error_stage ← details.get("stage")`, `retryable ← details.get("retryable", True)`;
  - `processing/summary` subdoc: `error = {"code": details.get("error_code", "UNKNOWN"), "message": details.get("error_message", "Processing failed"), "stage": details.get("stage")}`.
- Consequence (verified by reading both sides): every worker-originated failure persists `error = "Processing failed"`, `error_stage = None`, `retryable = True` (silent default), and the summary error subdoc inherits the same fallbacks with `error_code = "UNKNOWN"`.
- The persisted schema `error` / `error_stage` / `retryable` is already spoken by three other writers and both response models: the worker's stale-lease sweep (`_fail_if_still_stale` writes `error`, `error_stage: "processing"`, `retryable: True` directly), rag-api's enqueue-failure paths, and `models/resource.py` (`Resource.error`, `Resource.error_stage`, `Resource.retryable: bool = True`, present in `to_dict`/`from_dict`). The worker's status publisher is the only writer that doesn't speak it.
- The worker already classifies every exception via `classify_error(e)` (verified: `TransientError` → True; `httpx.ConnectError/ConnectTimeout/ReadTimeout/WriteTimeout/PoolTimeout`, `ConnectionError`, `TimeoutError`, `asyncio.TimeoutError` → True; `httpx.HTTPStatusError` with 429/500/502/503/504 → True, other 4xx → False; `PermanentError` → False; **unknown exceptions → False/permanent, conservative default**) and uses that classification for ACK/NACK in `run_worker` (transient → omitted from ack_ids, Pub/Sub redelivers; permanent → acked).
- The worker publishes named stages in its progress updates (verified call sites in `process_document`): `starting`, `text_retrieved` (progress 20), `tagging_complete` (40), `summary_generated` (50), `chunking_complete` (60), `embeddings_complete` (80), final `completed` (100). The failure handler has no stage tracking today.
- `_publish_status_update` swallows its own exceptions (logs `status_publish_failed`, never raises) — the tracker only needs to cover the pipeline steps, not the publishes.

## 2. Design decisions

### D1 — Worker publishes the API's contract keys (worker aligns to API; rag-api production code unchanged)

Add a module-level pure helper in `rag-worker-service/main.py`, placed next to `classify_error`:

```python
def build_failure_details(e: Exception, stage: str) -> Dict[str, Any]:
    """Failure payload for the rag-status topic, matching rag-api's failed branch.

    rag-api's run_transactional_update reads error_message / stage / retryable
    and persists error / error_stage / retryable. The legacy `error` key is
    retained alongside error_message as a hedge for unknown consumers of the
    status topic (F11 hedge; drop later if an audit confirms rag-api is the
    only consumer).
    """
    message = str(e)
    return {
        "error_message": message,        # rag-api persists as main-doc `error`
        "stage": stage,                  # rag-api persists as `error_stage`
        "retryable": classify_error(e),  # deliberately derived, never defaulted
        "error": message,                # legacy key, retained for compatibility
    }
```

The `process_document` exception handler becomes:

```python
except Exception as e:
    metrics.error_message, metrics.end_time = str(e), time.time()
    failure_details = build_failure_details(e, current_stage)
    self.logger.error("document_processing_failed", user_id=user_id, course_id=course_id,
                      resource_id=resource_id, error=str(e), stage=current_stage,
                      retryable=failure_details["retryable"])
    await self._publish_status_update(user_id, course_id, resource_id, "failed",
                                      failure_details, job_id)
    if trace: trace.update(output={"success": False, "error": str(e), "stage": current_stage})
    return metrics
```

Rationale for the helper: it makes the payload construction a pure, importable function, which is exactly what the contract test must exercise ("the worker's failure-payload construction") without standing up Firebase/Pub/Sub/OpenRouter. `classify_error` is called exactly once per failure and its result is used for both the payload and the log line.

Payload key set (pinned by test): `{error_message, stage, retryable, error}`. No structured error codes are introduced (constraint: prefer_not; rag-api's `error_code` keeps defaulting to `"UNKNOWN"`).

### D2 — retryable is derived, not defaulted

`retryable = classify_error(e)`, per the adopted default (F8):

| Exception class (verified `classify_error` behavior) | retryable | ACK/NACK behavior today |
|---|---|---|
| `TransientError` | `true` | NACK → Pub/Sub redelivers |
| `httpx.ConnectError/ConnectTimeout/ReadTimeout/WriteTimeout/PoolTimeout`, `ConnectionError`, `TimeoutError`, `asyncio.TimeoutError` | `true` | NACK → redelivers |
| `httpx.HTTPStatusError` 429/500/502/503/504 | `true` | NACK → redelivers |
| `PermanentError` | `false` | acked, no redelivery |
| `httpx.HTTPStatusError` other 4xx | `false` | acked |
| anything unclassified (e.g. `ValueError`, `PermissionError`, `RuntimeError`, tenacity `RetryError`) | `false` | acked (conservative default) |

Deliberate behavior change (documented, accepted): unclassified-unknown exceptions currently persist `retryable: true` via rag-api's silent default; they will now persist `false`, matching the worker's actual ack-and-don't-retry behavior. Manual reprocess via `POST /process` is unaffected. Widening `classify_error` is out of scope. The stale-lease sweep's separate direct write (`retryable: True`) is untouched and stays correct — a dead worker is a transient condition.

Edge noted, deliberately not special-cased: an exception whose `str(e)` is empty persists an empty `error_message`/`error`. That is the "actual message" verbatim, per the binding requirement; the contract stays exact rather than inventing a fallback string. Revisit only if it surfaces as a support problem.

### D3 — Stage tracking in `process_document`

A single local, initialized before the `try`, set immediately before each pipeline step, read by the exception handler:

```python
current_stage = "processing"   # safe value: failure before the first transition
try:
    await self._validate_processing_request(...)          # stage stays "processing"
    current_stage = "starting"
    await self._publish_status_update(..., {"stage": "starting"}, job_id)
    current_stage = "text_retrieved"
    text_content, doc_metadata = await self._get_extracted_text(...)
    ...
```

Full mapping (tracker semantics: the milestone the executing step is working toward; set immediately before the await — the convention that prevents drift):

| Step in `process_document` (verified call) | `current_stage` set to | When |
|---|---|---|
| function entry / trace setup / `_validate_processing_request` | `"processing"` (initial value) | before `try` |
| first status publish (`{"stage": "starting"}`) | `"starting"` | immediately before the call |
| `_get_extracted_text` | `"text_retrieved"` | immediately before the await |
| `content_tagger.generate_tags` | `"tagging_complete"` | immediately before the await |
| `generate_document_summary` + ragDescription Firestore write | `"summary_generated"` | immediately before the summary await |
| `_create_enhanced_chunks` | `"chunking_complete"` | immediately before the await |
| `_generate_embeddings_with_openrouter` | `"embeddings_complete"` | immediately before the await |
| `delete_old_vectors_via_service`, `store_chunks_via_service`, `_save_processing_metadata_to_subcollection`, `_update_user_usage`, `_generate_resource_map` | `"processing"` | set once, immediately after the `embeddings_complete` publish (unlabeled phase) |

Decisions embedded in the mapping:

- The vocabulary is exactly the six progress labels plus `"processing"` (binding requirement). `"processing"` is used both for "before the first transition" (the definition's own example: validation failure) and for the post-embedding vector-storage phase, which has no label in the progress vocabulary. Alternative considered and rejected: leaving the tracker at `"embeddings_complete"` during `store_chunks_via_service` would report a milestone that actually completed. With the mapping above, a failure during `store_chunks_via_service` (the only raise-capable step in that phase — `delete_old_vectors_via_service` and the metadata/usage/map writers swallow their exceptions, verified) reports `"processing"`, the same honest value the stale-lease sweep uses, and `error_stage` never regresses to null.
- Observed-but-unchanged: exceptions that mostly cannot reach the handler (`generate_document_summary` returns `None` on most failures; tenacity-`@retry` exhaustion on summary/embeddings surfaces as `RetryError` → classified permanent → `retryable: false`). This is `classify_error`'s existing conservatism applied consistently; no classification changes in this fix.

### D4 — rag-api side: zero production changes

Verified: `run_transactional_update` already reads `error_message`/`stage`/`retryable` and persists them unchanged into `error`/`error_stage`/`retryable` plus the summary error subdoc; `ResourceResponse`/`Resource` already expose the persisted fields. Changing rag-api's reads or schema is explicitly forbidden by the definition (must-not: no migration, no rename, no backfill). Two verified behaviors the tests must account for:

- Transition guard: `ALLOWED_TRANSITIONS` allows `processing → failed`; a test must seed the resource doc with `status: "processing"` or the update silently no-ops (`invalid_status_transition`).
- Idempotence: if the sweep already marked the doc `failed`, a late worker `failed` message hits `new_status == current_status` and returns — no corruption.

### D5 — Contract test architecture

New module `apps/ai-server/tests/integration/test_worker_failure_payload_contract.py`, following the house pattern of `tests/integration/test_api_contracts.py` (which imports `main as rag_api_main` and uses AST/subprocess static checks). Three layers, detailed in docs/test-plan.md:

1. Behavioral seam test: build the payload with the worker's `build_failure_details` (real code), feed it through rag-api's real `run_transactional_update` against the Firestore emulator, assert persisted `error`/`error_stage`/`retryable` and the summary error subdoc equal the worker's values.
2. Mechanism test: drive the real `process_document` on a `__new__`-constructed processor with monkeypatched pipeline steps to prove the tracker reports the right stage for an early-stage and a late-stage failure (representative stages, per the definition — not every step).
3. Drift guards: a behavioral key-set pin on `build_failure_details` plus a negative probe through `run_transactional_update` (payload carrying only the legacy `error` key must persist the `"Processing failed"` fallback — proving rag-api reads `error_message`, not `error`).

## 3. Changes by file

| File | Change |
|---|---|
| `apps/ai-server/rag-worker-service/main.py` | (a) add `build_failure_details(e, stage)` near `classify_error`; (b) in `process_document`: initialize `current_stage = "processing"` before `try`, insert the tracker assignments per the D3 table, rewrite the exception handler to publish `build_failure_details(e, current_stage)` and log `stage`/`retryable`. |
| `apps/ai-server/rag-api-service/*` | **None** (production code). Verified reads already match the contract. |
| `apps/ai-server/tests/integration/test_worker_failure_payload_contract.py` | New contract-test module (see docs/test-plan.md). |
| `apps/ai-server/tests/integration/conftest.py` | Possibly extended for worker-module import env stubs — **contents not read during investigation; verify first**, extend only if needed. |
| Existing worker tests asserting the old `{"error": str(e)}` payload | Unknown whether any exist (`rag-worker-service/tests/unit/` not read). Grep at implementation time; update assertions to the new payload. |

## 4. Implementation steps (ordered)

1. **Verify pre-flight unknowns** (no code changes): read `tests/integration/conftest.py` (how `sys.path`, emulator, and `import main as rag_api_main` are wired); read `rag-worker-service/exceptions.py` (ensure the new helper doesn't duplicate something already there — if `exceptions.py` is the natural low-import home for `build_failure_details`, prefer it; `classify_error` currently lives in `main.py` and can be imported from there); grep worker tests for the old failure payload.
2. **Worker payload helper**: add `build_failure_details` to `rag-worker-service/main.py` (or `exceptions.py` per step 1 findings) with the exact key set from D1.
3. **Worker stage tracker + handler rewrite**: apply D3 and the handler rewrite; keep `metrics.error_message`, logging, and trace behavior; no changes to `_publish_status_update` itself.
4. **Contract test module**: implement per docs/test-plan.md (behavioral seam tests T1–T4, mechanism tests T5–T8, drift guards T9–T10).
5. **Run**: new contract module green; existing `tests/integration/test_api_contracts.py` green; worker and rag-api unit suites green; update any stale payload assertions found in step 1.
6. **Acceptance walkthrough** against §5.

## 5. Acceptance criteria mapping

| Definition acceptance criterion | Proven by |
|---|---|
| AC1 — worker's failed status payload contains `error_message` (actual message), `stage` (failing stage), `retryable` (derived); no reliance on API fallbacks | `build_failure_details` (D1/D2) + mechanism tests T5–T8 capturing the published details + key-set pin T9 |
| AC2 — persisted main doc: `error` = actual message (not "Processing failed"), `error_stage` = failing stage (not None), `retryable` = worker's derived value | Behavioral seam tests T1–T3 against the emulator |
| AC3 — `processing/summary` error subdoc carries the same message and stage | T1/T2 assertions on `error.message`/`error.stage` (and `error.code == "UNKNOWN"`) |
| AC4 — contract test exists, passes, and fails on key drift on either side | The new module; drift matrix in docs/test-plan.md §4 (T9 catches worker-side key drift; T10 catches rag-api read-key drift) |

## 6. Risks and tradeoffs (from the definition, plus findings)

- **Unknown consumers of the status topic** reading the old key set — mitigated by retaining `error` alongside `error_message`; residual risk accepted as low; dropping the duplicate later is trivial cleanup.
- **Stage-tracker drift** as the pipeline evolves — mitigated by the "set immediately before the await" convention and representative early/late-stage tests; adding a labeled step without updating the tracker is caught only if it breaks a covered stage — accepted per the definition.
- **`retryable: false` for unclassified errors** may reduce auto-retry affordances for unrecognized-but-transient failures — accepted; widening `classify_error` is out of scope; manual reprocess via `POST /process` remains.
- **Contract test ossifies the payload** — intentional; that is the drift guard.
- **Worker module import weight in the test process** (found during investigation): `rag-worker-service/main.py` at import time requires `GCP_PROJECT` and `GOOGLE_APPLICATION_CREDENTIALS` env (raises otherwise), constructs a `pubsub_v1.SubscriberClient` from a service-account file, and pulls heavy deps (langchain, openai, langfuse, spacy, sklearn, tiktoken). Mitigations, in order: env stubs + a test-only dummy credential file fixture; if credential parsing blocks, generate a throwaway RSA key in the fixture; if the full import proves unfeasible in the integration env, fall back to (a) placing the worker-side tests under `rag-worker-service/tests/` where its requirements are the norm, or (b) a subprocess-based harness (house pattern already uses subprocess). Decided at implementation time per step 1; the contract semantics do not change.
- **Emulator vs fakes**: both services have verified `FIRESTORE_EMULATOR_HOST` branches, so the emulator path is primary; a fake `db` must emulate `@firestore.transactional` + `db.transaction()` (nontrivial) and is the fallback only.

## 7. Explicit non-goals (binding)

- No changes to the stale-lease sweep's direct failure write.
- No changes to retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals — only the *reporting* of retryability changes.
- No frontend/mobile changes (`ResourceResponse` already exposes `error`/`error_stage`).
- No structured error-code taxonomy; summary `error.code` stays `"UNKNOWN"` unless a code is actually sent (worker sends none).
- No rag-api reader/persistence changes; no Firestore migration, rename, or backfill.
- Anything the companion D3 issue covers beyond this payload alignment is deferred (its content is unavailable in this context), as is reconciling with the D4 deviation note in `plans/upload-flow.md` (file not present in the current tree).

## 8. Unknowns carried forward (not invented)

- Contents of `apps/ai-server/tests/integration/conftest.py` — unread; determines import/emulator wiring for the new test module.
- Contents of `apps/ai-server/rag-worker-service/exceptions.py` — unread; checked in step 1 for helper placement/duplication.
- Whether existing worker unit tests assert the old `{"error": str(e)}` payload — unread; grep in step 1.
- Exact CI provisioning of the Firestore emulator for `tests/integration/` — inferred available (both services ship emulator branches; `docker-compose.yml` exists) but the harness wiring must be confirmed in step 1.