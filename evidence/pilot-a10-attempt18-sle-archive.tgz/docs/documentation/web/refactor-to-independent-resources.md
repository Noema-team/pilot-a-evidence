# Resource Management Restructuring - Implementation Plan

## Overview

Restructure the Firestore data model so that:

1. All resources are stored in a single `users/{userId}/resources` collection (not split between `courseResources` and `ungroupedResources`)
2. Resources use `course_ids: string[]` and `group_ids: string[]` arrays for many-to-many relationships
3. A new `resourceGroups` collection is added for grouping resources
4. Courses reference resources/groups via `connected_resources` and maintain a `_resolved` cache

**Approach**: Clean break - no backward compatibility needed. Status field is read-only (external service updates it).

---

## Firestore Structure (Target)

```
users/{userId}/
  resources/{resourceId}
    - id, originalFilename, extractedText, processedAt, userId, title
    - extractedImages, tags, originBook, originChapterName/Number, originPageFrom/To
    - status: 'pending' | 'processing' | 'completed' | 'failed'  (read-only, set by external service)
    - storage_url?: string
    - group_ids: string[]
    - course_ids: string[]
    - createdAt, updatedAt

  resourceGroups/{groupId}
    - id, name, description?, userId
    - resource_ids: string[]
    - resource_count: number (auto-maintained)
    - createdAt, updatedAt

  courses/{courseId}
    - id, name, description?, userId, icon, color
    - connected_resources: { resources: string[], groups: string[] }
    - _resolved: { resource_ids: string[], resource_count: number, updated_at: Date }
    - createdAt, updatedAt
```

---

## Implementation Steps

### Step 1: Type Definitions

#### 1.1 Create `shared/types/resourceGroup.types.ts` (NEW)

```typescript
export interface ResourceGroup {
  id: string;
  name: string;
  description?: string;
  userId: string;
  resource_ids: string[];
  resource_count: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateResourceGroupInput { name, description?, userId, resource_ids? }
export interface UpdateResourceGroupInput { name?, description? }
export interface ResourceGroupResponse { /* dates as ISO strings */ }
```

#### 1.2 Update `shared/types/resource.types.ts`

- Remove: `courseId?: string`
- Add: `group_ids: string[]`, `course_ids: string[]`
- Add: `status: 'pending' | 'processing' | 'completed' | 'failed'`
- Add: `storage_url?: string`, `createdAt?: Date`, `updatedAt?: Date`
- Update `ResourceFilters` to filter by `course_ids`/`group_ids` arrays
- Remove `moveResourceToCourseSchema` related types

#### 1.3 Update `shared/types/course.types.ts`

- Add: `ConnectedResources { resources: string[], groups: string[] }`
- Add: `ResolvedResources { resource_ids: string[], resource_count: number, updated_at: Date }`
- Add to Course: `connected_resources`, `_resolved`

---

### Step 2: Validation Schemas

#### 2.1 Create `shared/validation/resourceGroup.schemas.ts` (NEW)

- `createResourceGroupSchema`: name (1-100), description?, resource_ids?
- `updateResourceGroupSchema`: partial updates (name?, description?)
- `addResourcesToGroupSchema`: { resource_ids: string[] }
- `removeResourcesFromGroupSchema`: { resource_ids: string[] }

#### 2.2 Update `shared/validation/resource.schemas.ts`

- Remove: `courseId` from create/update schemas
- Remove: `moveResourceToCourseSchema`
- Add: `group_ids`, `course_ids` as optional arrays (default [])
- Add: `status` as enum (default 'completed')
- Add: `connectToCoursesSchema`: { course_ids: string[] }
- Add: `addToGroupsSchema`: { group_ids: string[] }

#### 2.3 Update `shared/validation/course.schemas.ts`

- Add: `connectResourcesSchema`: { resource_ids?: string[], group_ids?: string[] }
- Add: `disconnectResourcesSchema`: same structure

---

### Step 3: Services

#### 3.1 Create `server/services/resourceGroups.service.ts` (NEW)

**Functions:**

- `getResourceGroupById(userId, groupId)` → ResourceGroup
- `getUserResourceGroups(userId)` → ResourceGroup[]
- `createResourceGroup(input)` → ResourceGroup
- `updateResourceGroup(userId, groupId, updates)` → ResourceGroup
- `deleteResourceGroup(userId, groupId)` → void (cascade: remove from resources, courses)
- `addResourcesToGroup(userId, groupId, resourceIds)` → ResourceGroup (transaction: update group + resources)
- `removeResourcesFromGroup(userId, groupId, resourceIds)` → ResourceGroup (transaction)
- `toResourceGroupResponse(group)` → ResourceGroupResponse

**Key pattern - bidirectional transaction for adding resource to group:**

```typescript
await db.runTransaction(async (transaction) => {
  // 1. Update group: add to resource_ids[], increment resource_count
  // 2. Update resource: add groupId to group_ids[]
});
```

**Key pattern - bidirectional transaction for removing resource from group:**

```typescript
await db.runTransaction(async (transaction) => {
  // 1. Update group: remove from resource_ids[], decrement resource_count
  // 2. Update resource: remove groupId from group_ids[]
});
```

#### 3.2 Rewrite `server/services/resources.service.ts`

**Remove:**

- `getResourceCollectionPath()` dual-collection logic
- `moveResourceToCollection()` function
- Searches across two collections

**Simplify to single collection:** `users/{userId}/resources`

 

**Update functions:**

- `getResourceById()` - single collection lookup
- `getUserResources(filters)` - query single collection, filter by course_ids/group_ids arrays
- `createResource()` - initialize group_ids: [], course_ids: []
- `updateResource()` - no more collection migration
- `deleteResource()` - transaction: remove from all groups/courses, then delete

**Add functions:**

- `getResourcesByIds(userId, resourceIds)` → Resource[]
- `connectResourceToCourses(userId, resourceId, courseIds)` → Resource (transaction)
- `disconnectResourceFromCourses(userId, resourceId, courseIds)` → Resource (transaction)
- `addResourceToGroups(userId, resourceId, groupIds)` → Resource (transaction)
- `removeResourceFromGroups(userId, resourceId, groupIds)` → Resource (transaction)

#### 3.3 Update `server/services/courses.service.ts`

**Update `createCourse()`:**

- Initialize `connected_resources: { resources: [], groups: [] }`
- Initialize `_resolved: { resource_ids: [], resource_count: 0, updated_at }`

**Update `deleteCourse()`:**

- Transaction: remove courseId from all connected resources' `course_ids`

**Add functions:**

- `connectResourcesToCourse(userId, courseId, resourceIds)` → Course
- `disconnectResourcesFromCourse(userId, courseId, resourceIds)` → Course
- `connectGroupsToCourse(userId, courseId, groupIds)` → Course
- `disconnectGroupsFromCourse(userId, courseId, groupIds)` → Course
- `recomputeResolved(userId, courseId)` → void
- `getCourseResolvedResourceIds(userId, courseId)` → string[]

**Key pattern - bidirectional transaction for connecting resource to course:**

```typescript
await db.runTransaction(async (transaction) => {
  // 1. Update course: add resourceId to connected_resources.resources[]
  // 2. Update course: recompute _resolved (resource_ids[], resource_count, updated_at)
  // 3. Update resource: add courseId to course_ids[]
});
```

**Key pattern - bidirectional transaction for disconnecting resource from course:**

```typescript
await db.runTransaction(async (transaction) => {
  // 1. Update course: remove resourceId from connected_resources.resources[]
  // 2. Update course: recompute _resolved (resource_ids[], resource_count, updated_at)
  // 3. Update resource: remove courseId from course_ids[]
});
```

**Key pattern - connecting group to course:**

```typescript
await db.runTransaction(async (transaction) => {
  // 1. Update course: add groupId to connected_resources.groups[]
  // 2. Update course: recompute _resolved (flatten all group resources + direct resources)
});
```

**Remove:**

- `getCourseTags()`, `getCourseBooks()`, `getCourseResourceCount()` - these query old `courseResources` collection

#### 3.4 Update `server/services/ocr.service.ts`

**Update `createResource()` call:**

- Change from `courseId?: string` to `course_ids: []`, `group_ids: []`
- Add `status: 'pending'` (or let external service set it)

---

### Step 4: API Routes

#### 4.1 Create `server/routes/resourceGroups.routes.ts` (NEW)

|Method|Endpoint|Description|
|---|---|---|
|GET|`/api/resource-groups`|List user's groups|
|GET|`/api/resource-groups/:id`|Get group by ID|
|POST|`/api/resource-groups`|Create group|
|PATCH|`/api/resource-groups/:id`|Update group|
|DELETE|`/api/resource-groups/:id`|Delete group (cascade)|
|POST|`/api/resource-groups/:id/resources`|Add resources to group|
|DELETE|`/api/resource-groups/:id/resources`|Remove resources from group|

#### 4.2 Update `server/routes/resources.routes.ts`

**Remove:**

- `PATCH /api/resources/:id/course` - no longer needed

**Add:**

|Method|Endpoint|Description|
|---|---|---|
|POST|`/api/resources/:id/courses`|Connect resource to courses|
|DELETE|`/api/resources/:id/courses`|Disconnect resource from courses|
|POST|`/api/resources/:id/groups`|Add resource to groups|
|DELETE|`/api/resources/:id/groups`|Remove resource from groups|

#### 4.3 Update `server/routes/courses.routes.ts`

**Remove:**

- `GET /api/courses/:id/tags` - relied on old collection
- `GET /api/courses/:id/books` - relied on old collection

**Add:**

|Method|Endpoint|Description|
|---|---|---|
|POST|`/api/courses/:id/resources`|Connect resources/groups to course|
|DELETE|`/api/courses/:id/resources`|Disconnect resources/groups from course|
|GET|`/api/courses/:id/resolved-resources`|Get flattened resource list|
|POST|`/api/courses/:id/recompute`|Force recompute _resolved|

#### 4.4 Update `server/index.ts`

Register new routes:

```typescript
import resourceGroupsRoutes from "./routes/resourceGroups.routes";
app.use('/api/resource-groups', verifyFirebaseToken, resourceGroupsRoutes);
```

---

## Files to Modify/Create

### New Files

1. `shared/types/resourceGroup.types.ts`
2. `shared/validation/resourceGroup.schemas.ts`
3. `server/services/resourceGroups.service.ts`
4. `server/routes/resourceGroups.routes.ts`

### Modified Files

1. `shared/types/resource.types.ts`
2. `shared/types/course.types.ts`
3. `shared/validation/resource.schemas.ts`
4. `shared/validation/course.schemas.ts`
5. `server/services/resources.service.ts` (major rewrite)
6. `server/services/courses.service.ts`
7. `server/services/ocr.service.ts` (minor)
8. `server/routes/resources.routes.ts`
9. `server/routes/courses.routes.ts`
10. `server/index.ts`

---

## Implementation Order

1. **Types first** - no dependencies
2. **Validation schemas** - depend on types
3. **ResourceGroups service** - new, independent
4. **Resources service** - major rewrite
5. **Courses service** - depends on resources/groups services
6. **OCR service** - minor update
7. **Routes** - depend on services
8. **Register routes** in index.ts

---

## Key Technical Notes

### Bidirectional Updates Summary

|Operation|Updates on Target|Updates on Resource|
|---|---|---|
|Add resource to group|`resource_ids[]` += resourceId, `resource_count`++|`group_ids[]` += groupId|
|Remove resource from group|`resource_ids[]` -= resourceId, `resource_count`--|`group_ids[]` -= groupId|
|Connect resource to course|`connected_resources.resources[]` += resourceId, recompute `_resolved`|`course_ids[]` += courseId|
|Disconnect resource from course|`connected_resources.resources[]` -= resourceId, recompute `_resolved`|`course_ids[]` -= courseId|
|Connect group to course|`connected_resources.groups[]` += groupId, recompute `_resolved`|(no change to resources)|
|Disconnect group from course|`connected_resources.groups[]` -= groupId, recompute `_resolved`|(no change to resources)|

### Transaction Pattern

All bidirectional updates use Firestore transactions to ensure atomicity:

```typescript
await db.runTransaction(async (transaction) => {
  // Read all documents first
  const groupDoc = await transaction.get(groupRef);
  const resourceDoc = await transaction.get(resourceRef);

  // Then write all updates atomically
  transaction.update(groupRef, {
    resource_ids: FieldValue.arrayUnion(resourceId),
    resource_count: FieldValue.increment(1),
    updatedAt: Timestamp.now()
  });
  transaction.update(resourceRef, {
    group_ids: FieldValue.arrayUnion(groupId),
    updatedAt: Timestamp.now()
  });
});
```

### _resolved Computation

Called after any change to `connected_resources`:

1. Start with `connected_resources.resources` (direct resources)
2. For each group in `connected_resources.groups`, add its `resource_ids`
3. Deduplicate and update `_resolved.resource_ids`, `_resolved.resource_count`, `_resolved.updated_at`

### Cascade Deletes

- **Delete resource**:
    - Update all groups: remove from `resource_ids[]`, decrement `resource_count`
    - Update all courses: remove from `connected_resources.resources[]`, recompute `_resolved`
- **Delete group**:
    - Update all resources: remove from `group_ids[]`
    - Update all courses: remove from `connected_resources.groups[]`, recompute `_resolved`
- **Delete course**:
    - Update all connected resources: remove from `course_ids[]`
