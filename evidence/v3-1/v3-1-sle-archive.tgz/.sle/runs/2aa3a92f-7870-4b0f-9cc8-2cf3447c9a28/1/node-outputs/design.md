Design complete. Both contracted artifacts follow, derived from the authoritative definition and the repository evidence verified during investigation (rag-api `run_transactional_update` failed branch, `_process_status_message` envelope parsing, `Resource`/`ResourceResponse` models, the emulator startup branch, `tests/integration/test_api_contracts.py` patterns, and the worker fake/transactional test kit in `tests/unit/test_processing_lease.py`).

<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path="docs/requirements.md">>>
# Requirements — rag-worker → rag-api failure payload contract alignment

- **Cycle intent:** rag-worker → rag-api: failure payload contract mismatch — failures persist without message or stage
- **Authoritative source:** WorkItem `wi-define-108-a8`, artifact `definition:obj-108` (sha256 `71f1c39c97ecea575b1195b63de510fa403dad4fecaa1df0c774d04fae89cac5`)
- **Step:** design (planning depth: minimal)
- **Status:** Proposed — implements the Definition exactly; no widening, narrowing, or reinterpretation

---

## 1. Problem statement

When RAG document processing fails, the worker's exception handler publishes a one-key failure payload
(`{"error": str(e)}`) while rag-api's failed branch reads three keys (`error_message`, `stage`, `retryable`).
Because of the key mismatch, every worker-originated failure currently persists in Firestore as:

| Persisted field | Actual value today | Required value |
|---|---|---|
| `error` | fallback `"Processing failed"` | the worker's actual exception message |
| `error_stage` | `None` | the failing pipeline stage |
| `retryable` | silent default `True` | a deliberately derived value |

The `processing/summary` error subdocument inherits the same fallbacks, with `error_code` always `"UNKNOWN"`.
Users and support cannot disambiguate failures. The seam between the two services is untested.

## 2. Goals

1. Align the worker's failure status payload to rag-api's existing failed-branch contract
   (`error_message` / `stage` / `retryable`) — the worker is the odd writer out; three other write paths
   (worker stale-lease sweep, rag-api `/process` and `POST /resources` enqueue-failure paths) and both
   response models already speak the `error` / `error_stage` / `retryable` persisted schema.
2. Persist the worker's real error message, the true failing pipeline stage, and a deliberately derived
   `retryable` flag on every worker-originated failure.
3. Lock the seam with a contract test that fails the build if either side's payload keys drift.

## 3. Scope

### 3.1 In scope

- `apps/ai-server/rag-worker-service/main.py`: stage tracking in `process_document`; failure-payload
  construction in the exception handler; `retryable` derivation from `classify_error()`; retention of the
  legacy `error` key.
- `apps/ai-server/rag-api-service/main.py`: **no behavioral change** — the failed branch of
  `run_transactional_update` already reads the correct keys; it is pinned, not modified.
- New contract test covering the worker failure → rag-api persistence path, using existing house patterns
  (`apps/ai-server/tests/integration/test_api_contracts.py` fixture/AST style; the fake
  transaction/Firestore kit proven in `apps/ai-server/rag-worker-service/tests/unit/test_processing_lease.py`).

### 3.2 Out of scope (non-goals, binding)

- Changing rag-api's reads or persisted schema; any Firestore migration, field rename, or backfill.
- Changing the stale-lease sweep's direct failure write (it already persists `error`/`error_stage`/
  `retryable` consistently; its `retryable=true` stays correct — a dead worker is a transient condition).
- Changing retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals — only
  the *reporting* of retryability changes.
- Frontend or mobile changes — `ResourceResponse` already exposes `error`/`error_stage` to clients.
- Introducing structured error codes or a failure taxonomy — the summary `error.code` remains `"UNKNOWN"`
  unless a code is actually sent.
- Anything the companion D3 issue covers beyond this payload alignment (its content is unavailable in this
  context; deferred), and reconciling this analysis with the D4 deviation note referenced in
  `plans/upload-flow.md` (file not present in the current tree).

## 4. Terms

- **Failure payload:** the `details` dict the worker publishes on the status topic inside the envelope
  `{user_id, course_id, resource_id, status, details}` for `status = "failed"`.
- **Stage:** the pipeline step executing at failure time, named from the existing progress-stage vocabulary.
- **Drift guard:** a test assertion that pins the exact key sets on both sides of the seam so a future
  rename/addition on either side fails the build.
- **Deliberately derived:** `retryable` is computed by the worker from `classify_error(e)`; it is never the
  result of rag-api's `details.get("retryable", True)` fallback for worker failures.

## 5. Functional requirements

### FR-1 (must) — Failure payload carries the full contract
When document processing fails, the worker's failed status payload `details` must include:
- `error_message`: the actual exception message (`str(e)`),
- `stage`: the pipeline stage executing at failure time,
- `retryable`: a boolean derived per FR-3.

The payload must never rely on rag-api's fallback defaults (`"Processing failed"`, `None`, `True`) for these
keys. Traceability: acceptance A1, A2; constraints C1, C3; facts F1, F3, F4, F5.

### FR-2 (must) — Stage tracking through `process_document`
The worker must track the currently executing pipeline stage through `process_document` so the failure
handler reports the true failing stage. Stage names must reuse the existing progress-stage vocabulary
(`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`,
`embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown (e.g.,
failure before the first stage transition). The value `"processing"` matches the stale-lease sweep's
`error_stage` convention, so the field never regresses to null. Traceability: acceptance A1, A2; fact F9.

### FR-3 (must) — Explicit `retryable` derivation aligned with ACK/NACK
The worker must derive `retryable` from `classify_error(e)` — the same classification that drives ACK/NACK
in `run_worker`:
- transient-classified errors → `retryable: true` (Pub/Sub will redeliver),
- permanent-classified errors, **including unclassified-unknown** (per `classify_error`'s conservative
  default) → `retryable: false` (message acked; manual reprocess via `POST /process` remains available).

Deliberate behavior change accepted: unclassified-unknown exceptions previously persisted the silent default
`true`; they now persist `false`. Traceability: acceptance A2; constraint C3; facts F7, F8.

### FR-4 (must) — rag-api persists worker-provided values unchanged
rag-api's failed branch must persist the worker-provided values unchanged:
- main document: `error` ← payload `error_message`; `error_stage` ← payload `stage`; `retryable` ← payload `retryable`;
- `processing/summary` error subdocument: `error.message` ← payload `error_message`; `error.stage` ← payload
  `stage` (and the summary `stage` field likewise); `error.code` remains `"UNKNOWN"` unless a code is sent.

No change to rag-api's reads, the persisted field names, or the envelope parsing in `_process_status_message`
(which forwards `details` verbatim). Traceability: acceptance A2, A3; constraints C1, C2; fact F4.

### FR-5 (should — preferred) — Retain the legacy `error` key
The worker's failure payload must retain the legacy `error` key (same value as `error_message`) alongside the
new keys, as a compatibility hedge for any unverified consumer of the status topic and for log tooling.
rag-api ignores this key (verified: the failed branch does not read `details["error"]`). Traceability:
constraint C4 (prefer); fact F11.

### FR-6 (must) — Contract test on the worker → rag-api failure path
A contract test must cover the worker failure → rag-api persistence path. It must:
1. exercise the worker's failure-payload construction through the worker's real code path (not a fixture
   restatement of the contract),
2. feed that payload through rag-api's `run_transactional_update` failed-branch persistence (Firestore
   emulator or fakes),
3. assert the persisted `error`, `error_stage`, and `retryable` equal the worker's payload values, and the
   summary subdocument carries the same message and stage,
4. fail if either side's payload keys drift (see FR-7).

Traceability: acceptance A4; fact F10.

### FR-7 (must) — Key-set drift guard
The contract test must pin the exact contract key sets:
- worker side: the published `details` key set must equal `{error_message, stage, retryable, error}`;
- api side: the set of `details` keys read by `run_transactional_update`'s failed branch must equal
  `{error_message, stage, retryable, error_code}` (with `error_code` documented as allowed-missing,
  defaulting to `"UNKNOWN"`);
- the intersection `{error_message, stage, retryable}` is the binding seam.

Any addition, removal, or rename on either side must fail the test. Traceability: acceptance A4.

## 6. Contract specification

### 6.1 Worker failure payload (status topic)

Envelope (unchanged, verified in `_process_status_message`): `user_id`, `course_id`, `resource_id`,
`status` (`"failed"`), `details`.

`details` for `status = "failed"` (new worker behavior):

| Key | Type | Source | Notes |
|---|---|---|---|
| `error_message` | str | `str(e)` from the exception handler | actual exception message |
| `stage` | str | stage tracker in `process_document` | progress vocabulary; `"processing"` if unknown |
| `retryable` | bool | `classify_error(e)` → transient=True, permanent/unknown=False | always present |
| `error` | str | same as `error_message` | legacy key retained (FR-5); ignored by rag-api |

### 6.2 rag-api failed-branch persistence mapping (unchanged, pinned)

| Payload key | Main document field | Summary subdocument field |
|---|---|---|
| `error_message` | `error` | `error.message` |
| `stage` | `error_stage` | `error.stage` (and summary `stage`) |
| `retryable` | `retryable` | — |
| `error_code` (optional) | — | `error.code` (default `"UNKNOWN"`) |

Fallbacks (`"Processing failed"`, `None`/`"unknown"`, `True`) remain in rag-api for non-worker publishers but
must never engage for worker failures (guaranteed by FR-1).

### 6.3 Stage vocabulary

`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`,
`embeddings_complete` — identical to the progress-update stage names — plus the safe fallback
`"processing"`. No new stage names are introduced.

## 7. Non-functional requirements

- **NFR-1 (must):** No Firestore migration, field rename, or backfill of existing documents; persisted
  fields `error`/`error_stage`/`retryable` keep their names and semantics.
- **NFR-2 (must):** The contract test runs hermetically (fakes by default; no live GCP dependencies), using
  the fake transaction/Firestore kit and `firestore.transactional`/`SERVER_TIMESTAMP` monkeypatch patterns
  already proven in the worker unit suite.
- **NFR-3 (should):** The worker's failure log line records the derived `stage` and `retryable` alongside the
  message, so the persisted record and the logs agree (incidental to the handler change; no new logging
  framework).
- **NFR-4 (must):** No changes to Pub/Sub ACK/NACK policy, lease, or heartbeat mechanics.

## 8. Constraints (from the Definition — binding)

- **C1 (must):** Align the worker to rag-api's existing contract (`error_message`/`stage`/`retryable`);
  do not change rag-api's reads or persisted schema.
- **C2 (must_not):** No fix requiring a Firestore migration, field rename, or backfill.
- **C3 (must):** Every worker-originated failure payload carries `retryable` explicitly; rag-api's
  `details.get("retryable", True)` fallback must not be the operative mechanism for worker failures.
- **C4 (prefer):** Retain the legacy `error` key alongside `error_message`.
- **C5 (prefer_not):** Do not introduce a structured error-code taxonomy.

## 9. Acceptance criteria

- **A1:** A failed job's status message published by the worker contains `error_message` (actual exception
  message), `stage` (failing pipeline stage), and `retryable` (deliberately derived) — none relying on
  rag-api's fallback defaults.
- **A2:** After a failed job, the persisted resource document has `error` = the worker's actual error message
  (not `"Processing failed"`), `error_stage` = the failing stage (not `None`), and `retryable` = the worker's
  derived value.
- **A3:** The `processing/summary` error subdocument for the failed job carries the same message and stage as
  the main document.
- **A4:** A contract test covering the worker failure → rag-api persistence path exists and passes: it
  exercises the worker's failure-payload construction through rag-api's failed-branch persistence and asserts
  the persisted `error`, `error_stage`, and `retryable` equal the worker's values, failing if either side's
  payload keys drift.

## 10. Test requirements

- **TR-1 (must):** Worker-side unit tests build the failure payload through `process_document`'s real
  exception handler (publisher captured via fake/monkeypatch), covering: an early-stage failure, a late-stage
  failure, an unclassified-unknown exception (`retryable` false), and a failure before any stage transition
  (`stage == "processing"`). Location: `apps/ai-server/rag-worker-service/tests/unit/`.
- **TR-2 (must):** Cross-service contract test feeds the worker-built payload through
  `run_transactional_update`'s failed branch against fakes (or the Firestore emulator) with the source
  document seeded at `status: "processing"` (the only state that legally transitions to `failed`), and
  asserts main-document and summary-subdocument persistence equality. Location:
  `apps/ai-server/tests/integration/` (new module alongside `test_api_contracts.py`).
- **TR-3 (must):** Drift guards per FR-7: dynamic key-set assertion on the captured worker payload, plus a
  static extraction (AST, following the `_get_agent_graph_shapes` precedent) of the `details` keys read in
  rag-api's failed branch, both compared against pinned contract constants.
- **TR-4 (should):** Representative-stage coverage only (early + late failure) — enough to catch the stage
  tracker being removed or bypassed without ossifying every pipeline step.

## 11. Traceability matrix

| Requirement | Acceptance | Constraints | Facts |
|---|---|---|---|
| FR-1 | A1, A2 | C1, C3 | F1, F3, F4, F5 |
| FR-2 | A1, A2 | C1 | F9 |
| FR-3 | A2 | C3 | F7, F8 |
| FR-4 | A2, A3 | C1, C2 | F4, F6 |
| FR-5 | A1 | C4 | F11 |
| FR-6, FR-7 | A4 | C1 | F10 |
| NFR-1 | — | C2 | F6 |
| NFR-2 | A4 | — | F10 |

## 12. Deferred / open items

- **D-1:** Companion D3 issue referenced by the Objective — content unavailable in this context; anything it
  covers beyond the worker→rag-api failure payload alignment is out of scope (fact F12).
- **D-2:** Reconciling this design with deviation D4 in `plans/upload-flow.md` — the file is not present in
  the current tree; deferred.
- **D-3:** Dropping the legacy `error` key — trivial cleanup only if a later audit confirms the worker is the
  only publisher and rag-api the only consumer of the status topic (fact F11).
- **D-4:** Widening `classify_error`'s heuristics — explicitly out of scope; the conservative
  unknown→permanent→`retryable:false` behavior is accepted (fact F8).
<<<END-SLE-ARTIFACT>>>
<<<SLE-ARTIFACT path="docs/architecture.md">>>
# Architecture — rag-worker → rag-api failure payload contract alignment

- **Cycle intent:** rag-worker → rag-api: failure payload contract mismatch — failures persist without message or stage
- **Implements:** `docs/requirements.md` (source: WorkItem `wi-define-108-a8`, artifact `definition:obj-108`, sha256 `71f1c39c…`)
- **Design stance:** the worker aligns to the API; the API is pinned, not changed; the seam is locked by a contract test.

---

## 1. Context: current state (verified)

### 1.1 The failure path today

```
rag-worker                                rag-api
──────────                                ───────
process_document                          _process_status_message
  └─ exception handler                      └─ parses envelope {user_id, course_id,
       └─ _publish_status_update                resource_id, status, details}
            └─ Pub/Sub "rag-status-updates" ──▶ run_transactional_update (failed branch)
                                                 ├─ main doc:  error   ← details.get("error_message", "Processing failed")
                                                 │             error_stage ← details.get("stage")            → None
                                                 │             retryable ← details.get("retryable", True)     → True
                                                 └─ summary:   error.{code,message,stage}
                                                               code ← details.get("error_code", "UNKNOWN")
```

- **Worker publishes:** `details = {"error": str(e)}` (Definition F3).
- **rag-api reads:** `error_message`, `stage`, `retryable`, optionally `error_code` (verified in
  `run_transactional_update`, `apps/ai-server/rag-api-service/main.py`).
- **Result (F5):** every worker failure persists `error = "Processing failed"`, `error_stage = None`,
  `retryable = True`; the summary error subdocument inherits the fallbacks with `error_code = "UNKNOWN"`.

### 1.2 Why the worker is the fix site

The persisted schema `error` / `error_stage` / `retryable` is already written consistently by three other
paths — the worker's stale-lease sweep (`_fail_if_still_stale`), and rag-api's enqueue-failure paths
(`/process`, `POST /resources`) — and exposed by the `Resource` model (`retryable` defaults `True`) and
`ResourceResponse` (`error`, `error_stage`) (F6, verified in `models/resource.py` and `main.py`). The
worker's status publisher is the only writer that doesn't speak the schema. Changing the API side would be
the change that ripples; changing the worker requires no migration, rename, or backfill.

### 1.3 Established facts the design relies on

- The worker classifies every exception via `classify_error()` (TransientError/PermanentError plus type- and
  status-code heuristics; unknown → permanent) and uses that for ACK/NACK in `run_worker` (F7).
- Progress updates already publish the stage vocabulary `starting`, `text_retrieved`, `tagging_complete`,
  `summary_generated`, `chunking_complete`, `embeddings_complete`, `completed` — but the failure handler has
  no stage tracking today (F9).
- `run_transactional_update` gates transitions: only `processing → failed` is legal, so a failed-branch test
  must seed the source document at `status: "processing"` (verified `ALLOWED_TRANSITIONS`).
- `_process_status_message` forwards `details` verbatim into `run_transactional_update` — the envelope needs
  no change (verified).
- Contract-test infrastructure exists: `apps/ai-server/tests/integration/test_api_contracts.py`
  (fixture- and AST-based), and both services support a hermetic Firestore-emulator mode
  (`FIRESTORE_EMULATOR_HOST` branch verified in rag-api's `startup()`) (F10).

## 2. Design principles

1. **Fix the odd one out.** The worker adopts the API's key names; nothing else moves.
2. **Derive, don't default.** Every failure payload value is computed by the worker; rag-api's fallbacks
   become dead code on this path instead of the operative mechanism.
3. **Pin the seam.** The contract is enforced by a test that imports both sides rather than restating the
   contract in a fixture.
4. **Hedge cheaply.** One redundant legacy key (`error`) insures unknown status-topic consumers (F11).

## 3. Target architecture

### 3.1 Worker: stage tracker in `process_document`

`process_document` is one large try block, so at failure time nothing knows where it was. The fix is a
stage tracker:

- A local variable (e.g. `current_stage`) initialized to `"starting"` at the top of the try block.
- **Convention: set the tracker immediately before each pipeline step/await.** The tracker value for a step
  is the same stage string that step's progress update uses, so a failure stage reads naturally next to the
  progress timeline clients already see (F9 vocabulary; no new names).
- The exception handler reads the tracker; if the failure occurs before the first transition (tracker never
  advanced meaningfully), the reported stage is `"processing"` — the same safe value the stale-lease sweep
  uses for `error_stage`, so the field never regresses to null (FR-2).

Known drift risk — a future pipeline step added without updating the tracker reports a stale stage — is
mitigated by the set-before-await convention plus representative-stage test coverage (early + late failure),
which catches the tracker being removed or bypassed without ossifying every step (TR-4).

### 3.2 Worker: failure payload construction

The exception handler in `process_document` builds and publishes, via `_publish_status_update`, a failure
payload whose `details` is:

```python
{
    "error_message": str(e),          # actual exception message
    "stage": current_stage,           # tracker value; "processing" if genuinely unknown
    "retryable": retryable,           # from classify_error(e) — see 3.3
    "error": str(e),                  # legacy key retained (FR-5); ignored by rag-api
}
```

The envelope (`user_id`, `course_id`, `resource_id`, `status="failed"`, `details`) is unchanged.
The handler's log line records `stage` and `retryable` alongside the message (NFR-3).

### 3.3 Worker: retryable derivation

```python
classification = classify_error(e)          # existing function, unchanged
retryable = (classification is transient)   # transient → True; permanent/unknown → False
```

- transient → `retryable: true` — Pub/Sub will redeliver (NACK path), so the record says "retryable".
- permanent, **including unclassified-unknown** (per `classify_error`'s conservative default) →
  `retryable: false` — the message is acked and will not return; manual reprocess via `POST /process`
  remains.
- Deliberate behavior change: unclassified-unknown exceptions previously persisted the silent default
  `true`; they now persist `false`. This is the conservatism `classify_error` was written for (prevents
  infinite retry loops); accepted per the Definition (F8).
- The stale-lease sweep's separate direct write keeps `retryable: true` — a dead worker is a transient
  condition by nature; the sweep is untouched (non-goal).

### 3.4 rag-api: failed branch (pinned, not modified)

`run_transactional_update`'s failed branch already implements the required mapping and is left as-is:

| Payload key | Main document | Summary subdocument |
|---|---|---|
| `error_message` | `error` | `error.message` |
| `stage` | `error_stage` | `error.stage` (and summary `stage`) |
| `retryable` | `retryable` | — |
| `error_code` (optional) | — | `error.code`, default `"UNKNOWN"` |

Notes pinned by the contract test:
- Because the worker always sends `stage`, neither the main-doc `error_stage = None` nor the summary
  `stage = "unknown"` fallback engages.
- Because the worker always sends `retryable`, the `details.get("retryable", True)` fallback never operates
  for worker failures (C3). The fallback remains for other publishers — unchanged.
- Summary `progress` defaults to `0` on failure (existing behavior; the failure payload does not carry
  progress — out of scope).
- The legacy `error` key is not read by rag-api (verified) — it exists only for unknown consumers (FR-5).

### 3.5 Contract test module

New module: `apps/ai-server/tests/integration/test_worker_failure_contract.py`, alongside the existing
`test_api_contracts.py` (whose fixture/AST patterns it follows).

**Module-loading design.** Both services name their entry module `main`, and a single pytest process cannot
import both under that name. The existing `test_api_contracts.py` does `import main as rag_api_main`
(relying on the integration conftest putting rag-api-service on `sys.path` — conftest contents not
inspected; the new module must be self-sufficient). The new module loads each service tree explicitly with
`importlib.util.spec_from_file_location` under unique names (e.g. `rag_worker_main`, `rag_api_contract_main`).

Import-time requirements (verified from rag-api `main.py`): constructing `AppState(ApiConfig())` requires
the settings without defaults — `gcp_project`, `google_application_credentials`, `shared_internal_token` —
so the test sets dummy env values before loading; Firebase/Pub/Sub clients are only created in
`startup()`, not at import, so loading is side-effect-safe. The worker's `main` is import-safe in tests
(verified: the worker unit suite imports it directly).

**Persistence harness.** Reuse the fake kit proven in
`rag-worker-service/tests/unit/test_processing_lease.py` against `run_transactional_update`:

- `FakeDb/FakeTx/FakeRef/FakeCollection/FakeSnap` — `FakeTx` records `update`/`set(merge=True)` writes and
  `get()` returns current doc state; `FakeRef.get(transaction=…)` and
  `FakeRef.collection("processing").document("summary")` match the shapes `run_transactional_update` uses.
- `firestore.transactional` monkeypatched to an identity (`_tx_identity`) — valid here because the
  decorator is applied inside `run_transactional_update` at call time, not at module import.
- `firestore.SERVER_TIMESTAMP` monkeypatched to a sentinel.
- Source document seeded at `status: "processing"` so the `processing → failed` transition is legal.

Emulator alternative: if `FIRESTORE_EMULATOR_HOST` is set, the same assertions can run against the real
emulator (both services have emulator branches, F10); fakes are the default because they are hermetic and
fast (NFR-2).

## 4. Data contracts

### 4.1 Worker failure payload (`details` on the status topic, `status = "failed"`)

| Key | Type | Producer | Consumer | Pinned |
|---|---|---|---|---|
| `error_message` | str | `str(e)` | rag-api → `error`, `error.message` | yes (FR-7) |
| `stage` | str | stage tracker | rag-api → `error_stage`, `error.stage`, summary `stage` | yes (FR-7) |
| `retryable` | bool | `classify_error(e)` | rag-api → `retryable` | yes (FR-7) |
| `error` | str | `= error_message` | none in rag-api; unknown consumers | yes (FR-7) |

### 4.2 Persisted failure schema (unchanged)

Main document: `error: str`, `error_stage: str`, `retryable: bool` (Resource model defaults `retryable` to
`True`). Summary subdocument: `error: {code: "UNKNOWN", message: str, stage: str}`, `stage: str`,
`progress: 0`. No migration, rename, or backfill (NFR-1).

## 5. Failure-flow sequence (target)

```
1. process_document sets tracker → "starting"; begins step; sets tracker before each await
2. step k raises exception e
3. handler: classification = classify_error(e)
           retryable    = (classification is transient)
           stage        = current_stage  (or "processing" if genuinely unknown)
4. _publish_status_update(status="failed",
       details={error_message: str(e), stage, retryable, error: str(e)})
5. Pub/Sub → rag-api _process_status_message (envelope parse unchanged)
6. run_transactional_update (processing → failed):
     main doc:    error = error_message; error_stage = stage; retryable = retryable
     summary:     error = {code: "UNKNOWN", message: error_message, stage: stage}; stage = stage
7. run_worker ACK/NACK per the same classification — record and routing now agree
```

## 6. Test architecture

### 6.1 Layers

| Layer | Location | Mechanism | Asserts |
|---|---|---|---|
| L1 worker payload construction | `rag-worker-service/tests/unit/` | drive `process_document` with a stubbed dependency that raises; capture `_publish_status_update` via fake/monkeypatch | payload keys + values; stage correctness; retryable derivation |
| L2 persistence | `tests/integration/test_worker_failure_contract.py` | worker-built payload → `run_transactional_update` on fakes | main doc `error`/`error_stage`/`retryable` == payload values; summary `error.message`/`error.stage`/`stage` == payload values |
| L3 drift guard | same module | dynamic key-set assertion (L1 capture) + static AST extraction of `details.get("…")`/`details["…"]` in rag-api's failed branch (precedent: `_get_agent_graph_shapes`) | worker key set == `{error_message, stage, retryable, error}`; api read set == `{error_message, stage, retryable, error_code}`; intersection `{error_message, stage, retryable}` binding |

### 6.2 Scenario matrix

| # | Scenario | Expected stage | Expected retryable |
|---|---|---|---|
| S1 | early-stage failure, transient-classified exception | early vocabulary stage | `true` |
| S2 | late-stage failure, permanent-classified exception | late vocabulary stage | `false` |
| S3 | unclassified-unknown exception | stage at raise site | `false` (pins the deliberate change) |
| S4 | failure before any stage transition | `"processing"` | per classification |
| S5 | drift: worker key set | test fails on any key add/remove/rename | — |
| S6 | drift: api failed-branch reads | test fails on any key add/remove/rename | — |
| S7 | persistence equality (L2) | persisted values == payload values, main + summary | — |

S1–S2 give representative-stage coverage (TR-4): enough to catch the tracker being removed or bypassed
without ossifying every pipeline step.

### 6.3 Why fakes over a fixture restatement

The test imports both sides rather than restating the contract in a fixture: the payload is built by the
worker's real handler, and persistence runs rag-api's real branch. A rename on either side breaks L1/L2/L3
at build time instead of silently re-creating the bug in production — which is exactly the failure mode this
cycle exists to close.

## 7. Edge cases and failure modes

| Case | Handling |
|---|---|
| Failure before tracker's first meaningful assignment | `stage = "processing"` (never null) — matches sweep convention |
| Empty `str(e)` | `error_message` persists as `""` (the actual message); optional implementation hardening — fall back to the exception class name — is permitted but not required and does not alter the contract |
| `error_code` absent from payload | summary `error.code` = `"UNKNOWN"` (existing default; preferred-not to introduce codes, C5) |
| Payload for a doc not in `processing` | `run_transactional_update` returns early (transition gate) — unchanged; tests seed `processing` |
| Doc missing / deleted | existing early-return warnings — unchanged |
| Unknown status-topic consumer reading old keys | served by retained legacy `error` key (FR-5) |
| Non-worker failure publishers (enqueue paths) | their payloads are untouched; rag-api fallbacks remain for them |

## 8. Risks and mitigations

- **Unknown consumers of the status topic** reading the old key set → mitigated by retaining `error`;
  residual risk accepted as low (F11).
- **Stage-tracker drift** as the pipeline evolves → set-before-await convention + representative-stage
  coverage (S1/S2).
- **`retryable=false` for unclassified errors** may reduce auto-retry affordances for genuinely
  transient-but-unrecognized failures → accepted; widening `classify_error` is out of scope; manual
  reprocess via `POST /process` unaffected.
- **Contract test ossifies the payload** → intentional; that is the drift guard doing its job. Adding a key
  later means touching the test, which is the point.
- **Dual `main` module collision in the contract test** → importlib unique-name loading (§3.5); env
  prerequisites for loading rag-api's config set explicitly by the test.

## 9. Compatibility, rollout, migration

- **Migration:** none. Persisted field names and semantics unchanged (C2/NFR-1).
- **Deploy ordering:** safe in any order. The worker change is additive from rag-api's perspective (rag-api
  already reads `error_message`/`stage`/`retryable` — verified); rag-api requires no code change. Deploying
  the worker alone closes the gap; before that deploy, behavior is today's fallback behavior.
- **Rollback:** revert the worker deploy; rag-api's fallbacks resume harmlessly.
- **Future cleanup:** dropping the legacy `error` key is trivial once an audit confirms worker is the only
  publisher and rag-api the only consumer (D-3).

## 10. Out of scope / deferred

As bounded by the Definition: no changes to the stale-lease sweep, ACK/NACK policy, leases, heartbeats, or
frontend; no structured error-code taxonomy (summary `error.code` stays `"UNKNOWN"` unless sent); the
companion D3 issue's scope beyond this alignment is deferred (F12), as is reconciliation with the D4 note
referenced from `plans/upload-flow.md` (file absent from the current tree).
<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>