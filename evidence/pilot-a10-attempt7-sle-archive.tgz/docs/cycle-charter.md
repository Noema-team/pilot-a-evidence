**Cycle charter — rag-worker → rag-api: failure payload contract mismatch**

Cycle intent: "rag-worker → rag-api: failure payload contract mismatch — failures persist without message or stage".
Scope source: authoritative Definition artifact from define-work WorkItem `wi-define-108-a8` (sha256-pinned); this charter restates that scope without widening or narrowing it.

## Scope

This cycle touches the rag-worker's failure reporting and adds one contract test. rag-api-service code is **not** modified — its failed branch already reads `error_message`/`stage`/`retryable` and persists `error`/`error_stage`/`retryable` (verified in `run_transactional_update` in `apps/ai-server/rag-api-service/main.py`).

1. **Worker failure payload** (`apps/ai-server/rag-worker-service/main.py`, `process_document` exception handler): the failed status payload published via `_publish_status_update` must carry `error_message` (actual exception message), `stage` (failing pipeline stage), and `retryable` (deliberately derived), with the legacy `error` key retained alongside `error_message`. Today it publishes only `{"error": str(e)}`.
2. **Stage tracking in `process_document`**: a local stage tracker set immediately before each pipeline step (convention: update the tracker immediately before the `await`) so the exception handler reports the true failing stage. Stage names reuse the existing progress-update vocabulary — `starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete` — with `"processing"` as the safe value when the stage is genuinely unknown (the same value the stale-lease sweep writes to `error_stage`).
3. **Retryable derivation**: the worker sets `retryable` from the existing `classify_error(e)` — transient-classified errors map to `true`, permanent-classified (including unclassified-unknown, per `classify_error`'s conservative default) map to `false` — so the persisted record matches the worker's actual ACK/NACK behavior in `run_worker`. Known deliberate behavior change: unclassified-unknown exceptions previously persisted `retryable: true` (silent default) and will now persist `false`.
4. **Contract test** (new file in `apps/ai-server/tests/integration/`, alongside `test_api_contracts.py`): imports both sides' real code rather than restating the contract in a fixture — builds the failure payload through the worker's code path and feeds it through rag-api's `run_transactional_update` failed branch against the Firestore emulator or fake-Firestore transaction fakes (patterns already proven in `rag-worker-service/tests/unit/test_processing_lease.py` and the shared integration conftest; both services have `FIRESTORE_EMULATOR_HOST` branches). Asserts persisted `error`, `error_stage`, and `retryable` equal the worker's values, includes a key-set drift guard so a future key change on either side fails the build, and covers an early-stage failure and a late-stage failure (representative stages pinning the tracker mechanism without ossifying every step).

## Purpose

Every worker-originated failure currently lands in Firestore as fallbacks: `error` = "Processing failed", `error_stage` = null, and a silently defaulted `retryable: true`; the `processing/summary` error subdocument inherits the same fallbacks with `error_code` always "UNKNOWN". The cause is a seam contract mismatch nobody tests: the worker publishes one key (`error`), rag-api's failed branch reads three (`error_message`, `stage`, `retryable`). Users and support cannot disambiguate what failed or where.

The worker is the only writer that doesn't speak the established `error`/`error_stage`/`retryable` schema — the stale-lease sweep (`_fail_if_still_stale`), rag-api's enqueue-failure paths (POST /process, POST /resources), the `Resource` model, and `ResourceResponse` all already use it — so the fix aligns the odd one out: the worker adopts `error_message`/`stage`/`retryable` in its payload. No migration, no field rename, no backfill, no reader changes.

## Requirements

1. When document processing fails, the worker's failed status payload must include `error_message` (the actual exception message), `stage` (the pipeline stage executing at failure time), and `retryable` (deliberately derived) — the payload must never rely on rag-api's fallback defaults for these keys.
2. The worker must track the currently executing pipeline stage through `process_document` so the failure handler reports the true failing stage; stage names reuse the existing progress-stage vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown.
3. rag-api's failed branch must persist the worker-provided values unchanged: main document `error` ← payload `error_message`, `error_stage` ← payload `stage`, `retryable` ← payload `retryable`; the processing/summary error subdocument must carry the same message and stage. (This already holds given a correct payload — no rag-api change is in scope; the contract test pins it.)
4. The retryable derivation must be explicit and aligned with the worker's ACK/NACK behavior: errors classified transient by `classify_error` → retryable `true`; classified permanent (including unclassified-unknown, per `classify_error`'s conservative default) → retryable `false`.
5. A contract test must cover the worker failure → rag-api persistence path: it must exercise the worker's failure-payload construction and rag-api's failed-branch persistence (via the Firestore emulator or fakes) and assert the persisted `error`, `error_stage`, and `retryable` equal the worker's values; it must fail if either side's payload keys drift.

Acceptance mapping: requirements 1–2 satisfy the payload-content acceptance criterion; requirement 3 satisfies the main-document persistence criterion (error ≠ "Processing failed", error_stage ≠ None, retryable = derived value) and the processing/summary subdocument criterion; requirement 5 satisfies the contract-test criterion.

## Boundaries

Constraints:

- **Must**: the worker aligns to rag-api's existing contract — publishing `error_message`/`stage`/`retryable` — rather than changing rag-api's reads or persisted schema.
- **Must**: every worker-originated failure payload carries `retryable` explicitly (deliberately derived); the API-side `details.get("retryable", True)` fallback must not be the operative mechanism for worker failures.
- **Must not**: no Firestore migration, field rename, or backfill of existing documents; the persisted fields (`error`, `error_stage`, `retryable`) keep their names and semantics.
- **Prefer**: retain the legacy `error` key in the worker's failure payload alongside `error_message`, for continuity with any existing consumers of the status topic and log tooling.
- **Prefer not**: no structured error-code taxonomy (`error_code` values) in this fix; the summary `error.code` remains "UNKNOWN" unless a code is actually sent.

Out of scope (non-goals):

- Changing the stale-lease sweep's direct failure write — it already persists `error`/`error_stage`/`retryable` consistently with this contract.
- Changing retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, or heartbeat intervals — only the *reporting* of retryability in the payload changes.
- Frontend or mobile changes — `ResourceResponse` already exposes `error` and `error_stage` to clients.
- Introducing structured error codes or a failure taxonomy.
- Any scope the companion D3 issue covers beyond this worker→rag-api failure payload alignment (its content is unavailable in this context; deferred).
- Widening `classify_error` for unrecognized-but-transient failure modes (accepted residual risk; manual reprocess via POST /process remains).

Known risks accepted in this scope: unknown consumers of the status topic reading the old key set (mitigated by retaining `error`); stage-tracker drift as the pipeline evolves (mitigated by the update-before-await convention and representative-stage contract-test coverage); the contract test ossifying the payload key set (intentional — that is the drift guard).

## Version bump

Patch-level: this is a bug fix to the worker's failure reporting plus a test; no schema, migration, dependency, or persisted-field changes. rag-api-service's declared FastAPI `version="1.0.0"` stays unchanged because its code is not modified. rag-worker-service has no version metadata in the verified tree (no version constant in its `main.py` or Dockerfile), so no in-repo version file is bumped; if the deployment convention tracks worker versions elsewhere (e.g. compose image tags — not verified in this cycle), treat this change as a patch bump there.

## Deferred items

- The companion D3 issue referenced by the Objective: its scope is not available in this context; anything it covers beyond the worker→rag-api failure payload alignment is deferred.
- Reconciling this analysis with the original D4 deviation note in `plans/upload-flow.md` — that file is not present in the current tree; the reference comes from the Objective text only.
- Dropping the legacy `error` key from the worker's failure payload once a consumer audit confirms rag-api's status subscriber is the only reader — trivial follow-up cleanup.
- A structured error-code taxonomy / failure taxonomy (`error_code` values beyond the "UNKNOWN" default).
- Widening `classify_error` to recognize more transient failure modes (e.g. to avoid the new `retryable: false` for unrecognized-but-transient errors).
- Any frontend or mobile work to surface the now-correct `error`/`error_stage` values — the response models already expose them.