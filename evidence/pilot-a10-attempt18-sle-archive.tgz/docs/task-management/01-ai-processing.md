---
tags:
  - TaskManagement
---
# RAG Agent types
#ToDo
Multi-agent architecture (Teaching, Problem Solver, Search, Study Advice). Summary on card, detailed spec in [[rag-agent-types]].

---
# PDF → Markdown image support
#ToDo
Extending the converter to extract images from PDFs.

---
# Scheduled function for unprocessed uploads
#ToDo
Research whether this should integrate with admin UI.

---
