"""
Guard: no service image runs as root.

Containers here mount service-account keys read-only and reach a database and
the model cache. Running them as root means a process compromise starts with
uid 0 inside the container, which is the difference between "read what this
service can read" and "write anywhere the image allows, install tooling, and
attack the runtime from a stronger position". It costs a line per Dockerfile
to avoid.

Two services already did this correctly (rag-worker-service, api-gateway), and
two more had the USER line written and then commented out — so the intent was
there and the switch was simply off. This test keeps it on.

Static check: it reads the Dockerfiles, so it needs no Docker daemon and runs
in CI like any other test. It cannot tell you the image *builds* — see the
note in each commit about that.
"""

import re
from pathlib import Path

import pytest

AI_SERVER = Path(__file__).resolve().parents[2]

# Anything legitimately unable to drop privileges belongs here, with a reason.
# Empty on purpose: every service in this stack binds a port above 1024 and
# writes only to paths that can be chowned at build time.
ALLOWED_ROOT: dict[str, str] = {}

USER_DIRECTIVE = re.compile(r"^\s*USER\s+(\S+)", re.MULTILINE)


def _dockerfiles() -> list[Path]:
    found = sorted(
        p for p in AI_SERVER.glob("*/Dockerfile*")
        if p.is_file() and not p.name.endswith((".md", ".txt"))
    )
    assert found, "no Dockerfiles discovered — has the layout moved?"
    return found


@pytest.mark.parametrize("dockerfile", _dockerfiles(), ids=lambda p: f"{p.parent.name}/{p.name}")
def test_dockerfile_drops_root(dockerfile: Path):
    service = dockerfile.parent.name
    if service in ALLOWED_ROOT:
        pytest.skip(f"{service} documented as root-required: {ALLOWED_ROOT[service]}")

    text = dockerfile.read_text()
    users = USER_DIRECTIVE.findall(text)

    assert users, (
        f"{dockerfile.relative_to(AI_SERVER)} has no USER directive, so the "
        f"container runs as root. Create a user and switch to it after "
        f"everything is installed and copied — see rag-worker-service/Dockerfile "
        f"for the pattern this repo uses."
    )

    final_user = users[-1]
    assert final_user not in {"root", "0"}, (
        f"{dockerfile.relative_to(AI_SERVER)} switches back to {final_user!r} "
        f"as its final USER."
    )


@pytest.mark.parametrize("dockerfile", _dockerfiles(), ids=lambda p: f"{p.parent.name}/{p.name}")
def test_user_directive_is_not_commented_out(dockerfile: Path):
    """
    auth-service and rag-api-service both shipped `# USER app` / `# USER node`:
    the groundwork done, the switch commented out, and the container running as
    root with every appearance of having been secured.
    """
    commented = re.findall(r"^\s*#\s*USER\s+\S+", dockerfile.read_text(), re.MULTILINE)
    assert not commented, (
        f"{dockerfile.relative_to(AI_SERVER)} has a commented-out USER line "
        f"({commented}). Either enable it or delete it — left as a comment it "
        f"reads as though the container drops privileges when it does not."
    )
