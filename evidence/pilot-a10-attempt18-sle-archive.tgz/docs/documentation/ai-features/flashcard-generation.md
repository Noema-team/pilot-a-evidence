# Flashcard Generation Pipeline

How flashcard generation works, what determines card quality, and the open
questions around improving it. Written after the Phase 3 on-device
walkthrough of `flashcards-mobile` (2026-09-10), which surfaced real
generation behavior end-to-end.

> **Status note:** this document lives on `main`, but the *mobile* preview
> behavior described below (preview page, edit/discard/save flow) belongs
> to the in-flight `feature/flashcards-mobile` work (#90, phases #92/#94)
> and has not landed on `main` yet. The backend pipeline description is
> main-accurate; the walkthrough evidence comes from the feature branch.

Implementation: `apps/ai-server/flashcard-service/algorithms/flashcard_generator.py`,
endpoint in `flashcard-service/main.py` (`POST .../flashcards/generate`).
Mobile consumer: `apps/mobile/lib/flashcards/` (plan: `plans/flashcards-mobile.md`).

## What cards are based on

1. The uploaded resource is parsed into **extracted markdown**
   (`extracted_text`) plus a **resource map**: structured sections over
   that text.
2. Per selected section, the endpoint loads the **full persisted
   `extracted_text` markdown** and slices out the section's content with
   `MarkdownParser.extract_section_content(extracted_text, section_id,
   sections)` using the resource-map structure (no chunk retrieval is
   involved).
3. That section text is embedded in the prompt, **truncated to its first
   2000 characters**. One LLM call produces **one card**. Four typed
   prompts exist — qa, cloze, true/false, concept — mixed by a per-request
   type distribution. The user-facing knob is `cards_per_section` (1–20).
   Note: `FlashcardGenerateRequest` also declares `preferred_types`, but
   the endpoint and generator never read it — it is dead schema today.
4. Sections and cards are processed **sequentially** (one awaited LLM call
   per card). Model: `gpt-4o-mini` via the LLM proxy. In the dev hermetic
   stack the proxy **replays cassettes**; a missing cassette fails that
   one card's call and the card is silently skipped (logged as
   `llm_call_failed`).
5. Parsed JSON → `Flashcard` → **dedup against the resource's
   already-saved cards** (embedding similarity, `filter_duplicates`).
   Near-duplicates of *existing* cards are removed **before** the client
   sees them; only the count survives (`duplicates_removed`). The batch's
   own internal near-duplicates are **not** filtered by this endpoint.
   Removed cards are unrecoverable — no ids or similarities are returned.
6. Generated cards set `source_chunk_ids=[]` (the model field exists, the
   comment says "will be filled when saving" — nothing fills it; the
   generator's interface receives only a `section_content: str`, so no
   provenance is available to it).

So the honest one-liner: **cards are LLM paraphrases of (the first 2000
characters of) whatever the extraction pipeline produced for a section.**
In the Phase 3 walkthrough, extraction was the largest observed quality
limitation — but the generation path carries its own problems: the hard
2000-character prefix truncation, opaque aggressive dedup, serial calls
(58.5 s wall time for five cards), and a difficulty output the model pins
at 3.

## Quality determinants and observed limits

| Determinant | Observed behavior (2026-09-10 walkthrough) |
|---|---|
| **Extraction quality** | The fixture seed itself warned: "PARTIAL: expected ~6 sections, got 2 — structure extraction is losing most of the document" (low confidence). Sections were coarse "Page 1"/"Page 2" blobs. Cards are only as good as these sections; prompts visibly truncated mid-sentence (the chain-rule text got cut). |
| **Dedup** | Dedup runs against the resource's **already-saved cards**, before the client sees anything. One run generated 4 cards, kept 1 (`duplicates_removed: 3`). Removed cards are unrecoverable — no ids or similarity scores are returned, and the new batch's internal near-duplicates are not checked. |
| **Difficulty output** | Prompts ask for 1–5; the model returned 3 on every observed card. There is no user-facing difficulty control; the field is model output only. |
| **Source grounding** | The backend `Flashcard` model has `source_chunk_ids`, but it is set to `[]` and nothing populates it. Cards cannot cite what they were made from. |
| **Dev-mode yield** | Cassette misses shrink the yield silently (one cloze prompt had no cassette → 409 → card skipped). Fine for tests, misleading when demoing. |
| **Accuracy (observed)** | The cards that did generate were factually correct and traceable to the section text — good study cards *given the source*. |

## Discussion / idea points (open — none decided)

Feedback loop idea: treat generation as propose → inspect → keep, with the
preview as the inspection surface. Today only "keep/discard + edit text"
exists. Candidates, roughly in leverage order:

1. **Fix extraction first (largest observed limitation).** Better section
   boundaries and completeness in rag-api would raise card quality for
   every downstream consumer. Also expose an *extraction* quality signal
   on the map (distinct from flashcard `coverage_status`) so clients can
   warn "poorly parsed resource → expect poor cards".
2. **Grounding: populate `source_chunk_ids`.** Unlocks "show source" on
   any card later — a genuine insight feature. Not a copy-the-ids job:
   provenance must be plumbed from the extraction/map side (which knows
   the source chunks) into generation, whose current interface carries
   only a section content string.
3. **Dedup transparency.** Return removed near-dupes (ids + similarity) in
   the generate response so the preview can offer "3 similar cards hidden
   — show?". Insight without behavior change; "save anyway" would be the
   only control.
4. **Difficulty honesty.** The difficulty field is currently model output
   pinned at 3: either make generation honor a difficulty intent or stop
   treating the field as meaningful.
5. **User controls — deliberately minimal.** Only these pay rent: type
   preference (the `preferred_types` request field exists in the schema
   but the service ignores it — needs backend wiring before any mobile
   exposure), per-card regenerate, reveal hidden dupes, post-save
   edit/delete (endpoints exist, mobile unused). Everything else
   (difficulty sliders, model pickers, tone knobs) is bloat — gate every
   control behind "does it change what gets saved?" and keep logic
   server-backed.
6. **Regenerate granularity.** Per-card regenerate needs a small backend
   path (current API is section-granular). Decide only if preview-stage
   editing proves insufficient in practice.
7. **Quality signal after the fact.** Grade outcomes (SM-2 "Again" rates
   per card/section) could identify systematically bad cards — interesting,
   but a metrics feature; do not build speculatively.

Non-goals for any of the above: config zoos, client-side dedup/quality
heuristics, or expanding `flashcards-mobile` scope (its plan explicitly
keeps mobile a pure API consumer; backend items need their own issues).

## Where this is tracked

- Umbrella issue: #96 (extraction-first, grounding, dedup transparency,
  minimal controls).
- `flashcards-mobile` plan records its own constraints and deviations:
  `plans/flashcards-mobile.md`.
