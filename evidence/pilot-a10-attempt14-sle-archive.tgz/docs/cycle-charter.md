## Scope

This cycle aligns the rag-worker's failure status payload with rag-api's existing failed-branch contract, and locks the seam with a contract test. Concretely:

- **Worker failure payload** (`apps/ai-server/rag-worker-service/main.py`, `process_document` exception handler): the failed status update's `details` must carry `error_message` (the actual exception message), `stage` (the pipeline stage executing at failure time), and `retryable` (deliberately derived). The legacy `error` key is retained alongside `error_message` as a compatibility hedge for unknown consumers of the status topic.
- **Stage tracking** in `process_document`: a stage tracker set immediately before each pipeline step (convention: "set the tracker immediately before the await") so the failure handler reports the true failing stage. Stage names reuse the existing progress-stage vocabulary — `starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete` — with `processing` as the safe value when the stage is genuinely unknown (e.g. failure before the first transition). Steps without a distinct vocabulary name retain the most recently set stage.
- **retryable derivation**: the worker sets `retryable` from `classify_error(e)` — transient-classified errors map to `true`; permanent-classified errors, including unclassified-unknown (classify_error's conservative default), map to `false`. This aligns the persisted record with the worker's actual ACK/NACK behavior and deliberately replaces today's silent `true` default for unclassified errors. The stale-lease sweep's separate `retryable=true` write is untouched and stays correct (a dead worker is a transient condition).
- **rag-api side**: no change to the failed branch's reads or the persisted schema. `run_transactional_update` in `apps/ai-server/rag-api-service/main.py` already reads `error_message`/`stage`/`retryable` and persists `error`/`error_stage`/`retryable` on the main resource document, and writes `message`/`stage` (with `error_code` defaulting to `"UNKNOWN"`) into the `processing/summary` error subdocument. This cycle pins that behavior with a test; it does not modify it.
- **Contract test** under `apps/ai-server/tests/integration/` (alongside `test_api_contracts.py`, reusing its conftest/mocking and Firestore-emulator-mode patterns): builds the failure payload through the worker's code path, feeds it through rag-api's `run_transactional_update` against the Firestore emulator or fakes, asserts the persisted `error`, `error_stage`, and `retryable` equal the worker's values, and includes a key-set drift guard so a future edit to either side's payload keys fails the build.

## Purpose

The worker's exception handler publishes a one-key payload (`{"error": str(e)}`) while rag-api's failed branch reads three keys (`error_message`, `stage`, `retryable`). Every worker-originated failure therefore persists the fallback string "Processing failed", a null `error_stage`, and a fabricated `retryable: true`; the `processing/summary` error subdocument inherits the same fallbacks with `error_code` always "UNKNOWN". Users and support cannot disambiguate failures, and retryability is silently defaulted rather than derived. This cycle makes the worker speak the contract rag-api (and the stale-lease sweep, the enqueue-failure paths, and the `Resource`/`ResourceResponse` models) already use — the worker is the only writer that doesn't — with no migration, no field rename, and no reader changes.

Definition of done (acceptance criteria):

- A failed job's status message published by the worker contains `error_message` (actual exception message), `stage` (failing pipeline stage), and `retryable` (deliberately derived) — none relying on rag-api's fallback defaults.
- After a failed job, the persisted resource document has `error` = the worker's actual error message (not "Processing failed"), `error_stage` = the failing stage (not None), and `retryable` = the worker's derived value.
- The `processing/summary` error subdocument for the failed job carries the same message and stage as the main document.
- A contract test covering the worker failure → rag-api persistence path exists and passes: it exercises the worker's failure-payload construction through rag-api's failed-branch persistence and asserts the persisted `error`, `error_stage`, and `retryable` equal the worker's values, failing if either side's payload keys drift.

## Requirements

- When document processing fails, the worker's failed status payload must include `error_message` (the actual exception message), `stage` (the pipeline stage executing at failure time), and `retryable` (deliberately derived) — the payload must never rely on rag-api's fallback defaults for these keys.
- The worker must track the currently executing pipeline stage through `process_document` so the failure handler reports the true failing stage; stage names must reuse the existing progress-stage vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`), with `processing` as the safe value when the stage is genuinely unknown.
- rag-api's failed branch must persist the worker-provided values unchanged: main document `error` ← payload `error_message`, `error_stage` ← payload `stage`, `retryable` ← payload `retryable`; the `processing/summary` error subdocument must carry the same message and stage.
- The retryable derivation must be explicit and aligned with the worker's ACK/NACK behavior: errors classified transient by `classify_error` → `retryable` true; classified permanent (including unclassified-unknown, per `classify_error`'s conservative default) → `retryable` false.
- A contract test must cover the worker failure → rag-api persistence path: it must exercise the worker's failure-payload construction and rag-api's failed-branch persistence (via the Firestore emulator or fakes) and assert the persisted `error`, `error_stage`, and `retryable` equal the worker's values; it must fail if either side's payload keys drift. Coverage pins the stage-tracker mechanism on representative stages (an early-stage failure and a late-stage failure) — enough to catch the tracker being removed or bypassed without ossifying every pipeline step.

## Boundaries

Constraints (from the authoritative definition):

- **must** — The worker is aligned to rag-api's existing contract — publishing `error_message`/`stage`/`retryable` — rather than changing rag-api's reads or persisted schema.
- **must_not** — No Firestore migration, field rename, or backfill of existing documents; the persisted fields (`error`, `error_stage`, `retryable`) keep their names and semantics.
- **must** — Every worker-originated failure payload carries `retryable` explicitly (deliberately derived); the API-side `details.get("retryable", True)` fallback must not be the operative mechanism for worker failures.
- **prefer** — Retain the legacy `error` key in the worker's failure payload alongside `error_message`, for continuity with any existing consumers of the status topic and log tooling.
- **prefer_not** — Do not introduce a structured error-code taxonomy (`error_code` values) in this fix; the `processing/summary` error `code` remains "UNKNOWN" unless a code is actually sent.

Non-goals (explicitly out of scope):

- Changing the stale-lease sweep's direct failure write — it already persists `error`/`error_stage`/`retryable` consistently with this contract.
- Changing retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, or heartbeat intervals — only the *reporting* of retryability in the payload changes.
- Frontend or mobile changes — `ResourceResponse` already exposes `error` and `error_stage` to clients.
- Introducing structured error codes or a failure taxonomy — the `processing/summary` error `code` remains "UNKNOWN" unless a code is actually sent.
- Any scope the companion D3 issue covers beyond this worker→rag-api failure payload alignment (its content is unavailable here; deferred).

## Version bump

- Treat this cycle as a patch-level bug fix.
- No persisted-schema version change: `schema_version` stays at its current value (2), no Firestore migration, field rename, or backfill; persisted field names and their semantics are unchanged.
- `apps/ai-server/rag-worker-service`: patch bump where service versions are recorded at release time (failure-payload behavior change only; no public API surface).
- `apps/ai-server/rag-api-service`: no runtime code change is planned (its failed branch is pinned by the contract test, which lives under `apps/ai-server/tests/integration/`), so no bump is expected; if release tooling requires a bump for test-only changes, treat it as patch.
- No request/response model changes: `ResourceResponse`, `Resource`, and the status-topic envelope shape (outside `details` for failed status) are unchanged.

## Deferred items

- The companion D3 issue referenced by the Objective — its scope is not available in this context; anything it covers beyond the worker→rag-api failure payload alignment is deferred to that issue.
- Reconciling this analysis with the original D4 deviation note in `plans/upload-flow.md` — that file is not present in the current tree; the reference comes from the Objective text.
- Dropping the legacy `error` duplicate key from the worker's failure payload — trivial cleanup once a consumer audit confirms rag-api's status subscriber is the only consumer of the status topic.
- Widening `classify_error` to recognize more genuinely-transient-but-unclassified exceptions — accepted residual risk that such errors now persist `retryable: false`; manual reprocess via `POST /process` remains available.
- A structured error-code taxonomy for the `processing/summary` error subdocument — currently a non-goal/prefer-not; revisit only if failure-disambiguation demand justifies it.