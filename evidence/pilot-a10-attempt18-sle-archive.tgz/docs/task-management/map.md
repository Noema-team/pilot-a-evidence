# Task Management — File Map

- `task-management/README.md` — hub entry point: structure, rules, skill to load
- `task-management/map.md` — this file: index of all task files
- `task-management/critical-tasks.md` — pointers to active and critical tasks (AI-maintained)
- `task-management/01-ai-processing.md` — AI & document processing tasks
- `task-management/02-frontend-backend.md` — frontend ↔ backend integration tasks
- `task-management/03-app-ui-ux.md` — app UI/UX tasks
- `task-management/04-timeline-feature.md` — timeline implementation task cards (v2 derived-timeline model)
- `task-management/05-testing-qa.md` — testing & QA tasks
- `task-management/06-business.md` — business tasks (GDPR, compliance)
- `task-management/07-feature-backlog.md` — feature ideas and backlog
- `task-management/08-infrastructure-devops.md` — infrastructure & DevOps tasks
