<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path="docs/cycle-charter.md">>>
## Scope

This cycle fixes one seam: the failure-status payload published by `rag-worker-service` and consumed by `rag-api-service`. The worker is the odd one out — three other write paths (the worker's stale-lease sweep, rag-api's `/process` and `POST /resources` enqueue-failure paths) plus the `Resource` model and `ResourceResponse` already speak the `error`/`error_stage`/`retryable` schema — so the worker aligns to the API, not the other way around.

In scope:

- **Worker failure payload alignment** — `apps/ai-server/rag-worker-service/main.py`: the `process_document` exception handler currently publishes `{"error": str(e)}` via `_publish_status_update`. It must publish `error_message` (the actual exception message), `stage` (the failing pipeline stage), and `retryable` (deliberately derived), while retaining the legacy `error` key alongside `error_message` as a compatibility hedge for unknown consumers of the status topic (`RAG_STATUS_TOPIC=rag-status-updates`).
- **Stage tracking** — a stage tracker in `process_document`, set immediately before each pipeline step and reported by the failure handler. Stage names reuse the existing progress-update vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown (matching the stale-lease sweep's `error_stage` value, so the field never regresses to null).
- **retryable derivation** — `retryable` derived from `classify_error(e)`: transient-classified → `true`; permanent-classified, including unclassified-unknown per `classify_error`'s conservative default, → `false`. Verified during investigation: `classify_error` exists in `rag-worker-service/main.py` with exactly this behavior (explicit TransientError/PermanentError types, httpx connection/timeout types, 429/500/502/503/504 status codes transient, other 4xx permanent, unknown exceptions conservatively permanent) and drives ACK/NACK in `run_worker`.
- **Contract test** — a new test under `apps/ai-server/tests/integration/`, alongside the existing `test_api_contracts.py` (fixture- and AST-based patterns; both services support hermetic `FIRESTORE_EMULATOR_HOST` branches). The test imports both sides rather than restating the contract: it builds the failure payload through the worker's code path, feeds it through rag-api's `run_transactional_update` failed branch (emulator or fakes), asserts persisted `error`, `error_stage`, and `retryable` equal the worker's values, and includes a key-set drift guard so an edit to either side's payload keys fails the build.
- **rag-api side: no production code change.** Its failed branch already reads `error_message`/`stage`/`retryable` and persists `error`/`error_stage`/`retryable`. Verified during investigation: `apps/ai-server/rag-api-service/models/resource.py` exposes `error: Optional[str]`, `error_stage: Optional[str]`, `retryable: bool = True` on the `Resource` model.

Expected file changes: `apps/ai-server/rag-worker-service/main.py` (payload keys, stage tracker, retryable derivation) and new/extended test module(s) under `apps/ai-server/tests/integration/`. No schema, model, reader, or migration changes.

## Purpose

Every worker-originated failure currently lands in Firestore as the fallback string `"Processing failed"`, a null `error_stage`, and a fabricated `retryable: true`, because the worker's one-key payload (`{"error": ...}`) does not match the three keys rag-api's failed branch reads (`error_message`, `stage`, `retryable`). The `processing`/`summary` error subdocuments inherit the same fallbacks, with `error_code` always defaulting to `"UNKNOWN"`. Users and support cannot disambiguate failures, and the persisted `retryable` flag does not reflect the worker's actual retry decision.

The purpose of this cycle is to make the persisted failure record tell the truth — the worker's actual error message, the pipeline stage executing at failure time, and a `retryable` flag deliberately derived from the same `classify_error()` classification that drives the worker's ACK/NACK behavior — using the already-established `error`/`error_stage`/`retryable` schema with no Firestore migration, field rename, backfill, or reader changes. The seam is then locked by a contract test so future key drift on either side fails the build instead of silently re-creating this bug.

## Requirements

Binding requirements for this cycle:

1. When document processing fails, the worker's failed status payload must include `error_message` (the actual exception message), `stage` (the pipeline stage executing at failure time), and `retryable` (deliberately derived) — the payload must never rely on rag-api's fallback defaults for these keys.
2. The worker must track the currently executing pipeline stage through `process_document` so the failure handler reports the true failing stage. Stage names must reuse the existing progress-stage vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown.
3. rag-api's failed branch must persist the worker-provided values unchanged: main document `error` ← payload `error_message`, `error_stage` ← payload `stage`, `retryable` ← payload `retryable`; the `processing`/`summary` error subdocument must carry the same message and stage.
4. The `retryable` derivation must be explicit and aligned with the worker's ACK/NACK behavior: errors classified transient by `classify_error` → `retryable` true; classified permanent (including unclassified-unknown, per `classify_error`'s conservative default) → `retryable` false.
5. A contract test must cover the worker failure → rag-api persistence path: it must exercise the worker's failure-payload construction and rag-api's failed-branch persistence (via the Firestore emulator or fakes) and assert the persisted `error`, `error_stage`, and `retryable` equal the worker's values; it must fail if either side's payload keys drift.

Acceptance criteria (all must be met to close the cycle):

- A failed job's status message published by the worker contains `error_message` (actual exception message), `stage` (failing pipeline stage), and `retryable` (deliberately derived) — none relying on rag-api's fallback defaults.
- After a failed job, the persisted resource document has `error` = the worker's actual error message (not `"Processing failed"`), `error_stage` = the failing stage (not None), and `retryable` = the worker's derived value.
- The `processing`/`summary` error subdocument for the failed job carries the same message and stage as the main document.
- The contract test covering the worker failure → rag-api persistence path exists and passes, and fails if either side's payload keys drift.

## Boundaries

Hard constraints:

- The worker aligns to rag-api's existing contract; rag-api's reads and persisted schema are not changed.
- No Firestore migration, field rename, or backfill of existing documents; the persisted fields `error`, `error_stage`, `retryable` keep their names and semantics.
- rag-api's `details.get("retryable", True)` fallback must not be the operative mechanism for worker failures.
- The legacy `error` key is retained in the worker's failure payload alongside `error_message` (prefer-level constraint, adopted as the compatibility hedge).

Out of scope (non-goals):

- The stale-lease sweep's direct failure write (`_fail_if_still_stale`) — it already persists `error`/`error_stage`/`retryable` consistently with this contract; its `retryable=true` write stays correct (a dead worker is a transient condition).
- Retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals — only the *reporting* of retryability in the payload changes.
- Frontend or mobile changes — `ResourceResponse` already exposes `error` and `error_stage` to clients.
- A structured error-code taxonomy or failure taxonomy — the `processing`/`summary` `error.code` remains `"UNKNOWN"` unless a code is actually sent (prefer-not constraint).
- Widening `classify_error`'s coverage; unrecognized-but-genuinely-transient failures will now persist `retryable: false` instead of the silent `true` default. This behavior change is accepted: it is the conservatism `classify_error` was written for, prevents infinite retry loops, and manual reprocess via `POST /process` remains available.

Accepted risks and conventions:

- Unknown consumers of the status topic reading the old key set — mitigated by retaining `error`; residual risk accepted as low.
- Stage-tracker drift as the pipeline evolves — mitigated by the "set the tracker immediately before the await" convention and representative-stage test coverage (an early-stage failure and a late-stage failure), without ossifying every step.
- The contract test intentionally ossifies the payload key set — that is the drift guard doing its job; adding a key later means touching the test.

Verified repository context bearing on boundaries:

- `apps/ai-server/rag-worker-service/models/processing_status.py` contains a divergent `ProcessingStage` enum (`pdf_download`, `text_extraction`, …) and an `ErrorCode` taxonomy with an `is_retryable` property. This fix does **not** adopt that vocabulary or taxonomy — stage names come from `main.py`'s progress-update vocabulary per the Definition, and no error codes are introduced. That module is left untouched.
- The worker's own `tests/integration/` directory currently contains only `__init__.py`; the cross-service seam test therefore belongs with the existing cross-service contract tests under `apps/ai-server/tests/integration/`, following the patterns verified in `test_api_contracts.py`.

## Version bump

No version manifest (VERSION file, CHANGELOG, or app-level version field) was verified in the investigated trees, so no specific version number is declared here. Semantically, this cycle is a patch-level behavior fix plus a test addition in `rag-worker-service`; `rag-api-service` receives no production code change (only test-side additions under `apps/ai-server/tests/`). If the release process keys off Docker image tags, `rag-worker-service` is the image to rebuild; `rag-api-service` needs no bump beyond whatever test-infra rebuild policy applies. The exact bump mechanism is left to the implementation step to confirm against the actual release tooling.

## Deferred items

- The companion D3 issue referenced by the Objective — its content is unavailable in this context; anything it covers beyond the worker→rag-api failure payload alignment is out of this cycle.
- Reconciling this analysis with deviation D4 in `plans/upload-flow.md` — that file is not present in the current tree; the reference exists only in the Objective text.
- Dropping the legacy `error` key from the worker's failure payload — deferred until an audit confirms the worker is the only publisher and rag-api the only consumer of the status topic; removal is trivial cleanup afterward.
- Any broader audit of additional status-topic consumers beyond rag-api's status subscriber.
- Widening `classify_error` to recognize more genuinely-transient exception shapes.
- Introducing a structured error-code taxonomy or failure taxonomy.
- Reconciling or removing the divergent `ProcessingStage`/`ErrorCode` model set in `apps/ai-server/rag-worker-service/models/processing_status.py` (verified to exist with a vocabulary that differs from both this fix's stage names and the persisted schema; its actual usage in the pipeline was not verified and it is not touched by this cycle).
<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>