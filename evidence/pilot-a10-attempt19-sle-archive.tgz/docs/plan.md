# Plan: Align rag-worker failure payload with rag-api's failed-branch contract

- **WorkItem:** wi-define-108-a8 (authoritative Definition artifact `definition:obj-108`, sha256 `71f1c39c…`)
- **Objective:** rag-worker → rag-api failure payload contract mismatch — failures persist without message or stage
- **Status:** Plan complete — implementation not started
- **Branch model:** feature work per `AGENTS.md`; suggested feature slug `fix/worker-failure-payload-contract` (small-change eligible: no schema change, no migration, touches rag-worker + its tests and shared integration tests only — if review prefers the feature path, phases below map 1:1 to phase branches)

---

## 1. Problem (verified)

The worker's `process_document` exception handler publishes a failed status whose details contain only `{"error": str(e)}`. rag-api's `run_transactional_update` failed branch reads three different keys and persists with fallbacks:

| rag-api reads (verified in `rag-api-service/main.py`) | Worker sends today | Persisted result today |
|---|---|---|
| `details.get("error_message", "Processing failed")` → `error` | `error` (ignored) | `"Processing failed"` |
| `details.get("stage")` → `error_stage` | — | `None` |
| `details.get("retryable", True)` → `retryable` | — | `True` (silent default) |

The `processing/summary` error subdocument inherits the same fallbacks: `{"code": "UNKNOWN", "message": "Processing failed", "stage": None}`, and `summary.stage` falls back to `"unknown"`.

The persisted schema (`error`, `error_stage`, `retryable`) is already written correctly by three other paths — the worker's stale-lease sweep (`_fail_if_still_stale`), rag-api's enqueue-failure path in `POST /process` (writes `error_stage: "enqueue"` directly), and the `Resource` model (`models/resource.py`: `error`, `error_stage`, `retryable: bool = True`). The worker's status publisher is the only writer that doesn't speak the contract.

## 2. Verified evidence base

Confirmed by direct repository reads during investigation:

- **rag-api `run_transactional_update`** (module-level, `rag-api-service/main.py`): signature `(db, doc_ref, new_status, details, logger, user_id)`; `ALLOWED_TRANSITIONS` allows `processing → failed`; failed branch writes `error`/`error_stage`/`retryable` on the main doc and `{"code": details.get("error_code", "UNKNOWN"), "message": details.get("error_message", "Processing failed"), "stage": details.get("stage")}` into `processing/summary`; summary also gets `stage = details.get("stage", "unknown")` and `progress = details.get("progress", 0)`.
- **rag-api `_process_status_message`**: parses envelope keys `user_id`, `course_id`, `resource_id`, `status`, `details`; resolves canonical `users/{uid}/resources/{rid}` vs legacy course path; runs the transactional update via `asyncio.to_thread`; acks/nacks.
- **rag-api `POST /process`**: enqueue-failure path writes `status: "failed"`, `error`, `error_stage: "enqueue"` directly (bypasses the transactional update) — untouched by this plan.
- **`models/resource.py`**: `Resource` dataclass persists `error`, `error_stage`, `retryable` (default `True`). `ResourceResponse` (in `main.py`) exposes `error` and `error_stage` to clients (no `retryable` field — surfacing it is out of scope).
- **Worker `classify_error(e) -> bool`** (`rag-worker-service/main.py`): `TransientError` → True; `PermanentError` → False; known transient types (httpx connect/timeout errors, `ConnectionError`, `TimeoutError`, `asyncio.TimeoutError`) → True; HTTP-status heuristics for transient status codes; unclassified exceptions fall through to permanent (conservative default). This classification drives ACK/NACK in `run_worker`.
- **Worker emulator branch**: `_init_services` supports `FIRESTORE_EMULATOR_HOST` (mirrors rag-api's branch).
- **Worker test fakes** (`rag-worker-service/tests/unit/test_processing_lease.py`): `FakeTx`/`FakeSnap`/`FakeRef`/`FakeCollection`/`FakeDb` + `_tx_identity` stand-in for `firestore.transactional` + `monkeypatch.setattr(main.firestore, "SERVER_TIMESTAMP", "TS", raising=False)`. The sweep test already asserts `retryable is True` on the stale-lease write — this must stay green (sweep is a non-goal).
- **Shared integration conftest** (`apps/ai-server/tests/integration/conftest.py`): env defaults (`GCP_PROJECT=test-project`, fake creds, `SHARED_INTERNAL_TOKEN`), `MagicMock` stubs for `firebase_admin`, `google.cloud.*`, `structlog`, and `sys.path` insert for `rag-api-service` only (not the worker).
- **Worker test conftest** (`rag-worker-service/tests/conftest.py`): minimal stubs for `openai`, `langfuse`, `firebase_admin`, `google.cloud.*`, `spacy`, `tiktoken`, `tenacity`, `langchain` — i.e., worker `main.py` imports all of these at module level; a test importing worker `main.py` outside the worker tree needs an equivalent stub set.
- **pytest configs**: both services use `pytest.ini` with `asyncio_mode = auto`; `apps/ai-server/tests/` has no local pytest.ini (async plugin mode there is unverified — see §10).

Pinned by the authoritative Definition (binding, not re-derived): the failure handler's current payload shape (F3), the progress-stage vocabulary (F9), the `retryable` derivation decision (F8), the legacy-`error` hedge (F11), and the contract-test infrastructure characterization of `test_api_contracts.py` as fixture- and AST-based (F10).

## 3. Design

### 3.1 Worker failure payload (the fix)

In `process_document`'s exception handler, replace the one-key payload with:

```python
{
    "error_message": str(e),          # actual exception message
    "stage": <current pipeline stage>,  # from the stage tracker (§3.2)
    "retryable": classify_error(e),   # deliberately derived (§3.3)
    "error": str(e),                  # legacy key retained (compat hedge, F11)
}
```

- `error_message` / `stage` / `retryable` are the contract keys rag-api already reads. None of them may be absent — rag-api's `.get()` fallbacks must never be the operative mechanism for worker failures (constraint 3).
- `error` is retained deliberately for unknown consumers of the status topic and log tooling (constraint: prefer). rag-api ignores it; it costs one redundant string per failure.
- No `error_code` is sent — the summary subdocument's `code` stays `"UNKNOWN"` via rag-api's existing default (constraint: prefer not to introduce a taxonomy).

### 3.2 Stage tracking

`process_document` is one large try block; today nothing knows where it failed. Add a stage tracker:

- A local variable (e.g. `current_stage`), initialized to a sentinel (`None`) **before** the try block so the handler can always see it.
- **Convention: set the tracker immediately before each awaited pipeline step**, using the existing progress-stage vocabulary: `starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`. A failure during a step reports the name of the step that was executing.
- Steps after the last vocabulary name (e.g. vector storage / post-processing persistence) retain the last assigned value — no new names invented in this fix.
- **Unknown fallback:** if the failure occurs before the first assignment, the handler resolves the stage to `"processing"` — the same value the stale-lease sweep uses for `error_stage` (per the Definition), so `error_stage` never regresses to `None`.
- Drift risk is managed by convention ("set before the await") plus representative-stage test coverage (§ test-plan), not by ossifying every step.

### 3.3 `retryable` derivation

`retryable = classify_error(e)` — the same classification that already drives ACK/NACK:

- Transient-classified → `retryable: true` (Pub/Sub will redeliver; the record tells the truth).
- Permanent-classified, **including unclassified-unknown** (classify_error's conservative default) → `retryable: false` (acked, no auto-redelivery; manual reprocess via `POST /process` remains).

**Deliberate behavior change:** unclassified-unknown exceptions currently persist `retryable: true` (silent default) and will now persist `false`. Accepted per the Definition (F8): this matches the worker's actual retry behavior and prevents infinite-retry affordances for unrecognized failures.

**Explicitly unchanged:** the stale-lease sweep keeps its direct `retryable: true` write (a dead worker is a transient condition); ACK/NACK policy, leases, heartbeats, and backoff are untouched — only the *reporting* of retryability changes.

### 3.4 Testability extraction (behavior-preserving refactor)

The payload construction currently lives inline in the exception handler. Extract it into a small module-level pure helper in the worker (illustrative name: `_build_failure_payload(e: Exception, stage: Optional[str]) -> dict`):

- Returns exactly the §3.1 key set; resolves `None`/sentinel stage to `"processing"`.
- The exception handler calls the helper and passes the result as the `details` argument to `_publish_status_update` (exact `_publish_status_update` call shape to be confirmed against `main.py` at implementation — see §10).
- No behavior change; this exists so the contract test can exercise the worker's real construction code path instead of restating the contract in a fixture.

### 3.5 rag-api side: no production change

rag-api's failed branch already reads `error_message`/`stage`/`retryable` and persists `error`/`error_stage`/`retryable` unchanged. The constraint "align the worker to rag-api, never the reverse" means **zero production-code changes in `rag-api-service`**. The API side is pinned by the new contract test only.

## 4. Phases

### Phase 01 — Worker failure payload + stage tracking — `NOT STARTED`

**Branch:** `phase/worker-failure-payload-contract/01-worker-payload` (or single small-change PR if the small-change path is chosen).

**Files:**
- `apps/ai-server/rag-worker-service/main.py` — stage tracker in `process_document`; `_build_failure_payload` helper; handler rewiring.
- `apps/ai-server/rag-worker-service/tests/unit/test_failure_payload.py` — new.

**Tasks:**
1. Read the current `process_document` exception handler and `_publish_status_update` call sites; confirm the payload flow described in §2/§3 before editing.
2. Add the stage tracker per §3.2 (init before try; assign before each awaited step using the six vocabulary names).
3. Add `_build_failure_payload` per §3.4; rewire the handler to use it.
4. Add worker unit tests (see test-plan §3.1): key set, value mapping, retryable derivation for transient/permanent/unclassified, legacy `error` key, stage fallback to `"processing"`.
5. Run worker suite; confirm `test_processing_lease.py` still passes (sweep untouched).

**Exit criteria:** every worker-originated failure publishes `error_message`/`stage`/`retryable` (+ legacy `error`); stage reflects the executing step or `"processing"`; worker unit tests green.

### Phase 02 — Cross-service contract test + drift guards — `NOT STARTED`

**Branch:** `phase/worker-failure-payload-contract/02-contract-test`.

**Files:**
- `apps/ai-server/tests/integration/test_worker_failure_contract.py` — new (self-contained stubbing at module top; see test-plan §2.3 for why not the shared conftest).
- `apps/ai-server/rag-worker-service/tests/integration/test_failure_stages.py` — new (worker-tree integration test driving `process_document`; the worker's own conftest already provides all stubs, and `tests/integration/` already exists with `__init__.py`).
- No changes to `apps/ai-server/tests/integration/conftest.py` (blast-radius avoidance; revisit only if §10 items force it).

**Tasks:**
1. Build the seam test: worker `_build_failure_payload` (real `classify_error`) → rag-api `run_transactional_update` against fake-db fakes (house pattern from `test_processing_lease.py`: `FakeTx`/`FakeSnap`/`FakeRef`/`FakeCollection`/`FakeDb`, `_tx_identity` for `firestore.transactional`, patched `SERVER_TIMESTAMP`); seed the doc with `status: "processing"` so the transition is valid.
2. Assert persisted main-doc `error == str(exception)`, `error_stage == stage`, `retryable == derived value` (and explicitly `!= "Processing failed"` / `!= None` guards); assert summary subdoc `error.message`/`error.stage` match, `error.code == "UNKNOWN"`, `summary.stage == stage`.
3. Add the process_document stage-tracker test (early-stage failure → `text_retrieved`; late-stage failure → `embeddings_complete`; pre-assignment failure → `processing`), capturing the payload via a monkeypatched `_publish_status_update`, and asserting the **published** payload's key set (handler-path drift guard).
4. Add the rag-api-side AST drift guard: parse `rag-api-service/main.py`, walk `run_transactional_update`, collect `details.get(...)` key literals in the failed-branch writes, assert they are exactly `{error_message, stage, retryable, error_code}` (following the AST-based approach the existing `test_api_contracts.py` uses — its concrete helpers were not retained in this context; implement standalone rather than assuming reuse).
5. Run the full `apps/ai-server/tests/integration` directory — existing tests must stay green.

**Exit criteria:** contract test passes end-to-end; a forced key drift on either side fails the build (verified once manually by temporarily renaming a key during development, then reverting).

## 5. Acceptance criteria mapping (from the Definition)

| # | Acceptance | Met by |
|---|---|---|
| 1 | Worker failure payload carries `error_message`/`stage`/`retryable`, none relying on rag-api fallbacks | Phase 01 implementation + unit tests + handler-path key-set guard (Phase 02, task 3) |
| 2 | Persisted `error` = actual message (not `"Processing failed"`), `error_stage` = failing stage (not None), `retryable` = derived | Phase 02 seam test assertions |
| 3 | `processing/summary` error subdocument carries same message and stage | Phase 02 seam test (summary assertions) |
| 4 | Contract test covering worker failure → rag-api persistence exists and passes; fails on key drift on either side | Phase 02 (tasks 1–4) |

## 6. Constraint compliance

- **Must (align worker, not rag-api):** §3.1/§3.5 — rag-api production code untouched.
- **Must-not (no migration/rename/backfill):** persisted field names `error`/`error_stage`/`retryable` unchanged; only payload keys on the wire change.
- **Must (explicit retryable):** §3.3 — `details.get("retryable", True)` fallback is never operative for worker failures.
- **Prefer (retain legacy `error`):** §3.1.
- **Prefer-not (no error-code taxonomy):** no `error_code` sent; summary `code` stays `"UNKNOWN"`.

## 7. Non-goals (from the Definition — do not implement)

- Stale-lease sweep changes (its direct write already conforms; existing test must stay green).
- Retry/backoff mechanics: ACK/NACK policy, leases, heartbeat intervals.
- Frontend/mobile changes (`ResourceResponse` already exposes `error`/`error_stage`).
- Structured error codes / failure taxonomy.
- Anything the companion D3 issue covers beyond this payload alignment (content unavailable here — deferred); reconciling with the D4 deviation note in `plans/upload-flow.md` (file not present in the current tree).

## 8. Risks & mitigations

- **Unknown consumers of the status topic** reading the old key set → mitigated by retaining `error`; residual risk accepted as low (per Definition F11).
- **Stage-tracker drift** as the pipeline evolves → mitigated by the set-before-await convention + representative early/late-stage tests.
- **`retryable: false` for unclassified-unknown errors** reduces auto-retry affordances → accepted; widening `classify_error` is out of scope; manual reprocess unaffected.
- **Contract test ossifies the payload** → intentional; that is the drift guard. Adding a key later means touching the test deliberately.
- **Cross-service import weight in the shared integration dir** (worker `main.py` needs stubs the shared conftest doesn't provide) → mitigated by module-local stubbing in the new test file (stub-if-missing semantics, matching both existing conftests) and by not touching the shared conftest. If import-time failures appear, fall back to hosting the both-sides test under `rag-worker-service/tests/integration/` with a local conftest addition for the rag-api import (decision point flagged in §10).
- **Async test mode in `apps/ai-server/tests/`** (no local pytest.ini; mode unverified) → write async-driving tests as sync tests using `asyncio.run(...)` to avoid plugin-mode assumptions.

## 9. Validation

- `pytest apps/ai-server/rag-worker-service/tests` (worker unit + integration; `asyncio_mode=auto` applies)
- `pytest apps/ai-server/rag-api-service/tests` (must remain green — no production change)
- `pytest apps/ai-server/tests/integration` (new contract tests + existing suite)
- `./dev/run ai-server` as the final gate (requires Docker Compose per `AGENTS.md`)

## 10. Verify at implementation (known unknowns — do not guess)

1. Exact body of `process_document`'s exception handler and the exact `_publish_status_update` signature/call shape (Definition F3 pins the behavior; the code must be read before editing).
2. Exact callable names of the pipeline step collaborators inside `process_document` (text extraction, tagging, summary, chunking, embeddings) needed for monkeypatching in the stage-tracker test.
3. Whether worker `main.py` imports anything at module level that neither conftest stubs (e.g. lazy vs. top-level imports of PDF-extraction libraries) — run the import in the test env early in Phase 02.
4. Whether `pytest-asyncio` is active for `apps/ai-server/tests/` and in which mode — resolved by the `asyncio.run` sync-test approach regardless.
5. Exact patterns/helpers inside `tests/integration/test_api_contracts.py` (existence and AST/fixture characterization pinned by Definition F10; specifics not retained) — implement the new AST guard standalone.
6. Whether `./dev/run ai-server` picks up `apps/ai-server/tests/integration` automatically (it runs the suite containing `test_api_contracts.py` today; confirm the new file is collected).

## 11. Plan deviations

None at planning time. Per `AGENTS.md`, any material deviation discovered during implementation stops the phase and is recorded here for human review.