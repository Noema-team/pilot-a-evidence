# Test Plan — worker → rag-api failure payload contract

Scope: the contract test required by the authoritative definition (AC4) plus the worker-side mechanism coverage needed to make AC1 trustworthy. Primary location: `apps/ai-server/tests/integration/test_worker_failure_payload_contract.py` (new), sibling of the existing `test_api_contracts.py` whose patterns (direct `import main as rag_api_main`, fixture- and AST-based static checks) it follows.

## 1. Strategy

Three layers, one seam:

1. **Behavioral seam (emulator)** — the real worker payload-construction code feeds the real rag-api persistence code; Firestore emulator provides hermetic persistence. This is the definition's core requirement: "exercise the worker's failure-payload construction and rag-api's failed-branch persistence … and assert the persisted error, error_stage, and retryable equal the worker's values".
2. **Mechanism (stage tracker)** — the real `process_document` runs on a minimally constructed processor with monkeypatched pipeline steps; asserts the failure payload's `stage` for representative early/late failures.
3. **Drift guards** — pin the worker's payload key set and probe rag-api's read keys so a future edit on either side fails the build instead of silently re-creating the bug.

## 2. Environment & fixtures

- **Firestore emulator**: both services have verified `FIRESTORE_EMULATOR_HOST` branches (`rag-api-service/main.py` `AppState.startup`; `rag-worker-service/main.py` `_init_services`). The test module initializes its own `firebase_admin` app with `projectId` from `GCP_PROJECT` (default `demo-project`) when `FIRESTORE_EMULATOR_HOST` is set, mirroring those branches. **Verify at implementation** how `tests/integration/conftest.py` (unread) already wires the emulator and reuse it rather than inventing a parallel mechanism.
- **Worker module import stubs** (verified import-time requirements of `rag-worker-service/main.py`): set `GCP_PROJECT` and `GOOGLE_APPLICATION_CREDENTIALS` before import; provide a test-only dummy service-account JSON fixture (module import constructs `pubsub_v1.SubscriberClient` from it but never connects). If `from_service_account_file` rejects a static dummy (it parses the private key), generate a throwaway RSA key in a session-scoped fixture via the `cryptography` dependency of the google-auth stack (verify availability). Heavy deps (langchain/openai/spacy/sklearn/tiktoken) must be installed in the test env — verify; fallback options in §6.
- **Seeding**: a resource document at `users/{test-user}/resources/{test-resource}` with `status: "processing"` — required because rag-api's `ALLOWED_TRANSITIONS` only permits `processing → failed`; without it `run_transactional_update` silently no-ops (verified). Use unique IDs per test to avoid cross-test state.
- **No rag-api app startup**: tests call `run_transactional_update(db, doc_ref, ...)` directly (module-level function, verified) — no FastAPI/Pub/Sub subscriber needed.

## 3. Test inventory

### Behavioral seam tests (emulator)

- **T1 — transient early-stage failure end-to-end.**
  Act: `details = build_failure_details(httpx.ConnectTimeout("upstream unreachable"), "text_retrieved")`; call `run_transactional_update(db, doc_ref, "failed", details, logger, user_id)`.
  Assert main doc: `status == "failed"`, `error == "upstream unreachable"`, `error_stage == "text_retrieved"`, `retryable is True`. Assert summary subdoc: `error.message == "upstream unreachable"`, `error.stage == "text_retrieved"`, `error.code == "UNKNOWN"`, `stage == "text_retrieved"`.
  Note: `retryable is True` alone cannot distinguish "sent" from "defaulted" — T9/T10 close that gap.

- **T2 — permanent late-stage failure end-to-end.**
  Act: `details = build_failure_details(ValueError("malformed document"), "embeddings_complete")`; same persistence call.
  Assert: `error == "malformed document"`, `error_stage == "embeddings_complete"`, `retryable is False`; summary error subdoc mirrors message/stage. This case also proves the payload is *sent* (a defaulted `retryable` would be `True`, so `False` can only come from the worker payload).

- **T3 — unclassified-unknown exception pins the deliberate behavior change.**
  Act: `details = build_failure_details(RuntimeError("boom"), "chunking_complete")`.
  Assert persisted `retryable is False` (classify_error's conservative default), `error == "boom"`, `error_stage == "chunking_complete"`. Documents F8: unknown ≠ silently-retryable anymore.

- **T4 — no-fallback invariant.**
  Assert on every persisted doc from T1–T3: `error != "Processing failed"`, `error_stage is not None`, and summary `error.message`/`error.stage` equal the main doc's `error`/`error_stage` (AC3 parity, verified same-source reads in rag-api).

### Mechanism tests (stage tracker, real `process_document`)

Construction: `processor = EnhancedDocumentProcessor.__new__(EnhancedDocumentProcessor)`; set `langfuse = None`, a stub `config`, stub `logger`, stub `db`, and monkeypatch every collaborator `process_document` touches (verified reference list): `_validate_processing_request`, `_publish_status_update` (capture `(status, details)` calls), `_get_extracted_text`, `content_tagger.generate_tags`, `generate_document_summary`, `_get_document_path`, `_create_enhanced_chunks`, `_generate_embeddings_with_openrouter`, `delete_old_vectors_via_service`, `store_chunks_via_service`, `_save_processing_metadata_to_subcollection`, `_update_user_usage`, `_generate_resource_map`. Each case makes exactly one step raise.

- **T5 — early-stage failure**: `_get_extracted_text` raises → captured failed-payload `stage == "text_retrieved"`, `error_message` == the raised message, `retryable` per `classify_error`.
- **T6 — late-stage failure**: `_generate_embeddings_with_openrouter` raises → `stage == "embeddings_complete"`.
- **T7 — unlabeled-phase failure**: `store_chunks_via_service` raises (verified: it is the raise-capable step after embeddings) → `stage == "processing"`.
- **T8 — pre-transition failure**: `_validate_processing_request` raises → `stage == "processing"` (initial value; the definition's own "before the first transition" example).
- Each of T5–T8 also asserts the captured failed payload contains all four keys `{error_message, stage, retryable, error}` and that a `"completed"` publish never preceded the failure.

### Drift guards

- **T9 — worker payload key-set pin (behavioral).** `set(build_failure_details(Exception("x"), "starting").keys()) == {"error_message", "stage", "retryable", "error"}`. Any worker-side key rename/addition/remove fails here.
- **T10 — rag-api read-key probe (behavioral negative).** Feed `run_transactional_update` a failed-status payload carrying only the legacy key (`{"error": "legacy"}`) with status seeded `processing`. Assert persisted `error == "Processing failed"` and `error_stage is None` — i.e., rag-api demonstrably reads `error_message`/`stage`, not `error`. If rag-api's read keys drift, this probe's outcome changes and the test fails.
- **T11 — optional AST guard (house pattern).** Following `_get_agent_graph_shapes` in `test_api_contracts.py`, statically scan `rag-api-service/main.py` for `details.get("error_message"`, `details.get("stage"`, `details.get("retryable"` inside the failed branch, and `rag-worker-service/main.py` for the `build_failure_details` return keys. Include if the behavioral probes are judged insufficient; skip if it duplicates T9/T10 without adding failure modes.

### Regression

- **T12** — existing `tests/integration/test_api_contracts.py` stays green (no rag-api model/field changes are made).
- **T13** — worker and rag-api unit suites (`rag-worker-service/tests/`, `rag-api-service/tests/`) stay green; update any test asserting the old `{"error": str(e)}` failed payload (existence unknown — grep at implementation).

## 4. Drift-failure matrix (what edit breaks what)

| Future edit | Failing test |
|---|---|
| Worker renames/drops `error_message`, `stage`, or `retryable`; drops legacy `error` | T9 (key set), T5–T8 (captured payload), T1–T3 (persisted values regress to fallbacks) |
| Worker removes/bypasses a tracker assignment | T5–T8 report the wrong stage |
| Worker stops deriving retryable from `classify_error` | T2/T3 (persisted `retryable` flips) |
| rag-api renames a read key (`error_message`/`stage`/`retryable`) | T1–T3 (persisted values regress), T10 (probe outcome changes) |
| rag-api changes summary error subdoc shape | T1/T2/T4 assertions |
| rag-api transition guard changes such that `processing → failed` no longer applies | T1–T3 no-op and fail on missing `failed` status |

## 5. Assertions vocabulary (exact, no near-misses)

Persisted main doc: `error` (str, exact equality with `str(e)`), `error_stage` (str from the fixed vocabulary `starting | text_retrieved | tagging_complete | summary_generated | chunking_complete | embeddings_complete | processing`), `retryable` (exact bool identity, `is True` / `is False`), `status == "failed"`. Summary subdoc: `error.message`, `error.stage`, `error.code == "UNKNOWN"`. Never assert "truthy" — the whole point is exact-value persistence.

## 6. Implementation risks & fallbacks

- **Worker import weight** (verified import-time env/key requirements and heavy top-level imports): primary mitigation is env stubs + dummy credential fixture (§2). Fallback A: run the worker-side tests (T5–T9) inside `rag-worker-service/tests/` where its requirements are standard, keeping T1–T4/T10 in `tests/integration/`, with the payload key set shared via a small checked-in fixture so both sides pin the same contract. Fallback B: subprocess harness (the house pattern already runs AST scripts via `subprocess`).
- **Emulator unavailable in a given CI context**: fallback is a fake `db`, which must emulate `@firestore.transactional` + `db.transaction()` (buffer writes, apply on clean exit, pass a transaction object into `get`/`update`/`set`) — implement only if needed; the emulator path is primary because it exercises the real transactional semantics.
- **Unknowns to resolve before writing tests** (carried from docs/plan.md §8): `tests/integration/conftest.py` wiring; `rag-worker-service/exceptions.py` contents (helper placement); whether the integration env installs worker requirements; CI emulator provisioning.

## 7. Done criteria for the test workstream

- T1–T10 implemented and passing (T11 optional per §3); T12/T13 green after any stale-assertion updates.
- Every definition acceptance criterion has at least one asserting test (mapping in docs/plan.md §5).
- A reviewer can point to the specific test that fails for each row of §4's matrix — that is the "fails if either side's payload keys drift" requirement made concrete.