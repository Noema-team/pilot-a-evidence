# Documentation

This folder contains detailed feature specs, UX flows, and design decisions. These are heavy documents — load only the specific file you need, not the whole folder.

## When to load files here

Only load a file from this folder when:
- You are actively working on that specific feature
- The task card links to a doc here with `[[filename]]`

## Before writing or updating docs

Check the repo-root `AGENTS.md` workflow first: docs-only changes go on a
`docs/<slug>` branch as a small-change PR.

## Folder structure

```
documentation/
├── README.md              ← you are here
├── map.md                 ← index of all docs with one-liners
├── ai-features/           ← AI feature specs (RAG, chat, error handling)
├── compliance/            ← GDPR, legal, and compliance docs
├── testing/               ← testing strategy, phase docs, and audit findings
├── tooling/               ← development tooling (the `dev/` framework)
└── web/                   ← web app docs (logging, resource refactor, schema contract)
```

## Important

- Load `map.md` to find specific files
- Do not load this folder broadly — use the map to locate only what you need
- After adding or changing any file, update `map.md`
