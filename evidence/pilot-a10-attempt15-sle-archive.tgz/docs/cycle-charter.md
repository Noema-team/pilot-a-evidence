**Cycle charter — rag-worker → rag-api failure payload contract alignment**
Run 10489e65-9af2-495a-88a3-688deb4cf731 · Iteration 1 · Step: scoping.produce

## Scope

Three bounded changes, derived from the authoritative Definition (`wi-define-108-a8`):

1. **Worker failure payload** (`apps/ai-server/rag-worker-service/main.py`). `process_document`'s exception handler currently publishes `{"error": str(e)}`. It will publish a failure payload carrying:
   - `error_message` — the actual exception message (`str(e)`);
   - `stage` — the pipeline stage executing at failure time, via a stage tracker set immediately before each pipeline step in `process_document` (the "update before the await" convention). Stage names reuse the existing progress-update vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown;
   - `retryable` — deliberately derived from `classify_error(e)`: transient-classified → `true`; permanent-classified, including unclassified-unknown per `classify_error`'s conservative default, → `false`;
   - the legacy `error` key retained alongside `error_message` (same value) as a compatibility hedge for any unknown consumer of the status topic.

2. **rag-api failed branch** (`apps/ai-server/rag-api-service/main.py`, `run_transactional_update`). **Unchanged code.** It is the fixed reference contract: it reads `error_message`/`stage`/`retryable` from the details payload, persists `error`/`error_stage`/`retryable` on the main resource document, and writes `message`/`stage` (with `error.code` defaulting to `"UNKNOWN"`) into the `processing/summary` subdocument. This cycle verifies — via the contract test — that the branch persists worker-provided values unchanged. If verification reveals a rag-api code change is required, that is a scope deviation to escalate, not to make silently.

3. **Contract test** (new, in `apps/ai-server/tests/integration/`, following the fixture- and AST-based patterns of `test_api_contracts.py`). It must:
   - build the failure payload through the worker's real code path (not a restated fixture);
   - feed it through rag-api's `run_transactional_update` failed branch against the Firestore emulator or fakes;
   - assert the persisted `error`, `error_stage`, and `retryable` equal the worker's values, and that the `processing/summary` error subdocument carries the same message and stage;
   - include a key-set drift guard so a future edit to either side's payload keys fails the build;
   - cover representative stages — an early-stage failure and a late-stage failure — pinning the stage-tracker mechanism without ossifying every pipeline step.

## Purpose

Every worker-originated failure currently persists the fallback string `"Processing failed"`, a null `error_stage`, and a fabricated `retryable: true`, because the worker's one-key payload does not match rag-api's three-key read. Users and support cannot disambiguate failures, and retryability is silently defaulted rather than derived. The worker is the odd one out: the stale-lease sweep, both enqueue-failure paths, and the `Resource`/`ResourceResponse` models already speak the `error`/`error_stage`/`retryable` schema. This cycle aligns the worker to that established contract — no migration, no field rename, no backfill, no reader changes — and locks the seam with a contract test so the drift cannot silently return.

## Requirements

1. The worker's failed status payload must include `error_message` (actual exception message), `stage` (failing pipeline stage), and `retryable` (deliberately derived) — it must never rely on rag-api's fallback defaults for these keys.
2. The worker must track the currently executing pipeline stage through `process_document` so the failure handler reports the true failing stage; stage names reuse the existing progress-stage vocabulary, with `"processing"` as the safe value when the stage is genuinely unknown (the field must never regress to null).
3. rag-api's failed branch must persist the worker-provided values unchanged: main document `error` ← payload `error_message`, `error_stage` ← payload `stage`, `retryable` ← payload `retryable`; the `processing/summary` error subdocument must carry the same message and stage.
4. The `retryable` derivation must be explicit and aligned with the worker's ACK/NACK behavior: errors classified transient by `classify_error` → `true`; classified permanent (including unclassified-unknown) → `false`.
5. A contract test must cover the worker failure → rag-api persistence path: exercising the worker's failure-payload construction and rag-api's failed-branch persistence (via the Firestore emulator or fakes), asserting the persisted `error`, `error_stage`, and `retryable` equal the worker's values, and failing if either side's payload keys drift.

Binding constraints: the worker is aligned to rag-api's existing contract — rag-api's reads and persisted schema are not changed. No Firestore migration, field rename, or backfill; persisted field names and semantics are preserved. Every worker-originated failure payload carries `retryable` explicitly; the API-side `details.get("retryable", True)` fallback must not be the operative mechanism for worker failures. The legacy `error` key is retained alongside `error_message` (preferred). No structured error-code taxonomy is introduced (preferred not); `error.code` remains `"UNKNOWN"` unless a code is actually sent.

## Boundaries

- No changes to the stale-lease sweep (`_fail_if_still_stale`) — it already persists `error`/`error_stage`/`retryable` consistently with this contract.
- No retry/backoff mechanics changes: Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals — only the *reporting* of retryability in the payload changes.
- No frontend or mobile changes — `ResourceResponse` already exposes `error` and `error_stage` to clients.
- No structured error codes or failure taxonomy.
- No rag-api read/schema changes; no Firestore migration, rename, or backfill.
- Nothing the companion D3 issue covers beyond this worker→rag-api failure payload alignment (its content is unavailable in this context).

## Version bump

**Patch.** This is a bug fix within the existing contract: no client-visible API shape change (`ResourceResponse` is untouched), no persisted-schema change — Firestore `schema_version` remains `2`, with no migration or backfill. Where service version markers exist (e.g. rag-api's FastAPI `version="1.0.0"`), a patch bump applies if those markers are touched; no version file changes are otherwise required, and no changelog entry beyond the PR description.

## Deferred items

- The companion D3 issue referenced by the Objective — its scope is unavailable here; anything it covers beyond this payload alignment is deferred.
- Reconciling this analysis with the original D4 deviation note in `plans/upload-flow.md` (that file is not present in the current tree; the reference comes from the Objective text).
- Dropping the legacy `error` key from the worker's failure payload, after an audit confirms rag-api's status subscriber is the only consumer of the topic (trivial cleanup once confirmed).
- Widening `classify_error`'s transient heuristics — the accepted residual risk is that genuinely transient-but-unrecognized failures now persist `retryable: false`; manual reprocess via `POST /process` remains available.
- A structured error-code taxonomy / failure classification scheme.
- A full audit of other potential consumers of the status topic beyond rag-api's subscriber (hedged by retaining the `error` key).