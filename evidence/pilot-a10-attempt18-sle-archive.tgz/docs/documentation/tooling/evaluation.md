---
tags:
  - Documentation/Internal
  - Development
---

# Evaluation: start here

How to use the evaluation system to make the product measurably better. This is the end-to-end workflow; the deeper references are linked at the bottom.

The system answers two questions with two tools:

| Question | Tool | Command |
|---|---|---|
| Does it work? | Golden journeys | `dev/run journeys` |
| Is it good? | Eval scorecard | `dev/run eval` |

Everything below assumes the hermetic test stack (Docker Compose, Firebase/PubSub/Storage emulators, a record/replay LLM proxy). **Replay mode is free and deterministic** — every model call comes from a cassette; a miss is a hard 409, never a live call. Only `dev/env/run cassettes record` spends money.

---

## 1. Bring the stack up (choose a profile)

```bash
dev/env/run up --profile fast       # default: pypdf, no reranker — offline, fast
dev/env/run up --profile fidelity   # marker-pdf + reranker — real extraction, ~2GB download
dev/run seed                        # ingest the fixture corpus (3 documents)
```

**Profile rules:**

- `fast` for journeys and retrieval smoke checks. Never score **structure** on it — pypdf flattens headings and you'd be measuring degraded extraction as if it were the product.
- `fidelity` for structure quality and any number you intend to promote as a baseline.

Known gotcha: after restarting containers, Pub/Sub topics vanish and consumers hold stale clients. If seed fails with `404 Topic not found` or hangs at "no stage reported": `python3 dev/env/seed-emulators.py`, then restart `rag-worker-service` and `rag-api-service`, then reseed.

## 2. Verify for free (replay)

```bash
dev/run journeys                    # does it work?  → .devloop/verdict.json
dev/run eval                        # is it good?    → eval/results/<run-id>.json
```

`dev/run eval` always runs the **corpus-integrity preflight** first, and exits 2 (blocked, harness problem — not a product failure) if:

- a golden-mapped resource's map can't be fetched (run `dev/run seed`; J7 deletes a resource without reseeding), or
- the search index doesn't hold exactly the chunks a resource's map claims (`partial index N/M` / `stale index` — vector writes failed or leaked).

This is deliberate: both v1 baselines were once recorded against a half-deleted index and their "retrieval misses" were fiction. The preflight makes that class of scorecard impossible.

## 3. Judge answers and flashcards (recorded)

Retrieval and routing are scored deterministically; faithfulness, relevance, and card quality need the LLM judge, which needs cassettes. They exist (`eval/cassettes/`, 280+), so replay just works:

```bash
dev/run eval --judge                # + faithfulness/relevance per answer
dev/run eval --judge-cards          # + generate flashcards for leaf sections, judge each
```

**Re-recording after a prompt/model change** (the only path that spends money):

```bash
# optional but recommended: cap live calls on a limited-budget key
LLM_RECORD_MAX_CALLS=150 LLM_UPSTREAM_API_KEY=sk-... dev/env/run cassettes record

dev/run eval --judge --judge-cards --label my-change    # records as it runs
dev/env/run cassettes stop-record                       # back to free replay

# then re-run the eval WITHOUT record and confirm identical numbers (0 misses)
dev/run eval --judge --judge-cards
curl -sf localhost:9100/__misses                        # "count": 0
```

A run that requested `--judge`/`--judge-cards` but scored nothing (or nothing on some dimension) **exits 2** — a judged-looking run that judged nothing must not read as complete.

## 4. Compare against the baseline

```bash
dev/run eval --judge --judge-cards --compare eval/baselines/fidelity-v2.json
```

The verdict prints and the exit code encodes it (0 adoptable / 1 regression / 2 blocked). Adoption is blocked by:

- any aggregate regression beyond noise thresholds (e.g. judge means ≥1.0 point),
- any **per-query** regression (one query's faithfulness dropping 1 point, a routing flip, a retrieval miss appearing),
- **judge/card coverage loss**: the candidate scored fewer results than the baseline, *or* scored a smaller fraction of its generated pool (baseline 6/6 judged vs candidate 6/12 = 50% coverage is a loss even though the count held).

Invalid baselines are rejected before any paid work: `fast-v1` and `fidelity-v1` are marked invalid (recorded against the contaminated index — see `eval/TUNING-LOG.md` 2026-08-20).

## 5. The tuning loop

```bash
# change ONE thing (e.g. the classifier prompt)
$EDITOR apps/ai-server/agent-graph-service/src/agents/classifier.py

# a prompt edit invalidates its cassettes — re-record just what changed (step 3)
dev/run eval --judge --judge-cards --compare eval/baselines/fidelity-v2.json
# verdict "IMPROVED, nothing regressed" → adopt; anything else → revert and read the diff
```

Log every attempt in `eval/TUNING-LOG.md` — what changed, before/after, verdict. Six weeks later it is the only record of why a prompt looks the way it does.

**Current baseline and first target** (`fidelity-v2`, 2026-08-21): retrieval recall@5 1.00 / MRR 1.00, structure F1 1.00, judge faithfulness 4.70 / relevance 4.85 (20/20), cards 6/6 at 100% on all dimensions, routing 80%. The proven weakness: `TEACHING_CONCEPTUAL → SEARCH` misroutes ×3 — conceptual "explain why" questions get treated as lookup. Routing is the first lever; see `docs/TUNING-GUIDE.md` §1.

## Quick reference

```bash
dev/env/run up --profile fidelity   # stack with real extraction
dev/run seed                        # ingest the fixture corpus
dev/run journeys                    # does it work?
dev/run eval                        # is it good?   (preflight + scorecard)
dev/run eval --judge --judge-cards  # + LLM-judged quality (replay: free)
dev/env/run cassettes status        # proxy mode + cassette count + miss log
dev/run eval --compare eval/baselines/fidelity-v2.json
```

| Exit code | Meaning |
|---|---|
| 0 | pass / adoptable |
| 1 | fail — the product regressed |
| 2 | blocked — the harness or environment is wrong; fix that, not the code |

## Where to read more

- `eval/README.md` — what each scorer measures, tier table, dataset honesty rules, baselines
- `docs/TUNING-GUIDE.md` — symptom → lever → loop, ranked levers, temperature table
- `eval/TUNING-LOG.md` — every recorded decision, and why
- `docs/EVAL-AND-TUNING-SPEC.md` — the original design spec (intent; commands may predate wiring)
- `docs/documentation/tooling/dev-framework.md` — the broader `dev/` collectors/context-pack
