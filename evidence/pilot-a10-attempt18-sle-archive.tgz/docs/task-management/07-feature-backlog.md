---
tags:
  - TaskManagement
---
# Prepare for lecture feature
#ToDo
AI-powered lecture prep. User selects relevant resources (tags, topics) and adds lecture slides. Configurable depth (Overview → In-Depth). AI uses resource skeletons to understand context and suggests what to read, understand, or review. See [[prepare-for-lecture]] for detailed spec.

---
