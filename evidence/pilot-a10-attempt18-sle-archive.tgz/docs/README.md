# docs/ — Documentation Index

The one-page map of all documentation: what exists, what layer it operates at, and which doc to open for a given question. The loading chain is `AGENTS.md` (repo + agent rules) → **this file** (landscape) → hub `README.md` → hub `map.md` → leaf doc.

## Which doc answers which question

| Question you're asking | Doc |
|---|---|
| How does the product work? (services, auth, data flow) | `system-overview/` hub |
| What does feature X do? (specs, UX flows, design decisions) | `documentation/` hub |
| What should be tested, and to what coverage? | `TESTING-STRATEGY.md` |
| How do I run evals / journeys / cassettes / tuning loops? | `documentation/tooling/evaluation.md` → `TUNING-GUIDE.md` |
| Where do I start with tuning prompts/answers? | `eval/PLAYBOOK.md` (the tuning loop, start to finish) — `TUNING-GUIDE.md` is the deeper reference |
| Why was the verification system built this way? | `AUTONOMOUS-VERIFICATION-PLAN.md` |
| What was the original eval design intent? | `EVAL-AND-TUNING-SPEC.md` |
| What tuning decisions were made, with numbers? | `eval/TUNING-LOG.md` (repo root, referenced from map.md) |
| Where does CI physically run and how is it operated? | `documentation/tooling/self-hosted-runner-setup.md` |
| How do I replicate the CI/protection stack on another repo? | `documentation/tooling/new-repo-ci-checklist.md` |
| How do I develop/debug the Flutter app on a real phone? | `apps/mobile/docs/DEVICE-WORKFLOW.md` (human workflow) → `documentation/tooling/agent-mobile-debugging.md` (agent runbook) |
| What work is planned / in flight? | `task-management/` hub |

## Root-level docs (not inside a hub)

- `TESTING-STRATEGY.md` — testing strategy: pyramid, naming, coverage targets, backend service map. The *what to test* layer.
- `TUNING-GUIDE.md` — symptom → lever → loop for quality tuning: ranked levers, five-minute scorecard read, adopt/revert rules. The *how to improve* layer.
- `EVAL-AND-TUNING-SPEC.md` — original eval/tuning design spec (intent; predates the current wiring — current behavior lives in `documentation/tooling/evaluation.md`).
- `AUTONOMOUS-VERIFICATION-PLAN.md` — the system assessment that motivated the verification stack: what was untested in 2026-08, why, and the build plan. Historical/decision record.

## Hubs (each with its own README + map.md — load maps, not folders)

- `system-overview/` — product architecture: `general/` (auth, Firebase, data flow, design rules), `ai-server/`, `mobile/`, `web/`.
- `documentation/` — feature specs and operational how-tos: `ai-features/`, `compliance/`, `testing/`, `tooling/`, `web/`.
- `task-management/` — numbered task areas (01–08) plus `critical-tasks.md`.
- `superpowers/` — `plans/` (implementation plans) and `specs/` (design specs), produced by the planning/brainstorming workflows.

## Layer discipline (why docs are split this way)

- **Strategy vs operations vs records:** TESTING-STRATEGY says what to test; tooling runbooks say how to run something; TUNING-LOG and the audits are append-only records of what was decided. A change usually touches one layer, not three.
- **Hub maps beat folder browsing:** every hub's `map.md` is the index; loading whole folders wastes context and goes stale.
- **Specs vs reality:** where a spec predates implementation (eVAL-AND-TUNING-SPEC), the tooling docs are authoritative; the spec stays as intent history.
