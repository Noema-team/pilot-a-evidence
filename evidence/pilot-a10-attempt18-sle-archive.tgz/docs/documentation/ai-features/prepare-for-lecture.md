---
tags:
  - Documentation/Internal
---
# Prepare for Lecture Feature

## Concept

A feature that helps students prepare for an upcoming lecture in a structured, AI-assisted way.

## User flow

1. The user selects relevant resources (or filters by tags, topics, or other groupings).
2. The user uploads or selects the specific lecture slides/PPT.
3. The user chooses a desired depth or time commitment. Options could be a slider (Overview → In-Depth) or radio buttons (Overview, Summary, Detailed, In-Depth).
4. The AI processes the materials and generates a preparation plan.

## How the AI works

- Uses a Resource Skeleton (similar to what flashcards use) to understand context, structure, and what is emphasized.
- Generates actionable suggestions: read this section, understand this concept, review this article.
- Tailors the output to the chosen depth level.

## Open questions

- Slider vs. radio buttons for depth selection?
- Should the user be able to set a time budget (e.g. "I have 30 minutes") instead of or in addition to depth?
- How does this integrate with the timeline feature — should prep sessions appear as units on the exam path?
