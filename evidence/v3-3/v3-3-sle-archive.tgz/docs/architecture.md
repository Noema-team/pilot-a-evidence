# Architecture — rag-worker → rag-api failure payload contract alignment

- **Cycle intent:** rag-worker → rag-api: failure payload contract mismatch — failures persist without message or stage
- **Run:** 79e8a2e6-4caa-40de-8f8d-9d7160fc5b1e (iteration 1, step: design)
- **Companion document:** `docs/requirements.md` (FR/AC/NFR IDs referenced below are defined there)
- **Authoritative source:** define-work WorkItem `wi-define-108-a8`, artifact `definition:obj-108`, sha256 `71f1c39c97ecea575b1195b63de510fa403dad4fecaa1df0c774d04fae89cac5`

---

## 1. System context and current (as-is) flow

```
rag-worker (process_document, one large try block)
      │  exception handler publishes failed status
      ▼
_publish_status_update(..., "failed", details = {"error": str(e)})   ← the ONLY writer
      │                                                            not speaking the schema
      ▼  Pub/Sub status topic
rag-api status subscriber → run_transactional_update — failed branch
      reads details["error_message"], details["stage"], details["retryable"]
      ▼
Firestore resource document:
      error        ← details.get("error_message", "Processing failed")   ← fallback hit
      error_stage  ← details.get("stage", None)                          ← fallback hit
      retryable    ← details.get("retryable", True)                      ← silent default hit
      processing/summary error subdocument ← {message, stage, error_code: "UNKNOWN"}
```

Every worker-originated failure therefore lands as `"Processing failed"` / `None` / fabricated `retryable: true` (Definition F3–F5). Three other write paths — the worker's stale-lease sweep (`_fail_if_still_stale`) and rag-api's enqueue-failure paths (`/process`, `POST /resources`) — already write `error`/`error_stage`/`retryable` directly, and `ResourceResponse` plus the `Resource` model expose them (F6). **The worker's status publisher is the only writer that doesn't speak the schema; fix the odd one out.**

## 2. Design principles

1. **The worker aligns to the API.** The persisted field names are consistent across three write paths and two response models; changing the API side is the change that ripples. No migration, no backfill, no reader changes (constraints C-1, C-2).
2. **Derive, don't default.** `retryable` comes from the worker's existing `classify_error()` — the same classification that drives ACK/NACK in `run_worker` (F7) — so the persisted record tells the truth about retry behavior (FR-4, assumption A-1).
3. **Test the seam, not a fixture copy.** The contract test imports both real sides rather than restating the contract in a fixture; the method under test is never mocked (house principle from `rag-api-service/tests/unit/test_service_contracts.py`).

## 3. Target (to-be) flow

```
process_document (rag-worker)
  current_stage = "processing"                      ← safe fallback, initialized
  ├─ set current_stage = "starting"                 → entry/kickoff step
  ├─ set current_stage = "text_retrieved"           → text extraction/retrieval step
  ├─ set current_stage = "tagging_complete"         → tagging step
  ├─ set current_stage = "summary_generated"        → summary step
  ├─ set current_stage = "chunking_complete"        → chunking step
  └─ set current_stage = "embeddings_complete"      → embedding/storage step
        │
        exception e
        ▼
  details = _build_failure_details(
      error_message = str(e),
      stage         = current_stage,
      retryable     = classify_error(e) is transient)
  # details = {"error": msg, "error_message": msg, "stage": stage, "retryable": bool}
        ▼
  _publish_status_update(..., "failed", details) ──── Pub/Sub status topic ────┐
                                                                               ▼
                              rag-api subscriber → run_transactional_update — failed branch
                              (UNCHANGED — reference consumer):
                                error        ← details["error_message"]
                                error_stage  ← details["stage"]
                                retryable    ← details["retryable"]
                                processing/summary.error ← {message, stage, error_code: "UNKNOWN"}
```

## 4. Worker-side design (the only functional change surface)

All changes are in `apps/ai-server/rag-worker-service/main.py`. rag-api requires **no functional changes** — its failed branch already implements FR-3 (F4); it is verified and pinned by the contract test (§6).

### 4.1 Stage tracker

- A local variable in `process_document` (the exception handler is in the same function scope, so a local suffices — no contextvar or class-level state).
- Initialized to `"processing"`; each pipeline step's vocabulary name is assigned **immediately before** the step's `await`/call (the "set-before-await" convention).
- `starting` is assigned at entry (kickoff); the remaining names are assigned before their respective steps. A failure path that somehow escapes assignment reports `"processing"` — the same value the stale-lease sweep uses for `error_stage`, so `error_stage` never regresses to null.
- Stage names reuse the existing progress-update vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`) so a failure stage reads naturally next to the progress timeline clients already see (F9). `completed` is excluded — a completed job does not fail.
- Semantic note: the name identifies the pipeline step whose work is in progress; it matches the progress milestone published when that step completes. A failure at `text_retrieved` reads as "failed during the text-retrieval step".

*Known drift risk:* a future pipeline step added without updating the tracker reports a stale stage. Mitigated by the set-before-await convention plus representative-stage test coverage (§6.3) — enough to catch the tracker being removed or bypassed without ossifying every step.

### 4.2 Failure payload construction

A small pure helper (indicative name `_build_failure_details`; exact identifier at implementation discretion — the **payload keys and semantics are binding**, not the name), co-located in `main.py` near `_publish_status_update`:

```
_build_failure_details(error_message: str, stage: str, retryable: bool) -> dict
  → {"error": error_message,          # legacy key, retained (FR-6 / C-4)
     "error_message": error_message,  # contract key rag-api reads
     "stage": stage,                  # contract key rag-api reads
     "retryable": retryable}          # contract key rag-api reads
```

The exception handler calls it with `str(e)`, the tracker value, and the derivation from §4.3. The helper is the single source of truth for the payload shape and the import anchor for the contract test (§6) — it keeps the test off the worker's heavy import graph for the payload-shape assertions.

### 4.3 retryable derivation

`retryable` is derived in the exception handler from the worker's existing `classify_error()` (F7): transient-classified → `true`; permanent-classified, including unclassified-unknown per `classify_error`'s conservative default → `false`. The exact call syntax maps to the function's actual return shape at implementation time; the semantics in FR-4 are binding.

Context (verified): `rag-worker-service/exceptions.py` carries a `retryable` metadata field on `PDFProcessingError`, whose docstring states it is metadata for consumers, not the retry decision. That metadata is **not** the derivation source here — not all exceptions are `PDFProcessingError`, and the Definition pins `classify_error` (which drives ACK/NACK in `run_worker`) as the source, so the persisted flag matches what the retry machinery actually does.

### 4.4 Deliberate behavior changes

| Case | Before | After | Assessment |
|---|---|---|---|
| Any worker failure — `error` | `"Processing failed"` | actual exception message | intended fix |
| Any worker failure — `error_stage` | `None` | failing stage (or `"processing"`) | intended fix |
| Transient-classified failure — `retryable` | `true` (silent default) | `true` (derived) | same value, now deliberate |
| Permanent-classified failure — `retryable` | `true` (silent default) | `false` (derived) | **visible change**; the conservatism `classify_error` was written for — prevents infinite retry loops; manual reprocess via `POST /process` unaffected |
| Unclassified-unknown failure — `retryable` | `true` (silent default) | `false` (classify_error's conservative default) | **visible change**; accepted per requirements §8 A-1 |
| Processing/summary subdocument | fallback message/stage, `error_code` `"UNKNOWN"` | real message/stage, `error_code` still `"UNKNOWN"` | intended fix; no taxonomy introduced (FR-7) |
| Stale-lease sweep write | `retryable: true` | unchanged | a dead worker is a transient condition by nature |

## 5. Data contract (to-be, binding)

### 5.1 Worker → status topic (failed status, details mapping)

| Key | Type | Source | Notes |
|---|---|---|---|
| `error` | string | `str(e)` | legacy, retained for unknown consumers/log tooling (FR-6); equal to `error_message` |
| `error_message` | string | `str(e)` | contract key |
| `stage` | string | stage tracker | vocabulary: `starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`; fallback `processing` |
| `retryable` | bool | `classify_error(e)` derivation | always explicit; never absent |

### 5.2 rag-api failed branch → Firestore (unchanged behavior, pinned by test)

| Payload key | Main document field | Processing/summary error subdocument |
|---|---|---|
| `error_message` | `error` | `message` |
| `stage` | `error_stage` | `stage` |
| `retryable` | `retryable` | — |
| *(absent)* | — | `error_code` defaults to `"UNKNOWN"` |

## 6. Contract test architecture

### 6.1 Placement and structure

Two files, respecting existing conftest ownership (both verified):

1. **`apps/ai-server/tests/integration/test_worker_failure_contract.py`** (new) — the cross-service seam test. The existing `tests/integration/conftest.py` already mocks rag-api's cloud dependencies and puts `rag-api-service` on `sys.path`; it is extended (mechanically, mirroring the verified stub set in `rag-worker-service/tests/conftest.py`) so worker `main` imports hermetically too.
2. **`apps/ai-server/rag-worker-service/tests/unit/test_failure_status_payload.py`** (new; name indicative) — worker-side behavioral tests for the stage tracker and derivation. The worker's test conftest already imports `main` hermetically (established pattern in `tests/unit/test_processing_lease.py`).

### 6.2 Cross-service seam test (FR-5, AC-2, AC-3, AC-4)

- **Worker side:** obtain the failure payload through the worker's real construction path — call the payload-building helper (§4.2) with representative values, and/or drive `process_document`'s exception path with stubbed pipeline collaborators where the import graph permits.
- **rag-api side:** feed that payload into the real `run_transactional_update` failed branch (exact call signature adapted to the actual function at implementation time; behavior per F4).
- **Persistence harness:** a fake Firestore transaction/document graph modeled on the verified `FakeTx`/`FakeDb`/`FakeRef` pattern in `rag-worker-service/tests/unit/test_processing_lease.py` — records every write, exposes final merged state for the resource document and its `processing`/`summary` subdocument, and stands in for `firestore.transactional`. (The emulator path remains compatible — both services have `FIRESTORE_EMULATOR_HOST` branches per F10 — but **fakes are the primary**, per NFR-2 determinism and zero-infra requirements.)
- **Assertions:** persisted `error` == payload `error_message`; `error_stage` == payload `stage`; `retryable` == payload `retryable`; subdocument `message`/`stage` equal the main document's; `error_code` == `"UNKNOWN"`.
- **House rule:** neither the payload builder nor `run_transactional_update` is mocked — only infrastructure is faked.

### 6.3 Representative-stage behavioral tests (worker-side file)

Drive `process_document` with induced failures at an **early** step and a **late** step (stubbed pipeline collaborators; captured status-publish sink) and assert the published details carry the correct stage — pinning the set-before-await tracker mechanism against removal or bypass (FR-2, FR-5). Additional cases: unknown-stage failure → `"processing"`; derivation table from FR-4 (transient → `true`, permanent → `false`, unclassified-unknown → `false`); legacy `error` key present and equal to `error_message`.

### 6.4 Key-drift guard (NFR-5)

Two layers, in the cross-service file, following the AST-based house pattern of `tests/integration/test_api_contracts.py` (F10):

- **Dynamic (worker):** call the payload builder; assert the emitted key set is exactly `{"error", "error_message", "stage", "retryable"}` and `error == error_message`.
- **Static (rag-api):** AST-parse `rag-api-service/main.py`, locate `run_transactional_update`'s failed branch, collect the string literals used as details keys, and assert they are exactly `{"error_message", "stage", "retryable"}`.

A future edit to either side's keys fails the build instead of silently re-creating the bug. The fallback behavior itself is not asserted — changing rag-api's reads is out of scope (C-1); the guard pins the keys both sides actually use.

## 7. Compatibility and rollout

- **Deploy order:** worker-only change; rag-api is untouched, so there is no ordering constraint. Old rag-api + new worker is the *current* pairing already (rag-api already reads the new keys).
- **Rollback:** redeploying the old worker restores the fallback behavior (the bug) — harmless, no data migration implications; fields and semantics are unchanged (C-2).
- **Unknown consumers:** only rag-api's status subscriber is a verified consumer (F11); the retained legacy `error` key hedges unverified readers of the shared topic. One redundant string per failure message as insurance; dropping it later is trivial cleanup pending the consumer audit (D-3).
- **Existing documents:** no backfill; historical failed documents keep their fallback values. New failures persist real values.

## 8. Risks and mitigations

| ID | Risk | Mitigation | Residual |
|---|---|---|---|
| R-1 | Unknown consumers of the status topic read the old key set | Retain legacy `error` key (FR-6) | Low, accepted |
| R-2 | Stage-tracker drift as the pipeline evolves | Set-before-await convention; representative early/late-stage tests | Accepted; convention documented in code |
| R-3 | `retryable=false` for genuinely transient-but-unrecognized failures reduces auto-retry affordances | Accepted per Definition; widening `classify_error` is out of scope; manual reprocess via `POST /process` remains | Accepted |
| R-4 | Contract test ossifies the payload | Intentional — that is the drift guard doing its job; adding a key later means touching the test | Accepted |
| R-5 | **CI gating gap (verified):** `.github/workflows/deploy.yml` currently gates only auth-service npm tests; the Python suites are not gated by this workflow, so the drift guard protects only where pytest runs | Wire the ai-server pytest suites into CI as a follow-up (D-4, outside this cycle's bounded scope); tests are placed in the existing pytest layout so they run wherever those suites run | Flagged, deferred |
| R-6 | Import-graph friction importing worker `main` in the cross-service test | Mechanical extension of the shared integration conftest, mirroring the verified worker stub set; fallback split described in §6.1 keeps the seam test light if friction proves high | Low |

## 9. Alternatives considered and rejected

- **Change rag-api to read the worker's `error` key** — rejected: ripples across three established write paths and two response models (F6); violates C-1.
- **Rename persisted fields to `error_message`/`failure_stage`** — rejected: requires migration/backfill; violates C-2.
- **Derive `retryable` from `PDFProcessingError.retryable` metadata** — rejected: not all exceptions carry it, and it is explicitly metadata, not the retry decision (verified in `exceptions.py`); `classify_error` is the operative ACK/NACK classifier (F7) and the Definition pins it.
- **Structured error-code taxonomy** — rejected (C-5, FR-7).
- **Firestore-emulator-only contract test** — rejected as primary: fakes are deterministic and infra-free (NFR-2); emulator stays compatible.
- **Contextvar/class-level stage state** — rejected: unnecessary; the handler shares `process_document`'s scope, and the Definition specifies a local.

## 10. File change map

| File | Change | Purpose |
|---|---|---|
| `apps/ai-server/rag-worker-service/main.py` | MODIFY | Stage tracker in `process_document`; failure-payload helper + handler rewrite; `classify_error`-derived `retryable`; legacy `error` key retained |
| `apps/ai-server/tests/integration/test_worker_failure_contract.py` | NEW | Cross-service seam test: worker payload construction → rag-api failed-branch persistence; persisted-value assertions; key-drift guard |
| `apps/ai-server/tests/integration/conftest.py` | MODIFY | Extend stub coverage so worker `main` imports hermetically (mirror worker conftest stub set) |
| `apps/ai-server/rag-worker-service/tests/unit/test_failure_status_payload.py` | NEW | Stage-tracker behavioral tests (early/late/unknown failure), derivation table, legacy key presence |
| `apps/ai-server/rag-api-service/**` | NO functional change | Failed branch is the reference consumer; verified against F4 and pinned by the contract test |
| `docs/requirements.md`, `docs/architecture.md` | NEW | This design pair |

## 11. Definition of done

- [ ] FR-1…FR-7 implemented/verified per §4–§5.
- [ ] AC-1…AC-4 demonstrated by the test files in §6.
- [ ] rag-api failed branch verified to match F4's reads/persistence; any discovered deviation surfaced and resolved within this bounded scope (the contract test is the arbiter).
- [ ] Stale-lease sweep, ACK/NACK policy, leases, heartbeats: confirmed untouched.
- [ ] No Firestore migration, rename, or backfill introduced.
- [ ] Risks R-1…R-6 reviewed; R-5 recorded as deferred follow-up D-4.
- [ ] Deferred items D-1…D-4 recorded in `docs/requirements.md` §9.