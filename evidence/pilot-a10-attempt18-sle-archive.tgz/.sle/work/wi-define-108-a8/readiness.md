---
schemaVersion: 1
gaps: []
---

## Definition Readiness Review — verdict: pass

### D.3d.4 — Contract compliance

The ledger represents every fact the Objective states with the epistemic status and provenance the contract assigns. The Objective's repository claims — the worker publishing only an `error` key from its failure path, rag-api's failed branch reading `error_message`/`stage`/`retryable` with fallbacks, and the resulting persisted shape (fallback string, null stage, silently-true retryable) — are carried as repository-verified facts; the Definition demonstrates genuine inspection rather than inheriting the Objective's assertions (it checked the tree for `plans/upload-flow.md` and recorded its absence, located the existing API-contract test pattern, confirmed the emulator branches, and confirmed what `ResourceResponse` exposes). The authoritative product intent — the four acceptance criteria, including that `retryable` must be sent or derived deliberately rather than defaulted — is KNOWN from the human. Design defaults adopted by the Definition (retryable derived via the existing error classifier, false for unclassified errors) are recorded honestly as ASSUMED with rationale, not passed off as known fact. No Objective fact is missing, silently weakened, or mis-provenanced.

### 1. Outcome — pass

The goal is a single concrete statement: align the worker's failure payload to the keys rag-api already persists so a failed job stores the worker's actual error message and failing stage, with retryability reported or derived deliberately, proven by a contract test. A reader can tell unambiguously whether eventual work satisfies it.

### 2. Boundary — pass

Non-goals draw a real edge: structured error-code taxonomy, retry/backoff mechanics (only the *reporting* of retryability changes), sweep behavior, and frontend work are all excluded, as are the companion D3 issue's contents and the D4 deviation-note reconciliation. The Objective's "retryable either sent or derived deliberately" authorizes either path; choosing derivation is a reversible HOW inside already-authorized intent, not genuinely undecided scope, so it does not block this dimension.

### 3. Critical constraints — pass

The shape-determining constraints are captured: align the worker to rag-api's keys rather than the reverse (avoids a migration), retain the legacy `error` key for unknown topic consumers, retryable must never be silently defaulted, and the contract test must exercise both real sides with a key-set drift guard.

### 4. Consistency — pass

Requirements, constraints, and non-goals cohere with the goal. The retryable derivation choice directly satisfies the "derived deliberately" criterion; retaining `error` is consistent with the consumer-compatibility mitigation; the drift-guard test is consistent with the intentional ossification of the payload.

### 5. Risky assumptions — pass

Among ASSUMED facts, none is unmitigated or goal-invalidating. Unknown consumers of the status topic are covered by the recorded fallback requirement (retain `error`), so falsity of the assumption cannot break the goal. The retryable=false-for-unclassified default carries recorded rationale (manual reprocess remains; widening the classifier is explicitly out of scope) and is the canonical safe-default closure for degenerate-input behavior. Stage-tracker drift is mitigated by the update-before-await convention plus representative-stage coverage. None of these, if false, invalidates the goal or a must/must_not constraint.

### 6. Acceptance — pass

The acceptance model is sufficient to know when the work is done: a contract test that builds the failure payload through the worker's actual code path, feeds it through rag-api's transactional update against the emulator, and asserts the persisted `error`, `error_stage`, and `retryable` — plus a drift guard so future key edits fail the build.

### 7. Remaining unknowns — pass

The two acknowledged open items — the companion D3 issue's content (unavailable in this context) and reconciling the analysis with the D4 deviation note (the referenced file is absent from the tree) — are real but recorded as DEFERRED: both lie outside the payload-alignment scope this Definition bounds, and neither could falsify the goal or any critical constraint. No UNKNOWN blocks the scope's feasibility; the fix is direct code alignment on both sides of an already-observed contract, with no build-or-measure uncertainty.

### Conclusion

All seven dimensions pass for the candidate bounded scope. The Definition is ready for authorization; no refinement, deferral bookkeeping, human decision, or exploration is outstanding.
