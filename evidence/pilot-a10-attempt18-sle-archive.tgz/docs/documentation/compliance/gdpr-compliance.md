---
tags:
  - Documentation/Internal
---
# GDPR & Compliance

## Core privacy principles

1. **User content isolation:** Uploaded content is only accessible to the specific user who uploaded it — both in direct form and indirectly through AI-generated responses.
2. **No cross-user AI leakage:** AI-generated content cannot be shared or leak between users. Each user's AI context is fully isolated.
3. **No training usage:** Content uploaded by users will never be used to train any AI model.

## Implementation considerations

- Firestore security rules must enforce per-user read/write access.
- RAG vector stores must be scoped per user — no shared embeddings across users.
- AI API calls must not include content from other users' documents.
- Audit logging should be in place to verify isolation.
