# Requirements — rag-worker → rag-api failure payload contract alignment

- **Cycle intent:** rag-worker → rag-api: failure payload contract mismatch — failures persist without message or stage
- **Authoritative source:** WorkItem `wi-define-108-a8`, artifact `definition:obj-108` (sha256 `71f1c39c97ecea575b1195b63de510fa403dad4fecaa1df0c774d04fae89cac5`)
- **Step:** design (planning depth: minimal)
- **Status:** Proposed — implements the Definition exactly; no widening, narrowing, or reinterpretation

---

## 1. Problem statement

When RAG document processing fails, the worker's exception handler publishes a one-key failure payload
(`{"error": str(e)}`) while rag-api's failed branch reads three keys (`error_message`, `stage`, `retryable`).
Because of the key mismatch, every worker-originated failure currently persists in Firestore as:

| Persisted field | Actual value today | Required value |
|---|---|---|
| `error` | fallback `"Processing failed"` | the worker's actual exception message |
| `error_stage` | `None` | the failing pipeline stage |
| `retryable` | silent default `True` | a deliberately derived value |

The `processing/summary` error subdocument inherits the same fallbacks, with `error_code` always `"UNKNOWN"`.
Users and support cannot disambiguate failures. The seam between the two services is untested.

## 2. Goals

1. Align the worker's failure status payload to rag-api's existing failed-branch contract
   (`error_message` / `stage` / `retryable`) — the worker is the odd writer out; three other write paths
   (worker stale-lease sweep, rag-api `/process` and `POST /resources` enqueue-failure paths) and both
   response models already speak the `error` / `error_stage` / `retryable` persisted schema.
2. Persist the worker's real error message, the true failing pipeline stage, and a deliberately derived
   `retryable` flag on every worker-originated failure.
3. Lock the seam with a contract test that fails the build if either side's payload keys drift.

## 3. Scope

### 3.1 In scope

- `apps/ai-server/rag-worker-service/main.py`: stage tracking in `process_document`; failure-payload
  construction in the exception handler; `retryable` derivation from `classify_error()`; retention of the
  legacy `error` key.
- `apps/ai-server/rag-api-service/main.py`: **no behavioral change** — the failed branch of
  `run_transactional_update` already reads the correct keys; it is pinned, not modified.
- New contract test covering the worker failure → rag-api persistence path, using existing house patterns
  (`apps/ai-server/tests/integration/test_api_contracts.py` fixture/AST style; the fake
  transaction/Firestore kit proven in `apps/ai-server/rag-worker-service/tests/unit/test_processing_lease.py`).

### 3.2 Out of scope (non-goals, binding)

- Changing rag-api's reads or persisted schema; any Firestore migration, field rename, or backfill.
- Changing the stale-lease sweep's direct failure write (it already persists `error`/`error_stage`/
  `retryable` consistently; its `retryable=true` stays correct — a dead worker is a transient condition).
- Changing retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals — only
  the *reporting* of retryability changes.
- Frontend or mobile changes — `ResourceResponse` already exposes `error`/`error_stage` to clients.
- Introducing structured error codes or a failure taxonomy — the summary `error.code` remains `"UNKNOWN"`
  unless a code is actually sent.
- Anything the companion D3 issue covers beyond this payload alignment (its content is unavailable in this
  context; deferred), and reconciling this analysis with the D4 deviation note referenced in
  `plans/upload-flow.md` (file not present in the current tree).

## 4. Terms

- **Failure payload:** the `details` dict the worker publishes on the status topic inside the envelope
  `{user_id, course_id, resource_id, status, details}` for `status = "failed"`.
- **Stage:** the pipeline step executing at failure time, named from the existing progress-stage vocabulary.
- **Drift guard:** a test assertion that pins the exact key sets on both sides of the seam so a future
  rename/addition on either side fails the build.
- **Deliberately derived:** `retryable` is computed by the worker from `classify_error(e)`; it is never the
  result of rag-api's `details.get("retryable", True)` fallback for worker failures.

## 5. Functional requirements

### FR-1 (must) — Failure payload carries the full contract
When document processing fails, the worker's failed status payload `details` must include:
- `error_message`: the actual exception message (`str(e)`),
- `stage`: the pipeline stage executing at failure time,
- `retryable`: a boolean derived per FR-3.

The payload must never rely on rag-api's fallback defaults (`"Processing failed"`, `None`, `True`) for these
keys. Traceability: acceptance A1, A2; constraints C1, C3; facts F1, F3, F4, F5.

### FR-2 (must) — Stage tracking through `process_document`
The worker must track the currently executing pipeline stage through `process_document` so the failure
handler reports the true failing stage. Stage names must reuse the existing progress-stage vocabulary
(`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`,
`embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown (e.g.,
failure before the first stage transition). The value `"processing"` matches the stale-lease sweep's
`error_stage` convention, so the field never regresses to null. Traceability: acceptance A1, A2; fact F9.

### FR-3 (must) — Explicit `retryable` derivation aligned with ACK/NACK
The worker must derive `retryable` from `classify_error(e)` — the same classification that drives ACK/NACK
in `run_worker`:
- transient-classified errors → `retryable: true` (Pub/Sub will redeliver),
- permanent-classified errors, **including unclassified-unknown** (per `classify_error`'s conservative
  default) → `retryable: false` (message acked; manual reprocess via `POST /process` remains available).

Deliberate behavior change accepted: unclassified-unknown exceptions previously persisted the silent default
`true`; they now persist `false`. Traceability: acceptance A2; constraint C3; facts F7, F8.

### FR-4 (must) — rag-api persists worker-provided values unchanged
rag-api's failed branch must persist the worker-provided values unchanged:
- main document: `error` ← payload `error_message`; `error_stage` ← payload `stage`; `retryable` ← payload `retryable`;
- `processing/summary` error subdocument: `error.message` ← payload `error_message`; `error.stage` ← payload
  `stage` (and the summary `stage` field likewise); `error.code` remains `"UNKNOWN"` unless a code is sent.

No change to rag-api's reads, the persisted field names, or the envelope parsing in `_process_status_message`
(which forwards `details` verbatim). Traceability: acceptance A2, A3; constraints C1, C2; fact F4.

### FR-5 (should — preferred) — Retain the legacy `error` key
The worker's failure payload must retain the legacy `error` key (same value as `error_message`) alongside the
new keys, as a compatibility hedge for any unverified consumer of the status topic and for log tooling.
rag-api ignores this key (verified: the failed branch does not read `details["error"]`). Traceability:
constraint C4 (prefer); fact F11.

### FR-6 (must) — Contract test on the worker → rag-api failure path
A contract test must cover the worker failure → rag-api persistence path. It must:
1. exercise the worker's failure-payload construction through the worker's real code path (not a fixture
   restatement of the contract),
2. feed that payload through rag-api's `run_transactional_update` failed-branch persistence (Firestore
   emulator or fakes),
3. assert the persisted `error`, `error_stage`, and `retryable` equal the worker's payload values, and the
   summary subdocument carries the same message and stage,
4. fail if either side's payload keys drift (see FR-7).

Traceability: acceptance A4; fact F10.

### FR-7 (must) — Key-set drift guard
The contract test must pin the exact contract key sets:
- worker side: the published `details` key set must equal `{error_message, stage, retryable, error}`;
- api side: the set of `details` keys read by `run_transactional_update`'s failed branch must equal
  `{error_message, stage, retryable, error_code}` (with `error_code` documented as allowed-missing,
  defaulting to `"UNKNOWN"`);
- the intersection `{error_message, stage, retryable}` is the binding seam.

Any addition, removal, or rename on either side must fail the test. Traceability: acceptance A4.

## 6. Contract specification

### 6.1 Worker failure payload (status topic)

Envelope (unchanged, verified in `_process_status_message`): `user_id`, `course_id`, `resource_id`,
`status` (`"failed"`), `details`.

`details` for `status = "failed"` (new worker behavior):

| Key | Type | Source | Notes |
|---|---|---|---|
| `error_message` | str | `str(e)` from the exception handler | actual exception message |
| `stage` | str | stage tracker in `process_document` | progress vocabulary; `"processing"` if unknown |
| `retryable` | bool | `classify_error(e)` → transient=True, permanent/unknown=False | always present |
| `error` | str | same as `error_message` | legacy key retained (FR-5); ignored by rag-api |

### 6.2 rag-api failed-branch persistence mapping (unchanged, pinned)

| Payload key | Main document field | Summary subdocument field |
|---|---|---|
| `error_message` | `error` | `error.message` |
| `stage` | `error_stage` | `error.stage` (and summary `stage`) |
| `retryable` | `retryable` | — |
| `error_code` (optional) | — | `error.code` (default `"UNKNOWN"`) |

Fallbacks (`"Processing failed"`, `None`/`"unknown"`, `True`) remain in rag-api for non-worker publishers but
must never engage for worker failures (guaranteed by FR-1).

### 6.3 Stage vocabulary

`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`,
`embeddings_complete` — identical to the progress-update stage names — plus the safe fallback
`"processing"`. No new stage names are introduced.

## 7. Non-functional requirements

- **NFR-1 (must):** No Firestore migration, field rename, or backfill of existing documents; persisted
  fields `error`/`error_stage`/`retryable` keep their names and semantics.
- **NFR-2 (must):** The contract test runs hermetically (fakes by default; no live GCP dependencies), using
  the fake transaction/Firestore kit and `firestore.transactional`/`SERVER_TIMESTAMP` monkeypatch patterns
  already proven in the worker unit suite.
- **NFR-3 (should):** The worker's failure log line records the derived `stage` and `retryable` alongside the
  message, so the persisted record and the logs agree (incidental to the handler change; no new logging
  framework).
- **NFR-4 (must):** No changes to Pub/Sub ACK/NACK policy, lease, or heartbeat mechanics.

## 8. Constraints (from the Definition — binding)

- **C1 (must):** Align the worker to rag-api's existing contract (`error_message`/`stage`/`retryable`);
  do not change rag-api's reads or persisted schema.
- **C2 (must_not):** No fix requiring a Firestore migration, field rename, or backfill.
- **C3 (must):** Every worker-originated failure payload carries `retryable` explicitly; rag-api's
  `details.get("retryable", True)` fallback must not be the operative mechanism for worker failures.
- **C4 (prefer):** Retain the legacy `error` key alongside `error_message`.
- **C5 (prefer_not):** Do not introduce a structured error-code taxonomy.

## 9. Acceptance criteria

- **A1:** A failed job's status message published by the worker contains `error_message` (actual exception
  message), `stage` (failing pipeline stage), and `retryable` (deliberately derived) — none relying on
  rag-api's fallback defaults.
- **A2:** After a failed job, the persisted resource document has `error` = the worker's actual error message
  (not `"Processing failed"`), `error_stage` = the failing stage (not `None`), and `retryable` = the worker's
  derived value.
- **A3:** The `processing/summary` error subdocument for the failed job carries the same message and stage as
  the main document.
- **A4:** A contract test covering the worker failure → rag-api persistence path exists and passes: it
  exercises the worker's failure-payload construction through rag-api's failed-branch persistence and asserts
  the persisted `error`, `error_stage`, and `retryable` equal the worker's values, failing if either side's
  payload keys drift.

## 10. Test requirements

- **TR-1 (must):** Worker-side unit tests build the failure payload through `process_document`'s real
  exception handler (publisher captured via fake/monkeypatch), covering: an early-stage failure, a late-stage
  failure, an unclassified-unknown exception (`retryable` false), and a failure before any stage transition
  (`stage == "processing"`). Location: `apps/ai-server/rag-worker-service/tests/unit/`.
- **TR-2 (must):** Cross-service contract test feeds the worker-built payload through
  `run_transactional_update`'s failed branch against fakes (or the Firestore emulator) with the source
  document seeded at `status: "processing"` (the only state that legally transitions to `failed`), and
  asserts main-document and summary-subdocument persistence equality. Location:
  `apps/ai-server/tests/integration/` (new module alongside `test_api_contracts.py`).
- **TR-3 (must):** Drift guards per FR-7: dynamic key-set assertion on the captured worker payload, plus a
  static extraction (AST, following the `_get_agent_graph_shapes` precedent) of the `details` keys read in
  rag-api's failed branch, both compared against pinned contract constants.
- **TR-4 (should):** Representative-stage coverage only (early + late failure) — enough to catch the stage
  tracker being removed or bypassed without ossifying every pipeline step.

## 11. Traceability matrix

| Requirement | Acceptance | Constraints | Facts |
|---|---|---|---|
| FR-1 | A1, A2 | C1, C3 | F1, F3, F4, F5 |
| FR-2 | A1, A2 | C1 | F9 |
| FR-3 | A2 | C3 | F7, F8 |
| FR-4 | A2, A3 | C1, C2 | F4, F6 |
| FR-5 | A1 | C4 | F11 |
| FR-6, FR-7 | A4 | C1 | F10 |
| NFR-1 | — | C2 | F6 |
| NFR-2 | A4 | — | F10 |

## 12. Deferred / open items

- **D-1:** Companion D3 issue referenced by the Objective — content unavailable in this context; anything it
  covers beyond the worker→rag-api failure payload alignment is out of scope (fact F12).
- **D-2:** Reconciling this design with deviation D4 in `plans/upload-flow.md` — the file is not present in
  the current tree; deferred.
- **D-3:** Dropping the legacy `error` key — trivial cleanup only if a later audit confirms the worker is the
  only publisher and rag-api the only consumer of the status topic (fact F11).
- **D-4:** Widening `classify_error`'s heuristics — explicitly out of scope; the conservative
  unknown→permanent→`retryable:false` behavior is accepted (fact F8).