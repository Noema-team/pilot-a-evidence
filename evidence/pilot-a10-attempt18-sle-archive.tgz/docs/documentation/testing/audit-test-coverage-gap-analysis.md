---
tags:
  - Documentation/Internal
---

# Audit Findings — Test Coverage & Gap Analysis

> **Last updated:** 2026-06-21 — Priority 1 items #1–3 closed (thread ownership, auth, graph tests)
> **Scope:** All backend services + API gateway + mobile app test infrastructure

---

## Coverage Scorecard

| Service | Endpoints | Any Test | Error Tests | Coverage |
|---------|-----------|----------|-------------|----------|
| RAG API Service | 24 | 22 | 14 | ~60% (+14 auth unit tests) |
| Weaviate Service | 7 | 7 | 2 | ~29% |
| Agent Graph Service | 7 | 7 | 1 | ~25% (+37 ownership/graph tests) |
| API Gateway | 41 | 30 | 15 | ~37% |
| Flashcard Service | 13 | 8 (gateway only) | 0 | Low |
| Observability Aggregator | 24 | — | — | Unknown |
| RAG Worker Service | N/A (Pub/Sub consumer) | — | — | Unit only |
| **Total** | **116+** | **66+** | **32** | **~30%** |

**Happy-path coverage is reasonable for core flows (search, chat, resource CRUD). Error paths, auth enforcement, and edge cases are the critical gaps. Auth enforcement at the dependency level is now tested (authenticate_s2s); per-endpoint auth rejection and thread ownership at the integration level remain gaps.**

---

## Endpoint Inventory & Test Status

### RAG API Service

| # | Method | Path | Happy | Error | Auth | Edge | Notes |
|---|--------|------|-------|-------|------|------|-------|
| 1 | GET | `/health` | ✅ | — | — | — | Covered |
| 2 | POST | `/process` | ❌ | ✅ | ❌ | ❌ | No happy-path test |
| 3 | POST | `/search` | ✅ | ✅ | ✅ | ✅ | Well covered (cross-svc) |
| 4 | GET | `/resources/{id}/content` | ✅ | ✅ | ❌ | ❌ | Partial |
| 5 | GET | `/resources/{id}/status` | ✅ | ✅ | ❌ | ❌ | Partial |
| 6 | GET | `/status/{id}` (legacy) | ✅ | ✅ | ❌ | ✅ | Covered |
| 7 | GET | `/courses/{id}/resources/info` | ✅ | ✅ | ❌ | ❌ | Partial |
| 8 | DELETE | `/resources/{id}` | ✅ | ✅ | ❌ | ❌ | Partial |
| 9 | DELETE | `/resources/{id}/vectors` (legacy) | ❌ | ❌ | ❌ | ❌ | **Untested** |
| 10 | GET | `/config/rag` | ✅ | ✅ | ✅ | ✅ | Covered |
| 11 | PUT | `/config/rag` | ✅ | ❌ | ✅ | ❌ | Missing invalid config test |
| 12 | POST | `/config/rag/preset/{name}` | ✅ | ✅ | ✅ | — | Covered |
| 13 | POST | `/resources` | ✅ | ✅ | ❌ | ✅ | Covered |
| 14 | GET | `/resources` | ✅ | ✅ | ❌ | ❌ | Missing pagination edge cases |
| 15 | GET | `/resources/{id}` | ✅ | ✅ | ❌ | — | Covered |
| 16 | POST | `/resources/{id}/regenerate-map` | ✅ | ✅ | ❌ | ❌ | Partial |
| 17 | POST | `/resource-groups` | ✅ | ❌ | ❌ | ❌ | No error tests |
| 18 | GET | `/resource-groups` | ✅ | ❌ | ❌ | ❌ | No pagination/error tests |
| 19 | GET | `/resource-groups/{id}` | ✅ | ✅ | ❌ | — | Covered |
| 20 | POST | `/resource-groups/{id}/resources` | ✅ | ✅ | ❌ | — | Covered |
| 21 | DELETE | `/resource-groups/{id}/resources` | ✅ | ❌ | ❌ | ❌ | No error test |
| 22 | DELETE | `/resource-groups/{id}` | ✅ | ❌ | ❌ | ❌ | No error test |
| 23 | POST | `/courses/{id}/resources` | ✅ | ❌ | ❌ | ❌ | No error test |
| 24 | DELETE | `/courses/{id}/resources` | ✅ | ❌ | ❌ | ❌ | No error test |

### Weaviate Service

| # | Method | Path | Happy | Error | Auth | Edge | Notes |
|---|--------|------|-------|-------|------|------|-------|
| 1 | POST | `/search` | ✅ | ❌ | N/A | ✅ | No 500/empty results test |
| 2 | DELETE | `/resources/{uid}/{rid}/vectors` | ✅ | ❌ | ✅ | ❌ | No error test |
| 3 | POST | `/vectors` | ✅ | ❌ | ✅ | ❌ | No error test |
| 4 | POST | `/batch/chunks` | ✅ | ❌ | ✅ | ❌ | No error/partial failure test |
| 5 | DELETE | `/vectors/all` | ✅ | ✅ | ✅ | — | Covered |
| 6 | GET | `/resources/{uid}/{rid}/chunks` | ✅ | ❌ | ✅ | ❌ | No error test |
| 7 | GET | `/health` | ✅ | ❌ | — | — | No unhealthy test |

### Agent Graph Service

| # | Method | Path | Happy | Error | Auth | Edge | Notes |
|---|--------|------|-------|-------|------|------|-------|
| 1 | POST | `/chat` | ✅ | ❌ | ❌ | ✅ | No error/auth test |
| 2 | POST | `/chat/stream` | ✅ | ❌ | N/A | ❌ | Basic only |
| 3 | GET | `/messages` | ✅ | ❌ | ❌ | ❌ | Missing thread_id error |
| 4 | GET | `/threads/{id}` | ✅ | ❌ | ❌ | ❌ | Missing non-existent thread |
| 5 | GET | `/health` | ✅ | — | — | — | Covered |
| 6 | GET | `/threads` | ✅ | ❌ | ✅ | ❌ | Partial |
| 7 | GET | `/search` | ✅ | ❌ | ✅ | ❌ | Partial |

> **Note:** `tests/test_graph_basic.py` is an empty file — core LangGraph execution path has no tests.

### API Gateway

| # | Method | Path | Happy | Error | Auth | Edge | Notes |
|---|--------|------|-------|-------|------|------|-------|
| 1 | GET | `/health` | ✅ | ✅ | — | — | Covered |
| 2 | GET | `/` | ✅ | — | — | — | Covered |
| 3 | GET | `/api/user` | ✅ | ✅ | ✅ | — | Covered |
| 4 | POST | `/api/chat/messages` | ✅ | ✅ | ✅ | ✅ | Well covered |
| 5 | GET | `/api/chat/messages` | ❌ | ❌ | ❌ | — | **Untested** (proxied) |
| 6 | GET | `/api/chat/threads` | ❌ | ❌ | ❌ | — | **Untested** (proxied) |
| 7 | POST | `/api/chat/threads/:id/name` | ❌ | ❌ | ❌ | — | **Untested** |
| 8 | GET | `/api/chat/search` | ✅ | ✅ | ✅ | — | Covered |
| 9 | POST | `/api/chat/audio-to-text` | ❌ | ❌ | ❌ | — | **Untested** |
| 10 | POST | `/api/chat/text-to-audio` | ❌ | ❌ | ❌ | — | **Untested** |
| 11 | POST | `/api/chat/feedback` | ✅ | ✅ | ✅ | — | Covered |
| 12 | POST | `/api/search` | ✅ | ✅ | ✅ | — | Covered |
| 13 | GET | `/api/status/:uid/:rid` | ✅ | ✅ | ✅ | — | Covered |
| 14 | GET | `/api/resources/:rid/content` | ✅ | ❌ | ✅ | — | Partial |
| 15 | DELETE | `/api/resources/:uid/:rid/vectors` | ✅ | ✅ | ✅ | — | Covered |
| 16 | GET | `/api/courses/:cid/resources/info` | ✅ | ❌ | ✅ | — | Partial |
| 17 | POST | `/api/process` | ✅ | ✅ | ✅ | ✅ | Well covered |
| 18 | POST | `/api/resources` | ✅ | ✅ | ✅ | — | Covered |
| 19 | GET | `/api/resources` | ✅ | ❌ | ✅ | ❌ | Partial |
| 20 | GET | `/api/resources/:rid` | ❌ | ❌ | ❌ | — | **Untested** |
| 21 | GET | `/api/resources/:rid/status` | ✅ | ❌ | ✅ | — | Partial |
| 22 | DELETE | `/api/resources/:rid` | ✅ | ❌ | ✅ | — | Partial |
| 23 | POST | `/api/resources/:rid/regenerate-map` | ✅ | ❌ | ✅ | — | Partial |
| 24 | GET | `/api/resource-groups` | ✅ | ❌ | ✅ | — | Partial |
| 25 | POST | `/api/resource-groups` | ✅ | ❌ | ✅ | — | Partial |
| 26 | POST | `/api/courses/:cid/resources/:rid/map` | ✅ | ❌ | ✅ | — | Happy path only |
| 27 | GET | `/api/courses/:cid/resources/:rid/map` | ✅ | ❌ | ✅ | — | Happy path only |
| 28 | GET | `.../flashcards/due` | ✅ | ❌ | ✅ | — | Happy path only |
| 29 | POST | `.../flashcards/:id/review` | ✅ | ❌ | ✅ | — | Happy path only |
| 30 | POST | `.../flashcards/generate` | ✅ | ❌ | ✅ | — | Happy path only |
| 31 | POST | `.../flashcards/save` | ✅ | ❌ | ✅ | — | Happy path only |
| 32 | GET | `.../flashcards` | ✅ | ❌ | ✅ | — | Happy path only |
| 33 | PUT | `.../flashcards/:id` | ✅ | ❌ | ✅ | — | Happy path only |
| 34 | DELETE | `.../flashcards/:id` | ✅ | ❌ | ✅ | — | Happy path only |
| 35 | GET | `.../study/stats` | ✅ | ❌ | ✅ | — | Happy path only |
| 36 | GET | `.../study/cram` | ✅ | ❌ | ✅ | — | Happy path only |
| 37 | GET | `.../sections/:sid/study` | ✅ | ❌ | ✅ | — | Happy path only |
| 38 | GET | `/api/users/:uid/resources` | ❌ | ❌ | ❌ | — | **Untested** (Firestore-direct) |
| 39 | GET | `/api/processing/metrics` | ❌ | ❌ | ❌ | — | **Untested** (Firestore-direct) |
| 40 | GET | `/api/resources/:rid/processing` | ✅ | ✅ | ✅ | — | Covered |
| 41 | POST | `/api/resources/:rid/reprocess` | ✅ | ✅ | ✅ | — | Covered (501) |

---

## Cross-Cutting Gaps (All Services)

| Gap | Details |
|-----|---------|
| **Auth enforcement** | All downstream services mock auth. No test verifies 401/403 for expired Firebase tokens, wrong shared internal token, or unauthorized cross-user access. |
| **Thread ownership** | Agent-graph has `verify_thread_ownership` returning 403 — never tested. A user could access another user's conversations without detection. |
| **Rate limiting** | Gateway has rate limiters (auth: 100/15min). No test validates 429 responses. |
| **Concurrent access** | No tests for race conditions: simultaneous deletes, status updates, double-process requests. |
| **Pagination edge cases** | No tests for offset beyond total, limit=0, limit at boundary values, has_more accuracy. |
| **Service dependency failures** | No tests for graceful degradation when Firestore, Weaviate, or Pub/Sub are down. |
| **Timeouts** | No tests for 120s chat timeout, 20s search timeout, or 15s processing timeout. |
| **SSE stream interruption** | No test for client disconnect or backend error mid-stream. |
| **Malformed input** | No fuzz tests for deeply nested JSON, extremely long strings, non-UTF8 bodies, or 10MB body limit. |
| **Idempotency** | No tests for double-process, double-delete, or create-if-exists behavior. |
| **Observability pipeline** | No end-to-end test verifying trace_id flows from gateway through to aggregator. |
| **Cost tracking integration** | Cost tracker is unit-tested but no integration test verifies it fires during chat. |

---

## Prioritized Action Plan

### Priority 1 — Critical (Security & Untested Endpoints)

| # | Task | Service | Rationale | Status |
|---|------|---------|-----------|--------|
| 1 | Add thread ownership security tests | Agent Graph | `verify_thread_ownership` 403 path is untested — cross-user access risk | **DONE** `d0f3a54` — extracted to `src/security.py`, 12 unit tests + 2 integration tests |
| 2 | Add auth rejection tests for all RAG API endpoints | RAG API | Every test mocks auth — no verification of actual 401/403 behavior | **DONE** `c7faf3c` — 14 unit tests for `authenticate_s2s` dependency covering all branches |
| 3 | Fill in `test_graph_basic.py` | Agent Graph | Empty file — core LangGraph execution path untested | **DONE** `c0584ac` — 24 tests: agent_router dispatch + graph structure in both chaining modes |
| 4 | Test audio endpoints (audio-to-text, text-to-audio) | Gateway | Completely untested proxy endpoints | OPEN |
| 5 | Test Firestore-direct endpoints | Gateway | GET `/api/users/:uid/resources` and GET `/api/processing/metrics` have zero coverage | OPEN |
| 6 | Test untested proxy endpoints | Gateway | GET messages, GET threads, POST thread rename, GET specific resource/group | OPEN |

### Priority 2 — High (Error Paths & Missing Scenarios)

| # | Task | Service | Rationale |
|---|------|---------|-----------|
| 7 | Add error path tests for all Weaviate endpoints | Weaviate | Only happy paths + auth tested; 500s, malformed input, partial batch failures untested |
| 8 | Add error path tests for agent-graph | Agent Graph | Streaming errors, non-existent threads, LLM timeouts all untested |
| 9 | Add POST `/process` happy-path test | RAG API | Only validation test exists — no successful enqueue test |
| 10 | Add error scenarios for flashcard endpoints | Gateway + Flashcard | All 8 flashcard gateway tests are happy-path only |
| 11 | Add error tests for gateway proxy endpoints | Gateway | GET specific resource, DELETE resource group — no backend failure tests |

### Priority 3 — Medium (Robustness & Edge Cases)

| # | Task | Service | Rationale |
|---|------|---------|-----------|
| 12 | Add pagination edge case tests | All list endpoints | offset beyond results, limit=0, has_more accuracy |
| 13 | Add concurrent access tests | RAG API + Weaviate | Simultaneous delete, double-process race conditions |
| 14 | Add timeout behavior tests | Gateway + Agent Graph | Verify 120s chat and 20s search timeouts return appropriate errors |
| 15 | Add Weaviate unhealthy health check | Weaviate | GET `/health` when Weaviate is down |
| 16 | Add DELETE `/resources/{id}/vectors` (legacy) test | RAG API | Deprecated endpoint with zero coverage |
| 17 | Add malformed/large request body tests | Gateway | JSON parse errors, 10MB body limit enforcement |

### Priority 4 — Low (Nice to Have)

| # | Task | Service | Rationale |
|---|------|---------|-----------|
| 18 | Add SSE stream interruption tests | Agent Graph | Client disconnect mid-stream, backend error mid-stream |
| 19 | Add observability end-to-end test | All | Verify trace_id flows from gateway to aggregator |
| 20 | Add rate limiting tests | Gateway | Verify 429 responses at configured limits |
| 21 | Add idempotency tests | RAG API | Double-process, double-delete behavior |
| 22 | Clean up non-test files | Agent Graph | `test_general_chat.py` and `test_combined_features.py` are documentation scripts with no assertions — move or convert |

---

## Detailed Test Plan

The compact tables above identify what's missing. This section specifies what to build, in what order, and with what effort.

### Priority 1 — Untested Gateway Endpoints (~20 tests, ~2.5h)

These endpoints have zero test coverage — no happy path, no error path, nothing. Do this batch before frontend work; it completes the API surface contract.

**#4 — Audio endpoints** (~30 min)

Routes: `POST /api/chat/audio-to-text` (server.ts:733), `POST /api/chat/text-to-audio` (server.ts:780). Proxy speech-to-text and text-to-speech to the agent-graph service.

Tests:
- 401 when no auth headers
- Forward audio file to agent-graph service (happy path, mocked multipart)
- 504 when agent-graph service unreachable
- 400 when audio file is missing (audio-to-text)
- 400 when text is missing (text-to-audio)

Risk: Voice features silently fail with no regression detection.

**#5 — Firestore-direct endpoints** (~45 min)

Routes: `GET /api/processing/metrics` (server.ts:2108), `GET /api/users/:uid/resources` (server.ts:2225). These bypass the normal proxy pattern — the gateway uses `firebase-admin` to read Firestore directly.

Tests:
- Return processing metrics aggregated from Firestore
- 403 when non-admin user requests metrics
- Return user resources list from Firestore
- 403 when requesting another user's resources
- Handle empty Firestore collections gracefully

Risk: Admin dashboard goes dark if these break. Cross-user access has no auth check test.

Note: Different mock pattern — mock `firebase-admin.firestore` instead of `axios`.

**#6 — Untested proxy endpoints** (~1h)

Routes: `GET /api/chat/messages` (513), `GET /api/chat/threads` (566), `POST /api/chat/threads/:thread_id/name` (613), `GET /api/resources/:resourceId` (1326).

Tests per route: happy path forward, 401 no auth, 504 downstream unreachable, error forwarding.

Risk: Core mobile app flows (chat history, conversation list, resource detail). Breakage immediately visible to users.

### Priority 2 — Error Paths (~25 tests, ~6h)

Every service has happy-path integration tests. The gap is what happens when things go wrong — downstream failures, invalid input, partial failures.

**#7 — Weaviate error paths** (~1.5h)

Tests:
- `POST /search` → Weaviate returns 500 → appropriate error
- `POST /search` → empty results → graceful empty response
- `POST /vectors` → batch partially fails (3 of 10 rejected) → error reporting
- `POST /batch/chunks` → invalid metadata → rejection with details
- `DELETE /resources/:uid/:rid/vectors` → non-existent resource → 404
- `GET /resources/:uid/:rid/chunks` → no chunks → empty list
- `GET /health` → Weaviate DB unreachable → unhealthy status

Risk: Partial batch failures during PDF processing silently lose chunks, degrading search quality.

**#8 — Agent-graph error paths** (~2h)

Tests:
- `POST /chat/stream` → LLM fails mid-stream → SSE `error` event
- `POST /chat/stream` → client disconnects → clean cleanup
- `GET /threads/:id` → non-existent → 404
- `GET /messages` → non-existent thread_id → 404 or empty
- `POST /chat` → exceeds max_hops → graceful stop
- `POST /chat` → all agents fail → fallback response (not 500)

Risk: Streaming error format drift breaks mobile SSE parser silently.

**#9 — POST /process happy-path** (~20 min)

Tests:
- Valid resource_id + course_id → 200 with `processing_enqueued: true`
- Verify Pub/Sub message published with correct topic + payload

Risk: Document processing trigger is the entry point for the entire RAG pipeline.

**#10 — Flashcard error scenarios** (~1h)

Tests:
- `POST /generate` → malformed LLM flashcards → graceful skip
- `POST /generate` → empty content → error
- `POST /review` → invalid rating → 400
- `POST /save` → duplicate detection
- `DELETE /:id` → non-existent → 404
- `GET /due` → no due cards → empty list

Risk: Malformed LLM output is a real failure mode for study features.

**#11 — Gateway proxy error tests** (~1h)

Tests:
- `GET /api/resources/:resourceId` → RAG 404 → forwarded
- `DELETE /api/resources/:resourceId` → RAG 500 → forwarded
- `GET /api/resource-groups` → RAG 500 → forwarded
- `POST /api/resource-groups` → RAG 400 (capacity) → forwarded
- `GET /api/resources` → RAG 500 → forwarded

Risk: Error propagation is the gateway's core job. Wrong status codes cause misleading mobile error messages.

### Priority 3 — Robustness & Edge Cases (~20 tests, ~6h)

Test the boundaries — inputs at the edge of valid, infrastructure failures, concurrent operations. Do after production deploy, during hardening.

**#12 — Pagination edge cases** (~1h)

Endpoints: all list endpoints (`GET /resources`, `GET /resource-groups`, `GET /chat/threads`, `GET /chat/messages`).

Tests: offset beyond total → empty + `has_more: false`; limit=0 → 400 or empty; limit=1 at boundary → `has_more: true`; limit exceeding total → all results; negative offset → 400.

Risk: Mobile `loadMore` depends on `has_more` accuracy. Wrong values cause infinite spinners or premature "no more results."

**#13 — Concurrent access tests** (~2h)

Tests: simultaneous DELETE of same resource; double POST /process for same resource; concurrent add_resources to same group (capacity race).

Note: Inherently flaky if not carefully designed — use deterministic mocks, not real timing.

Risk: Race conditions cause data corruption, hard to reproduce in production.

**#14 — Timeout behavior tests** (~1.5h)

Tests: chat 120s timeout → 504; search 20s timeout → error; processing 15s timeout → status "failed."

How: Mock downstream delay beyond threshold. Use `jest.useFakeTimers()` or `pytest.mark.timeout`.

Risk: Timeouts cause user-visible hangs.

**#15 — Weaviate unhealthy health check** (~15 min)

Test: `GET /health` when Weaviate DB connection is down → `status: unhealthy`, not 500.

**#16 — Legacy DELETE /resources/:id/vectors test** (~15 min)

Test: happy-path + auth for the deprecated endpoint (rag-api-service:993). Prevents regression if old mobile clients still call it.

**#17 — Malformed/large request body tests** (~45 min)

Tests: malformed JSON → 400; body >10MB → 413; deeply nested JSON (100 levels); non-UTF8 body; empty body on required POST endpoints.

Risk: Express body parser limits are untested. Malicious/buggy clients could trigger unhandled exceptions.

### Priority 4 — Nice to Have (~10 tests + cleanup, ~8h)

Production hardening items. Valuable for a mature system but not blocking for MVP.

**#18 — SSE stream interruption tests** (~2h)

Tests: client disconnect mid-stream → cleanup (no leaked LLM connections); backend error mid-stream → SSE error event before close; slow consumer → backpressure handling.

Note: Hard to test with TestClient; may need real HTTP.

Risk: Leaked connections accumulate under load → resource exhaustion.

**#19 — Observability end-to-end test** (~3h)

Test: chat request → verify trace_id propagates gateway → agent-graph → rag-api → weaviate → appears in aggregator.

How: Mock OpenTelemetry exporters, capture spans, assert parent-child relationships.

Risk: Broken trace propagation makes production debugging blind.

**#20 — Rate limiting tests** (~30 min)

Test: 100+ rapid requests to auth-limited endpoints → 429 with `Retry-After` header.

Risk: Rate limiting exists in code but is untested.

**#21 — Idempotency tests** (~1.5h)

Tests: double POST /process → second returns existing status; double DELETE → second returns 404 or 200 (define contract); double POST /resources with same filename.

Note: The idempotency contract doesn't exist yet — this item includes defining it.

Risk: Network retries (common on mobile) cause duplicate operations.

**#22 — Clean up non-test files** (~15 min)

Files: `test_general_chat.py` and `test_combined_features.py` in agent-graph-service/tests/ are documentation scripts with no assertions. They pollute test collection and confuse coverage metrics.

Action: Move to `examples/` or convert to real tests.

### Summary & Sequencing

| Priority | Theme | Tests | Effort | When |
|---|---|---|---|---|
| **P1** | Untested endpoints | ~20 | ~2.5h | Before frontend work (completes the API contract) |
| **P2** | Error paths | ~25 | ~6h | Before production deploy |
| **P3** | Edge cases & robustness | ~20 | ~6h | After production deploy, during hardening |
| **P4** | Nice to have | ~10 | ~8h | When scaling becomes a concern |
| **Total** | | **~75** | **~22h** | |

---

## Existing Test Inventory

### Cross-Service Integration Tests (`ai-server/tests/integration/`)

| File | Tests | Coverage |
|------|-------|----------|
| `test_api_contracts.py` | 17 | Response shape contracts (ResourceResponse, ListResourcesResponse, GroupResponse, SSE events, threads, messages, chat, upload) |
| `test_chat_pipeline.py` | 8 | GatewayClient requests, RAG search tool, course map tool |
| `test_search_pipeline.py` | 15 | Search forwarding, context resolution, auth chain, header propagation |

### RAG API Service (`rag-api-service/tests/`)

| File | Tests | Coverage |
|------|-------|----------|
| `integration/test_endpoints.py` | 34 | All CRUD endpoints (happy + basic errors), config, groups, courses |
| `unit/test_authenticate_s2s.py` | 14 | S2S auth dependency: missing token, propagated 401/403/500, isServiceAccount gate, transport failures |
| `unit/test_pydantic_models.py` | 32 | All Pydantic model construction and validation |
| `unit/test_validators.py` | 23 | Input validation (path traversal, extensions, length, protocols) |
| `unit/test_models_resource.py` | 31 | Domain models (Resource, ResourceGroup, Course, Thread) |
| `unit/test_query_resolver_cache.py` | 14 | Cache get/set/expiry/invalidation/stats |
| `unit/test_rag_config.py` | 19 | Config presets, defaults, round-trip |

### Weaviate Service (`weaviate-service/tests/`)

| File | Tests | Coverage |
|------|-------|----------|
| `integration/test_endpoints.py` | 12 | All endpoints (happy path + auth) |
| `unit/test_relevance_policy.py` | 5 | Score thresholds, relaxation, drop-off |
| `unit/test_utils.py` | 4 | UUID generation, LLM context building |

### Agent Graph Service (`agent-graph-service/tests/`)

| File | Tests | Coverage |
|------|-------|----------|
| `integration/test_endpoints.py` | 14 | All endpoints (happy path + basic auth, incl. thread ownership 403) |
| `unit/test_verify_thread_ownership.py` | 12 | Thread ownership: nested path, root collection, owner match/mismatch, legacy threads |
| `unit/test_classifier.py` | 6 | LLM fallback, labels, cache, agent_mode |
| `unit/test_state_models.py` | 4 | Message/ChatState serialization |
| `unit/test_router.py` | 12 | All routing paths, mode override |
| `unit/test_utils.py` | 12 | Truncation, PII, cost tracking |
| `test_graph_basic.py` | 24 | agent_router dispatch + graph structure (nodes, edges, branches) in both chaining modes |

### API Gateway (`api-gateway/tests/`)

| File | Tests | Coverage |
|------|-------|----------|
| `unit/server.test.ts` | 78 | Auth middleware, chat, search, feedback, resources, flashcards, process, status, vectors, CORS, error handling |

### RAG Worker Service (`rag-worker-service/tests/`)

| File | Tests | Coverage |
|------|-------|----------|
| `unit/test_content_tagger.py` | 8 | Tag generation, subject detection, complexity, concepts |
| `unit/test_chunking.py` | 3 | Chunk size/overlap, empty text, single chunk |
| `unit/test_utils.py` | 16 | Error classification, ProcessingConfig validation |
