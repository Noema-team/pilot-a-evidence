---
tags:
  - Documentation/Internal
---
# Testing Phases Strategy

## Phase 1: Logic

**Entrance criteria:** Chat and flashcards logic exists.

**Scope:** Test the logic with different scenarios. Focus on all use cases, options, edge cases, and logical paths the system can achieve — both product quality and errors. Stress test the system.

**Exit criteria:** All errors are handled.

## Phase 2: Usability

**Entrance criteria:** User observability, admin UI, and error handling are developed.

**Scope:** Test locally on a small group of users. Test product quality, usability, and how users naturally use the system.

**Exit criteria:** All usage and errors are captured by admin UI and observability.

## Phase 3: System health and production readiness

**Entrance criteria:** The system has automatic health updates and can self-recover (restart services if something breaks). CI/CD and testing pipelines are in place.

**Scope:** Move the system to production. Test in the production environment.

**Exit criteria:** System is stable in production with monitoring and automated recovery.
