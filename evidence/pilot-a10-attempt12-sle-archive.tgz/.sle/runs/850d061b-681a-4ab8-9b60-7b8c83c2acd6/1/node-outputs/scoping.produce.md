I've reviewed the authoritative definition, both service implementations (`rag-worker-service/main.py`, `rag-api-service/main.py`), the existing contract-test infrastructure, the worker's test conventions, and the `Resource` model. The repository evidence in the definition checks out: the worker's exception handler publishes `{"error": str(e)}`, rag-api's failed branch reads `error_message`/`stage`/`retryable`, and the sweep/enqueue paths plus the model already use `error`/`error_stage`/`retryable`. The charter below is written strictly within that bounded scope.

<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path="docs/cycle-charter.md">>>
# Cycle Charter — rag-worker → rag-api failure payload contract alignment

## Scope

This cycle fixes the contract mismatch on the worker → rag-api failure path:

- **rag-worker-service (`apps/ai-server/rag-worker-service/main.py`)** — the only production code changed:
  - The `process_document` exception handler's failed-status payload is aligned to rag-api's failed-branch contract: it publishes `error_message` (the actual exception message), `stage` (the pipeline stage executing at failure time), and `retryable` (deliberately derived). The payload never relies on rag-api's fallback defaults for these keys.
  - A stage tracker is added inside `process_document`: a local set immediately before each pipeline step and reported by the failure handler. Stage names reuse the existing progress-stage vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown.
  - The failed payload retains the legacy `error` key alongside `error_message` as a compatibility hedge for any unknown consumers of the status topic.
  - `retryable` is derived from the worker's existing `classify_error()`: transient-classified → `true`; permanent-classified (including unclassified-unknown, per `classify_error`'s conservative default) → `false`.
- **Contract test** — a new test covering the worker failure → rag-api persistence path. It imports both sides rather than restating the contract in a fixture: builds the failure payload through the worker's code path, feeds it through rag-api's `run_transactional_update` failed branch (via the Firestore emulator or fakes), and asserts the persisted `error`, `error_stage`, and `retryable` equal the worker's values. It includes a key-set drift guard so a future edit to either side's payload keys fails the build. It follows the house pattern in `apps/ai-server/tests/integration/test_api_contracts.py` and the worker's existing fake-based test conventions.
- **rag-api-service** — no production code changes. Its failed branch (`run_transactional_update`), persisted schema (`error`, `error_stage`, `retryable`), and reads are consumed as-is by the contract test.

## Purpose

Every worker-originated failure currently persists the fallback string `"Processing failed"` as `error`, `None` as `error_stage`, and a silently defaulted `retryable: true`, because the worker publishes a one-key payload (`{"error": str(e)}`) while rag-api's failed branch reads `error_message`/`stage`/`retryable`. Users and support cannot disambiguate failures, and the persisted record misrepresents the worker's actual retry behavior.

The purpose of this cycle is to make a failed RAG processing job persist the worker's actual error message, the failing pipeline stage, and a deliberately derived retryable flag — with the worker aligned to rag-api's existing contract (no migration, no field rename, no backfill) and the seam locked in by a contract test so the mismatch cannot silently recur.

## Requirements

- When document processing fails, the worker's failed status payload must include `error_message` (the actual exception message), `stage` (the pipeline stage executing at failure time), and `retryable` (deliberately derived) — the payload must never rely on rag-api's fallback defaults for these keys.
- The worker must track the currently executing pipeline stage through `process_document` so the failure handler reports the true failing stage; stage names must reuse the existing progress-stage vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown.
- rag-api's failed branch must persist the worker-provided values unchanged: main document `error` ← payload `error_message`, `error_stage` ← payload `stage`, `retryable` ← payload `retryable`; the `processing/summary` error subdocument must carry the same message and stage.
- The retryable derivation must be explicit and aligned with the worker's ACK/NACK behavior: errors classified transient by `classify_error` → retryable true; classified permanent (including unclassified-unknown, per `classify_error`'s conservative default) → retryable false.
- A contract test must cover the worker failure → rag-api persistence path: it must exercise the worker's failure-payload construction and rag-api's failed-branch persistence (via the Firestore emulator or fakes) and assert the persisted `error`, `error_stage`, and `retryable` equal the worker's values; it must fail if either side's payload keys drift.

Acceptance criteria (from the Definition, all gated on this cycle):
- A failed job's published status message contains `error_message`, `stage`, and `retryable` — none relying on rag-api's fallback defaults.
- After a failed job, the persisted resource document has `error` = the worker's actual error message (not `"Processing failed"`), `error_stage` = the failing stage (not `None`), and `retryable` = the worker's derived value.
- The `processing/summary` error subdocument carries the same message and stage as the main document.
- The contract test exists, passes, and covers the worker failure → rag-api persistence path including the drift guard.

## Boundaries

Must-not and out-of-scope constraints:

- rag-api's failed-branch reads and persisted schema are not changed — the worker aligns to the API, not the reverse. No Firestore migration, field rename, or backfill of existing documents; `error`, `error_stage`, and `retryable` keep their names and semantics.
- The stale-lease sweep's direct failure write (`_fail_if_still_stale`) is not changed — it already persists `error`/`error_stage`/`retryable` consistently with this contract, and its separate `retryable: true` write stays correct (a dead worker is a transient condition).
- Retry/backoff mechanics are not changed: Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals — only the *reporting* of retryability in the payload changes. The one deliberate behavior change (unclassified-unknown errors now persist `retryable: false` instead of the silent default `true`) is accepted as `classify_error`'s intended conservatism; manual reprocess via `POST /process` is unaffected.
- No frontend or mobile changes — `ResourceResponse` already exposes `error` and `error_stage` to clients.
- No structured error-code taxonomy — the `processing/summary` error `code` remains `"UNKNOWN"` unless a code is actually sent.
- Nothing covered by the companion D3 issue beyond this worker→rag-api failure payload alignment (see Deferred items).

Risks accepted by this charter (from the Definition): unknown consumers of the status topic reading the old key set (mitigated by retaining `error`); stage-tracker drift as the pipeline evolves (mitigated by the update-before-await convention and representative early-stage/late-stage test coverage); `retryable=false` for genuinely transient-but-unrecognized failures (accepted; widening `classify_error` is out of scope); the contract test ossifying the payload (intentional drift guard).

## Version bump

None required in code. The changed service (`rag-worker-service`) carries no version constant, and `rag-api-service` — whose FastAPI app declares `version="1.0.0"` — is untouched. This is a patch-level behavioral fix within the worker plus a new test; it is delivered as a patch build/deploy of the rag-worker image, with no semver constant to increment and no client-facing API version change.

## Deferred items

- **Companion D3 issue (Objective reference)** — its scope is not available in this context; anything it covers beyond this worker→rag-api failure payload alignment is deferred.
- **Reconciling with the original D4 deviation note in `plans/upload-flow.md`** — that file is not present in the current tree (the reference comes from the Objective text); reconciliation is deferred.
- **Dropping the legacy `error` key duplicate from the worker's failure payload** — deferred pending an audit confirming the worker is the only publisher and rag-api the only consumer of the status topic; trivial cleanup if confirmed.
- **Structured error-code taxonomy / failure taxonomy** — explicitly not in this fix (`error_code` stays `"UNKNOWN"` unless actually sent).
- **Widening `classify_error`** to recognize more transient failure shapes (which would change the retryable derivation for currently-unclassified errors) — out of scope.
<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>