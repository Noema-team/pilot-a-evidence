# AI-Optimized Documentation System Implementation Plan

> **Status: DONE** — all 9 tasks implemented and verified on the `revise-docs`
> branch. Structure, hubs, maps, skills, and `CLAUDE.md` are in place; the old
> `docs/Documentation/` and `docs/Task_Management/` folders are removed.
>
> Three files were not covered by this plan's migration or delete lists and
> were migrated separately: the two audit documents to
> `docs/documentation/testing/`, and `Dev Framework - Docs.md` to
> `docs/documentation/tooling/dev-framework.md` (a new subfolder).

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Restructure `docs/`, create `CLAUDE.md`, and add `claude/skills/` so Claude Code has layered, context-efficient access to project documentation and task management.

**Architecture:** Layer 0 (`CLAUDE.md`) is always auto-loaded. Layer 1 (hub `README.md` files) is loaded when a domain is relevant. Layer 2 (`map.md`) is loaded to locate a specific file. Layer 3 (leaf docs) is loaded only when working on a specific task or feature. Skills in `claude/skills/` enforce consistent behavior when reading or writing tasks and docs.

**Tech Stack:** Markdown files only — no code. Flutter (mobile), Next.js/React/Express (web), Python FastAPI + Node.js microservices (ai-server), Firebase/Firestore (auth + database).

---

## File Map

### Files to create

```
CLAUDE.md                                          ← Layer 0, always loaded
claude/skills/task-management.md                  ← skill: read/write/update tasks
claude/skills/documentation.md                    ← skill: write/update docs and indexes

docs/system-overview/README.md                    ← hub for system architecture
docs/system-overview/map.md                       ← file index for system-overview
docs/system-overview/general/overview.md          ← cross-cutting: auth, infra, data flow
docs/system-overview/ai-server/overview.md        ← AI server architecture
docs/system-overview/mobile/overview.md           ← Flutter app structure
docs/system-overview/web/overview.md              ← Next.js/web app structure

docs/documentation/README.md                      ← hub for feature specs
docs/documentation/map.md                         ← file index for documentation
docs/documentation/ai-features/rag-agent-types.md
docs/documentation/ai-features/ai-chat-error-handling.md
docs/documentation/ai-features/retry-logic.md
docs/documentation/ai-features/prepare-for-lecture.md
docs/documentation/compliance/gdpr-compliance.md
docs/documentation/testing/testing-phases.md

docs/task-management/README.md                    ← hub for task management
docs/task-management/map.md                       ← file index for task-management
docs/task-management/critical-tasks.md            ← pointers only: critical/active tasks
docs/task-management/01-ai-processing.md
docs/task-management/02-frontend-backend.md
docs/task-management/03-app-ui-ux.md
docs/task-management/04-timeline-feature.md
docs/task-management/05-testing-qa.md
docs/task-management/06-business.md
docs/task-management/07-feature-backlog.md
docs/task-management/08-infrastructure-devops.md
```

### Files to delete (after migration)

```
docs/Documentation/AI Chat error handling - Docs.md
docs/Documentation/GDPR & Compliance - Docs.md
docs/Documentation/Prepare for lecture feature - Docs.md
docs/Documentation/RAG Agent types - Docs.md
docs/Documentation/Retry logic & error handling - Docs.md
docs/Documentation/Testing Phases - Docs.md
docs/Task_Management/01 - AI & Document Processing.md
docs/Task_Management/02 - Frontend ↔ Backend Integration.md
docs/Task_Management/03 - App UI UX.md
docs/Task_Management/04 - Timeline Feature.md
docs/Task_Management/05 - Testing & QA.md
docs/Task_Management/06 - Business.md
docs/Task_Management/07 - Feature Ideas & Backlog.md
docs/Task_Management/08 - Infrastructure & DevOps.md
docs/Task_Management/How to use Task_Management.md
```

---

## Task 1: Create skills

**Files:**
- Create: `claude/skills/task-management.md`
- Create: `claude/skills/documentation.md`

- [x] **Step 1: Create the task-management skill**

Create `claude/skills/task-management.md` with this exact content:

```markdown
# Task Management Skill

Load this skill before reading or writing any task file in `docs/task-management/`.

---

## Before you begin

1. Read `docs/task-management/README.md` to understand the folder structure.
2. Read `docs/task-management/critical-tasks.md` to see what is active and critical.
3. Read the specific task file(s) relevant to the work.

---

## Card format

Every task is a card. Cards follow this exact format:

```
# Task title
#StatusTag
Brief description (1–3 sentences). Link to doc if needed: [[filename]].

---
```

Rules:
- `# H1` header = task title
- Status tag on its own line directly below the header
- Description below the tag — keep it concise
- If a detailed doc exists, link with `[[filename]]` — the file lives in `docs/documentation/`
- End every card with `---`
- Cards are ordered top-to-bottom by priority within the file

---

## Status tags

Every card must have exactly one status tag:

- `#ToDo` — not started
- `#Planning` — in detailed planning with AI
- `#InProgress` — actively being worked on
- `#Done` — completed
- `#Blocked` — waiting on something external

---

## Maintenance rules (non-negotiable)

After every task operation, you MUST:

1. **Update the task file** with the correct status tag and description.
2. **Update `docs/task-management/critical-tasks.md`:**
   - Add a pointer when a task becomes `#InProgress`
   - Add a pointer when AI determines a task is `#Critical` (high business impact, blocks other tasks)
   - Remove the pointer when a task is marked `#Done` or `#Blocked`
3. **Update `docs/task-management/map.md`** if a new task file is created.
4. **Update `docs/task-management/README.md`** if the folder structure changes.

Never close a task operation leaving `critical-tasks.md` or `map.md` out of sync.

---

## critical-tasks.md format

Pointers only — no task content. Format:

```
# Critical & Active Tasks

## In Progress
- [Task title] → `docs/task-management/02-frontend-backend.md`

## Critical (not yet started)
- [Task title] → `docs/task-management/01-ai-processing.md`
```

---

## Criticality criteria

A task is critical if any of the following are true:
- It is currently `#InProgress`
- It blocks multiple other tasks
- It has high business impact (user-facing, revenue, compliance)
- The user explicitly marks it as critical
```

- [x] **Step 2: Create the documentation skill**

Create `claude/skills/documentation.md` with this exact content:

```markdown
# Documentation Skill

Load this skill before writing or updating any file in `docs/`.

---

## Before you begin

1. Read the relevant hub `README.md` for the domain you are working in:
   - System architecture → `docs/system-overview/README.md`
   - Feature specs → `docs/documentation/README.md`
   - Tasks → use the task-management skill instead
2. Read the hub's `map.md` to locate the specific file you need.

---

## Naming conventions

- All doc files: `kebab-case.md`
- Place files in the correct subfolder — never at the hub root
- Never create a doc without a subfolder

---

## Maintenance rules (non-negotiable)

After every documentation operation, you MUST:

1. **Update `map.md`** in the affected folder:
   - Add entry when a file is created
   - Update entry when a file is renamed or its content changes significantly
   - Remove entry when a file is deleted
2. **Update hub `README.md`** if a subfolder is added or removed.
3. Verify `map.md` is accurate before closing the task.

---

## map.md entry format

One line per file:

```
- `path/to/file.md` — one-line description of what's in this file
```

---

## When to create a documentation file

Create a file in `docs/documentation/` when:
- A feature has a spec, UX flow, or design decision that exceeds 5–6 lines
- There are multiple scenarios, edge cases, or open questions to document

Do not create docs for simple, self-explanatory tasks — the task card description is sufficient.
```

- [x] **Step 3: Commit**

```bash
git add claude/skills/task-management.md claude/skills/documentation.md
git commit -m "feat: add task-management and documentation skills"
```

---

## Task 2: Create task-management hub files

**Files:**
- Create: `docs/task-management/README.md`
- Create: `docs/task-management/map.md`

- [x] **Step 1: Create `docs/task-management/README.md`**

```markdown
# Task Management

This folder is the project's task board. It replaces Trello and lives in Markdown.

## Before reading or writing tasks

Load the task-management skill: `claude/skills/task-management.md`

## How to navigate

1. Read `critical-tasks.md` first — it lists all active and critical tasks with pointers to their files.
2. Use `map.md` to find the full list of task files.
3. Open the specific task file to read or update a task.

## Folder structure

```
task-management/
├── README.md            ← you are here
├── map.md               ← index of all task files
├── critical-tasks.md    ← pointers to active and critical tasks
├── 01-ai-processing.md  ← AI & document processing tasks
├── 02-frontend-backend.md ← frontend ↔ backend integration tasks
├── 03-app-ui-ux.md      ← app UI/UX tasks
├── 04-timeline-feature.md ← timeline feature tasks
├── 05-testing-qa.md     ← testing & QA tasks
├── 06-business.md       ← business tasks (compliance, legal)
├── 07-feature-backlog.md ← feature ideas and backlog
└── 08-infrastructure-devops.md ← infrastructure & DevOps tasks
```

## Card format

```
# Task title
#StatusTag
Description (1–3 sentences). [[Link to doc if needed]].

---
```

## Status tags

- `#ToDo` — not started
- `#Planning` — in planning with AI
- `#InProgress` — actively being worked on
- `#Done` — completed
- `#Blocked` — waiting on something external
```

- [x] **Step 2: Create `docs/task-management/map.md`**

```markdown
# Task Management — File Map

- `task-management/README.md` — hub entry point: structure, rules, skill to load
- `task-management/map.md` — this file: index of all task files
- `task-management/critical-tasks.md` — pointers to active and critical tasks (AI-maintained)
- `task-management/01-ai-processing.md` — AI & document processing tasks
- `task-management/02-frontend-backend.md` — frontend ↔ backend integration tasks
- `task-management/03-app-ui-ux.md` — app UI/UX tasks
- `task-management/04-timeline-feature.md` — timeline feature tasks
- `task-management/05-testing-qa.md` — testing & QA tasks
- `task-management/06-business.md` — business tasks (GDPR, compliance)
- `task-management/07-feature-backlog.md` — feature ideas and backlog
- `task-management/08-infrastructure-devops.md` — infrastructure & DevOps tasks
```

- [x] **Step 3: Commit**

```bash
git add docs/task-management/README.md docs/task-management/map.md
git commit -m "feat: add task-management hub README and map"
```

---

## Task 3: Migrate task files

**Files:**
- Create: `docs/task-management/01-ai-processing.md` through `08-infrastructure-devops.md`

- [x] **Step 1: Create `docs/task-management/01-ai-processing.md`**

```markdown
---
tags:
  - TaskManagement
---
# RAG Agent types
#ToDo
Multi-agent architecture (Teaching, Problem Solver, Search, Study Advice). Summary on card, detailed spec in [[rag-agent-types]].

---
# PDF → Markdown image support
#ToDo
Extending the converter to extract images from PDFs.

---
# Scheduled function for unprocessed uploads
#ToDo
Research whether this should integrate with admin UI.

---
```

- [x] **Step 2: Create `docs/task-management/02-frontend-backend.md`**

```markdown
---
tags:
  - TaskManagement
---
# Retry logic & error handling
#ToDo
Full history sync strategy, failure scenarios (network error vs backend crash), idempotency support. See [[retry-logic]] for detailed design.

---
# AI Chat error handling — failed message flow
#ToDo
Frontend saves failed chats to Firestore with a failed parameter. Retry UX: ghost message turns red with retry icon. Deduplication logic when a failed message is successfully re-sent. See [[ai-chat-error-handling]] for full flow.

---
# AI Backend Firestore cleanup
#ToDo
Investigate and fix unwanted writes to `chat_checkpoints` in Firestore. The AI backend appears to store checkpoint data that duplicates what already exists under `user/{userId}/aiChatHistory/{threadId}`.

---
# Historic AI Chat loading
#ToDo
Revise how the frontend fetches and displays historical chats from Firestore. Revise how the frontend resumes an old `threadId` and sends a request to the AI backend.

---
```

- [x] **Step 3: Create `docs/task-management/03-app-ui-ux.md`**

```markdown
---
tags:
  - TaskManagement
---
# Sidebar structure
#ToDo
Left sidebar: courses overview page (archive, create, star courses), list of starred courses, general chat (with histories from all course chats), flashcards, resource page, profile, settings.

---
# Course page layout
#ToDo
Small buttons: upload resources, manage resources (add/remove existing), star course. Cards: flashcards, timeline milestones relevant to course. Bottom: chat.

---
# System instructions
#ToDo
The user should be able to set system instructions for AI agents. Needs decision: same instructions for all agents, or per-agent instructions?

---
```

- [x] **Step 4: Create `docs/task-management/04-timeline-feature.md`**

```markdown
---
tags:
  - TaskManagement
---
# Flashcards in timeline
#ToDo
Define how flashcard deadlines and review schedules appear on the timeline.

---
# Gjøremål (tasks) in timeline
#ToDo
Define how student tasks and to-dos integrate with the timeline view.

---
# Exams in timeline
#ToDo
Define how exam dates and preparation milestones are shown on the timeline.

---
```

- [x] **Step 5: Create `docs/task-management/05-testing-qa.md`**

```markdown
---
tags:
  - TaskManagement
---
# Testing Phases strategy
#ToDo
Three-phase approach: Phase 1 (Logic), Phase 2 (Usability), Phase 3 (Production readiness). See [[testing-phases]] for full breakdown.

---
# Stress test doc processing
#ToDo
Stress test the document processing pipeline with high volume and edge-case documents.

---
# Test full doc processing flow
#ToDo
End-to-end test from UI file upload through backend processing to stored result.

---
# Test new user creation
#ToDo
Verify the full new user creation flow works correctly.

---
```

- [x] **Step 6: Create `docs/task-management/06-business.md`**

```markdown
---
tags:
  - TaskManagement
---
# GDPR & Compliance
#ToDo
User uploaded content must only be accessible to the specific user who uploaded it — both in direct form and indirectly through AI. AI-generated content cannot be shared between users. Content uploaded by the user will never be used to train any AI. See [[gdpr-compliance]] for policy details.

---
```

- [x] **Step 7: Create `docs/task-management/07-feature-backlog.md`**

```markdown
---
tags:
  - TaskManagement
---
# Prepare for lecture feature
#ToDo
AI-powered lecture prep. User selects relevant resources (tags, topics) and adds lecture slides. Configurable depth (Overview → In-Depth). AI uses resource skeletons to understand context and suggests what to read, understand, or review. See [[prepare-for-lecture]] for detailed spec.

---
```

- [x] **Step 8: Create `docs/task-management/08-infrastructure-devops.md`**

```markdown
---
tags:
  - TaskManagement
---
# Document system with BMAD method
#ToDo
Document the entire system architecture and workflows using the BMAD method.

---
# Define document roles
#ToDo
Every document in the project should have a clear role and description. Similar to how `rules.md` describes how `TODO.md` is used — apply this to all docs from task management to monorepo files.

---
# AppCheck implementation
#ToDo
Implement Firebase AppCheck to verify that requests to the backend come from the legitimate app.

---
```

- [x] **Step 9: Commit**

```bash
git add docs/task-management/
git commit -m "feat: migrate task files to new task-management structure"
```

---

## Task 4: Create critical-tasks.md

**Files:**
- Create: `docs/task-management/critical-tasks.md`

- [x] **Step 1: Assess criticality from existing tasks**

Review all 8 task files. All tasks are currently `#ToDo` with no `#InProgress` tasks. Apply criticality criteria: high business impact, blocks other tasks, compliance-related.

Critical tasks identified:
- **RAG Agent types** — core AI architecture, blocks all AI feature work
- **Retry logic & error handling** — blocks reliable AI chat
- **AI Chat error handling** — blocks reliable AI chat UX
- **GDPR & Compliance** — compliance requirement, must be implemented before any user data handling
- **AppCheck implementation** — security requirement, blocks production readiness

- [x] **Step 2: Create `docs/task-management/critical-tasks.md`**

```markdown
# Critical & Active Tasks

> This file is AI-maintained. Do not edit manually.
> Updated automatically on every task status change.

---

## In Progress

_No tasks currently in progress._

---

## Critical (not yet started)

- [RAG Agent types] → `docs/task-management/01-ai-processing.md`
- [Retry logic & error handling] → `docs/task-management/02-frontend-backend.md`
- [AI Chat error handling — failed message flow] → `docs/task-management/02-frontend-backend.md`
- [GDPR & Compliance] → `docs/task-management/06-business.md`
- [AppCheck implementation] → `docs/task-management/08-infrastructure-devops.md`
```

- [x] **Step 3: Commit**

```bash
git add docs/task-management/critical-tasks.md
git commit -m "feat: add critical-tasks.md with initial critical task pointers"
```

---

## Task 5: Create documentation hub files and migrate docs

**Files:**
- Create: `docs/documentation/README.md`
- Create: `docs/documentation/map.md`
- Create: `docs/documentation/ai-features/rag-agent-types.md`
- Create: `docs/documentation/ai-features/ai-chat-error-handling.md`
- Create: `docs/documentation/ai-features/retry-logic.md`
- Create: `docs/documentation/ai-features/prepare-for-lecture.md`
- Create: `docs/documentation/compliance/gdpr-compliance.md`
- Create: `docs/documentation/testing/testing-phases.md`

- [x] **Step 1: Create `docs/documentation/README.md`**

```markdown
# Documentation

This folder contains detailed feature specs, UX flows, and design decisions. These are heavy documents — load only the specific file you need, not the whole folder.

## When to load files here

Only load a file from this folder when:
- You are actively working on that specific feature
- The task card links to a doc here with `[[filename]]`

## Before writing or updating docs

Load the documentation skill: `claude/skills/documentation.md`

## Folder structure

```
documentation/
├── README.md              ← you are here
├── map.md                 ← index of all docs with one-liners
├── ai-features/           ← AI feature specs (RAG, chat, error handling)
├── compliance/            ← GDPR, legal, and compliance docs
├── testing/               ← testing strategy and phase docs
└── ux-flows/              ← user experience flows (to be added)
```

## Important

- Load `map.md` to find specific files
- Do not load this folder broadly — use the map to locate only what you need
- After adding or changing any file, update `map.md`
```

- [x] **Step 2: Create `docs/documentation/map.md`**

```markdown
# Documentation — File Map

- `documentation/README.md` — hub entry point: structure, rules, skill to load
- `documentation/map.md` — this file: index of all documentation files
- `documentation/ai-features/rag-agent-types.md` — multi-agent architecture spec (Teaching, Problem Solver, Search, Study Advice)
- `documentation/ai-features/ai-chat-error-handling.md` — failed message flow, retry UX, deduplication logic
- `documentation/ai-features/retry-logic.md` — full history sync, failure scenarios, idempotency design
- `documentation/ai-features/prepare-for-lecture.md` — AI-powered lecture prep feature spec and UX flow
- `documentation/compliance/gdpr-compliance.md` — GDPR privacy principles and implementation requirements
- `documentation/testing/testing-phases.md` — three-phase testing strategy (Logic, Usability, Production)
```

- [x] **Step 3: Create `docs/documentation/ai-features/rag-agent-types.md`**

```markdown
---
tags:
  - Documentation/Internal
---
# RAG Agent Types

## Multi-agent architecture

The AI uses a multi-agent system where a classifier routes each user message to the most appropriate agent.

### Agent types

- **Teaching agent** — triggered by: "teach me about", "teach me how to", explain-style queries
- **Problem solver agent** — triggered by: "give me the answer", "solve this problem", direct answer requests
- **Search / default agent** — general chat with access to the user's uploaded resources
- **Study advice agent** _(proposed)_ — triggered by: "give me a structured approach to study this", "how should I study X". Helps the user classify information, recommend study methods, and estimate time per task.

### Search agent classifier

The search agent should include a sub-classifier: is the student asking what materials the AI has access to, or are they asking a content question? These require different response strategies.
```

- [x] **Step 4: Create `docs/documentation/ai-features/ai-chat-error-handling.md`**

```markdown
---
tags:
  - Documentation/Internal
---
# AI Chat Error Handling — Failed Message Flow

## Failed message flow

When an AI chat message fails (no contact with backend or no response after three attempts), the frontend must handle persistence and display.

## Save to Firestore

The chat is saved to Firestore with the `threadId` and a `failed` parameter indicating the message did not succeed.

## Display

- The failed chat appears in the UI with a visual failed state (red/error styling).
- It is also visible in historic chats as a failed message without a response.

## Retry flow

When the user retries a failed message:

1. **Not successful:** No change — the message stays in failed state.
2. **Successful:** The backend saves the user message and assistant response in the Firestore document.
3. **Deduplication:** When the frontend sees a failed message followed by an identical successful message and an assistant response, it hides the first (failed) message and only shows the successful exchange.
```

- [x] **Step 5: Create `docs/documentation/ai-features/retry-logic.md`**

```markdown
---
tags:
  - Documentation/Internal
---
# Retry Logic & Error Handling

## Why we send full history every request

Even if the frontend already knows the history, sending the full array back in every response is the gold standard for synchronization:

- **Auto-Truncation (Memory Management):** The backend has a setting (`MAX_MESSAGE_HISTORY=20`). When the chat gets long, the backend deletes the oldest messages to save tokens. If we only send the last message, the frontend will keep showing messages the AI has "forgotten."
- **AI Corrections:** The AI pipeline may clean up previous queries (coreference resolution). Syncing the whole history ensures the UI matches the AI's actual context.
- **Simplicity:** Prevents "out of sync" states where frontend and backend have different versions of the truth.

## Failure Handling

### Scenario A: Frontend fails to reach the backend (network error)

Responsibility: 100% Frontend.

- If `fetch()` throws an error or the gateway returns a 503, the frontend should NOT add the message to the official history state. Mark it as "Failed" in the UI and show a "Retry" button.
- Save failed messages in LocalStorage so that after a page refresh the frontend can prompt: "You had a message that failed to send. Want to try again?"

### Scenario B: Backend fails mid-answer (crashes or timeouts)

Responsibility: Both frontend and backend.

- **Backend:** LangGraph Checkpoints are only saved after the AI successfully finishes. If the backend crashes mid-stream, the checkpoint is not updated. This makes retrying safe — the backend sees the conversation as it was before the failure.
- **Frontend:** Detects the failed stream and offers retry using the same `thread_id`.

## Idempotency

If the frontend sends the same message twice (retry), the backend should not treat it as two separate questions. For a chat app, the `thread_id` plus manual "Retry" click is usually sufficient. No special idempotency endpoint needed — re-call `POST /messages` with the same `thread_id`.

## Frontend implementation notes

- Keep a `pendingMessages` list for messages not yet confirmed by the backend.
- Show a "ghost" message or loader while waiting. On error, turn it red with a retry icon.
- The existing API response format already supports this flow.
```

- [x] **Step 6: Create `docs/documentation/ai-features/prepare-for-lecture.md`**

```markdown
---
tags:
  - Documentation/Internal
---
# Prepare for Lecture Feature

## Concept

A feature that helps students prepare for an upcoming lecture in a structured, AI-assisted way.

## User flow

1. The user selects relevant resources (or filters by tags, topics, or other groupings).
2. The user uploads or selects the specific lecture slides/PPT.
3. The user chooses a desired depth or time commitment. Options could be a slider (Overview → In-Depth) or radio buttons (Overview, Summary, Detailed, In-Depth).
4. The AI processes the materials and generates a preparation plan.

## How the AI works

- Uses a Resource Skeleton (similar to what flashcards use) to understand context, structure, and what is emphasized.
- Generates actionable suggestions: read this section, understand this concept, review this article.
- Tailors the output to the chosen depth level.

## Open questions

- Slider vs. radio buttons for depth selection?
- Should the user be able to set a time budget (e.g. "I have 30 minutes") instead of or in addition to depth?
- How does this integrate with the timeline feature — should prep sessions appear as milestones?
```

- [x] **Step 7: Create `docs/documentation/compliance/gdpr-compliance.md`**

```markdown
---
tags:
  - Documentation/Internal
---
# GDPR & Compliance

## Core privacy principles

1. **User content isolation:** Uploaded content is only accessible to the specific user who uploaded it — both in direct form and indirectly through AI-generated responses.
2. **No cross-user AI leakage:** AI-generated content cannot be shared or leak between users. Each user's AI context is fully isolated.
3. **No training usage:** Content uploaded by users will never be used to train any AI model.

## Implementation considerations

- Firestore security rules must enforce per-user read/write access.
- RAG vector stores must be scoped per user — no shared embeddings across users.
- AI API calls must not include content from other users' documents.
- Audit logging should be in place to verify isolation.
```

- [x] **Step 8: Create `docs/documentation/testing/testing-phases.md`**

```markdown
---
tags:
  - Documentation/Internal
---
# Testing Phases Strategy

## Phase 1: Logic

**Entrance criteria:** Chat and flashcards logic exists.

**Scope:** Test the logic with different scenarios. Focus on all use cases, options, edge cases, and logical paths the system can achieve — both product quality and errors. Stress test the system.

**Exit criteria:** All errors are handled.

## Phase 2: Usability

**Entrance criteria:** User observability, admin UI, and error handling are developed.

**Scope:** Test locally on a small group of users. Test product quality, usability, and how users naturally use the system.

**Exit criteria:** All usage and errors are captured by admin UI and observability.

## Phase 3: System health and production readiness

**Entrance criteria:** The system has automatic health updates and can self-recover (restart services if something breaks). CI/CD and testing pipelines are in place.

**Scope:** Move the system to production. Test in the production environment.

**Exit criteria:** System is stable in production with monitoring and automated recovery.
```

- [x] **Step 9: Commit**

```bash
git add docs/documentation/
git commit -m "feat: add documentation hub files and migrate existing docs"
```

---

## Task 6: Create system-overview hub and initial overview docs

**Files:**
- Create: `docs/system-overview/README.md`
- Create: `docs/system-overview/map.md`
- Create: `docs/system-overview/general/overview.md`
- Create: `docs/system-overview/ai-server/overview.md`
- Create: `docs/system-overview/mobile/overview.md`
- Create: `docs/system-overview/web/overview.md`

- [x] **Step 1: Create `docs/system-overview/README.md`**

```markdown
# System Overview

This folder documents the architecture, structure, and design rules of the student platform. Load files here when you need to understand how the system works before making changes.

## Pinned — read these first

- `general/overview.md` — cross-cutting concerns: auth, data flow, infra, design rules
- `ai-server/overview.md` — AI server architecture and service breakdown
- `mobile/overview.md` — Flutter mobile app structure
- `web/overview.md` — Next.js web app structure

## Folder structure

```
system-overview/
├── README.md          ← you are here
├── map.md             ← index of all files
├── general/           ← cross-cutting: auth, Firebase, data flow, design rules
├── ai-server/         ← AI server microservices, endpoints, agent types
├── mobile/            ← Flutter app: structure, navigation, state
└── web/               ← Next.js/Express app: routing, components, API
```

## When to load files here

- Before making architectural decisions
- Before adding new services or endpoints
- Before modifying auth, Firestore rules, or data models
- When onboarding to a new part of the codebase
```

- [x] **Step 2: Create `docs/system-overview/map.md`**

```markdown
# System Overview — File Map

- `system-overview/README.md` — hub entry point: structure, pinned files, when to load
- `system-overview/map.md` — this file: index of all system-overview files
- `system-overview/general/overview.md` — cross-cutting: auth, Firebase, data flow, monorepo design rules
- `system-overview/ai-server/overview.md` — AI server microservices, service breakdown, endpoints
- `system-overview/mobile/overview.md` — Flutter mobile app: structure, navigation, state management
- `system-overview/web/overview.md` — Next.js/Express web app: routing, components, API-first constraint
```

- [x] **Step 3: Create `docs/system-overview/general/overview.md`**

```markdown
# General System Overview

## What the platform does

A student learning platform that helps university students manage course materials, generate flashcards, and get AI-powered study assistance. Students upload documents (PDFs, slides) and the AI processes them for search, Q&A, and study tools.

## Monorepo structure

```
apps/
├── ai-server/    ← Python FastAPI + Node.js microservices for AI and document processing
├── mobile/       ← Flutter mobile app (primary user-facing app)
└── web/          ← Next.js + Express web app (admin UI and web access)
```

## Authentication

Firebase Authentication is used across all apps. The AI server validates Firebase ID tokens on every request via the auth-service microservice. The mobile app and web app both use Firebase Auth SDKs.

## Database

Firestore is the primary database. Key collections:
- `users/{userId}` — user profile
- `users/{userId}/courses/{courseId}` — user courses
- `users/{userId}/resources/{resourceId}` — uploaded documents
- `users/{userId}/aiChatHistory/{threadId}` — AI chat history

## Data flow (document processing)

1. User uploads a file via mobile or web
2. File is stored in Firebase Storage
3. A Firestore document is created with `status: pending`
4. The RAG worker service picks up the job via Pub/Sub
5. Worker processes the document (PDF → Markdown, chunking, embedding)
6. Embeddings stored in vector store, status updated to `processed`

## Design rules

- **User isolation:** All data is scoped per user. No cross-user data access anywhere.
- **API-first (web):** Web client never calls Firestore directly — all data goes through the Express API.
- **Mobile:** Flutter app uses Firebase SDKs directly for Firestore and Storage.
- **GDPR:** User content never trains AI models. Vector stores are scoped per user.
```

- [x] **Step 4: Create `docs/system-overview/ai-server/overview.md`**

```markdown
# AI Server Overview

## Architecture

The AI server is a set of Docker microservices orchestrated with Docker Compose.

## Services

| Service | Language | Role |
|---------|----------|------|
| `api-gateway` | Node.js/TypeScript | Routes requests, handles auth verification hand-off |
| `auth-service` | Node.js/TypeScript | Validates Firebase ID tokens |
| `rag-api-service` | Python FastAPI | AI chat endpoint, LangGraph agent orchestration |
| `rag-worker-service` | Python | Document processing (PDF → Markdown → embeddings) |
| `flashcard-service` | (check codebase) | Flashcard generation |
| `observability-aggregator` | (check codebase) | Logging and observability |

## Key endpoints (via api-gateway)

- `POST /messages` — send a chat message, returns SSE stream
- Document upload triggers are handled via Firebase Storage + Pub/Sub (not a direct HTTP call)

## Agent types

See `docs/documentation/ai-features/rag-agent-types.md` for the multi-agent routing design.

## LangGraph

The RAG API service uses LangGraph for agent orchestration. Checkpoints are saved to Firestore after a successful AI response. If the AI crashes mid-stream, the checkpoint is not updated — making retries safe.
```

- [x] **Step 5: Create `docs/system-overview/mobile/overview.md`**

```markdown
# Mobile App Overview

## Tech stack

- **Framework:** Flutter (Dart)
- **Auth:** Firebase Auth
- **Database:** Firestore (direct SDK access)
- **Storage:** Firebase Storage (direct SDK access)
- **State management:** (check codebase — likely Riverpod or Provider)

## Key app areas

- Course management (create, archive, star courses)
- Resource upload and management (PDFs, slides)
- AI chat (per-course and general)
- Flashcards
- Timeline (upcoming feature)

## Firestore access

Unlike the web app, the mobile app accesses Firestore directly using the Firebase Flutter SDK. Firestore security rules enforce per-user access.

## Structure

See `apps/mobile/` for full source. Key areas:
- `lib/` — main Flutter source
- `firestore.rules` — security rules
- `firebase.json` — Firebase project config
```

- [x] **Step 6: Create `docs/system-overview/web/overview.md`**

```markdown
# Web App Overview

## Tech stack

- **Frontend:** React 18, Wouter (routing), TanStack React Query, Zustand, Tailwind CSS, shadcn/ui
- **Backend:** Express, Firebase Admin SDK, Firestore
- **Auth:** Firebase Auth (client-side only — `firebase/auth` is the only Firebase import allowed in client code)
- **Validation:** Zod schemas shared between client and server
- **AI:** Mistral AI for OCR and chat features

## Key constraint: API-first data access

**Client code must NEVER import `firebase/firestore` or `firebase/storage` directly.** All data operations go through the Express API server. Only `firebase/auth` is allowed in client code. This is enforced by ESLint.

## Structure

```
apps/web/
├── client/src/
│   ├── components/ui/       ← shadcn/ui components
│   ├── pages/               ← route components
│   ├── hooks/useDataQueries.ts ← React Query hooks for all API calls
│   ├── lib/api.ts           ← typed API wrapper functions
│   └── lib/queryClient.ts   ← HTTP client with auth token injection
└── server/
    ├── routes/              ← REST endpoints (users, courses, resources, chat, ocr)
    └── services/            ← business logic layer
```

## Dev commands

```bash
npm run dev      # Start development server (Express + Vite HMR on port 5000)
npm run build    # Build for production
npm run check    # TypeScript type checking
```
```

- [x] **Step 7: Commit**

```bash
git add docs/system-overview/
git commit -m "feat: add system-overview hub with initial architecture docs"
```

---

## Task 7: Create CLAUDE.md

**Files:**
- Create: `CLAUDE.md`

- [x] **Step 1: Create `CLAUDE.md`**

```markdown
# Student Platform

A student learning platform that helps university students manage course materials, generate flashcards, and get AI-powered study assistance. Students upload documents and the AI processes them for search, Q&A, and study tools.

## Monorepo structure

```
apps/
├── ai-server/   ← Python FastAPI + Node.js microservices (AI, document processing, RAG)
├── mobile/      ← Flutter mobile app (primary user-facing app)
└── web/         ← Next.js + Express web app (admin UI, web access)
```

## Tech stack

- **ai-server:** Python FastAPI (rag-api-service, rag-worker), Node.js/TypeScript (api-gateway, auth-service), Docker Compose, LangGraph, Firebase Admin
- **mobile:** Flutter/Dart, Firebase Auth, Firestore, Firebase Storage
- **web:** React 18, Express, Tailwind CSS, shadcn/ui, Firebase Auth, Zod, Mistral AI

---

## Documentation layers

Context is loaded in layers. Always start at the hub README, then use map.md to find specific files.

```
Layer 0: CLAUDE.md (this file — always in context)
Layer 1: Hub README.md (load when the domain is relevant)
Layer 2: map.md (load to locate a specific file)
Layer 3: Leaf docs (load only for the specific feature or task)
```

### When to load each hub

| Domain | Load when | Hub README |
|--------|-----------|------------|
| System architecture | Understanding how the system works, before modifying services or data models | `docs/system-overview/README.md` |
| Feature specs | Working on a specific feature with a detailed spec | `docs/documentation/README.md` |
| Tasks | Reading or writing project tasks | `docs/task-management/README.md` |

---

## Skills

Load the relevant skill before acting in that domain:

| Domain | Skill |
|--------|-------|
| Reading or writing tasks | `claude/skills/task-management.md` |
| Writing or updating documentation | `claude/skills/documentation.md` |

---

## Loading rule

1. Identify which domain is relevant to the current task.
2. Load the hub `README.md` for that domain.
3. Load `map.md` from that hub to locate the specific file(s) needed.
4. Load only the specific leaf doc(s) required.
5. Load the relevant skill before making any changes.

Never load an entire folder. Always use the map to locate what you need.
```

- [x] **Step 2: Commit**

```bash
git add CLAUDE.md
git commit -m "feat: add CLAUDE.md with layered documentation loading rules"
```

---

## Task 8: Delete old files

**Files to delete:**
- `docs/Documentation/` (entire folder)
- `docs/Task_Management/` (entire folder)

- [x] **Step 1: Delete old Documentation folder**

```bash
git rm -r "docs/Documentation/"
```

- [x] **Step 2: Delete old Task_Management folder**

```bash
git rm -r "docs/Task_Management/"
```

- [x] **Step 3: Commit**

```bash
git commit -m "chore: remove old Documentation and Task_Management folders"
```

---

## Task 9: Final verification

- [x] **Step 1: Verify directory structure**

```bash
find /Users/lukasm/Documents/StudentApp/Code/student-platform/docs -type f | sort
```

Expected output includes:
- `docs/documentation/README.md`
- `docs/documentation/map.md`
- `docs/documentation/ai-features/rag-agent-types.md`
- `docs/documentation/ai-features/ai-chat-error-handling.md`
- `docs/documentation/ai-features/retry-logic.md`
- `docs/documentation/ai-features/prepare-for-lecture.md`
- `docs/documentation/compliance/gdpr-compliance.md`
- `docs/documentation/testing/testing-phases.md`
- `docs/system-overview/README.md`
- `docs/system-overview/map.md`
- `docs/system-overview/general/overview.md`
- `docs/system-overview/ai-server/overview.md`
- `docs/system-overview/mobile/overview.md`
- `docs/system-overview/web/overview.md`
- `docs/task-management/README.md`
- `docs/task-management/map.md`
- `docs/task-management/critical-tasks.md`
- `docs/task-management/01-ai-processing.md` through `08-infrastructure-devops.md`

Does NOT include:
- `docs/Documentation/` (any files)
- `docs/Task_Management/` (any files)

- [x] **Step 2: Verify CLAUDE.md exists at root**

```bash
ls /Users/lukasm/Documents/StudentApp/Code/student-platform/CLAUDE.md
```

Expected: file exists.

- [x] **Step 3: Verify skills exist**

```bash
ls /Users/lukasm/Documents/StudentApp/Code/student-platform/claude/skills/
```

Expected:
```
documentation.md
task-management.md
```

- [x] **Step 4: Verify no old folder references remain**

```bash
find /Users/lukasm/Documents/StudentApp/Code/student-platform/docs -name "*.md" | xargs grep -l "Task_Management\|Documentation/" 2>/dev/null
```

Expected: no output (or only the spec file in `docs/superpowers/`).

- [x] **Step 5: Final commit if any cleanup needed, then summarize**

```bash
git status
```

If clean: done. If any untracked or modified files remain, add and commit them.
