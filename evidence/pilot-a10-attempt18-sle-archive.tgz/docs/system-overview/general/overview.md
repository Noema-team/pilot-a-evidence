# General System Overview

## What the platform does

A student learning platform that helps university students manage course materials, generate flashcards, and get AI-powered study assistance. Students upload documents (PDFs, slides) and the AI processes them for search, Q&A, and study tools.

## Monorepo structure

```
apps/
├── ai-server/    ← Python FastAPI + Node.js microservices for AI and document processing
├── mobile/       ← Flutter mobile app (primary user-facing app)
└── web/          ← Next.js + Express web app (admin UI and web access)
```

## Authentication

Firebase Authentication is used across all apps. The AI server validates Firebase ID tokens on every request via the auth-service microservice. The mobile app and web app both use Firebase Auth SDKs.

## Database

Firestore is the primary database. Key collections:
- `users/{userId}` — user profile
- `users/{userId}/courses/{courseId}` — user courses
- `users/{userId}/resources/{resourceId}` — uploaded documents
- `users/{userId}/aiChatHistory/{threadId}` — AI chat history

## Data flow (document processing)

1. User uploads a file via mobile or web
2. File is stored in Firebase Storage
3. A Firestore document is created with `status: pending`
4. The RAG worker service picks up the job via Pub/Sub
5. Worker processes the document (PDF → Markdown, chunking, embedding)
6. Embeddings stored in vector store, status updated to `processed`

## Design rules

- **User isolation:** All data is scoped per user. No cross-user data access anywhere.
- **API-first (web):** Web client never calls Firestore directly — all data goes through the Express API.
- **Mobile:** Flutter app uses Firebase SDKs directly for Firestore and Storage.
- **GDPR:** User content never trains AI models. Vector stores are scoped per user.
