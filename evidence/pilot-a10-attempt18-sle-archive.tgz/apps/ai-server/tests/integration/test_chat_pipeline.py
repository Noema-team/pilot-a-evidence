import sys
import os
import pytest
from unittest.mock import MagicMock, AsyncMock, patch

import httpx

AGENT_GRAPH_DIR = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "..", "agent-graph-service"))

for _mod in [
    "firebase_admin", "firebase_admin.credentials", "firebase_admin.firestore",
    "firebase_admin.auth", "firebase_admin._apps",
    "google", "google.cloud", "google.cloud.firestore", "google.cloud.firestore_v1",
    "google.cloud.pubsub_v1", "google.oauth2", "google.oauth2.service_account",
    "google.api_core", "google.api_core.exceptions",
    "opentelemetry", "opentelemetry.trace", "opentelemetry.sdk.trace",
    "opentelemetry.sdk.resources", "opentelemetry.sdk.trace.export",
    "opentelemetry.exporter.otlp.proto.grpc.trace_exporter",
    "opentelemetry.instrumentation", "opentelemetry.instrumentation.fastapi",
    "opentelemetry.instrumentation.httpx",
    "structlog",
    "langgraph", "langgraph.graph", "langgraph.graph.state",
    "langgraph.checkpoint", "langgraph.checkpoint.base",
    "psycopg2", "psycopg2.sql",
    "redis", "redis.asyncio",
]:
    if _mod not in sys.modules:
        sys.modules[_mod] = MagicMock()

os.environ.setdefault("SHARED_INTERNAL_TOKEN", "test-internal-token")
os.environ.setdefault("RAG_API_BASE_URL", "http://test-rag-api:8000")
os.environ.setdefault("INTERNAL_TOKEN", "test-internal-token")
os.environ.setdefault("PERSISTENCE_STRATEGY", "memory")
os.environ.setdefault("GOOGLE_APPLICATION_CREDENTIALS", "/dev/null")
os.environ.setdefault("FIRESTORE_EMULATOR_HOST", "localhost:8080")

if AGENT_GRAPH_DIR not in sys.path:
    sys.path.insert(0, AGENT_GRAPH_DIR)

import asyncio


def _run(coro):
    return asyncio.get_event_loop().run_until_complete(coro)


class TestGatewayClient:
    def test_default_headers_include_internal_token(self):
        from src.tools.client import GatewayClient
        client = GatewayClient(base_url="http://test-rag:8000")
        assert "x-internal-token" in client.headers
        assert client.headers["x-internal-token"] == os.environ.get("INTERNAL_TOKEN")

    def test_merged_headers_include_user_id(self):
        from src.tools.client import GatewayClient
        client = GatewayClient(base_url="http://test-rag:8000")
        custom = {"x-authenticated-user-id": "user123"}
        merged = {**client.headers, **custom}
        assert "x-internal-token" in merged
        assert merged["x-authenticated-user-id"] == "user123"

    def test_post_sends_correct_url_and_headers(self):
        from src.tools.client import GatewayClient
        client = GatewayClient(base_url="http://test-rag:8000")

        mock_resp = MagicMock()
        mock_resp.json.return_value = {"data": "ok"}
        mock_resp.raise_for_status = MagicMock()

        with patch("src.tools.client.httpx.AsyncClient") as mock_cls:
            mock_inst = AsyncMock()
            mock_inst.post = AsyncMock(return_value=mock_resp)
            mock_inst.__aenter__ = AsyncMock(return_value=mock_inst)
            mock_inst.__aexit__ = AsyncMock(return_value=None)
            mock_cls.return_value = mock_inst

            _run(client.post("/search", json={"query": "test"}, headers={"x-authenticated-user-id": "user1"}))

        post_call = mock_inst.post.call_args
        assert post_call[0][0] == "http://test-rag:8000/search"
        headers = post_call[1]["headers"]
        assert headers["x-internal-token"] == "test-internal-token"
        assert headers["x-authenticated-user-id"] == "user1"
        assert post_call[1]["json"] == {"query": "test"}

    def test_get_sends_correct_url_and_headers(self):
        from src.tools.client import GatewayClient
        client = GatewayClient(base_url="http://test-rag:8000")

        mock_resp = MagicMock()
        mock_resp.json.return_value = {"data": "ok"}
        mock_resp.raise_for_status = MagicMock()

        with patch("src.tools.client.httpx.AsyncClient") as mock_cls:
            mock_inst = AsyncMock()
            mock_inst.get = AsyncMock(return_value=mock_resp)
            mock_inst.__aenter__ = AsyncMock(return_value=mock_inst)
            mock_inst.__aexit__ = AsyncMock(return_value=None)
            mock_cls.return_value = mock_inst

            _run(client.get("/courses/c1/resources/info", headers={"x-impersonate-user-id": "user1"}))

        get_call = mock_inst.get.call_args
        assert get_call[0][0] == "http://test-rag:8000/courses/c1/resources/info"
        headers = get_call[1]["headers"]
        assert headers["x-internal-token"] == "test-internal-token"
        assert headers["x-impersonate-user-id"] == "user1"


class TestRagSearchTool:
    def test_sends_search_request_with_query_and_course_id(self):
        mock_return = {
            "query": "what is AI?",
            "results": [{"id": "1", "content": "AI is...", "score": 0.9, "distance": 0.1, "resource_id": "r1", "chunk_id": "c1"}],
            "contexts_markdown": ["AI is..."],
            "combined_context": "AI is...",
        }

        with patch("src.tools.rag_search.client") as mock_client:
            mock_client.post = AsyncMock(return_value=mock_return)

            from src.tools.rag_search import rag_search
            _run(rag_search(query="what is AI?", user_id="user1", course_id="c1", top_k=6))

        call_args = mock_client.post.call_args
        body = call_args[1]["json"]
        assert body["query"] == "what is AI?"
        # course_id travels inside `context` now, not as a bare top-level
        # field — rag-api-service's /search takes the elif request.course_id
        # legacy branch when context is absent, so this always sends context
        # to make additional_group_ids reachable too (rag_search.py).
        assert body["context"]["mode"] == "course"
        assert body["context"]["course_id"] == "c1"
        assert body["limit"] == 6
        headers = call_args[1]["headers"]
        assert headers["x-authenticated-user-id"] == "user1"

    def test_sends_additional_group_ids_inside_context(self):
        mock_return = {
            "query": "test", "results": [], "contexts_markdown": [], "combined_context": "",
        }

        with patch("src.tools.rag_search.client") as mock_client:
            mock_client.post = AsyncMock(return_value=mock_return)

            from src.tools.rag_search import rag_search
            _run(rag_search(query="test", user_id="user1",
                            additional_group_ids=["g1", "g2"], top_k=5))

        body = mock_client.post.call_args[1]["json"]
        assert body["context"]["additional_group_ids"] == ["g1", "g2"]
        assert body["context"]["mode"] == "general"  # no course_id supplied

    def test_sends_user_id_in_header_not_body(self):
        mock_return = {
            "query": "test", "results": [], "contexts_markdown": [], "combined_context": "",
        }

        with patch("src.tools.rag_search.client") as mock_client:
            mock_client.post = AsyncMock(return_value=mock_return)

            from src.tools.rag_search import rag_search
            _run(rag_search(query="test", user_id="user-abc-123", top_k=3))

        body = mock_client.post.call_args[1]["json"]
        assert "user_id" not in body
        headers = mock_client.post.call_args[1]["headers"]
        assert headers["x-authenticated-user-id"] == "user-abc-123"

    def test_propagates_connection_error(self):
        with patch("src.tools.rag_search.client") as mock_client:
            mock_client.post = AsyncMock(side_effect=httpx.ConnectError("Connection refused"))

            from src.tools.rag_search import rag_search
            with pytest.raises(httpx.ConnectError):
                _run(rag_search(query="test", user_id="user1"))

    def test_works_without_course_id(self):
        mock_return = {
            "query": "test", "results": [], "contexts_markdown": [], "combined_context": "",
        }

        with patch("src.tools.rag_search.client") as mock_client:
            mock_client.post = AsyncMock(return_value=mock_return)

            from src.tools.rag_search import rag_search
            _run(rag_search(query="general question", user_id="user1", top_k=5))

        body = mock_client.post.call_args[1]["json"]
        assert body["context"]["course_id"] is None
        assert body["context"]["mode"] == "general"


class TestCourseMapTool:
    def test_calls_rag_api_with_course_id(self):
        with patch("src.tools.course_map.client") as mock_client:
            mock_client.get = AsyncMock(return_value={
                "courseId": "c1",
                "courseName": "Test Course",
                "resources": [],
            })

            from src.tools.course_map import get_course_map
            _run(get_course_map(user_id="user1", course_id="c1"))

        call_args = mock_client.get.call_args
        assert "/courses/c1/resources/info" in call_args[1].get("path", call_args[0][0] if call_args[0] else "")
        headers = call_args[1]["headers"]
        assert headers["x-impersonate-user-id"] == "user1"

    def test_uses_impersonate_header_for_service_account(self):
        with patch("src.tools.course_map.client") as mock_client:
            mock_client.get = AsyncMock(return_value={
                "courseId": "c1",
                "courseName": "Test",
                "resources": [],
            })

            from src.tools.course_map import get_course_map
            _run(get_course_map(user_id="user-xyz-789", course_id="c1"))

        headers = mock_client.get.call_args[1]["headers"]
        assert headers["x-impersonate-user-id"] == "user-xyz-789"
