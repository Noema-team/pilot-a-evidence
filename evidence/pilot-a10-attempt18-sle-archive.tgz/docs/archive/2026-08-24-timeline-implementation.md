# Timeline Implementation Plan (reality-corrected)

**Date:** 2026-08-24
**Spec:** `apps/ai-server/docs/architecture/timeline-and-flashcards/design-specification.md` (v2.2)
**Status:** Active. Supersedes the ordering/assumptions in the task cards as they were before recon.
**Task cards:** `docs/task-management/04-timeline-feature.md`

---

## 1. What we are solving (unchanged by recon)

The timeline gives students a clear picture of where they stand on the path to an exam
and the pace required to close the gap. The design exists to guarantee five properties:

1. **Anti-rot** — nothing calendar-shaped is stored; the view is derived from
   `(today, exam, units, completions)` on every read. Missed days self-heal.
2. **Efficient** — skeletons already exist as ResourceMaps (cheap, one-shot
   extraction); path builds are one cheap LLM call over tiny JSON (~$0.01);
   derivation is pure and free.
3. **Anti-bloat** — minimal stored domain state (Exam, Unit, CompletionEvent,
   ActivityLog), one derivation implementation, one mutation mechanism per mode,
   LLM confined to two edge jobs (extraction ordering).
4. **Mirror, not controller** — facts and projections, never verdicts; suggest,
   never act; no nagging, no stored schedule to defend.
5. **Observed over declared** — the grounding links double as sensors;
   completions arrive as one-tap confirmations of observed activity.

Everything below is subordinate to these. A change that violates one needs a very
good reason.

## 2. What recon changed (the reality map)

The original cards were written without full knowledge of the codebase. Corrections:

| Was assumed | Reality (verified 2026-08-24) |
|---|---|
| Skeleton extraction greenfield | Tiers 1/3 already existed (`MarkdownParser` → ResourceMap). Tier 2 shipped (`algorithms/skeleton_refiner.py`); confidence now reflects path usability. **Done.** |
| Derivation lives in api-gateway (TS) | Gateway is a thin auth proxy (hand-written routes, no business layer). Business logic + Firestore live in **rag-api-service** (Python, `services/` + `models/` pattern). The TS module must be **ported to Python and the TS version retired** — one derivation, anti-bloat/anti-drift. |
| Exams nested under `courses/{c}/exams/` | V2 storage is flattened: `users/{u}/resources/{r}` with `course_ids[]` membership; subcollections like `resourceMap/data`. Exams follow: **`users/{u}/exams/{examId}`** with `course_id` field. |
| Units link to flashcard "decks" by page range | **No deck entity.** Cards live at `users/{u}/resources/{r}/flashcards/{fid}`, grouped by `section_id`; cards carry **no page ranges** — pages live on map Sections. Linking is: unit page range → **overlapping Sections** → cards via `section_id`. Generation already accepts `section_ids[]` (flashcard-service `/generate`). |
| Skeletons need a new endpoint building new data | Skeleton = existing ResourceMap (`users/{u}/resources/{r}/resourceMap/data`). A course's skeletons = maps of resources where `course_ids` contains the course — `QueryResolver` already resolves course→resource_ids (with cache). |
| TimelinePlannerAgent wiring unknown | agent-graph-service is Python FastAPI + LangGraph. Convention: new FastAPI route (e.g. `POST /plan`), inline `TIMELINE_PLANNER_SYSTEM_PROMPT`, `TIMELINE_PLANNER_MODEL`/`_TEMPERATURE` in `config.py` + `.env.example`. Stateless — rag-api-service assembles input, gateway proxies. |
| Gateway routing generic | Every route is hand-written in `server.ts` (axios or scoped proxy). Each timeline endpoint = one gateway route + one rag-api route. |

## 3. Decisions locked by this plan

- **D1 — Ownership:** rag-api-service owns the timeline domain (endpoints, Firestore,
  derivation). api-gateway only gains thin proxy routes. agent-graph-service owns the
  planner LLM call. flashcard-service is reused as-is (except optional section-lookup
  convenience).
- **D2 — Derivation port:** port `derivation.ts` (+ its 34 table tests) to
  `rag-api-service/services/timeline_derivation.py`; port tests 1:1 as the acceptance
  criterion; **delete** the TS module + tests once green (git history preserves them).
  No client ever reimplements derivation (server-side single source of truth).
- **D3 — Storage:** `users/{u}/exams/{examId}` (fields: course_id, title, date,
  description, daily_capacity_pages, study_days_per_week) with subcollections
  `units/{unitId}`, `completions/{eventId}`. Sensing telemetry in
  `users/{u}/timelineActivity/{eventId}` (user-scoped, not exam-scoped: practice
  beacons originate from resources/sections, matched to units on read).
- **D4 — Flashcard linking is page-overlap lookup, not a new subsystem:** unit →
  overlapping sections (page range vs map) → existing cards by `section_id`;
  "generate" forwards overlapping `section_ids` to the existing flashcard-service
  endpoint. No new generation path.

## 4. Phases (each ends green: tests + lint/typecheck + card update)

**P1 — Derivation port (D2), with multi-currency baked in.** Not a pure 1:1 port
anymore: the TS prototype is pages-only; spec v2.4 adds the size abstraction
(pages | cards | work-item), normalized fraction-of-path pace for mixed paths,
and coarse (`covered: null`) completions. Port the 34 table tests, extend with
currency table tests (per-currency coverage, mixed-path normalization, card-unit
completion via coarse events). Keep the pure-module discipline. Delete the TS
module when green. *Anti-bloat enforced here.*

**P2 — Exam/unit/completion storage + CRUD + progress (D3).**
`models/exam.py`, `services/exam_service.py` in rag-api-service following the
resource_service pattern. Unit carries `currency` (derived from sources at
commit: page range | linked sections' cards | work-item) and `card_total`
snapshot for card units (re-snapshotted when decks grow). Endpoints: exam CRUD,
`PUT /path` (build-time commit only), `POST /completions` (idempotent, origin,
coarse or fine-grained), `POST /completions/:id/void`,
`GET /exams/:id/progress` (Python derivation; `previous_band` read from a small
cache/doc field server-side). Gateway routes for each. Skeleton lookup:
`GET /courses/:cid/skeletons` assembling existing maps via QueryResolver.

**P3 — Sensing.** `POST /timeline/activity` beacon (unit-link PDF opens);
suggestion engine derives from trailing ~48h window on read; confirm = existing
completions endpoint with `origin: confirmed_suggestion`. Card-practice beacons
match via section page ranges; exposure rule (≥80% of unit's cards practiced →
suggest) lives in the suggestion engine, never persisted.

**P4 — Path build.** agent-graph `POST /plan` (ordering/prioritization only, no
dates; JSON in/out); rag-api assembles skeleton input; student edits; commit via
`PUT /path`. Duplicate suggestion at build time (title similarity), student decides.

**P5 — Split editor ops.** Server-side structural ops (split/merge/rename/reweight/
fill-placeholder) with completion-carry semantics (page-overlap re-map, straddles
flagged, events append-only). Load-bearing UX — MVP-grade polish budget goes here.

**P6 — Unit↔flashcard linking (D4).** Overlap lookup endpoint + generate-forwarding.
Small. **Scope added 2026-08-26 (deviation D-1):** card-practice → unit matching and
the ≥80% exposure rule move here from P3; see Plan deviations.

**P7 — Crammer triage.** Progress states required pace > capacity; agent-graph trim
proposal (units marked cut, never deleted). Honest projection copy already falls out
of the derivation.

**P8 — Mobile UI.** Exam setup, path review/edit, progress view with confirmable
suggestions. Mirror-not-controller tone throughout.

Dependency order is P1→P2→{P3,P4}→P5→{P6,P7}→P8. P3/P4 are independent of each other.

## 5. Verification discipline

- Derivation: table tests stay 1:1 across the port; no behavior changes sneak in.
- Every phase: rag-api-service pytest suite + api-gateway `npm test` (when touched)
  + `tsc --noEmit` green before the next phase starts.
- Card status updates in `docs/task-management/04-timeline-feature.md` +
  `critical-tasks.md` sync per the task-management skill, at every phase boundary.
- Spec §5 stays the contract; this plan stays the sequence. If they conflict, fix
  one of them in the same commit — never let them drift.

## 6. Plan deviations

**D-1 (2026-08-26, maintainer-approved): P3 ships PDF-open sensing only; card-practice
matching moves to P6.** Rationale: card-currency units only exist after P4 path commits
and are only practiced via unit links built in P8 — the card signal has no emitter for
two more phases. Designing section-overlap linkage twice (rushed in P3, revised in P6)
is drift risk with no near-term payoff. Requirement captured: the ActivityLog beacon
schema records `resource_id` + `section_id` from day one, so card-practice beacons
stored now are matched retroactively when P6 lands — deferral is deferred
interpretation, not lost signal. The suggestion engine stays signal-agnostic: built as
activity → unit via page range, extended in P6 as activity → unit via section overlap.
