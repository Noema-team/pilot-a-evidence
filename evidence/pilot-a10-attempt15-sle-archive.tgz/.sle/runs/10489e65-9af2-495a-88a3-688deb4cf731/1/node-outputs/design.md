I've reviewed the worker's `process_document`/`classify_error`/`_publish_status_update`, rag-api's `run_transactional_update` failed branch, the `Resource` model, the existing contract-test patterns (`test_api_contracts.py` with AST/fixture/subprocess patterns), and both services' test stubbing conventions. The design below aligns the worker to rag-api's existing failed-branch contract with a single payload-construction seam, a stage tracker, `classify_error`-derived retryability, and a subprocess-isolated cross-service contract test.

<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path=".sle/work/wi-define-108-a8/design.md">>>
# Design — rag-worker → rag-api failure payload contract alignment

WorkItem: `wi-define-108-a8` (definition artifact `definition:obj-108`)
Step: design (requirements + architecture)
Charter: a failed RAG processing job must persist the worker's actual error message, the failing
pipeline stage, and a deliberately derived retryable flag — locked in by a contract test on the
worker→rag-api failure path.

---

## 1. Binding requirements (restated verbatim from the authoritative definition)

1. **R1 — payload completeness.** When document processing fails, the worker's failed status payload
   must include `error_message` (the actual exception message), `stage` (the pipeline stage
   executing at failure time), and `retryable` (deliberately derived) — the payload must never rely
   on rag-api's fallback defaults for these keys.
2. **R2 — stage tracking.** The worker must track the currently executing pipeline stage through
   `process_document` so the failure handler reports the true failing stage; stage names must reuse
   the existing progress-stage vocabulary (`starting`, `text_retrieved`, `tagging_complete`,
   `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the
   safe value when the stage is genuinely unknown.
3. **R3 — API persists unchanged.** rag-api's failed branch must persist the worker-provided values
   unchanged: main document `error` ← payload `error_message`, `error_stage` ← payload `stage`,
   `retryable` ← payload `retryable`; the `processing/summary` error subdocument must carry the
   same message and stage.
4. **R4 — explicit retryable derivation.** The retryable derivation must be explicit and aligned
   with the worker's ACK/NACK behavior: errors classified transient by `classify_error` →
   `retryable` true; classified permanent (including unclassified-unknown, per `classify_error`'s
   conservative default) → `retryable` false.
5. **R5 — contract test.** A contract test must cover the worker failure → rag-api persistence
   path: it must exercise the worker's failure-payload construction and rag-api's
   failed-branch persistence (via the Firestore emulator or fakes) and assert the persisted
   `error`, `error_stage`, and `retryable` equal the worker's values; it must fail if either
   side's payload keys drift.

### Constraints honored (from definition)

- Worker aligns to rag-api's contract; **no rag-api production-code changes**, no read changes.
- **No Firestore migration, rename, or backfill**; persisted fields stay `error` / `error_stage`
  / `retryable`.
- `retryable` always sent explicitly by the worker; rag-api's `details.get("retryable", True)`
  fallback must never be the operative mechanism for worker failures.
- Prefer: retain legacy `error` key alongside `error_message` (compatibility hedge, F11).
- Prefer not: no structured error-code taxonomy; `processing/summary.error.code` stays `"UNKNOWN"`.

---

## 2. Architecture overview

### 2.1 The canonical failure contract (single statement of truth)

The worker publishes, on the existing `rag-status-updates` topic envelope, a failed-status message
whose `details` object is:

```json
{
  "error_message": "<actual exception message>",
  "stage": "<pipeline stage executing at failure time>",
  "retryable": <bool, derived from classify_error>,
  "error": "<duplicate of error_message — legacy continuity key>"
}
```

rag-api's `run_transactional_update` failed branch (already in production, unchanged) maps:

| payload key      | main document field | processing/summary subdocument            |
|------------------|---------------------|-------------------------------------------|
| `error_message`  | `error`             | `error.message` (with `error.code` still defaulting `"UNKNOWN"`) |
| `stage`          | `error_stage`       | `error.stage`, and top-level `stage`      |
| `retryable`      | `retryable`         | —                                          |
| `error` (legacy) | ignored             | ignored                                    |

This contract is canonical and pinned in code by the docstring of the worker's
`build_failure_details` (§3.1) and enforced by the drift guards in §4.3.

### 2.2 Component touchpoints

| Component | File | Change |
|---|---|---|
| Worker payload builder | `apps/ai-server/rag-worker-service/main.py` | **New** module-level `build_failure_details(error, stage)` — the single construction site for the failure payload |
| Worker stage tracker | `apps/ai-server/rag-worker-service/main.py` | **New** `current_stage` local in `process_document`, set immediately before each pipeline step; read in the exception handler |
| Worker failure handler | `apps/ai-server/rag-worker-service/main.py` (`process_document` except block) | **Modified**: publishes `build_failure_details(e, current_stage)` instead of `{"error": str(e)}`; log line gains `stage`/`retryable` fields |
| Worker classification | `apps/ai-server/rag-worker-service/main.py` (`classify_error`) | **Unchanged** — reused as the retryable oracle |
| rag-api failed branch | `apps/ai-server/rag-api-service/main.py` (`run_transactional_update`) | **Unchanged** (R3 satisfied by construction; pinned by the contract test) |
| Worker unit tests | `apps/ai-server/rag-worker-service/tests/unit/test_failure_payload.py` | **New** |
| Cross-service contract test | `apps/ai-server/tests/integration/test_worker_failure_contract.py` + `_worker_failure_contract_harness.py` | **New** |

### 2.3 Data flow (failure path, after this change)

```
process_document step raises
        │
        ▼
except block reads current_stage (tracker)
        │
        ▼
build_failure_details(e, current_stage)
  ├─ error_message = str(e) or type(e).__name__   (§3.4)
  ├─ stage        = current_stage or "processing"
  ├─ retryable    = classify_error(e)             (§3.3 — same oracle as ACK/NACK)
  └─ error        = error_message                  (legacy hedge)
        │
        ▼
_publish_status_update(..., "failed", details, job_id)
  (envelope gains sequence/timestamp; details gains jobId when job_id present — §3.5)
        │
        ▼  Pub/Sub topic rag-status-updates
_process_status_message → run_transactional_update (UNCHANGED)
  ├─ main doc:  error ← error_message, error_stage ← stage, retryable ← retryable
  └─ summary:   stage ← stage, error{code:"UNKNOWN", message ← error_message, stage ← stage}
```

### 2.4 Why the worker aligns and not the API (recorded rationale, per F2/F6)

`error` / `error_stage` / `retryable` are the established persisted schema on three other write
paths (worker stale-lease sweep `_fail_if_still_stale`, rag-api's `/process` and
`POST /resources` enqueue-failure paths) and both read models (`ResourceResponse`,
`models/resource.py` `Resource`). The worker's status publisher is the only writer off-schema.
Changing the worker is therefore the zero-migration, zero-reader-change fix.

---

## 3. Detailed design

### 3.1 `build_failure_details` — the single seam

New module-level function in the worker's `main.py`, placed next to `classify_error`:

```python
FAILURE_STAGE_UNKNOWN = "processing"

def build_failure_details(error: Exception, stage: Optional[str]) -> Dict[str, Any]:
    """Build the failed-status payload for the worker → rag-api contract.

    Contract (pinned by tests/integration/test_worker_failure_contract.py):
      error_message — the actual exception message; never empty (falls back to the
                      exception type name so a persisted `error` is never blank).
      stage         — the pipeline stage executing at failure time, using the
                      progress-stage vocabulary; "processing" when genuinely unknown.
      retryable     — classify_error(error): transient → True, permanent/unknown → False.
                      Same oracle run_worker uses for ACK/NACK, so the persisted record
                      matches actual Pub/Sub redelivery behavior.
      error         — legacy duplicate of error_message, retained so any unknown
                      consumer of the status topic keeps working (compatibility hedge).
    """
    message = str(error).strip() or type(error).__name__
    return {
        "error_message": message,
        "stage": stage or FAILURE_STAGE_UNKNOWN,
        "retryable": classify_error(error),
        "error": message,
    }
```

Design properties:

- **One construction site.** Every worker-originated failure payload passes through this function;
  the contract test and unit tests both target it directly, so key drift is caught at the seam
  where it would be introduced.
- **Pure function.** No I/O, no processor state — trivially unit-testable and safe to call from the
  test harness without stubbing the processor.
- **Deliberately does NOT consult `exceptions.py`'s `PDFProcessingError.retryable` metadata.** F8
  pins the derivation to `classify_error(e)` alone. Those exception types are unrelated to the
  pipeline's `ProcessingError` hierarchy in `main.py`, are not raised on the current pipeline path,
  and honoring a second retryability oracle would reintroduce exactly the ambiguity this fix
  removes. Documented here as an explicit non-goal.

### 3.2 Stage tracker in `process_document`

A `current_stage` local, initialized to `FAILURE_STAGE_UNKNOWN` before the `try`, set immediately
before each pipeline step, read in the `except` handler:

```python
current_stage = FAILURE_STAGE_UNKNOWN
try:
    current_stage = "starting"
    await self._validate_processing_request(user_id, course_id, resource_id)
    await self._publish_status_update(..., {"stage": "starting"}, job_id)

    current_stage = "text_retrieved"
    text_content, doc_metadata = await self._get_extracted_text(...)

    current_stage = "tagging_complete"
    tags, confidence_scores = await self.content_tagger.generate_tags(...)

    current_stage = "summary_generated"
    summary_data = await self.generate_document_summary(...)
    # (the summary Firestore write + ragDescription update are inside this segment)

    current_stage = "chunking_complete"
    chunks = await self._create_enhanced_chunks(...)

    current_stage = "embeddings_complete"
    vectors = await self._generate_embeddings_with_openrouter(chunks)
    # (delete_old_vectors_via_service, store_chunks_via_service, metadata saves,
    #  resource map — all inside this final persistence segment)

    ...
except Exception as e:
    metrics.error_message, metrics.end_time = str(e), time.time()
    failure_details = build_failure_details(e, current_stage)
    self.logger.error("document_processing_failed", ..., error=failure_details["error_message"],
                      stage=failure_details["stage"], retryable=failure_details["retryable"])
    await self._publish_status_update(..., "failed", failure_details, job_id)
    ...
```

**Stage semantics (explicit decision).** `error_stage` names the *pipeline phase in which the
failure occurred*, using the phase's completion-marker vocabulary — i.e., the tracker is set to the
stage value that the in-flight step would publish on success. A failure inside
`_get_extracted_text` reports `"text_retrieved"` (text retrieval failed); a failure inside
`generate_tags` reports `"tagging_complete"` (tagging failed). This is more useful than the
alternative (mirroring the last *published* stage, which would report a tagging failure as
`"text_retrieved"` and send support to debug the wrong step), it uses only the sanctioned
vocabulary (R2), and `error_stage` never regresses to `None` or to a name absent from a successful
run's progress timeline.

**Segment granularity.** The convention is "set the tracker immediately before the await". Steps
between two publishes (e.g., the summary Firestore write inside the `summary_generated` segment;
vector deletion/storage inside `embeddings_complete`) inherit the enclosing segment's stage — no
new stage names are introduced, per R2's fixed vocabulary.

**`"processing"` fallback.** Reachable only defensively (e.g., a future pipeline step added without
updating the tracker at the very start, or a refactor that bypasses the assignments). It matches
the stale-lease sweep's `error_stage` value, so the field never reads as a special "unknown" case
to clients. Validation failures (`_validate_processing_request`) report `"starting"`: the tracker
is set before that call, and job startup is what failed.

**Post-embeddings persistence steps** (old-vector deletion, Weaviate storage, metadata saves)
report `"embeddings_complete"` — the phase whose progress marker (progress 80) clients already saw.
This is honest: the failure occurred in the persistence phase after embeddings completed, and
introducing a `"storage"` stage name would violate R2's fixed vocabulary.

**Drift risk (accepted, mitigated).** A future step added without a tracker assignment reports the
previous phase's stage — stale but never `None` and never off-vocabulary. Mitigation: the
contract test pins the mechanism on representative stages (§4.2: an early-stage and a late-stage
failure), which catches the tracker being removed or bypassed without ossifying every step.

### 3.3 `retryable` derivation semantics

`retryable = classify_error(e)` — exactly the oracle `run_worker` already uses for ACK/NACK:

| Exception class | `classify_error` | `retryable` | Consistency with delivery |
|---|---|---|---|
| `TransientError`, `httpx.ConnectError/ConnectTimeout/ReadTimeout/WriteTimeout/PoolTimeout`, `ConnectionError`, `TimeoutError`, `asyncio.TimeoutError` | transient | `True` | Pub/Sub will redeliver (NACK) |
| `httpx.HTTPStatusError` with 429/500/502/503/504 | transient | `True` | Pub/Sub will redeliver |
| `PermanentError`, other 4xx `HTTPStatusError` | permanent | `False` | Acked, no redelivery; manual reprocess via `POST /process` |
| Anything else (unknown: `ValueError`, `RuntimeError`, `PermissionError`, …) | permanent (conservative default) | `False` | Acked, no redelivery |

**Deliberate behavior change (accepted).** Unclassified-unknown exceptions previously persisted
`retryable: True` via rag-api's silent default while being *acked* as permanent — the persisted
record lied. They will now persist `False`, matching reality. This is the conservatism
`classify_error` was written for (prevents poison-pill retry loops); the manual reprocess path is
unaffected. Widening `classify_error` is out of scope.

**Unchanged on purpose.** The stale-lease sweep keeps its direct `retryable: True` write (a dead
worker is a transient condition by nature), and rag-api's `details.get("retryable", True)` default
stays in code for any future publisher — it simply stops being the operative mechanism for worker
failures, satisfying the constraint.

### 3.4 Error-message hardening

`str(e)` may be `""` for bare `raise Exception()`. Persisting an empty `error` is indistinguishable
from no message and would defeat the point of the fix, so `build_failure_details` falls back to
`type(e).__name__`. This is the only deviation from literal "the actual exception message" and it
exists to guarantee the acceptance invariant `error != "Processing failed"` is never vacuously
replaced by `error == ""`. Flagged here for reviewer visibility; the common case is unaffected.

### 3.5 Envelope interactions (no surprises for the test)

- `_publish_status_update` injects `details["jobId"] = job_id` when a job id is present. The
  published `details` for a real failure therefore carries the four contract keys **plus `jobId`**.
  rag-api ignores `jobId` on the failed branch. The contract test passes a `job_id` and pins the
  exact key set including `jobId` (§4.3), so the injection side effect is documented behavior, not
  a surprise.
- Envelope fields `sequence`, `timestamp`, `user_id`, `course_id`, `resource_id`, `status` are
  unchanged.
- The lease heartbeat write inside `_publish_status_update` is unchanged.

---

## 4. Test design

### 4.1 Worker unit tests — `rag-worker-service/tests/unit/test_failure_payload.py`

In-process (existing worker test conftest stubs apply). Covers:

1. **Derivation table (R4):** `TransientError`/`httpx.ConnectError` → `retryable is True`;
   `httpx.HTTPStatusError` (429 → True, 404 → False); `PermanentError`, `ValueError`,
   `PermissionError` → `False`. Pins the conservative unknown → `False` behavior change explicitly.
2. **Message hardening (§3.4):** `Exception("boom")` → `error_message == "boom"`;
   `Exception()` → `error_message == "Exception"`.
3. **Legacy hedge:** `details["error"] == details["error_message"]` always.
4. **Unknown stage (R2):** `build_failure_details(e, None)` → `stage == "processing"`.
5. **Stage tracker through the real `process_document`** (minimal processor built via
   `__new__`, fake publisher + fake db — same fakes as the harness, shared shape):
   - failure injected into `_get_extracted_text` (transient) → published `status == "failed"`,
     `stage == "text_retrieved"`, `retryable is True`;
   - failure injected into `_generate_embeddings_with_openrouter` (permanent) →
     `stage == "embeddings_complete"`, `retryable is False`;
   - failure injected into `_validate_processing_request` → `stage == "starting"`.
   These catch tracker removal/bypass at the earliest possible layer.

### 4.2 Cross-service contract test — `apps/ai-server/tests/integration/`

**Isolation: subprocess harness.** The two services both expose `main.py` and need *different*
dependency stub sets (worker: spacy/tiktoken/langchain/openai/langfuse/firebase stubs; api: fastapi
real, firebase mocked). In-process import would fight over `sys.modules` across the suite. The
house pattern for exactly this situation already exists — `_get_agent_graph_shapes()` in
`test_api_contracts.py` runs a script in a subprocess. Accordingly:

- `test_worker_failure_contract.py` (parent, in the existing integration suite) spawns
  `sys.executable` with `_worker_failure_contract_harness.py`, parses its JSON output, and makes
  all assertions. A harness crash (import failure, stub rot) fails the test loudly rather than
  silently skipping — no skip conditions.
- `_worker_failure_contract_harness.py` (child):
  1. Sets worker env defaults and installs the worker stub-module set — **extracted from
     `rag-worker-service/tests/conftest.py` into `tests/_testing_stubs.py::install_worker_stubs()`
     and called from both places**, so the two stub setups cannot drift (the same disease
     `test_shared_algorithms_in_sync.py` guards against).
  2. Imports worker `main.py` via `importlib.util.spec_from_file_location("rag_worker_main", ...)`
     and rag-api `main.py` as `rag_api_main` (api dir on `sys.path`), with
     `firebase_admin.firestore` stubbed to include `transactional` (identity), `SERVER_TIMESTAMP`,
     `Increment`, `ArrayUnion` — the minimal surface `run_transactional_update` touches.
  3. Builds a minimal `EnhancedDocumentProcessor` via `__new__` with fake `db` (in-memory
     dict-backed document refs supporting `get/update/set(merge)`/`collection().document()`),
     fake `pubsub_publisher` whose `publish()` records `(topic_path, data)` and returns a completed
     `concurrent.futures.Future` (the code path uses `asyncio.wrap_future`), `langfuse=None`, and a
     config namespace carrying `gcp_project`/`rag_status_topic`. Seed the fake store with a
     `status: "processing"` resource so the `processing → failed` transition passes
     `ALLOWED_TRANSITIONS` honestly.
  4. Runs **two scenarios end-to-end** through real production code:
     - **Early-stage / transient:** patch `_get_extracted_text` to raise
       `httpx.ConnectError("weaviate unreachable")` → expect `stage == "text_retrieved"`,
       `retryable == True`.
     - **Late-stage / permanent:** patch `_generate_embeddings_with_openrouter` to raise
       `ValueError("embedding input must not be empty")` → expect `stage == "embeddings_complete"`,
       `retryable == False`.
     Each scenario: decode the captured Pub/Sub envelope, assert `status == "failed"`, then feed
     the captured `details` **unmodified** into the real
     `rag_api_main.run_transactional_update(db, doc_ref, "failed", details, logger_shim, user_id)`
     against the fake Firestore, then read back the main document and `processing/summary`.
  5. Emits JSON: per-scenario worker payload (keys + values), persisted main-doc fields,
     persisted summary error subdocument.

**Assertions (parent tests):**

| Test | Asserts |
|---|---|
| `test_persisted_error_is_worker_message` | main doc `error == details["error_message"]` (both scenarios); explicitly `!= "Processing failed"` |
| `test_persisted_error_stage_is_worker_stage` | main doc `error_stage == details["stage"]` (both scenarios); explicitly `is not None` |
| `test_persisted_retryable_is_worker_derivation` | main doc `retryable == details["retryable"]`; scenario 1 `True`, scenario 2 `False` |
| `test_summary_error_subdocument_matches` | `processing/summary.error.message == error_message`, `.stage == stage`, `.code == "UNKNOWN"`; top-level summary `stage == stage` |
| `test_worker_payload_key_set_pinned` | captured `details` keys exactly `{"error_message", "stage", "retryable", "error", "jobId"}` |
| `test_api_failed_branch_reads_pinned_keys` | AST guard (house pattern): inside `run_transactional_update`, the `failed` branches read `error_message`, `stage`, `retryable` from `details` — deletion or rename of any read fails the build |
| `test_fallback_defaults_not_operative` | persisted `retryable` is a real `bool` sent by the worker (scenario 2 proves the `True` default was overridden) |

**Emulator note.** The definition permits "the Firestore emulator or fakes". Fakes are the default
(hermetic, no services, matches the existing integration suite's mock-based style). The fake only
replaces Firestore transport; both sides' real production logic — worker payload construction,
`classify_error`, `run_transactional_update`'s transition table, key mapping, and summary write —
executes for real, which is what R5 requires the test to exercise.

### 4.3 Drift-guard matrix (R5, "fail if either side's payload keys drift")

| Drift event | Caught by |
|---|---|
| Worker renames/removes `error_message`, `stage`, or `retryable` | `test_persisted_*` (rag-api falls back → persisted ≠ payload); `test_worker_payload_key_set_pinned` |
| Worker removes legacy `error` | `test_worker_payload_key_set_pinned` (exact key set) |
| Worker adds a new key | `test_worker_payload_key_set_pinned` (forces a deliberate contract decision) |
| rag-api renames a `details.get(...)` read | `test_persisted_*` (fallback values ≠ payload); `test_api_failed_branch_reads_pinned_keys` (AST) |
| rag-api deletes the failed-branch reads entirely | `test_persisted_*` + AST guard |
| Stage tracker removed/bypassed | unit stage-tracker tests + `test_persisted_error_stage_is_worker_stage` (would read `"processing"` for both scenarios) |
| `classify_error` semantics change | unit derivation table + `test_persisted_retryable_is_worker_derivation` |

---

## 5. Edge cases and failure modes

| Case | Behavior |
|---|---|
| Failure before first transition (`_validate_processing_request`) | `stage == "starting"`, real message persisted |
| Empty exception message | `error_message`/`error` = exception type name (§3.4) |
| Unclassified-unknown exception | `retryable == False` (deliberate change, matches ACK behavior) |
| `_publish_status_update` itself fails on the failure path | Pre-existing behavior: publish errors are logged (`status_publish_failed`), not raised — unchanged, out of scope |
| Stale-lease sweep failure write | Unchanged; already writes `error`/`error_stage: "processing"`/`retryable: True` consistent with this contract (non-goal to touch) |
| Legacy `error` consumers on the topic | Keep working — key retained with identical value (F11 hedge) |
| `processing/summary.error.code` | Remains `"UNKNOWN"` — no error-code taxonomy sent (prefer-not honored) |

---

## 6. Traceability

| Requirement | Design element | Test |
|---|---|---|
| R1 payload completeness | `build_failure_details` sets all three keys unconditionally | `test_worker_payload_key_set_pinned`, `test_persisted_*` |
| R2 stage tracking | `current_stage` tracker + fixed vocabulary + `"processing"` fallback | unit stage-tracker tests, `test_persisted_error_stage_is_worker_stage` |
| R3 API persists unchanged | No rag-api production change; mapping via existing failed branch | `test_persisted_*`, `test_summary_error_subdocument_matches`, AST guard |
| R4 retryable derivation | `retryable = classify_error(e)` in `build_failure_details` | unit derivation table, `test_persisted_retryable_is_worker_derivation` |
| R5 contract test | Subprocess harness + drift-guard matrix (§4.2–4.3) | the contract test itself |

Acceptance criteria mapping:

- **AC1** (published failure message carries the three keys, no fallback reliance) → §3.1/§3.5,
  verified by `test_worker_payload_key_set_pinned` + capture through the real code path.
- **AC2** (persisted `error`/`error_stage`/`retryable` equal worker values, not fallbacks) →
  `test_persisted_error_is_worker_message`, `test_persisted_error_stage_is_worker_stage`,
  `test_persisted_retryable_is_worker_derivation`.
- **AC3** (summary error subdocument carries same message and stage) →
  `test_summary_error_subdocument_matches`.
- **AC4** (contract test exists, passes, fails on drift on either side) → §4 test files +
  §4.3 matrix.

---

## 7. Risks and tradeoffs (from the charter, with mitigations)

- **Unknown consumers of the status topic** reading the old key set → mitigated by retaining
  `error`; residual risk accepted as low; dropping the duplicate later is trivial cleanup.
- **Stage-tracker drift as the pipeline evolves** → update-before-await convention documented at
  the tracker; representative-stage tests pin the mechanism without ossifying every step.
- **`retryable=False` for unrecognized-but-transient failures** reduces auto-retry affordances →
  accepted; matches actual ACK behavior (the record now tells the truth); manual reprocess via
  `POST /process` unaffected; widening `classify_error` explicitly out of scope.
- **Contract test ossifies the payload** → intentional; that is the drift guard. Adding a key
  later means touching `test_worker_payload_key_set_pinned` — a deliberate contract decision.
- **Subprocess harness weight** → slower than in-process unit tests but confined to one test
  module; pays for itself by eliminating cross-service `sys.modules` conflicts and reusing the
  established house pattern.
- **Stub-set duplication between worker conftest and harness** → mitigated by extracting
  `install_worker_stubs()` into a shared helper imported by both.

---

## 8. Out of scope (restated)

- Changing rag-api's reads, persisted schema, or response models; any Firestore migration/backfill.
- The stale-lease sweep's direct failure write (already contract-consistent).
- Retry/backoff mechanics: Pub/Sub ACK/NACK policy, leases, heartbeat intervals — only the
  *reporting* of retryability changes.
- Frontend/mobile changes — `ResourceResponse` already exposes `error`/`error_stage`.
- Structured error codes / failure taxonomy (`summary.error.code` stays `"UNKNOWN"`).
- Consulting `exceptions.py` `PDFProcessingError.retryable` metadata in the derivation (§3.1).
- Anything the companion D3 issue covers beyond this payload alignment (unavailable here;
  deferred), and reconciling with the missing `plans/upload-flow.md` D4 note.

---

## 9. Implementation and validation plan

Workflow fit (AGENTS.md): touches one service's production code plus the shared integration suite
and its tests; no schema/migration; no security; no CI-config or new runtime dependencies. The one
flagged criterion is "cross-client contract changes" — the rag-status topic is ai-server-internal
(only verified consumer: rag-api's subscriber; mobile/web read persisted fields via
`ResourceResponse`, which does not change). Recommendation: **small-change path**, branch
`fix/rag-worker-failure-payload-contract`, single PR to `main`; if review reads the topic as a
shared ai-server contract requiring the feature path, escalate per the escalation rule before
implementation.

Commits (logical units within the one PR):

1. **Worker failure payload + stage tracking** — `build_failure_details`, `current_stage` tracker,
   exception-handler rewiring, log fields; unit tests
   (`rag-worker-service/tests/unit/test_failure_payload.py`); extract
   `tests/_testing_stubs.py::install_worker_stubs()` (pure refactor, no behavior change).
2. **Contract test pinning the seam** —
   `tests/integration/_worker_failure_contract_harness.py` +
   `tests/integration/test_worker_failure_contract.py`.

Validation: `./dev/run ai-server` (service gates + suites) and `./dev/run integration`; additionally
run the new contract test module directly for a fast seam check. Pre-merge verification per the
definition's acceptance list: all four ACs demonstrated by the named tests in §6.
<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>