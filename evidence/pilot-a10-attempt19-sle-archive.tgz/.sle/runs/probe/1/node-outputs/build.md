{
  "kind": "step-failure-observation",
  "result_transport": "submit-result",
  "turns_taken": 2,
  "format_repairs": 1,
  "result_repairs": 0,
  "stop_reason": "end_turn",
  "text_length": 0,
  "tool_calls": [],
  "tool_uses": [],
  "error": "Agent reply carried no recognizable result block and format repair is exhausted (2 provider turn(s), 1 format-repair attempt(s)): the reply ended without a submit_result call — submit the complete semantic result through the submit_result tool"
}