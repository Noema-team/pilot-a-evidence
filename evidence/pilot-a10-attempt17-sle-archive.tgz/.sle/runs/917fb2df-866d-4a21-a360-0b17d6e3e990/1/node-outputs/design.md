<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path=".sle/work/wi-define-108-a8/design.md">>>
# Design — rag-worker → rag-api failure payload contract alignment

WorkItem: `wi-define-108-a8` (authoritative definition artifact `definition:obj-108`, sha256 `71f1c39c…`)
Step: design · Run `917fb2df-866d-4a21-a360-0b17d6e3e990` · Iteration 1

---

## 1. Summary

The rag-worker's failure publisher and rag-api's failure consumer speak different contracts. The worker's
`process_document` exception handler publishes `{"error": str(e)}`; rag-api's `run_transactional_update` failed
branch reads `error_message`, `stage`, and `retryable` and persists them as `error` / `error_stage` /
`retryable`. Every worker-originated failure therefore lands in Firestore as the fallback string
"Processing failed", a null stage, and a silently defaulted `retryable: true`.

The fix direction is fixed by the definition: **the worker aligns to rag-api** — no API-side changes, no
schema migration, no backfill. The worker (a) tracks the executing pipeline stage, (b) derives `retryable`
from its existing `classify_error()` classification (the same signal that drives ACK/NACK), and (c) publishes
the full contract payload. A contract test pins the worker→rag-api failure seam so key drift on either side
fails the build.

---

## 2. Evidence base

### 2.1 Authoritative (pinned by the definition — binding)

| Fact | Content |
|---|---|
| F3 | Worker publishes failed status with details `{"error": str(e)}` from `process_document`'s exception handler via `_publish_status_update`. |
| F4 | rag-api's failed branch (`run_transactional_update`) reads `error_message` / `stage` / `retryable`; persists `error` / `error_stage` / `retryable` on the main document; writes `message` / `stage` (with `error_code` defaulting to `"UNKNOWN"`) into the processing/summary subdocument. |
| F5 | Net effect today: `error` = "Processing failed", `error_stage` = None, `retryable` = silent default True. |
| F6 | `error` / `error_stage` / `retryable` is the established persisted schema — used by the worker's stale-lease sweep (`_fail_if_still_stale`), rag-api's enqueue-failure paths, `ResourceResponse`, and the `Resource` model. |
| F7 | Worker classifies exceptions via `classify_error()` (TransientError/PermanentError + type/status-code heuristics; unknown → permanent) and uses that for ACK/NACK in `run_worker`. |
| F8 (ASSUMED, adopted) | `retryable` derives from `classify_error(e)`: transient → true, permanent (incl. unknown) → false. |
| F9 | Worker publishes progress stages: `starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`, `completed`. No stage tracking exists in the failure handler today. |
| F10 | Contract-test infra exists at `apps/ai-server/tests/integration/test_api_contracts.py` (fixture- and AST-based static contract tests); both services have `FIRESTORE_EMULATOR_HOST` branches. |
| F11 (ASSUMED, adopted) | Retain legacy `error` key alongside `error_message` as a hedge for unknown status-topic consumers. |

### 2.2 Directly verified in the repository during investigation

- `apps/ai-server/rag-api-service/models/resource.py` — `Resource` carries `error: Optional[str]`,
  `error_stage: Optional[str]`, `retryable: bool = True`; both `to_dict()` and `from_dict()` include all three
  (`from_dict` defaults `retryable` to True when absent). No other failure fields exist.
- `apps/ai-server/rag-worker-service/exceptions.py` — `PDFProcessingError(message, resource_id=None,
  retryable=False)` carries `retryable` as **metadata**; subclasses: `PDFExtractionError`,
  `MarkdownConversionError`, `ChunkingError`, `EmbeddingError`, `WeaviateStorageError`. Docstring states the
  central retry DECISION lives in `RetryHandler.is_retryable_error`, which does **not** read this field.
- `apps/ai-server/rag-worker-service/utils/retry_handler.py` — `RetryHandler.is_retryable_error(error,
  error_code=None)` (in-process retry-loop classifier, ErrorCode-based + message heuristics);
  `RetryConfig.RETRYABLE_ERROR_CODES` over `ErrorCode` from `models.processing_status`.
- CI wiring — `.github/scripts/ci-detect-changes.sh` (read in full):
  - `UNIT_SERVICES` **includes** `rag-worker-service`; `INTEGRATION_SERVICES` **excludes** it.
  - The cross-service job runs when `apps/ai-server/tests/`, `rag-api-service/`, **or**
    `rag-worker-service/` changes, and installs exactly **rag-api-service and agent-graph-service**.
- Both services' `pytest.ini`: `testpaths = tests`, `asyncio_mode = auto`.
- Requirements: rag-api installs `firebase-admin`, `google-cloud-pubsub`, `structlog`, `pytest`,
  `pytest-asyncio`; the worker additionally installs the heavy ML stack (`marker-pdf`, `spacy`,
  `transformers`, `openai`, …) and `pytest-mock`.
- Shared integration suite contains `conftest.py`, `test_api_contracts.py`, `test_chat_pipeline.py`,
  `test_search_pipeline.py`, `test_shared_algorithms_in_sync.py` (dynamic cross-service tests are established
  practice there). Worker suite has `conftest.py` + populated `tests/unit/`; `tests/integration/` is empty
  except `__init__.py`.

### 2.3 Unknowns preserved (not invented)

The full bodies of `rag-worker-service/main.py` and `rag-api-service/main.py` were not retained line-by-line
in this session; their behavior is taken from the definition's pinned claims (§2.1). The following must be
confirmed against current code during implementation and are flagged where they matter:

- U1 — exact signature/return shape of `classify_error` and the definition location of
  `TransientError` / `PermanentError` (somewhere in the worker; **not** in `exceptions.py`, which was read in
  full and contains only the `PDFProcessingError` family).
- U2 — exact signature of `_publish_status_update` and of `run_transactional_update` (message/document
  shapes), and whether rag-api's fallbacks are `.get(key, default)` (missing-key only) or `or`-coercion
  (also triggered by empty strings) — affects the empty-message edge case (§8).
- U3 — module-level import graph of both `main.py` files (drives contract-test import strategy, §6.2).
- U4 — exact AST/fixture conventions inside `test_api_contracts.py` (to be matched, not reinvented).

---

## 3. Requirements (binding, from the definition)

- **R1** — The worker's failed status payload must include `error_message` (actual exception message),
  `stage` (pipeline stage executing at failure time), and `retryable` (deliberately derived). The payload
  must never rely on rag-api's fallback defaults for these keys.
- **R2** — The worker must track the currently executing pipeline stage through `process_document`; stage
  names reuse the existing progress vocabulary (`starting`, `text_retrieved`, `tagging_complete`,
  `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the safe value
  when the stage is genuinely unknown.
- **R3** — rag-api's failed branch persists worker-provided values unchanged: `error` ← `error_message`,
  `error_stage` ← `stage`, `retryable` ← `retryable`; the processing/summary error subdocument carries the
  same message and stage. (No rag-api code changes.)
- **R4** — `retryable` derivation is explicit and aligned with ACK/NACK behavior: `classify_error` transient
  → true; permanent (including unclassified-unknown, its conservative default) → false.
- **R5** — A contract test must cover worker failure → rag-api persistence: exercise the worker's
  failure-payload construction and rag-api's failed-branch persistence (Firestore emulator or fakes), assert
  persisted `error` / `error_stage` / `retryable` equal the worker's values, and fail if either side's payload
  keys drift.

Constraints honored by this design: worker aligns to API (must); no migration/rename/backfill (must_not);
fallback never operative for worker failures (must); retain legacy `error` key (prefer); no error-code
taxonomy (prefer_not).

---

## 4. Architecture

### 4.1 The wire contract (single source of truth)

Worker → status topic → rag-api subscriber → `run_transactional_update` failed branch:

```
worker failure payload (details)         rag-api persistence (unchanged)
┌───────────────────────────────┐        ┌──────────────────────────────────────────┐
│ "error":        <str(e)>      │ legacy │ main doc:                                │
│ "error_message":<str(e)>      │  ─────► │   error       ← details["error_message"] │
│ "stage":        <stage>       │        │   error_stage ← details["stage"]         │
│ "retryable":    <bool>        │        │   retryable   ← details["retryable"]     │
└───────────────────────────────┘        │ processing/summary error subdoc:         │
                                         │   message ← details["error_message"]     │
                                         │   stage   ← details["stage"]             │
                                         │   error_code ← "UNKNOWN" (no code sent)  │
                                         └──────────────────────────────────────────┘
```

Contract key set (exact): `{"error", "error_message", "stage", "retryable"}`. The status value, topic,
message envelope, and publish mechanism are unchanged — only the `details` keys change.

### 4.2 Worker changes

#### 4.2.1 New light module: `utils/error_classification.py`

Move `TransientError`, `PermanentError`, and `classify_error` **verbatim** from `main.py` into
`apps/ai-server/rag-worker-service/utils/error_classification.py` (behavior-preserving relocation; `main.py`
imports them back so every existing reference — including `run_worker`'s ACK/NACK call site and any test
monkeypatching — keeps working). This is the minimal enabling refactor for R5: it makes the classification
importable without pulling `main.py`'s heavy module-level import graph (Pub/Sub client, processing pipeline,
ML libraries — U3).

*Implementation note:* confirm current definitions/locations first (U1). If `classify_error` turns out to
already live in a light module, skip the move and import from there. The move must not change any
classification outcome — `run_worker`'s ACK/NACK behavior is untouched.

#### 4.2.2 New light module: `utils/failure_payload.py`

```python
"""Failure status payload construction for the rag-worker.

Single seam where the worker's failure contract is built. Imported by
main.py's process_document exception handler and by the cross-service
contract test (apps/ai-server/tests/integration) — keep imports light
(stdlib + utils.error_classification only).
"""
from utils.error_classification import classify_error  # shape per U1

# Exact wire contract consumed by rag-api's run_transactional_update
# failed branch. Changing this set requires changing that branch and
# the contract test together.
FAILURE_PAYLOAD_CONTRACT_KEYS = frozenset(
    {"error", "error_message", "stage", "retryable"}
)

# Safe stage value when the failing stage is genuinely unknown; same
# value the stale-lease sweep uses for error_stage, so the persisted
# field never regresses to null.
UNKNOWN_STAGE = "processing"


def build_failure_details(exception: Exception, stage: str | None) -> dict:
    """Build the failed-status details payload.

    retryable is derived from classify_error — the same classification
    that drives ACK/NACK in run_worker — so the persisted record tells
    the truth about whether Pub/Sub will redeliver:
      transient-classified  -> True  (NACK; Pub/Sub redelivers)
      permanent/unknown     -> False (acked; manual reprocess via POST /process)
    The legacy "error" key is retained alongside "error_message" as a
    hedge for unknown consumers of the status topic (definition F11).
    """
    message = str(exception)
    retryable = _is_transient(exception)
    return {
        "error": message,          # legacy key — retained deliberately
        "error_message": message,  # rag-api contract
        "stage": stage or UNKNOWN_STAGE,
        "retryable": retryable,
    }


def _is_transient(exception: Exception) -> bool:
    """Map classify_error's verdict to the wire boolean (shape per U1)."""
    classification = classify_error(exception)
    return classification == TRANSIENT  # adapt to actual return type
```

Deliberate decisions baked in here:

- **`classify_error` is the only derivation source.** The worker contains two other retryability notions —
  `PDFProcessingError.retryable` (metadata, default False, verified in `exceptions.py`) and
  `RetryHandler.is_retryable_error` (in-process retry-loop classifier, verified in
  `utils/retry_handler.py`). Neither is the ACK/NACK signal; wiring either in would create a second,
  competing notion of retryability. Rejected alternatives — recorded so the implementer doesn't reach for
  them.
- **Empty/None stage coerces to `"processing"`**, never null (R2).
- **`str(e)` is passed through as-is** — "the actual exception message" (R1). No wrapping, no stage
  interpolation into the message.

#### 4.2.3 `main.py` — stage tracking in `process_document`

`process_document` is one large `try` block (definition/direction). Add a local stage tracker and the
update-before-await convention:

```python
def process_document(...):
    current_stage = UNKNOWN_STAGE          # safe value until first assignment
    try:
        _publish_status_update(..., stage="starting", ...)   # unchanged progress publish
        current_stage = "starting"
        <initial load step>                                # await
        current_stage = "text_retrieved"                   # set immediately BEFORE the await
        text = await <text extraction>
        _publish_status_update(..., "text_retrieved", ...)  # unchanged
        current_stage = "tagging_complete"
        ...
        current_stage = "embeddings_complete"
        ...
        _publish_status_update(..., "completed", ...)       # unchanged
    except Exception as e:
        details = build_failure_details(e, current_stage)
        _publish_status_update(..., status="failed", details=details, ...)  # same call shape as today
        ...
```

Convention (this is the drift guard against future pipeline steps): **assign the tracker immediately before
each pipeline step's `await`, using the progress-vocabulary name of the milestone that step produces**
(extraction → `text_retrieved`, tagging → `tagging_complete`, summarization → `summary_generated`,
chunking → `chunking_complete`, embedding → `embeddings_complete`; the initial phase → `starting`). The
tracker's initial value is `"processing"`, covering failure before the first assignment. The exact per-step
assignment list is finalized against the real `process_document` body at implementation time (the body was
not retained line-by-line in this session; the vocabulary itself is pinned by F9). The contract test pins an
early-stage and a late-stage failure with distinct, accurate stages, which catches the tracker being removed
or bypassed without ossifying every step.

The exception handler shrinks to: build payload via `build_failure_details(e, current_stage)`, publish with
the same status value / topic / envelope as today, log the details dict (structlog) for operator visibility.
No other handler logic changes.

#### 4.2.4 Worker unit test: `tests/unit/test_failure_payload.py`

The worker's unit leg runs in CI (verified: `rag-worker-service` ∈ `UNIT_SERVICES`). Cover:

- transient-classified exception → `retryable is True`; permanent-classified → `False`;
  unclassified-unknown exception → `False` (conservative default — pins the deliberate behavior change);
- `error_message` equals `str(e)` exactly; legacy `error` key present and equal;
- `stage=None` / `""` → `"processing"`; provided stage passes through;
- exact key set: `set(payload) == FAILURE_PAYLOAD_CONTRACT_KEYS` (add/remove of any key fails).

### 4.3 rag-api changes

**None.** R3 is satisfied by the existing failed branch once the worker speaks its contract. The
`details.get(...)` fallbacks remain in the code as defense for non-worker publishers, but for worker
failures they are dead paths (R1: never the operative mechanism). Persisted field names, semantics, the
`Resource` model, `ResourceResponse`, and the `"UNKNOWN"` error-code default are all untouched.

### 4.4 Compatibility hedge (F11)

The legacy `error` key is retained in every failure payload — one redundant string per failure message as
insurance for unverified consumers of the shared status topic (only rag-api's subscriber is a *verified*
consumer). Cost: negligible. Dropping it later, if an audit confirms rag-api is the only consumer, is
trivial cleanup and explicitly out of scope here.

---

## 5. Deliberate behavior change (must be visible in review)

Unclassified-unknown exceptions currently persist `retryable: true` (rag-api's silent default) but classify
as **permanent** under `classify_error`. After this change they persist `retryable: false`. This is the
conservatism `classify_error` was written for — it prevents infinite retry loops — and the manual reprocess
path (`POST /process`) is unaffected. The stale-lease sweep's separate direct write keeps
`retryable: true`, which stays correct: a worker dying mid-extraction is a transient condition by nature
(sweep unchanged, per non-goals). No data backfill for already-persisted failed documents (constraint:
must_not migrate/backfill).

---

## 6. Contract test design (R5)

### 6.1 Placement and CI wiring (verified facts)

New file: **`apps/ai-server/tests/integration/test_rag_failure_payload_contract.py`** in the shared suite.

- The cross-service CI job triggers on changes to `apps/ai-server/tests/`, `rag-api-service/`, **or**
  `rag-worker-service/` (verified in `ci-detect-changes.sh`) — so edits to either service always re-run the
  contract suite. This is precisely the seam being pinned.
- The cross job installs rag-api-service and agent-graph-service **only** (verified). It does **not**
  install the worker's heavy ML stack. Therefore the worker-side import used by this test must be
  dependency-light — which is why §4.2.1/§4.2.2 extract `classify_error` and the payload builder into
  `utils/` modules rather than importing worker `main.py` (U3). Importing rag-api's `run_transactional_update`
  from its `main.py` is supported: rag-api is installed in that environment.
- Placing the test inside `rag-worker-service/tests/` was rejected: the worker has **no** integration CI leg
  (verified: worker ∉ `INTEGRATION_SERVICES`), so an emulator-based test there would not guard drift in CI.

### 6.2 Test structure

Follow the house patterns in `test_api_contracts.py` (match its fixture/AST conventions at implementation
time — U4) and the existing emulator/fake conventions in the shared `conftest.py` (skip behavior when the
Firestore emulator is unavailable, mirroring how existing tests handle `FIRESTORE_EMULATOR_HOST`).

**Dynamic round-trip (the contract):**

1. *Worker side* — build the failure payload through the worker's real construction path:
   `build_failure_details(exception, stage)` from `rag-worker-service/utils/failure_payload.py` (the same
   function the production exception handler calls — not a restated fixture).
2. *API side* — feed that payload through rag-api's failed branch: call `run_transactional_update` with the
   failed-status payload shape against the Firestore emulator, or in-memory fakes of the
   transaction/update path when the emulator is unavailable (both modes supported per F10).
3. *Assertions* — persisted main document: `error == payload["error_message"]`,
   `error_stage == payload["stage"]`, `retryable == payload["retryable"]`; processing/summary error
   subdocument: `message` and `stage` equal the same values. Adapt call shapes to the real
   `run_transactional_update` signature (U2); the *asserted contract* is fixed.

**Cases:**

| Case | Exception | Stage at failure | Expected persisted |
|---|---|---|---|
| Early-stage transient failure | `TransientError("bucket unavailable")` (or the worker's actual transient type, U1) | early vocabulary stage (e.g. `text_retrieved`) | `error` = message, `error_stage` = stage, `retryable = True` |
| Late-stage permanent failure | `PermanentError(...)` (or actual type) | late vocabulary stage (e.g. `embeddings_complete`) | `error` = message, `error_stage` = stage, `retryable = False` |
| Unclassified unknown | generic `RuntimeError("boom")` | stage where raised | `retryable = False` (conservative default — pins §5) |
| Unknown stage | any | `None` | `error_stage = "processing"` (never null) |
| Subdocument parity | any | any | subdoc `message`/`stage` == main doc values |

**Drift guards (the point of the test):**

- *Dynamic key-set guard:* `set(payload.keys()) == FAILURE_PAYLOAD_CONTRACT_KEYS` — importing the constant
  from the worker module means the test and the producer share one definition; any key added or removed on
  the worker side fails here.
- *Static AST guard (house pattern, zero-dependency — runs even where imports can't):* `ast.parse` both
  `main.py` files as text and assert (a) the worker's failure publisher emits the contract keys / routes
  through `build_failure_details`, and (b) rag-api's failed branch reads `error_message`, `stage`,
  `retryable` from `details`. This catches rag-api-side key drift even though rag-api is unchanged today —
  the seam is pinned from both directions, and a future edit to either side's keys fails the build instead
  of silently re-creating this bug.

The test intentionally ossifies the payload: adding a key later means touching this test. That is the drift
guard doing its job.

---

## 7. Data flow after the fix

```
process_document step N raises e
  └─ except Exception as e:
       details = build_failure_details(e, current_stage)
       #  {"error": msg, "error_message": msg, "stage": stage, "retryable": transient?}
       └─ _publish_status_update(status="failed", details=details)     [unchanged envelope]
            └─ Pub/Sub status topic
                 └─ rag-api status subscriber (unchanged)
                      └─ run_transactional_update failed branch (unchanged)
                           ├─ main doc:   error=msg, error_stage=stage, retryable=derived
                           └─ subdoc:     message=msg, stage=stage, error_code="UNKNOWN"
                                └─ ResourceResponse exposes error/error_stage to clients (unchanged)

ACK/NACK in run_worker (unchanged): classify_error(e) transient → NACK (redelivery);
permanent/unknown → ACK. Persisted retryable now mirrors this exactly.
```

---

## 8. Edge cases

- **Empty exception message** (`str(e) == ""`): payload carries `error_message: ""`. If rag-api's fallback
  is `.get(key, default)` (missing-key only — U2), the empty string persists as-is (truthful). If it is
  `or`-coercion, the fallback string appears. Do not "fix" this in the builder by inventing a message;
  record which semantics rag-api uses during implementation and accept the outcome — the requirement is
  that the *keys* are always present, which they are.
- **Failure before the first tracker assignment**: stage = `"processing"` (initializer), never null.
- **Repeated failure across redeliveries**: each attempt publishes its own failed status; last write wins in
  rag-api — unchanged behavior.
- **`PDFProcessingError` subclasses** (e.g. `EmbeddingError`, which carries `retryable=False` metadata):
  classified by `classify_error` like any other exception; the metadata field is deliberately ignored
  (§4.2.2).
- **Non-Exception / control-flow exits**: the handler catches `Exception` exactly as today; no change.

---

## 9. Explicitly out of scope (from the definition — restated to guard scope)

- Stale-lease sweep behavior (already writes `error`/`error_stage`/`retryable` consistently).
- Retry/backoff mechanics: Pub/Sub ACK/NACK policy, leases, heartbeats — only the *reporting* of
  retryability changes.
- Frontend/mobile — `ResourceResponse` already exposes `error`/`error_stage`.
- Structured error codes / failure taxonomy — subdoc `error.code` stays `"UNKNOWN"` unless a code is
  actually sent (none is).
- Anything the companion D3 issue covers beyond this payload alignment (content unavailable here;
  deferred), and reconciling with the D4 deviation note in `plans/upload-flow.md` (file not present in the
  current tree; reference exists only in the Objective text).
- Dropping the legacy `error` key (future cleanup after a consumer audit).
- Widening `classify_error`'s heuristics.

---

## 10. Risks and mitigations

| Risk | Mitigation |
|---|---|
| Unknown consumers of the status topic read the old key set | Legacy `error` key retained (F11); residual risk accepted as low. |
| Stage-tracker drift as the pipeline evolves | Update-before-await convention documented in code; contract test pins early + late representative stages. |
| `retryable=false` for genuinely-transient-but-unrecognized failures reduces auto-retry affordances | Accepted per F8 rationale; manual reprocess via `POST /process` unaffected; widening `classify_error` is out of scope. |
| Contract test ossifies the payload | Intentional — it is the drift guard; adding a key means touching the test. |
| Worker `main.py` not importable in the cross CI job (heavy deps not installed there — verified) | Payload builder + classifier live in dependency-light `utils/` modules; static AST guard runs with zero imports. |
| `classify_error` move (§4.2.1) accidentally changes classification | Verbatim relocation, `main.py` re-imports preserve all references; worker unit tests + ACK/NACK behavior unchanged; confirm current definitions first (U1). |
| rag-api fallback semantics (`or`-coercion vs `.get`) affects empty-message edge | Verification point U2; outcome accepted either way (§8); keys are always present regardless. |

Process note: this change spans two services plus the shared test suite, so it exceeds the repo's
small-change criteria (AGENTS.md); it proceeds under the cycle's branch/PR workflow, with the cross-service
CI job as the validating gate for the contract.

---

## 11. Acceptance criteria → design mapping

| Acceptance (definition) | Satisfied by |
|---|---|
| Worker's failed status message contains `error_message`, `stage`, `retryable` — none relying on rag-api fallbacks | `build_failure_details` (§4.2.2) + handler wiring (§4.2.3); pinned by worker unit test + contract test key-set guard |
| Persisted `error` = actual message (not "Processing failed"), `error_stage` = failing stage (not None), `retryable` = derived value | rag-api failed branch consumes the now-correct keys (§4.3); asserted by dynamic round-trip cases (§6.2) |
| Processing/summary error subdocument carries same message and stage | Subdoc-parity case (§6.2); rag-api behavior unchanged (F4) |
| Contract test exists, passes, exercises construction → persistence, fails on key drift on either side | §6: shared-suite test, dynamic round-trip + dynamic key-set guard + static AST guard; CI trigger verified for both services |

---

## 12. Implementation checklist (files touched)

| File | Change |
|---|---|
| `apps/ai-server/rag-worker-service/utils/error_classification.py` | **new** — `TransientError`, `PermanentError`, `classify_error` moved verbatim from `main.py` (U1) |
| `apps/ai-server/rag-worker-service/utils/failure_payload.py` | **new** — `FAILURE_PAYLOAD_CONTRACT_KEYS`, `UNKNOWN_STAGE`, `build_failure_details` |
| `apps/ai-server/rag-worker-service/main.py` | stage tracker in `process_document` (update-before-await); exception handler builds payload via `build_failure_details`; imports classification from new module (re-export for compatibility) |
| `apps/ai-server/rag-worker-service/tests/unit/test_failure_payload.py` | **new** — derivation mapping, legacy key, stage fallback, exact key set |
| `apps/ai-server/tests/integration/test_rag_failure_payload_contract.py` | **new** — dynamic round-trip (emulator/fakes) + key-set guard + static AST drift guard, following `test_api_contracts.py` conventions (U4) |
| rag-api service | **no changes** |

Validation: worker unit leg (`pytest`, `asyncio_mode=auto`), rag-api unit leg, and the cross-service
contract job locally where possible (`./dev/run ai-server` requires Docker Compose up, per AGENTS.md).

---

## 13. Open items requiring implementation-time verification

Carried from §2.3 — resolve against current code before/while implementing; none block the design:

1. U1 — exact `classify_error` signature/return and `TransientError`/`PermanentError` definition site;
   adapt `_is_transient`'s comparison accordingly.
2. U2 — `_publish_status_update` and `run_transactional_update` signatures; rag-api fallback coercion
   semantics (`.get(key, default)` vs `or`).
3. U3 — module-level import graphs of both `main.py` files; confirms the light-module strategy and the
   static-guard necessity.
4. U4 — exact fixture/AST/skip conventions in `test_api_contracts.py` and the shared `conftest.py`; the new
   test must match them.
5. Exact per-step stage-assignment list in `process_document`, finalized against the real function body
   under the update-before-await convention (§4.2.3).
<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>