# Implementation Plan — rag-worker → rag-api failure payload contract alignment

Run: 58232065-c773-4179-bfbd-de9348344b7e · Iteration 1 · Step: plan
Authoritative scope: WorkItem `wi-define-108-a8` (definition artifact `definition:obj-108`, sha256 `71f1c39c…`). Everything below implements exactly that Definition; no scope is added or dropped.

---

## 1. Problem (verified)

The worker→rag-api failure seam was written against two different contracts and nothing tests it:

| Layer | What it does today (verified) |
|---|---|
| Worker `process_document` exception handler (`apps/ai-server/rag-worker-service/main.py`) | Publishes failed status with `details = {"error": str(e)}` via `_publish_status_update` (Definition F3) |
| rag-api failed branch (`run_transactional_update`, `apps/ai-server/rag-api-service/main.py`) | Reads `details.get("error_message", "Processing failed")`, `details.get("stage")`, `details.get("retryable", True)`; persists `error` / `error_stage` / `retryable` on the main doc, and writes `error = {code: details.get("error_code", "UNKNOWN"), message, stage}` plus top-level `stage` into `processing/summary` (Definition F4) |

Net effect (F5): every worker-originated failure persists `error = "Processing failed"`, `error_stage = None`, `retryable = True` (fabricated default). The `processing/summary` error subdocument inherits the same fallbacks with `error_code` always `"UNKNOWN"`.

The persisted schema `error` / `error_stage` / `retryable` is already spoken by three other write paths (worker stale-lease sweep `_fail_if_still_stale`, rag-api `POST /process` and `POST /resources` enqueue-failure paths) and by both read models (`Resource` dataclass in `rag-api-service/models/resource.py`, `ResourceResponse` in rag-api `main.py`). **The worker's status publisher is the only writer that doesn't speak the schema — so the worker aligns to the API, not the reverse.** No migration, no rename, no backfill, no reader changes.

Additional verified constraint: the worker already classifies every exception via `classify_error()` (TransientError/PermanentError + type/status-code heuristics; unknown → permanent) and uses that classification for ACK/NACK in `run_worker` (F7). The failure handler has no stage tracking today (F9); progress updates already use the stage vocabulary `starting, text_retrieved, tagging_complete, summary_generated, chunking_complete, embeddings_complete, completed`.

## 2. The pinned contract

After this change, the worker's failed-status `details` payload contains exactly:

| Key | Value | rag-api consumption (unchanged code) |
|---|---|---|
| `error_message` | `str(e)` (guarded, see D1) | → main doc `error`; → summary `error.message` |
| `stage` | failing pipeline stage (tracker, see D2) | → main doc `error_stage`; → summary `error.stage` and summary `stage` |
| `retryable` | `classify_error(e)` (see D3) | → main doc `retryable` |
| `error` | `str(e)` — legacy key retained (see D4) | not read by rag-api; hedge for unknown topic consumers |

The `processing/summary` `error.code` stays `"UNKNOWN"` (no structured error taxonomy — non-goal).

## 3. Design decisions

### D1 — Extract a pure failure-payload helper (worker)
Add a module-level function in `rag-worker-service/main.py`, placed next to `classify_error`:

```python
def build_failure_details(exc: Exception, stage: Optional[str] = None) -> Dict[str, Any]:
    """Contract payload for a failed job, aligned with rag-api's failed branch.

    Keys (pinned by tests/integration contract test):
      error_message — actual exception message (rag-api persists it as `error`)
      stage         — failing pipeline stage (rag-api persists it as `error_stage`)
      retryable     — derived from classify_error (transient=True, permanent/unknown=False)
      error         — legacy duplicate of error_message, retained for unknown
                      consumers of the status topic (Definition F11 hedge)
    """
    message = str(exc) or exc.__class__.__name__
    return {
        "error_message": message,
        "stage": stage if stage else "processing",
        "retryable": bool(classify_error(exc)),
        "error": message,
    }
```

Rationale for the `str(exc) or exc.__class__.__name__` guard: some exceptions stringify to `""`; persisting an empty `error` would be worse than the fabricated fallback for support disambiguation. The class name is actual information about the failure. This is a micro-hardening inside the spirit of "the worker's actual error message", not a new behavior.

The helper is pure (no I/O) so the contract test can exercise the worker's real payload construction without importing Pub/Sub or Firestore machinery.

### D2 — Stage tracker in `process_document` (worker)
- Declare `current_stage: str = "starting"` immediately before the main `try` block.
- Convention: **set `current_stage = "<token>"` immediately before the `await` of each named pipeline phase**, where `<token>` is the progress-stage name that phase's completion update already uses (`text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`). Semantics: the tracker holds the phase in flight, named by its progress-completion token — so a failure during tagging reports `tagging_complete`, reading naturally next to the progress timeline clients already see.
- Auxiliary awaits (heartbeat, lease renewal, old-vector cleanup after the last named phase) do **not** touch the tracker; the tracker simply keeps its last value, which stays truthful ("failure after the embeddings phase").
- The exception handler passes `current_stage` to `build_failure_details(e, current_stage)`.
- Fallback: the helper normalizes a falsy stage to `"processing"` — the same safe value the stale-lease sweep uses for `error_stage`, so `error_stage` never regresses to `None`.

Drift risk (a future pipeline step added without updating the tracker) is mitigated by the update-before-await convention plus representative-stage contract coverage (early and late failure — see test plan), not by ossifying every step.

### D3 — retryable derived, never defaulted (worker)
`retryable = classify_error(e)` — the same function that drives ACK/NACK in `run_worker`:
- transient-classified → `True` (Pub/Sub will redeliver);
- permanent-classified, including unclassified-unknown per `classify_error`'s conservative default → `False` (acked; manual reprocess via `POST /process` remains).

Deliberate behavior change: unclassified-unknown exceptions previously persisted `retryable: true` (rag-api's silent default) and will now persist `false`. That is the conservatism `classify_error` was written for; accepted per Definition F8.

### D4 — Legacy `error` key retained (worker)
The payload carries `error` alongside `error_message` (one redundant string per failure message) as insurance for unverified consumers of the `rag-status-updates` topic and existing log tooling (F11). Dropping it later is trivial cleanup after a consumer audit.

### D5 — rag-api: zero code changes
`run_transactional_update`'s failed branch already reads exactly `error_message` / `stage` / `retryable` and persists them unchanged into `error` / `error_stage` / `retryable` and the summary error subdocument (verified in source). The contract is locked by the new test, not by edits. The `details.get(...)` fallbacks remain in the API for non-worker writers; for worker failures they are no longer operative (constraint: must not be the operative mechanism).

### D6 — Stale-lease sweep untouched
`_fail_if_still_stale` already writes `error` / `error_stage="processing"` / `retryable=True` directly and consistently with this contract; a dead worker is a transient condition. Non-goal.

## 4. File change plan

### 4.1 `apps/ai-server/rag-worker-service/main.py` (only production file changed)
1. Add `build_failure_details(exc, stage=None)` near `classify_error` (D1).
2. In `process_document`: add the `current_stage` tracker (D2) — init `"starting"` before the `try`; assign before each named-phase await.
3. In the `process_document` exception handler: replace `details={"error": str(e)}` with `details=build_failure_details(e, current_stage)` in the failed `_publish_status_update` call. Envelope (user_id/course_id/resource_id/status) unchanged.
4. No changes to `classify_error`, `run_worker`, `_fail_if_still_stale`, `_publish_status_update` signature, retry/ACK mechanics, or leases.

### 4.2 `apps/ai-server/tests/integration/test_worker_failure_contract.py` (new)
Cross-service contract test — worker payload construction → rag-api failed-branch persistence with fakes. See `docs/test-plan.md` Suite A for the full specification. Self-contained stubbing at the top of the file (worker deps are stubbed locally, not in the shared conftest, to avoid perturbing existing contract tests); worker `main.py` is loaded via `importlib` under a distinct module name to avoid the `main` name collision with rag-api's module already imported by the suite conftest.

### 4.3 `apps/ai-server/rag-worker-service/tests/integration/test_failure_stage_tracking.py` (new)
Worker-local tests that the tracker reports the true failing stage through the real `process_document` handler with stubbed pipeline steps. See test plan Suite B.

### 4.4 Not changed
`rag-api-service/main.py`, `rag-api-service/models/resource.py`, the stale-lease sweep, Pub/Sub ACK/NACK policy, leases/heartbeats, frontend/mobile, contract fixtures in `tests/fixtures/api-contracts/`.

## 5. Behavior changes & compatibility

- Persisted worker failures change from (`"Processing failed"`, `None`, `True`) to (actual message, actual stage, derived flag). This is the fix.
- `retryable` for unclassified-unknown errors flips `True → False` (D3) — accepted, documented here and in the Definition (F8).
- Unknown topic consumers keep working via the retained `error` key (D4).
- No Firestore migration/backfill; field names and semantics unchanged (constraint honored).
- `summary.error.code` remains `"UNKNOWN"` (no taxonomy — prefer-not honored).

## 6. Out of scope (non-goals, restated from Definition)

- Stale-lease sweep behavior; retry/backoff mechanics (ACK/NACK policy, leases, heartbeats) — only the *reporting* of retryability changes.
- Structured error codes / failure taxonomy.
- Frontend or mobile changes (`ResourceResponse` already exposes `error` / `error_stage`).
- Anything the companion D3 issue covers beyond this payload alignment (content unavailable here; deferred), and reconciling with the D4 deviation note in `plans/upload-flow.md` (file absent from tree).

## 7. Risks & mitigations

| Risk | Mitigation |
|---|---|
| Unknown consumers of the status topic read the old key set | Retain legacy `error` key (D4); residual risk accepted as low |
| Stage-tracker drift as pipeline evolves | Update-before-await convention; representative early/late-stage tests (Suite B) |
| `retryable=false` for genuinely transient-but-unrecognized failures | Accepted; widening `classify_error` is out of scope; `POST /process` manual reprocess unaffected |
| Contract test ossifies the payload | Intentional — it is the drift guard; adding a key means touching the test |
| Worker `main.py` import weight in the integration suite (heavy third-party deps; module name collides with rag-api's `main`) | Load via `importlib` under a distinct name; stub heavy deps locally in the new test file (mirroring `rag-worker-service/tests/conftest.py`'s stub map); no shared-conftest edits. If module-level side effects surface at import, stubs are extended additively — verified at implementation time |
| `firestore.transactional` is a MagicMock in the integration conftest, so calling `run_transactional_update` unpatched would no-op | Patch `rag_api_main.firestore.transactional` to an identity decorator and `SERVER_TIMESTAMP` to a sentinel per test — the exact pattern already proven in `rag-worker-service/tests/unit/test_processing_lease.py` (`_tx_identity`) |

## 8. Implementation order & verification gates

1. **Worker helper** — add `build_failure_details`; unit-check it in isolation (pure function). Gate: `pytest rag-worker-service` still green.
2. **Stage tracker + handler wiring** — tracker assignments before each named-phase await; handler calls the helper. Gate: worker unit suite green.
3. **Suite B** (worker tracker tests) — proves stage/retryable/message through the real handler. Gate: new tests pass.
4. **Suite A** (cross-service contract test) — worker helper output fed through real `run_transactional_update` with fakes. Gate: new tests pass; existing `tests/integration/test_api_contracts.py` untouched and green.
5. **Full verification** — run all three suites (commands in test plan). Gate: all green; acceptance map below fully covered.

## 9. Acceptance criteria mapping

| Acceptance (Definition) | Covered by |
|---|---|
| Failed status payload carries `error_message` / `stage` / `retryable`, none relying on API fallbacks | D1–D3; Suite A TC-A1/TC-A2/TC-A4; Suite B TC-B1–B4 |
| Persisted `error` = actual message (not "Processing failed"), `error_stage` = failing stage (not None), `retryable` = derived | Suite A TC-A1, TC-A2, TC-A3 |
| Summary error subdocument carries same message and stage | Suite A TC-A1 (asserts summary `error.message`, `error.stage`, `code == "UNKNOWN"`) |
| Contract test exists, passes, exercises worker construction → rag-api persistence, fails on key drift on either side | Suite A TC-A1 + TC-A5 (worker key-set equality) + persisted-equality assertions (API read drift) |