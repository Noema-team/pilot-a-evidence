Design is settled from the verified evidence: the worker's `process_document` exception handler (verified at `rag-worker-service/main.py` ~L1092–1096) publishes only `{"error": str(e)}` while rag-api's failed branch reads `error_message`/`stage`/`retryable` (definition F4, binding); the fix is a stage tracker initialized before the try block, a failure-payload constructor that derives `retryable` from the existing `classify_error()` (verified logic: TransientError/connect-timeout/429-5xx → transient; PermanentError/other-4xx/unknown → permanent), retention of the legacy `error` key, zero rag-api production changes, and a contract test in the existing `tests/integration/` house pattern that imports both sides (worker module import needs a harness — verified import-time side effects: `GCP_PROJECT` KeyError, credentials guard, subscriber construction) and pins key sets against drift.

One verified mechanics nuance is documented honestly: `process_document` swallows pipeline exceptions and returns normally, so `run_worker`'s ACK/NACK branch governs only pre-pipeline errors; the persisted `retryable` reports the `classify_error` verdict as the definition adopts (F8), with no ACK/NACK mechanics touched (non-goal).

<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path="docs/requirements.md">>>
# Requirements — rag-worker → rag-api failure payload contract alignment

- Run: 58232065-c773-4179-bfbd-de9348344b7e (iteration 1, step: design)
- Authoritative source: Definition artifact `definition:obj-108` (WorkItem `wi-define-108-a8`, sha256 `71f1c39c97ecea575b1195b63de510fa403dad4fecaa1df0c774d04fae89cac5`). Binding; not widened, narrowed, or reinterpreted below.
- Evidence marks: **[V]** = directly verified in repository this cycle; **[D]** = pinned by the authoritative Definition (facts F1–F12).

## 1. Problem statement

A failed RAG processing job loses the worker's actual error information. The worker's exception handler in `process_document` publishes a failed status with details `{"error": str(e)}` **[V]**; rag-api's failed branch reads `error_message`, `stage`, and `retryable` from details **[D, F4]** and persists `error`/`error_stage`/`retryable` on the main resource document plus `message`/`stage` (with `error_code` defaulting to `"UNKNOWN"`) into the `processing/summary` subdocument **[D, F4]**. Because of the key mismatch, every worker-originated failure persists `error = "Processing failed"` (fallback), `error_stage = None`, and `retryable = True` (silent default) **[D, F5]**. The established persisted failure schema is `error`/`error_stage`/`retryable`: the worker's stale-lease sweep writes it directly (`error_stage: "processing"`, `retryable: True`) **[V]**, rag-api's enqueue-failure paths write it **[D, F6]**, and the `Resource` model exposes it (`retryable` defaults `True`) **[V]**. The worker's status publisher is the only writer that does not speak it.

## 2. Scope

In scope:
- Worker failure-payload construction in `process_document`'s exception handler.
- Stage tracking through `process_document` so the failing stage is reported.
- Deliberate derivation of `retryable` from the worker's existing `classify_error()`.
- A contract test covering the worker failure → rag-api persistence path, with key-drift guards.

Out of scope (non-goals, from the Definition):
- Changing the stale-lease sweep's direct failure write (already consistent) **[V]**.
- Changing retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals — only the *reporting* of retryability changes.
- Frontend or mobile changes (`ResourceResponse` already exposes `error`/`error_stage`) **[D, F6]**.
- Introducing structured error codes or a failure taxonomy (`processing/summary` `error.code` remains `"UNKNOWN"` unless a code is actually sent).
- Anything the companion D3 issue covers beyond this worker→rag-api payload alignment (its content is unavailable here; deferred), and reconciling this analysis with the D4 deviation note in `plans/upload-flow.md` (file not present in the current tree).

## 3. Functional requirements

### FR-1 (must) — Failure payload keys
When document processing fails, the worker's failed status payload must include:
- `error_message` — the actual exception message (`str(e)`),
- `stage` — the pipeline stage executing at failure time,
- `retryable` — deliberately derived (FR-4).

The payload must never rely on rag-api's fallback defaults for these keys. (Definition requirement 1; facts F1, F3, F4.)

### FR-2 (must) — Stage tracking and stage vocabulary
The worker must track the currently executing pipeline stage through `process_document` so the failure handler reports the true failing stage. Stage names must reuse the existing progress-stage vocabulary **[V — exact strings verified in `process_document`'s `_publish_status_update` calls]**:

| Stage value | Pipeline step it labels |
|---|---|
| `starting` | request validation / start of processing |
| `text_retrieved` | text extraction/retrieval |
| `tagging_complete` | content tagging and analysis |
| `summary_generated` | summary generation + document update |
| `chunking_complete` | chunk creation |
| `embeddings_complete` | embedding generation |

`"processing"` is the safe value when the stage is genuinely unknown (e.g., failure before the first transition); it matches the stale-lease sweep's `error_stage` value **[V]**, so `error_stage` never regresses to null. (Definition requirement 2; fact F9.)

### FR-3 (must) — rag-api passthrough persistence
rag-api's failed branch must persist the worker-provided values unchanged:
- main document: `error` ← payload `error_message`; `error_stage` ← payload `stage`; `retryable` ← payload `retryable`;
- `processing/summary` error subdocument: same message and stage as the main document.

No changes to rag-api's reads or persisted schema; no Firestore migration, field rename, or backfill. (Definition requirement 3; facts F2, F4, F6; constraint must / must_not.)

### FR-4 (must) — Deliberate retryable derivation
The worker sets `retryable` from `classify_error(e)` **[V — verified classification logic]**:
- classified transient → `retryable: true`;
- classified permanent, including unclassified-unknown (classify_error's conservative default) → `retryable: false`.

Binding mapping **[V]**:

| Exception | classify_error verdict | retryable |
|---|---|---|
| `TransientError` | transient | `true` |
| `PermanentError` | permanent | `false` |
| `httpx.ConnectError/ConnectTimeout/ReadTimeout/WriteTimeout/PoolTimeout`, `ConnectionError`, `TimeoutError`, `asyncio.TimeoutError` | transient | `true` |
| `httpx.HTTPStatusError` with status 429, 500, 502, 503, 504 | transient | `true` |
| `httpx.HTTPStatusError` with other 4xx | permanent | `false` |
| any other (unclassified-unknown) | permanent (conservative) | `false` |

Accepted behavior change: unclassified-unknown exceptions previously persisted `retryable: true` via the silent default and will now persist `false` — this is the conservatism `classify_error` was written for; manual reprocess via `POST /process` is unaffected. (Definition requirement 4; facts F7, F8.)

### FR-5 (must) — Contract test with drift guard
A contract test must cover the worker failure → rag-api persistence path. It must:
- exercise the worker's failure-payload construction and rag-api's failed-branch persistence (via the Firestore emulator or fakes);
- assert the persisted `error`, `error_stage`, and `retryable` equal the worker's values;
- assert the `processing/summary` error subdocument carries the same message and stage;
- fail if either side's payload keys drift (see architecture §4.4 for the guard mechanism). (Definition requirement 5; facts F10.)

### FR-6 (prefer) — Legacy key retention
The worker retains the legacy `error` key alongside `error_message` in the failure payload, for continuity with any existing consumers of the status topic and log tooling. (Definition constraint prefer; fact F11.)

## 4. Constraints (from the Definition, binding)

- **must** — The worker is aligned to rag-api's existing contract (`error_message`/`stage`/`retryable`); rag-api's reads and persisted schema are not changed.
- **must_not** — No Firestore migration, field rename, or backfill of existing documents; persisted fields (`error`, `error_stage`, `retryable`) keep their names and semantics.
- **must** — Every worker-originated failure payload carries `retryable` explicitly; rag-api's `details.get("retryable", True)` fallback must not be the operative mechanism for worker failures.
- **prefer** — Retain the legacy `error` key in the worker's failure payload alongside `error_message`.
- **prefer_not** — Do not introduce a structured error-code taxonomy (`error_code` values).

## 5. Acceptance criteria

- **AC-1** — A failed job's status message published by the worker contains `error_message` (actual exception message), `stage` (failing pipeline stage), and `retryable` (deliberately derived) — none relying on rag-api's fallback defaults. *Verified by: FR-5 contract test, worker-side payload assertions.*
- **AC-2** — After a failed job, the persisted resource document has `error` = the worker's actual error message (not `"Processing failed"`), `error_stage` = the failing stage (not None), and `retryable` = the worker's derived value. *Verified by: FR-5 contract test, main-document assertions.*
- **AC-3** — The `processing/summary` error subdocument for the failed job carries the same message and stage as the main document. *Verified by: FR-5 contract test, subdocument assertions.*
- **AC-4** — A contract test covering the worker failure → rag-api persistence path exists and passes, exercising the worker's failure-payload construction through rag-api's failed-branch persistence and asserting persisted `error`/`error_stage`/`retryable` equal the worker's values, failing if either side's payload keys drift. *Verified by: FR-5.*

## 6. Traceability

| Requirement | Facts | Acceptance |
|---|---|---|
| FR-1 | F1, F3, F4 | AC-1 |
| FR-2 | F9 | AC-1, AC-2 |
| FR-3 | F2, F4, F6 | AC-2, AC-3 |
| FR-4 | F7, F8 | AC-1, AC-2 |
| FR-5 | F10 | AC-4 |
| FR-6 | F11 | (hedge; not acceptance-gated) |

## 7. Deferred / open

- Companion D3 issue referenced by the Objective: content unavailable in this context; anything beyond the worker→rag-api payload alignment is deferred (F12).
- Reconciliation with the D4 deviation note in `plans/upload-flow.md`: file not present in the current tree; deferred.
- Dropping the legacy `error` key after a consumer audit confirms rag-api is the only subscriber: future cleanup, explicitly out of scope now (F11).
<<<END-SLE-ARTIFACT>>>
<<<SLE-ARTIFACT path="docs/architecture.md">>>
# Architecture — rag-worker → rag-api failure payload contract alignment

- Run: 58232065-c773-4179-bfbd-de9348344b7e (iteration 1, step: design)
- Companion document: `docs/requirements.md` (FR-1…FR-6, AC-1…AC-4).
- Evidence marks: **[V]** = directly verified this cycle; **[D]** = pinned by the authoritative Definition.

## 1. Context and seam

```
rag-worker                              rag-api
process_document                        status subscriber
  │ exception handler                     │
  ▼                                       ▼
_publish_status_update ── Pub/Sub ──▶ run_transactional_update
  (status topic, JSON)   rag-status     (failed branch)
                                          │
                                          ▼
                                    Firestore
                                      ├─ main resource doc:
                                      │    error / error_stage / retryable
                                      └─ processing/summary subdoc:
                                           message / stage / error_code
```

The seam is untested today: the worker writes one key (`error`), rag-api reads three (`error_message`, `stage`, `retryable`) **[V / D, F4]**. The worker is the odd writer out — three other write paths (stale-lease sweep **[V]**, rag-api enqueue-failure paths **[D, F6]**, `Resource` model defaults **[V]**) already use the persisted schema — so the worker aligns to the API. No migration, no reader changes.

## 2. Verified current behavior

| # | Behavior | Evidence |
|---|---|---|
| 2.1 | `process_document` is one large `try`; its `except` handler sets `metrics.error_message`, logs, and publishes `"failed"` with details `{"error": str(e)}`; no stage tracking exists | **[V]** rag-worker-service/main.py ~L946–1096 |
| 2.2 | Progress updates publish stages `starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`, then `completed` | **[V]** same file |
| 2.3 | `_publish_status_update` injects `details["jobId"]` only when `job_id` is provided, adds `timestamp`/`sequence`, resets sequence on terminal states, and heartbeats the lease | **[V]** ~L1540–1610 |
| 2.4 | `classify_error(e)`: `TransientError`→True; `PermanentError`→False; httpx connect/timeout family, `ConnectionError`, `TimeoutError`, `asyncio.TimeoutError`→True; `HTTPStatusError` 429/500/502/503/504→True; other 4xx→False; unknown→False (conservative) | **[V]** ~L39–78 |
| 2.5 | `process_document` swallows all pipeline exceptions and returns normally; `run_worker` acks after `process_fn` returns. `run_worker`'s `classify_error` ACK/NACK branch governs exceptions raised *outside* `process_document` (message decode, claim, regenerate-map) | **[V]** ~L1090–1096, ~L2075–2105 |
| 2.6 | Stale-lease sweep (`_fail_if_still_stale`) writes `status:"failed"`, `error:"processing lease expired…"`, `error_stage:"processing"`, `retryable:True` transactionally | **[V]** ~L2160–2185 |
| 2.7 | `Resource` model: `error: Optional[str]`, `error_stage: Optional[str]`, `retryable: bool = True`; serialized in `to_dict`/`from_dict` | **[V]** rag-api-service/models/resource.py |
| 2.8 | rag-api failed branch reads `error_message`/`stage`/`retryable`; persists `error`/`error_stage`/`retryable` on the main doc; writes `message`/`stage` with `error_code` default `"UNKNOWN"` into `processing/summary` | **[D, F4]** |
| 2.9 | Worker supports hermetic Firestore-emulator mode (`FIRESTORE_EMULATOR_HOST` → `initialize_app` with projectId); rag-api has the equivalent branch | **[V]** worker `_init_services` / **[D, F10]** API |
| 2.10 | Worker `main.py` has import-time side effects: `GCP_PROJECT = os.environ["GCP_PROJECT"]` (KeyError if unset), `GOOGLE_APPLICATION_CREDENTIALS` guard raising RuntimeError, service-account credential load, `SubscriberClient` construction | **[V]** ~L1779–1800 |
| 2.11 | Contract-test house patterns exist: `tests/integration/test_api_contracts.py` imports `main as rag_api_main` and uses fixture- and AST/subprocess-based static extraction for modules that cannot be imported directly | **[V]** |

## 3. Target design

### 3.1 Stage tracker (FR-2)

A local `current_stage` in `process_document`:

- Initialized to `"processing"` **before** the `try` block, so the `except` handler can always read it and early failures never regress `error_stage` to null.
- Set **immediately before the `await` of each pipeline step**, to the stage label whose completion that step publishes (convention: "set the tracker immediately before the await"). A failure during a step therefore reports the step that was in flight.

| Tracker set to | Immediately before |
|---|---|
| `"processing"` | (initialization, before `try`) |
| `"starting"` | `_validate_processing_request` + first status publish |
| `"text_retrieved"` | `_get_extracted_text` |
| `"tagging_complete"` | `content_tagger.generate_tags` |
| `"summary_generated"` | `generate_document_summary` + document update |
| `"chunking_complete"` | `_create_enhanced_chunks` |
| `"embeddings_complete"` | `_generate_embeddings_with_openrouter` |

Steps without a dedicated vocabulary label (old-vector deletion, chunk storage — both after the `embeddings_complete` publish) inherit the last set value; no new stage names are introduced. Post-completion tail steps (`_update_user_usage`, `_generate_resource_map`) swallow their own exceptions internally **[V]**, so they cannot produce a failure payload.

### 3.2 Failure payload construction (FR-1, FR-6)

The `except` block builds the payload explicitly:

```python
failure_details = {
    "error": str(e),                 # legacy key retained (FR-6 hedge)
    "error_message": str(e),         # contract key read by rag-api
    "stage": current_stage,          # contract key
    "retryable": classify_error(e),  # deliberate derivation (FR-4)
}
await self._publish_status_update(..., "failed", failure_details, job_id)
```

`retryable = classify_error(e)` directly: the function returns True for transient, False for permanent (verified mapping, §2.4 / requirements FR-4 table). `metrics.error_message` assignment, logging, and trace update are unchanged. `_publish_status_update` continues to inject `jobId` when a job id exists — that injection is downstream of the failure contract and out of the constructor's key set.

**Mechanics note (verified, §2.5):** because `process_document` swallows pipeline exceptions, the message is acked after a handled pipeline failure regardless of classification; `run_worker`'s ACK/NACK branch applies to pre-pipeline errors. The persisted `retryable` therefore reports the `classify_error` verdict of the failure — the Definition's adopted derivation (F8). No ACK/NACK, lease, or heartbeat mechanics change (non-goal).

**Derivation placement:** the exception object is only in scope inside `process_document`'s `except` block (§2.5), so the derivation must live there.

**Testability extraction (recommended):** move the pure failure-payload logic — `TransientError`, `PermanentError`, `classify_error`, and a new module-level pure `build_failure_details(e: Exception, stage: str) -> dict` (which calls `classify_error` internally) — into a side-effect-free module in the worker service (e.g., `rag-worker-service/utils/` or alongside the existing `exceptions.py`, whose contents were not inspected this cycle; exact path is the implementer's choice). `main.py` imports the names so all existing call sites (`run_worker`, `process_document`) are unchanged. This lets the contract test import the real logic directly. Fallback if relocation is deemed too invasive: keep everything in `main.py` and import it inside a subprocess harness with stubbed env and patched credentials (§4.2, option B) — the verified house pattern for non-importable modules.

### 3.3 rag-api side (FR-3)

No production code changes. The failed branch continues to read `error_message`/`stage`/`retryable` and persist unchanged values **[D, F4]**:

| Worker failure-details key | rag-api read | Main doc field | processing/summary |
|---|---|---|---|
| `error_message` | `details["error_message"]` | `error` | `error.message` |
| `stage` | `details["stage"]` | `error_stage` | `error.stage` |
| `retryable` | `details["retryable"]` | `retryable` | — |
| `error` (legacy) | not read | — | — |
| *(key absent)* | fallbacks | `"Processing failed"` / `None` / `True` | must not be operative for worker failures |

No `error_code` is sent, so the subdoc's `error.code` stays `"UNKNOWN"` (prefer_not on a taxonomy).

### 3.4 End-to-end failed-job sequence

1. `run_worker` claims the resource (`status: "processing"`); message processing begins.
2. `current_stage` advances with each pipeline step; progress updates publish as today.
3. An exception propagates to `process_document`'s handler.
4. The handler builds `failure_details` (§3.2) with the true stage and derived retryable.
5. `_publish_status_update` publishes `status:"failed"` (adding `jobId`/`sequence`, heartbeating the lease, resetting the sequence counter) — unchanged mechanics.
6. rag-api's subscriber invokes `run_transactional_update`; the failed branch persists `error`/`error_stage`/`retryable` on the main doc and `message`/`stage` (code `"UNKNOWN"`) on `processing/summary` **[D, F4]**.
7. `run_worker` acks (§3.2 mechanics note). The stale-lease sweep is untouched; its direct write already matches this contract (§2.6).

### 3.5 Compatibility hedges

- Legacy `error` key retained in the payload (FR-6): one redundant string per failure as insurance for unknown consumers of the shared status topic; dropping it later is trivial cleanup after a consumer audit (F11).
- Sequence numbers, timestamps, lease heartbeat, and `jobId` injection are unchanged.
- Persisted field names and semantics unchanged; existing documents need no backfill.

## 4. Contract test architecture (FR-5, AC-4)

### 4.1 Location and pattern
New module in `apps/ai-server/tests/integration/` (e.g., `test_worker_failure_contract.py`), following the verified house patterns in `test_api_contracts.py` (direct import of `main as rag_api_main`; fixture- and AST/subprocess-based static checks). Extending `test_api_contracts.py` itself is acceptable if preferred.

### 4.2 Import strategy for the worker side
The worker's `main.py` cannot be imported unconfigured (§2.10: env KeyError, credentials guard, subscriber construction). Options:

- **Option A (recommended, with §3.2 extraction):** the test imports the new side-effect-free module (`classify_error` + `build_failure_details`) directly — no env stubs, no subprocess.
- **Option B (fallback):** subprocess harness mirroring `_get_agent_graph_shapes` **[V]**: a child script stubs `GCP_PROJECT`/`GOOGLE_APPLICATION_CREDENTIALS`, patches `service_account.Credentials.from_service_account_file` (and, if needed, `pubsub_v1.SubscriberClient`) before importing the worker module, calls `build_failure_details` with representative exceptions, and prints JSON.

Either way, the test must exercise the **real** worker code (`build_failure_details` + `classify_error`) and the **real** rag-api failed branch — never a restated fixture.

### 4.3 Test flow and assertions
1. Build failure payloads via the worker's construction path for representative cases:
   - early-stage failure: tracker at `"text_retrieved"`;
   - late-stage failure: tracker at `"embeddings_complete"`;
   - one transient-classified exception (e.g., `httpx.ConnectTimeout` or `TransientError`) → `retryable: true`;
   - one permanent-classified exception (e.g., `ValueError`, unclassified-unknown) → `retryable: false`.
2. Feed each payload through rag-api's failed-branch persistence (`run_transactional_update` **[D, F4]**, or the subscriber entry that wraps it — exact signature confirmed at build time) against the Firestore emulator (`FIRESTORE_EMULATOR_HOST`; worker branch verified §2.9, API branch per F10) or fakes.
3. Assert on the persisted main document: `error == payload["error_message"]`, `error_stage == payload["stage"]`, `retryable == payload["retryable"]` (AC-2).
4. Assert on `processing/summary`: error message and stage equal the main document's (AC-3).

### 4.4 Drift guards
- **Worker-side key-set guard:** `set(build_failure_details(...).keys()) == {"error", "error_message", "stage", "retryable"}` exactly (constructed at the payload-constructor boundary; `jobId` is injected downstream by `_publish_status_update` and is out of scope — drive with `job_id=None` if going through the publish path).
- **API-side read-key guard:** AST/static scan of rag-api's failed branch pinning the read key literals to `{"error_message", "stage", "retryable"}` (house AST pattern, §2.11), optionally reinforced behaviorally by an absent-key probe (omit a key and observe the fallback).
- Any future key addition or rename on either side fails the build — intentional ossification; that is the drift guard doing its job.

### 4.5 Hermeticity
Emulator mode exists in both services (§2.9); fake-based persistence is the acceptable fallback where the emulator is unavailable in CI. No network egress is required by the contract under test.

## 5. Risks and tradeoffs

- **Unknown consumers of the status topic** reading the old key set — mitigated by retaining `error`; residual risk accepted as low (F11).
- **Stage-tracker drift** as the pipeline evolves — mitigated by the update-before-await convention and representative early/late-stage test coverage; a step added without updating the tracker reports the previous stage, which the convention documents.
- **`retryable: false` for unclassified-unknown errors** reduces auto-retry affordances for genuinely transient-but-unrecognized failures — accepted per F8; widening `classify_error` is out of scope; manual reprocess via `POST /process` remains.
- **Contract test ossifies the payload** — intentional; adding a key later means touching the test, which is the point.
- **Worker module import hazard in tests** — mitigated by the side-effect-free extraction (Option A) or the subprocess harness (Option B), both grounded in verified patterns (§2.10–2.11).

## 6. Out of scope

Stale-lease sweep behavior; ACK/NACK policy, leases, heartbeats; frontend/mobile; structured error codes; companion D3 issue content; `plans/upload-flow.md` D4 reconciliation (file absent from the tree).

## 7. Implementation checklist (files touched)

| File | Change |
|---|---|
| `apps/ai-server/rag-worker-service/main.py` | Stage tracker init + per-step sets; `except` block builds `failure_details` via `build_failure_details`; import of extracted names if Option A |
| new side-effect-free worker module (path per §3.2) | `TransientError`/`PermanentError`/`classify_error`/`build_failure_details` (Option A) |
| `apps/ai-server/tests/integration/test_worker_failure_contract.py` (new) | Contract test + drift guards (§4) |
| rag-api production code, models, frontend | **None** |
<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>