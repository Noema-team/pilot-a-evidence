# Task Management

This folder is the project's task board. It replaces Trello and lives in Markdown.

## Before reading or writing tasks

Check the repo-root `AGENTS.md` workflow first; task-only edits qualify as
small changes (`docs/<slug>` branch, single PR).

## How to navigate

1. Read `critical-tasks.md` first — it lists all active and critical tasks with pointers to their files.
2. Use `map.md` to find the full list of task files.
3. Open the specific task file to read or update a task.

## Folder structure

```
task-management/
├── README.md            ← you are here
├── map.md               ← index of all task files
├── critical-tasks.md    ← pointers to active and critical tasks
├── 01-ai-processing.md  ← AI & document processing tasks
├── 02-frontend-backend.md ← frontend ↔ backend integration tasks
├── 03-app-ui-ux.md      ← app UI/UX tasks
├── 04-timeline-feature.md ← timeline feature tasks
├── 05-testing-qa.md     ← testing & QA tasks
├── 06-business.md       ← business tasks (compliance, legal)
├── 07-feature-backlog.md ← feature ideas and backlog
└── 08-infrastructure-devops.md ← infrastructure & DevOps tasks
```

## Card format

```
# Task title
#StatusTag
Description (1–3 sentences). [[Link to doc if needed]].

---
```

## Status tags

- `#ToDo` — not started
- `#Planning` — in planning with AI
- `#InProgress` — actively being worked on
- `#Done` — completed
- `#Blocked` — waiting on something external
