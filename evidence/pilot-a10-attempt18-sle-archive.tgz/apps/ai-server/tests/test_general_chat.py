#!/usr/bin/env python3
"""
Test script for General Chat functionality
Demonstrates the expected behavior when course_id is not provided
"""

import asyncio
import json
import sys


def test_api_gateway_payloads():
    """
    Test examples of API payloads for general chat mode
    These demonstrate what the client should send
    """

    print("=== API Gateway Payload Examples ===")

    # General chat payload (no course_id)
    general_payload = {
        "query": "What is artificial intelligence?",
        "response_mode": "streaming",
        "inputs": {},  # No course_id - triggers general mode
    }

    print("\n1. General Chat Payload (no course_id):")
    print(json.dumps(general_payload, indent=2))

    # Explicit general mode
    explicit_general = {
        "query": "How do I study better?",
        "response_mode": "streaming",
        "inputs": {
            "course_id": None  # Explicitly null
        },
    }

    print("\n2. Explicit General Mode (course_id: null):")
    print(json.dumps(explicit_general, indent=2))

    # Course-specific payload (existing functionality)
    course_payload = {
        "query": "What topics are covered in CS101?",
        "response_mode": "streaming",
        "inputs": {
            "course_id": "course-123"  # Specific course
        },
    }

    print("\n3. Course-Specific Payload (existing):")
    print(json.dumps(course_payload, indent=2))

    return True


def test_expected_behaviors():
    """
    Document the expected behaviors for each mode
    """

    print("\n=== Expected Behaviors ===")

    behaviors = [
        {
            "mode": "General Chat (no course_id)",
            "search_scope": "ALL user resources across all courses",
            "prompt_mode": "GENERAL_RAG_SYSTEM_PROMPT",
            "capabilities": [
                "Access materials from any course",
                "Casual conversation support",
                "General knowledge questions",
                "Study advice",
            ],
        },
        {
            "mode": "Course-Specific (with course_id)",
            "search_scope": "Resources only from specified course",
            "prompt_mode": "RAG_SYSTEM_PROMPT",
            "capabilities": [
                "Course-focused responses",
                "Pedagogical explanations",
                "Course-specific citations",
            ],
        },
    ]

    for b in behaviors:
        print(f"\n{b['mode']}:")
        print(f"  - Search Scope: {b['search_scope']}")
        print(f"  - Prompt: {b['prompt_mode']}")
        print(f"  - Capabilities:")
        for cap in b["capabilities"]:
            print(f"    • {cap}")

    return True


def test_code_changes():
    """
    Verify the code changes were made correctly
    """

    print("\n=== Code Change Verification ===")

    changes = [
        {
            "file": "api-gateway/src/server.ts",
            "change": "Made course_id optional (removes strict validation)",
            "location": "Lines 376-383",
        },
        {
            "file": "agent-graph-service/src/tools/rag_search.py",
            "change": "Made course_id parameter Optional[str] with default None",
            "location": "Function signature",
        },
        {
            "file": "agent-graph-service/src/agents/rag_agent.py",
            "change": "Added GENERAL_RAG_SYSTEM_PROMPT and conditional logic",
            "location": "System prompts and prompt selection",
        },
    ]

    for change in changes:
        print(f"\n{change['file']}:")
        print(f"  - Change: {change['change']}")
        print(f"  - Location: {change['location']}")

    return True


def main():
    """Run all documentation tests"""
    print("General Chat Implementation Test Suite")
    print("=" * 50)

    tests = [
        test_api_gateway_payloads(),
        test_expected_behaviors(),
        test_code_changes(),
    ]

    all_passed = all(tests)

    print("\n" + "=" * 50)
    print(f"Documentation Tests: {'✓ All passed' if all_passed else '✗ Some failed'}")
    print("\nNext Steps:")
    print("1. Start services with these changes")
    print("2. Test general chat with a client")
    print("3. Verify both modes work correctly")

    return all_passed


if __name__ == "__main__":
    main()
