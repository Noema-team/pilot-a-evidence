---
tags:
  - Documentation/Internal
---

# Audit Findings — Testing Framework & Main System

> **Last updated:** 2026-06-21 — all Priority 1 and Priority 2 items resolved
> **Branch status:** Testing branch is 26 commits ahead of main. All audit findings closed except Priority 3 (low-risk infra items).

---

## Action Plan — What to Focus On

### Priority 1 — Fix Before This Branch Can Merge to Main
These block merging or give false confidence:

| # | Finding | Status | Action |
|---|---------|--------|--------|
| 1 | CI Python 3.13 → 3.11 | **DONE** `4225eb3` | Changed `python-version` in `test.yml` from 3.13 to 3.11 |
| 2 | SSE contract tests are tautologies | **DONE** `79beb10` | Rewrote to use runtime introspection |
| 3 | `test_chat_pipeline.py` runtime file write | **DONE** `13aadfd` | Removed runtime file write, pre-created `src/__init__.py` |
| 4 | Empty test fixtures | **DONE** `f01150f` | Populated all fixture directories with sample JSON data |

### Priority 2 — Real Bugs Still Unfixed
| # | Finding | Status | Action |
|---|---------|--------|--------|
| 5 | Pagination mobile providers ignore `has_more` | **DONE** `7b74f01` | AsyncNotifier with `loadMore()` added to mobile resource/group providers |
| 6 | `original_filename` rename | **DONE** `c71592a` + `0f8e881` | Phase 1: dual-read/dual-write. Phase 2: full removal across 36 files |
| 7 | `rag-worker-service` Dockerfile runs as root | **DONE** `b049f68` | Uncommented `USER app`, runs as non-root |

### Priority 3 — Lower Risk, Address Later
| # | Finding | Status | Action |
|---|---------|--------|--------|
| 8 | Subprocess introspection fragility | **OPEN** | Consider direct imports with conftest mocking |
| 9 | `setup-gcp-keys.sh` shared SA key | **OPEN** | Dev acceptable, prod needs separation |

---

## Fixed Issues (Completed)

### SSE done event contract mismatch
#Bug #Priority:Critical #Component:AI-Chat #Component:Mobile #Status:FIXED

**Fixed by testing branch** — backend now includes `message_id`, `full_response`, `thread_id` at top level of done event. Mobile `ChatDoneEvent` parsing aligned.

Was: backend emitted only `thread_id` and `trace_id` nested under `data` key. Mobile expected `message_id`, `full_response`, `thread_id` at top level — all three non-nullable. Silent TypeError was swallowed, never yielding `ChatDoneEvent`, so every message started a new conversation.

**Files:** `agent-graph-service/src/main.py`, `mobile/lib/chat/api/chat_api_client.dart`

---

### SSE streaming: gateway body field mismatch
#Bug #Priority:High #Component:API-Gateway #Component:Mobile #Status:FIXED

**Fixed by testing branch** — gateway now accepts `message` as alias for `query`, supports `?stream=true` query param in addition to `response_mode` body field.

Was: gateway expected `query` field, mobile sent `message`. Gateway checked `response_mode === 'streaming'` from body, mobile sent `stream=true` as query param.

**Files:** `api-gateway/src/server.ts`, `mobile/lib/chat/api/chat_api_client.dart`

---

### teaching.py error handler returns empty dict
#Bug #Priority:Medium #Component:AI-Chat #Status:FIXED

**Fixed on main** (`e1a7997`), merged into testing branch (`70d9c11`) — now returns fallback assistant message on error. Duplicate unreachable `except` block removed.

Was: `teaching.py:166-171` caught exceptions and returned `{}` — empty dict with no assistant message. Other agents (rag, problem_solving, study_advice) all returned a fallback message.

**Files:** `agent-graph-service/src/agents/teaching.py`

---

### ApiConfig.get_firebase_credentials_dict() — dead code
#Bug #Priority:Medium #Component:RAG-API #Status:FIXED

**Fixed on main** (`e1a7997`), merged into testing branch (`70d9c11`) — method deleted.

Was: method referenced `self.firebase_project_id` and other `firebase_*` fields not declared in `ApiConfig`. Would throw `AttributeError` if called. Never invoked — service uses file-based credentials via `GOOGLE_APPLICATION_CREDENTIALS`.

**Files:** `rag-api-service/main.py`

---

### Pagination backend — has_more field missing
#Bug #Priority:High #Component:RAG-API #Status:FIXED

**Fixed by testing branch** — `has_more: bool = False` added to `ListResourcesResponse` and `ListGroupsResponse`. Logic `has_more=len(results) >= limit` implemented.

Was: no `has_more` field, `total` set to page size not true count. Testing branch's `TestListResourcesResponseContract` (subprocess introspection) caught this and forced the fix.

**Remaining:** `total` still reflects page size, not true total count. Mobile providers still discard `hasMore` — see Open Issues.

**Files:** `rag-api-service/main.py`, `rag-api-service/services/resource_service.py`

---

### CI Python 3.13 → 3.11 mismatch
#Infra #Priority:Critical #Component:CI/CD #Status:FIXED

**Fixed** (`4225eb3`) — changed `python-version: '3.13'` → `'3.11'` in `test.yml`.

Was: testing branch `test.yml` specified **Python 3.13** while all Dockerfiles use **Python 3.11**. Key packages would break:
- `numpy==1.26.2`, `torch==2.1.2`, `scikit-learn==1.3.2` — no 3.13 wheels
- `spacy==3.7.2`, `tiktoken==0.5.1` — may lack 3.13 wheels

**Files:** `ai-server/.github/workflows/test.yml`

---

### SSE contract tests rewritten — no longer tautologies
#Testing #Priority:Medium #Component:Testing-Framework #Status:FIXED

**Fixed** (`79beb10`) — rewrote `TestSSEChatStreamContract`, `TestChatThreadsContract`, `TestChatMessagesContract` to use runtime introspection instead of hardcoded dicts.

Was: these tests asserted against hardcoded dicts they created themselves — tautologies that pass despite bugs. Only `TestResourceResponseContract` and `TestListResourcesResponseContract` used subprocess introspection and caught real issues.

**Files:** `tests/integration/test_api_contracts.py`

---

### test_chat_pipeline.py runtime file write removed
#Testing #Priority:Medium #Component:Testing-Framework #Status:FIXED

**Fixed** (`13aadfd`) — removed runtime `src/__init__.py` creation, pre-created `src/__init__.py` in source tree.

Was: test created `src/__init__.py` if it didn't exist — fails in read-only CI or Docker builds.

**Files:** `tests/integration/test_chat_pipeline.py:50-51`

---

### Test fixtures populated with sample data
#Testing #Priority:Low #Component:Testing-Framework #Status:FIXED

**Fixed** (`f01150f`) — populated all fixture directories with realistic sample JSON data.

Was: fixture directories contained only `.gitkeep` files — no actual sample documents or response fixtures.

**Files:** `tests/fixtures/sample_documents/`, `tests/fixtures/sample_responses/`

---

### rag-worker-service Dockerfile — runs as non-root
#Security #Priority:Low #Component:Infra #Status:FIXED

**Fixed** (`b049f68`) — uncommented `USER app`, container now runs as non-root.

Was: `USER app` commented out at line 72, container ran as root.

**Files:** `rag-worker-service/Dockerfile:72`

---

## Open Issues

### Contract test subprocess introspection is fragile
#Testing #Priority:Low #Component:Testing-Framework #Status:OPEN

`_get_rag_api_model_fields()` runs subprocess importing `main.py` with mocked modules. Will break silently if import graph changes.

**Fix:** Consider direct imports with `conftest.py` mocking, or add explicit error messages for subprocess failures.

**Files:** `tests/integration/test_api_contracts.py:42-80`

---

### setup-gcp-keys.sh copies one SA key to all 6 services
#Security #Priority:Low #Component:Infra #Status:OPEN

Violates least privilege — single service account key used for all services.

**Fix:** Dev/staging acceptable. Production needs per-service accounts.

**Files:** `scripts/setup-gcp-keys.sh`

---

## Recently Resolved (2026-06-21)

### Security holes in testing framework — closed
#Testing #Priority:High #Component:Testing-Framework #Status:FIXED

Three security coverage gaps identified in the Test Coverage & Gap Analysis audit have been closed:

1. **`verify_thread_ownership` logic bug + missing tests** (`d0f3a54`): Extracted the function to `src/security.py` as a pure, injectable function. Documented the actual trust model. Added 12 unit tests covering every branch. Replaced the non-deterministic integration test (`assert status in (200, 403)`) with two deterministic tests.
2. **`authenticate_s2s` zero coverage** (`c7faf3c`): Added 14 unit tests calling the dependency directly with the auth-service HTTP client mocked. Covers missing/empty token, success path, header forwarding, URL construction, propagated non-200, isServiceAccount gate, transport failures.
3. **Empty `test_graph_basic.py`** (`c0584ac`): Filled with 24 tests — 9 for `agent_router` pure function, 10 for `ENABLE_AGENT_CHAINING=false` graph structure, 5 for `ENABLE_AGENT_CHAINING=true` graph structure.

### Pagination mobile providers ignore has_more
#Bug #Priority:High #Component:Mobile #Status:FIXED

**Fixed** (`7b74f01`) — replaced `FutureProvider` with `AsyncNotifier` for resources and groups. Added `PaginatedResourceState`/`PaginatedGroupState` with `loadMore()`. Added `LoadMoreIndicator` widget. Updated all derived providers and downstream UI.

### original_filename rename — completed
#Risk #Priority:High #Component:RAG-API #Component:RAG-Worker #Component:Weaviate #Component:Mobile #Status:FIXED

**Phase 1** (`c71592a`): Added dual-read/dual-write for `filename` alongside `original_filename` across all services. Backward-compatible — no data loss.

**Phase 2** (`0f8e881`): Removed all `original_filename` / `originalFilename` references from source code, models, API contracts, and test fixtures. 36 files changed, net -87 lines. User confirmed no production data exists that relies solely on the old field name.

**Files:** `rag-api-service/`, `rag-worker-service/`, `weaviate-service/`, `agent-graph-service/`, `api-gateway/`, `admin-webui/`, `mobile/`, `web/`
