# AI-Optimized Documentation System Design

**Date:** 2026-04-11
**Status:** Approved

---

## Overview

Restructure `docs/` and introduce `CLAUDE.md` + `claude/` to give Claude Code layered, context-efficient access to project documentation and task management. AI loads only what is relevant to the current task, never filling context with unnecessary files.

---

## Goals

- AI always has top-level project context without being asked
- AI can locate and load only the relevant docs for any given task
- Docs, README files, and map files stay accurate — enforced via skills
- System is readable in Obsidian for human use
- Skills enforce consistent behavior when reading/writing tasks or docs

---

## Layer Model

Context is loaded in layers. Each layer tells AI what to load next.

```
Layer 0: CLAUDE.md (always in context, auto-loaded by Claude Code)
Layer 1: Hub README.md files (loaded when domain is relevant)
Layer 2: map.md files (loaded to locate a specific file)
Layer 3: Leaf docs (loaded when working on a specific feature or task)
```

AI never skips layers. It reads the hub README before scanning map.md, and reads map.md before loading a leaf doc.

---

## Directory Structure

```
student-platform/
├── CLAUDE.md                              ← Layer 0: always loaded
├── claude/                                ← AI tooling
│   └── skills/
│       ├── task-management.md             ← skill: read/write/update tasks
│       └── documentation.md              ← skill: write/update docs and indexes
└── docs/
    ├── system-overview/
    │   ├── README.md                      ← hub: purpose, rules, when to load subfolders
    │   ├── map.md                         ← full index of all files with one-liners
    │   ├── general/                       ← cross-cutting: auth, infra, data flow, design rules
    │   ├── ai-server/                     ← AI server architecture, endpoints, agent types
    │   ├── mobile/                        ← Flutter app structure, navigation, state
    │   └── web/                           ← Next.js app structure, routing, components
    ├── documentation/
    │   ├── README.md                      ← hub: purpose, rules, load specific files only
    │   ├── map.md                         ← index of all feature docs with one-liners
    │   ├── ai-features/                   ← specs for AI-related features
    │   ├── ux-flows/                      ← user experience flows and UI specs
    │   └── ...                            ← other subfolders as features grow
    └── task-management/
        ├── README.md                      ← hub: task format, skill to load, how to navigate
        ├── map.md                         ← index of all task files
        ├── critical-tasks.md              ← pointers only: title + file for critical/active tasks
        ├── 01-ai-processing.md
        ├── 02-frontend-backend.md
        ├── 03-app-ui-ux.md
        ├── 04-timeline-feature.md
        ├── 05-testing-qa.md
        ├── 06-business.md
        ├── 07-feature-backlog.md
        └── 08-infrastructure-devops.md
```

---

## CLAUDE.md (Layer 0)

**Location:** `/CLAUDE.md`
**Size target:** ~100 lines max. Never grows beyond this — details live in hubs.

**Contents:**
- App purpose (2-3 sentences): what the student platform does, who it's for
- Monorepo layout: `apps/ai-server`, `apps/mobile`, `apps/web`
- Tech stack summary (one line per app)
- The 3 hub domains and when to load each:
  - `docs/system-overview/` — load when understanding how the system works
  - `docs/documentation/` — load when working on a specific feature spec
  - `docs/task-management/` — load when reading or writing tasks
- Skill directory: which skill to load for which domain
- Loading rule: "Always read the hub's `README.md` first, then `map.md` to locate specific files"

---

## Hub README Files (Layer 1)

Each of the three `docs/` subfolders has a `README.md` that serves as the domain entry point.

**`docs/system-overview/README.md`**
- What this folder is for
- Which subfolder covers which app/concern
- Which files are especially important (pinned)
- Rule: load before reading any system-overview file

**`docs/documentation/README.md`**
- What this folder is for
- Warning: these are heavy docs — load only the specific file needed
- Subfolder index with one-line descriptions
- Skill to load: `claude/skills/documentation.md`

**`docs/task-management/README.md`**
- What this folder is for
- Task card format and status tags
- Skill to load: `claude/skills/task-management.md`
- Rule: always load `critical-tasks.md` first when asked about tasks

---

## Map Files (Layer 2)

Each of the three `docs/` subfolders has a `map.md` alongside its `README.md`.

**Format — each entry is one line:**
```
- `path/to/file.md` — one-line description of what's in this file
```

Map files are never used for understanding — only for locating files. AI loads them when it knows which domain it needs but hasn't identified the specific file yet.

---

## critical-tasks.md

**Location:** `docs/task-management/critical-tasks.md`
**Purpose:** Give AI a fast starting point when asked about tasks, without loading all 8 task files.

**Format — pointers only:**
```
# Critical & Active Tasks

## In Progress
- [Task title] → `task-management/02-frontend-backend.md`

## Critical (not yet started)
- [Task title] → `task-management/01-ai-processing.md`
```

**Rules:**
- Contains no task content — only title and file pointer
- AI updates this file on every task status change:
  - Add pointer when a task becomes `#InProgress` or AI determines it is `#Critical`
  - Remove pointer when a task is marked `#Done` or `#Blocked`
- AI decides criticality based on: business impact, blocking other tasks, explicit user instruction
- Human never edits this file directly — AI owns it

---

## Skills

### `claude/skills/task-management.md`

Enforces consistent behavior whenever AI reads or writes tasks. Rules include:

- Always load `task-management/README.md` before touching any task file
- Always load `claude/skills/task-management.md` before reading or writing tasks
- Card format: `# Title`, status tag, description, optional doc link, `---` separator
- Status tags: `#ToDo`, `#Planning`, `#InProgress`, `#Done`, `#Blocked`
- On every task status change: update `critical-tasks.md` and the relevant task file
- On every new task or file addition: update `task-management/map.md`
- Never leave `map.md` or `critical-tasks.md` out of sync after a task operation

### `claude/skills/documentation.md`

Enforces consistent behavior when writing or updating any doc. Rules include:

- Always load the relevant hub `README.md` before writing a doc in that domain
- On every new file created: add an entry to the folder's `map.md`
- On every file renamed or moved: update `map.md` and any links pointing to it
- Doc naming convention: `kebab-case.md`
- Never create a doc without placing it in the correct subfolder
- After writing a doc: verify `map.md` is up to date before closing the task

---

## Maintenance Contract

AI is responsible for keeping all index files accurate. This is non-negotiable and enforced via skill rules:

| File | Updated when |
|------|-------------|
| `map.md` (any folder) | Any file is created, renamed, moved, or deleted in that folder |
| `README.md` (any hub) | Folder structure changes or a new subfolder is added |
| `critical-tasks.md` | Any task status changes or AI assesses criticality |

Humans never need to manually update `map.md`, `critical-tasks.md`, or hub `README.md` files. If a human edits docs outside Claude Code (e.g. in Obsidian), they should ask AI to re-sync the indexes afterward.

---

## Obsidian Compatibility

- All files are standard Markdown — fully readable in Obsidian
- `[[wikilinks]]` can still be used within leaf docs for human navigation
- The folder structure works as an Obsidian vault without modification
- `README.md` files appear as normal notes in Obsidian
- The `.obsidian/` config folder is preserved as-is

---

## What This Replaces

| Old | New |
|-----|-----|
| `docs/Documentation/` | `docs/documentation/` (restructured) |
| `docs/Task_Management/` | `docs/task-management/` (restructured) |
| No system overview | `docs/system-overview/` (new) |
| No CLAUDE.md | `CLAUDE.md` at root (new) |
| No skills | `claude/skills/` (new) |
| No map or index files | `map.md` + `README.md` per hub (new) |
| No critical tasks index | `critical-tasks.md` (new) |
