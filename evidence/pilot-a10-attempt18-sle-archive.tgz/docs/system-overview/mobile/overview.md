# Mobile App Overview

## Tech stack

- **Framework:** Flutter (Dart)
- **Auth:** Firebase Auth
- **Database:** Firestore (direct SDK access)
- **Storage:** Firebase Storage (direct SDK access)
- **State management:** (check codebase — likely Riverpod or Provider)

## Key app areas

- Course management (create, archive, star courses)
- Resource upload and management (PDFs, slides)
- AI chat (per-course and general)
- Flashcards
- Timeline (upcoming feature)

## Firestore access

Unlike the web app, the mobile app accesses Firestore directly using the Firebase Flutter SDK. Firestore security rules enforce per-user access.

## Structure

See `apps/mobile/` for full source. Key areas:
- `lib/` — main Flutter source
- `firestore.rules` — security rules
- `firebase.json` — Firebase project config
