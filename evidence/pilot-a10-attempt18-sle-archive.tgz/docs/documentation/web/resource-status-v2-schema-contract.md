# Resource Status V2 Schema Contract

## Purpose

This contract finalizes **Phase 1** of the Resource Status V2 plan.

It defines:
- Canonical Firestore document/subcollection schema
- Field ownership (which service writes which fields)
- Required vs optional fields
- Status enum and allowed transitions
- API read model expectations

This is the source of truth for implementation phases 2–6.

---

## 1) Canonical Firestore Layout

```text
users/{userId}/resources/{resourceId}                     # main (lightweight)
├─ processing/
│  ├─ summary                                              # latest processing state
│  └─ events/{eventId}                                     # optional stage/event timeline
├─ content/
│  └─ extracted                                            # extracted text payload
└─ resourceMap/
   └─ data                                                 # map/sections payload
```

> Note: If `resourceMap/` is later renamed to `maps/`, perform a single coordinated rename in code + docs.

---

## 2) Main Resource Document (Canonical)

**Path:** `users/{userId}/resources/{resourceId}`

### 2.1 Required fields

| Field | Type | Description |
|---|---|---|
| `resource_id` | string | Must equal Firestore doc id |
| `user_id` | string | Owner UID |
| `filename` | string | Uploaded file name |
| `status` | enum | Lifecycle state (see section 6) |
| `status_updated_at` | timestamp | Last lifecycle status update |
| `created_at` | timestamp | Creation time |
| `updated_at` | timestamp | Last main-doc update |
| `storage.url` | string | Firebase/GCS URL |
| `storage.bucket` | string | Storage bucket |

### 2.2 Optional fields

| Field | Type | Description |
|---|---|---|
| `storage.path` | string | Canonical object path |
| `storage.mime_type` | string | MIME type if known |
| `storage.size_bytes` | number | Source file size |
| `group_ids` | string[] | Resource groups |
| `course_ids` | string[] | Connected courses |
| `summary.total_pages` | number | Lightweight summary |
| `summary.total_chunks` | number | Lightweight summary |
| `summary.total_embeddings` | number | Lightweight summary |
| `error.code` | string | Error classification |
| `error.message` | string | Human-readable error |
| `error.stage` | string | Stage where error occurred |
| `error.retryable` | boolean | Retry hint |
| `schema_version` | number | Set to `2` |

### 2.3 `filename` field detail

`filename` remains a **required** main-doc field by design.

#### Why it exists

- It is user-facing metadata needed for list/detail UI without extra subcollection reads.
- It preserves the upload identity for citations, map labels, and audit/debugging.
- It avoids requiring storage-path parsing to display a human-readable file name.

#### Contract rules

- Must store the user-provided display name at upload time (not inferred from storage path).
- Must not be used as a unique identifier (resource identity is `resource_id`).
- Must not be used for authorization or ownership checks.
- Should be treated as immutable after upload except explicit rename operations.
- Max length and safe-character validation are enforced at API validation layer.

#### Related fields

- `storage.path` is the canonical object location (system-facing).
- `filename` is the canonical human-readable upload name (user-facing).

### 2.5 App-Backend-Owned User Metadata Fields

These fields are owned and managed by the App Backend for UI/UX purposes.
They are lightweight and do not conflict with the V2 lightweight main-doc constraint.

| Field | Type | Description |
|---|---|---|
| `title` | string? | User-provided or auto-generated display title |
| `tags` | string[]? | User-defined tags |
| `origin_book` | string? | Source book name |
| `origin_chapter_name` | string? | Chapter name |
| `origin_chapter_number` | string? | Chapter number |
| `origin_page_from` | number? | Start page |
| `origin_page_to` | number? | End page |

### 2.4 Main-doc constraints

- Main doc must remain lightweight (no extracted full text, no full processing metrics object, no full resource map payload).
- Main doc lifecycle is represented only by `status`.
- Legacy fields are disallowed in new writes:
  - `ragProcessingStatus`
  - `ragProcessingDetails`
  - `ragProcessingMetrics`
  - `ragContentTags`
  - `ragContentAnalysis`
  - `ragVectorStorage`
  - `extractedText`
  - `resourceMap` (embedded payload)

---

## 3) Processing Summary Document

**Path:** `users/{userId}/resources/{resourceId}/processing/summary`

### 3.1 Required fields

| Field | Type | Description |
|---|---|---|
| `stage` | string | Current stage identifier |
| `progress` | number | Integer 0–100 |
| `updated_at` | timestamp | Last processing detail update |

### 3.2 Optional fields

| Field | Type | Description |
|---|---|---|
| `job_id` | string | Processing job identifier |
| `started_at` | timestamp | Processing start |
| `completed_at` | timestamp | Processing completion |
| `metrics.chunks_created` | number | Processing metric |
| `metrics.tokens_used` | number | Processing metric |
| `metrics.cost_estimate` | number | Processing metric |
| `metrics.processing_time` | number | Seconds |
| `metrics.embeddings_generated` | number | Processing metric |
| `analysis.tags` | string[] | Content tags |
| `analysis.document_type` | string | Classified type |
| `analysis.confidence_scores` | map<string, number> | Confidence map |
| `analysis.text_length` | number | Text length |
| `vector_storage.provider` | string | e.g. `weaviate-service` |
| `vector_storage.chunks_stored` | number | Stored chunks |
| `error.code` | string | Detailed error info |
| `error.message` | string | Detailed error info |
| `error.stage` | string | Detailed error info |

### 3.3 Constraints

- This document is the canonical location for processing details (stage/progress/metrics/analysis).
- Keep values JSON-serializable and API-safe.

---

## 4) Processing Events Collection (Optional)

**Path:** `users/{userId}/resources/{resourceId}/processing/events/{eventId}`

### Event schema

| Field | Type | Description |
|---|---|---|
| `sequence` | number | Monotonic order within resource |
| `type` | string | `stage_update` / `status_update` / `error` |
| `stage` | string? | Stage name where relevant |
| `progress` | number? | 0–100 |
| `details` | map | Event payload |
| `created_at` | timestamp | Event time |
| `job_id` | string? | Correlation id |

### Constraints

- Optional for MVP, but recommended for observability/debugging.
- If enabled, event writes must not block core processing completion flow.

---

## 5) Content Document

**Path:** `users/{userId}/resources/{resourceId}/content/extracted`

### Required fields

| Field | Type | Description |
|---|---|---|
| `text` | string | Full extracted markdown/text |
| `text_length` | number | Character count |
| `extraction_method` | string | `marker-pdf` / `pypdf` / etc |
| `extracted_at` | timestamp | Extraction completion |
| `total_pages` | number | Document pages |

### Constraints

- Full extracted text must exist only here.
- Main doc must not store full extracted text.

---

## 6) Resource Map Document

**Path:** `users/{userId}/resources/{resourceId}/resourceMap/data`

### Required fields

| Field | Type | Description |
|---|---|---|
| `resource_id` | string | Resource identifier |
| `filename` | string | Original filename |
| `total_pages` | number | Page count |
| `sections` | array | Structured section list |
| `total_sections` | number | Section count |
| `generated_at` | timestamp | Initial generation time |
| `updated_at` | timestamp | Last update |

### Optional fields

| Field | Type | Description |
|---|---|---|
| `extraction_confidence` | string | `high`/`medium`/`low` |
| `extraction_method` | string | `markdown`/`heuristic`/etc |
| `sections_with_flashcards` | number | Coverage metric |
| `total_flashcards` | number | Coverage metric |

### Constraints

- Full map payload must exist only here.
- Main doc must not duplicate full map payload.

---

## 7) Canonical Status Enum and Transition Rules

### 7.1 Enum

```text
uploaded | queued | processing | completed | failed | deleted
```

### 7.2 Allowed transitions

- `uploaded -> queued`
- `queued -> processing`
- `processing -> completed`
- `processing -> failed`
- `failed -> queued` (retry)
- `completed -> queued` (explicit reprocess only)
- `* -> deleted` (resource deletion flow)

### 7.3 Invalid transitions

- `failed -> processing` (must pass through `queued`)
- `uploaded -> completed` (must process)
- `deleted -> *` (terminal)

### 7.4 Idempotency expectations

- Repeated writes of same `status` are no-op safe.
- Out-of-order updates must not regress terminal states without explicit reprocess trigger.

---

## 8) Field Ownership Matrix

| Field Area | Owner | Notes |
|---|---|---|
| Main doc identity/storage/relationships | API (`POST /resources`, relationship endpoints) | authoritative |
| Main doc `status` lifecycle updates | Worker + API status subscriber pipeline | canonical status only |
| `processing/summary` | Worker pipeline | authoritative details |
| `processing/events/*` | Worker pipeline (optional) | observability |
| `content/extracted` | Worker extraction stage | full text source |
| `resourceMap/data` | Resource map generator | map source |

---

## 9) API Read Model Expectations

- `GET /api/resources` returns main doc lightweight summary fields only.
- `GET /api/resources/{resource_id}` returns main doc lifecycle/summary (not full content/map/details).
- Processing detail endpoint(s) must read from `processing/summary` (and `events/*` if provided).
- Content endpoint must read from `content/extracted`.
- Resource map endpoint must read from `resourceMap/data`.

---

## 10) Definition of Done for Phase 1

Phase 1 is complete when:

1. This schema contract is approved by backend/API/worker owners.
2. Status enum + transition rules are accepted as canonical.
3. Field ownership matrix is accepted.
4. Implementation phases reference this document as authoritative.

