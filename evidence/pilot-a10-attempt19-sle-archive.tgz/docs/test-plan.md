# Test Plan: worker→rag-api failure payload contract

Companion to `docs/plan.md`. Covers the contract test required by the Definition's requirement 5 / acceptance criterion 4, plus the worker-side unit coverage that makes the seam test meaningful.

## 1. Strategy

1. **Import both sides; never restate the contract in a fixture.** The payload is built by the worker's real code path (`_build_failure_payload`, called by the real exception handler) and persisted by rag-api's real `run_transactional_update`. The test asserts equality across the seam, so either side drifting fails the build.
2. **Fakes over the Firestore emulator.** rag-api's `run_transactional_update(db, doc_ref, new_status, details, logger, user_id)` takes the db as a parameter and is already exercised against fakes elsewhere; the house fake pattern exists and is hermetic (no Docker, no emulator lifecycle). The Definition permits "the Firestore emulator or fakes" — fakes are primary. An emulator-based variant is optional and not required for acceptance.
3. **Drift guards on both sides.** Worker side: behavioral key-set assertions on the helper output and on the payload the real handler publishes. rag-api side: an AST scan pinning the `details.get(...)` key literals in the failed branch.
4. **Existing tests stay green.** `test_processing_lease.py` already asserts the sweep writes `retryable is True` — the sweep is a non-goal and its test is the regression canary.

## 2. Test environments & fakes

### 2.1 Worker tree (`rag-worker-service/tests/…`)
- `tests/conftest.py` already stubs everything worker `main.py` imports at module level (`openai`, `langfuse`, `firebase_admin`, `google.cloud.*`, `spacy`, `tiktoken`, `tenacity`, `langchain`) and sets env defaults. New tests under `tests/unit/` and `tests/integration/` inherit it automatically.
- `pytest.ini` sets `asyncio_mode = auto` — async test functions work directly in this tree.
- Reuse the fake family proven in `tests/unit/test_processing_lease.py`: `FakeTx` (records writes, `get()` returns current doc state), `FakeSnap`, `FakeRef` (with `collection()`/`document()`), `FakeCollection`, `FakeDb`; `_tx_identity` monkeypatched over `firestore.transactional`; `SERVER_TIMESTAMP` monkeypatched to a sentinel. For the new tests these fakes are re-declared locally in the new test module (copy, don't refactor the existing file — avoids touching a regression test for an unrelated bug).

### 2.2 rag-api tree (`rag-api-service/tests/…`)
- No new tests required here (rag-api production code is unchanged). Existing suites must pass unchanged.

### 2.3 Shared integration tree (`apps/ai-server/tests/integration/…`)
- The directory conftest mocks `firebase_admin`, `google.cloud.*`, `structlog` and puts **only** `rag-api-service` on `sys.path`. It does **not** stub the worker's heavier imports (`openai`, `langchain`, `langfuse`, `spacy`, `tiktoken`, `tenacity`).
- Decision: **do not modify the shared conftest** (it would change stubbing for six existing test modules). Instead, the new test file performs module-local setup *before* importing worker `main.py`: append the worker service dir to `sys.path` and install stub-if-missing entries for the worker-only modules, mirroring the worker conftest's stub set. The parent conftest's `MagicMock` stubs for `firebase_admin`/`google.cloud`/`structlog` run first and are compatible (stub-if-missing semantics in both conftests mean no double-stubbing conflicts).
- No local `pytest.ini` exists in this tree and the async plugin mode is unverified → any async driving is done from **sync tests via `asyncio.run(...)`**.
- Fallback (pre-approved decision point): if worker `main.py` proves unimportable here for reasons the stub set can't fix, relocate the both-sides test under `rag-worker-service/tests/integration/` with a local conftest addition that stubs rag-api's import surface instead. Record the switch as a plan deviation note, not a silent change.

## 3. Test inventory

### 3.1 `rag-worker-service/tests/unit/test_failure_payload.py` (Phase 01)

Pure tests of `_build_failure_payload(e, stage)` — no mocks beyond `monkeypatch` of `firestore` sentinels if the helper touches them (it should not).

| Case | Assertion |
|---|---|
| Key set | `set(payload) == {"error_message", "stage", "retryable", "error"}` — exact; extra/missing keys fail |
| Message fidelity | `payload["error_message"] == str(e)` and `payload["error"] == str(e)` (legacy hedge carries the same string) |
| Transient → retryable true | `TransientError("x")` → `retryable is True`; also spot-check a known transient type (e.g. `httpx.ConnectError`) → True |
| Permanent → retryable false | `PermanentError("x")` → `retryable is False` |
| Unclassified-unknown → retryable false | plain `ValueError("boom")` / generic `Exception` → `retryable is False` (conservative default; this pins the deliberate behavior change) |
| Stage passthrough | a concrete stage string is returned unchanged; the helper never invents a stage |
| Unknown-stage fallback | `None` (sentinel) → `"processing"` |

### 3.2 `rag-worker-service/tests/integration/test_failure_stages.py` (Phase 02)

Drives the real `process_document` with pipeline collaborators monkeypatched to raise, capturing the payload via a monkeypatched `_publish_status_update` (records `(status, details)` calls). The exact collaborator callables to patch are identified by reading `main.py` at implementation time (plan §10.2); the *mechanism* below is the contract.

| Case | Setup | Assertion |
|---|---|---|
| Early-stage failure | force the text-extraction step to raise `ValueError("extract exploded")` | captured failed-status details: `stage == "text_retrieved"`, `error_message == "extract exploded"`, `error == "extract exploded"`, `retryable is False`; key set exact |
| Late-stage failure | let early steps succeed (stubbed), force the embeddings step to raise `TransientError("embed timeout")` | `stage == "embeddings_complete"`, `retryable is True` |
| Pre-assignment failure | raise before the first tracker assignment (e.g. patch the earliest collaborator / entry path) | `stage == "processing"` (never `None`) |
| Handler uses the helper | any of the above | captured payload equals `_build_failure_payload(raised_exception, expected_stage)` — proves the handler routes through the extracted code path (no parallel inline construction) |
| Transient/permanent agreement | same runs | `payload["retryable"] == classify_error(raised_exception)` — payload and ACK/NACK classification can never disagree |

Representative stages only (early + late), per the Definition — the test pins the tracker mechanism, not every step.

### 3.3 `apps/ai-server/tests/integration/test_worker_failure_contract.py` (Phase 02) — the seam

Module-local stubbing per §2.3, then:

**Fixture:** fake-db family (§2.1 pattern); `monkeypatch` rag-api `main.firestore.transactional → _tx_identity` and `SERVER_TIMESTAMP → "TS"`; seed the document with `status: "processing"` (so `processing → failed` is an allowed transition), a filename, and `user_id`.

**Core test — end-to-end persistence equality:**
1. `payload = worker_main._build_failure_payload(exc, stage)` with a real exception (e.g. `ValueError("OCR returned garbage")`, stage `"chunking_complete"`).
2. `api_main.run_transactional_update(db, ref, "failed", payload, logger, user_id)` (logger may be a stub).
3. Assert on the recorded main-doc update:
   - `error == "OCR returned garbage"` (and a guard assertion `error != "Processing failed"`)
   - `error_stage == "chunking_complete"` (and `!= None`)
   - `retryable is False` (matches the worker's derivation for that exception class; run a second case with a `TransientError` asserting `retryable is True`)
   - `status == "failed"`
4. Assert on the recorded `processing/summary` write:
   - `error.message == payload["error_message"]`, `error.stage == payload["stage"]` (same as main doc)
   - `error.code == "UNKNOWN"` (no `error_code` sent — taxonomy stays out)
   - `stage == payload["stage"]` (not the `"unknown"` fallback)

**Drift guards:**

| Guard | Mechanism | Fails when |
|---|---|---|
| Worker payload keys (helper) | `set(payload) == {"error_message", "stage", "retryable", "error"}` | a key is added/renamed/removed in the helper |
| Worker payload keys (handler path) | key-set assertion on the payload captured from the real `process_document` failure (§3.2) | the handler stops routing through the helper or constructs divergent keys inline |
| rag-api failed-branch reads | AST walk of `rag-api-service/main.py` → `run_transactional_update`; collect string literals passed to `details.get(...)` within the failed-branch code (main-doc failed writes + summary failed-error block); assert exactly `{"error_message", "stage", "retryable", "error_code"}` | rag-api reads a renamed key, drops a read, or adds a new details key silently |
| Behavioral backstop | the equality assertions in the core test | rag-api stops reading a key the worker sends (persisted value falls back → equality fails) |

The AST guard is implemented standalone in this file (the concrete helpers inside the existing `test_api_contracts.py` were not retained in this context; only its fixture-/AST-based character is pinned by the Definition). If `run_transactional_update` is refactored so the AST walk can't find the failed branch, the guard fails loudly — that is desired; update the guard deliberately in the same change.

### 3.4 Regression watchlist (must remain green, no edits)

- `rag-worker-service/tests/unit/test_processing_lease.py` — sweep still writes `retryable is True`, `status == "failed"`; claim/sweep race behavior unchanged.
- `rag-api-service/tests/integration/test_endpoints.py`, `test_timeline_endpoints.py` — no production change; untouched.
- `apps/ai-server/tests/integration/*` — the new module-local stubbing must not leak (stub-if-missing only; verify by running the whole directory).

## 4. Acceptance coverage matrix

| Acceptance criterion (Definition) | Covered by |
|---|---|
| AC1: payload carries error_message/stage/retryable, no fallback reliance | §3.1 key-set + value cases; §3.2 handler-path capture |
| AC2: persisted error/error_stage/retryable equal worker values | §3.3 core test equality + not-fallback guards |
| AC3: summary subdocument carries same message/stage | §3.3 summary assertions |
| AC4: contract test exists, passes, fails on either-side key drift | §3.3 (whole file) + §3.2 handler-path guard |

## 5. How to run

```bash
pytest apps/ai-server/rag-worker-service/tests          # §3.1, §3.2
pytest apps/ai-server/rag-api-service/tests             # regression only
pytest apps/ai-server/tests/integration                 # §3.3 + existing suite
./dev/run ai-server                                     # final gate (Docker Compose required)
```

## 6. Explicitly not tested (out of scope, per the Definition)

- Stale-lease sweep behavior (already covered by `test_processing_lease.py`; unchanged).
- ACK/NACK policy, leases, heartbeats, backoff — only the payload's `retryable` reporting changes.
- Real Pub/Sub transport, real Firestore, the emulator stack — fakes suffice for the contract.
- Frontend exposure of `retryable` (`ResourceResponse` unchanged).
- Error-code taxonomy (`error.code` asserted to remain `"UNKNOWN"`; nothing else).
- Exhaustive per-step stage assertions beyond the two representative stages.

## 7. Open items resolved during implementation

Same list as plan §10 (handler/`_publish_status_update` exact shape; pipeline collaborator names for monkeypatching; worker import surface under the shared conftest; async plugin mode in `apps/ai-server/tests/`). Each resolves during Phase 01/02 execution and does not change test strategy — only patch points.