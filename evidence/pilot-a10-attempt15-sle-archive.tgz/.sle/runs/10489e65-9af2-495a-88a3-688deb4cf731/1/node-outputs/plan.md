I have enough context from the worker, API, models, and existing contract-test infrastructure. Here is the implementation plan.

Summary of the plan: extract a single failure-payload builder in the worker (keys `error_message`, `stage`, `retryable` plus retained legacy `error`), add stage tracking to `process_document`, derive `retryable` from `classify_error`, leave rag-api's failed branch untouched, and pin the seam with a contract test that imports both sides (worker payload builder → `run_transactional_update` → persisted fields).

<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path=".sle/work/wi-define-108-a8/plan.md">>>
# Implementation Plan — rag-worker → rag-api failure payload contract alignment

WorkItem: wi-define-108-a8 (definition sha256 71f1c39c…)
Run: 10489e65-9af2-495a-88a3-688deb4cf731, Iteration 1

## 0. Ground truth (verified against the tree)

- **Worker failure publisher**: `apps/ai-server/rag-worker-service/main.py`, `process_document` exception handler publishes
  `await self._publish_status_update(..., "failed", {"error": str(e)}, job_id)` — one key.
- **API failed branch**: `apps/ai-server/rag-api-service/main.py`, `run_transactional_update`, `new_status == "failed"` reads
  `details.get("error_message", "Processing failed")`, `details.get("stage")`, `details.get("retryable", True)` and persists
  `error` / `error_stage` / `retryable` on the main doc plus
  `summary_update["error"] = {"code": details.get("error_code", "UNKNOWN"), "message": ..., "stage": ...}`.
- **retryable derivation source**: worker's `classify_error(e)` in the same file — TransientError/httpx connection/timeout
  types/429-5xx → transient (True); PermanentError, other 4xx, and unknown exceptions → permanent (False).
- **Established persisted schema**: `error` / `error_stage` / `retryable` on the Resource model
  (`rag-api-service/models/resource.py`, retryable defaults True) and written directly by `_fail_if_still_stale`
  (`error_stage: "processing"`, `retryable: True`) and by the two enqueue-failure paths in rag-api
  (`error_stage: "enqueue"`).
- **Progress stage vocabulary**: `starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`,
  `embeddings_complete`, `completed` (all `_publish_status_update` calls in `process_document`).
- **Contract-test home**: `apps/ai-server/tests/integration/test_api_contracts.py` (fixture- and AST-based, imports
  `rag_api_main` directly). Worker unit tests live under `apps/ai-server/rag-worker-service/tests/unit` with a heavy
  stub `conftest.py` (firebase/pubsub/openai all stubbed — suitable for importing worker code hermetically).

## 1. Design

### 1.1 Worker: failure payload construction (new function)

Add to `rag-worker-service/main.py` a module-level helper:

```python
def _build_failure_details(error: Exception, stage: str) -> Dict[str, Any]:
    """Build the failed-status payload aligned with rag-api's failed branch.

    Keys (the contract, pinned by tests/integration):
      error_message — actual exception message (API persists as `error`)
      stage         — pipeline stage executing at failure time (API persists as `error_stage`)
      retryable     — derived from classify_error(); never silently defaulted
      error         — legacy duplicate of error_message, kept for unknown consumers of the topic
    """
    return {
        "error_message": str(error),
        "stage": stage,
        "retryable": classify_error(error),
        "error": str(error),  # legacy key retained; see Definition F11
    }
```

- Key set is exactly `{"error_message", "stage", "retryable", "error"}` — no structured error codes (non-goal).
- `retryable` is always explicitly present; rag-api's `details.get("retryable", True)` fallback can no longer be the
  operative mechanism for worker failures.
- Deliberate behavior change (accepted per Definition F8): unclassified-unknown exceptions now persist
  `retryable: false` (classify_error's conservative default) instead of the old silent `true`.

### 1.2 Worker: stage tracking in `process_document`

- Initialize `current_stage = "processing"` at the top of `process_document` (safe value for "stage genuinely unknown",
  matching `_fail_if_still_stale`'s `error_stage` value; never null).
- Immediately before each pipeline step that corresponds to a progress stage, set `current_stage` to that stage name,
  reusing the existing vocabulary exactly:
  - `"starting"` (before `_validate_processing_request` / first status publish)
  - `"text_retrieved"` before the status publish after `_get_extracted_text`
  - `"tagging_complete"` before tagging step
  - `"summary_generated"` before summary generation + Firestore write block
  - `"chunking_complete"` before `_create_enhanced_chunks`
  - `"embeddings_complete"` before `_generate_embeddings_with_openrouter`
  - `"completed"` before the final `store_chunks_via_service` / metadata-save / final publish block
- Convention (documented in a comment at the tracker declaration): **set the tracker immediately before the `await`
  it describes**. A step added without updating the tracker reports a stale-but-plausible stage — acceptable residual
  risk per the Definition; representative-stage contract tests catch removal/bypass of the mechanism.
- The exception handler changes to:

```python
except Exception as e:
    metrics.error_message, metrics.end_time = str(e), time.time()
    self.logger.error("document_processing_failed", ..., error=str(e), stage=current_stage)
    await self._publish_status_update(
        user_id, course_id, resource_id, "failed",
        _build_failure_details(e, current_stage), job_id,
    )
    ...
```

- The exception handler's own Pub/Sub publish could itself fail; that path already swallows inside
  `_publish_status_update` — no change.
- Stages after the tracker (e.g. `_update_user_usage`, `_generate_resource_map`) run inside the success path; a failure
  there reports `"completed"` — correct: the pipeline completed, post-processing housekeeping failed.

### 1.3 rag-api: no changes

`run_transactional_update` is untouched. The failed branch already reads `error_message` / `stage` / `retryable` /
`error_code` and persists `error` / `error_stage` / `retryable` plus the summary error subdocument — all satisfied by
the new payload. `error_code` stays absent → summary `error.code` = "UNKNOWN" (preferred-not constraint respected).
Constraint "must not change API reads or persisted schema" satisfied trivially.

## 2. Tests

### 2.1 Contract test (required by acceptance #4)

New file: `apps/ai-server/tests/integration/test_worker_failure_contract.py`
(plus, if needed, a small conftest addition to put the worker service dir on `sys.path` and apply the worker stub
conftest pattern — the worker's stub setup currently lives in `rag-worker-service/tests/conftest.py`; factor the
stubbing into an importable helper or replicate the minimal stub set in the new test's conftest so importing
`rag-worker-service/main.py` does not require real firebase/pubsub/openai. Do NOT modify worker behavior in conftest.)

Tests, importing both real sides (never restating the contract in a fixture):

1. `test_worker_failure_payload_keys_pinned` — build the payload via `_build_failure_details(exc, stage)` and assert
   the exact key set `{"error_message", "stage", "retryable", "error"}` with equal values for `error_message`/`error`.
   A removed or renamed key fails the build (drift guard, worker side).
2. `test_worker_failure_payload_through_rag_api_persistence` — end-to-end seam:
   - Construct a resource doc in the Firestore emulator (`FIRESTORE_EMULATOR_HOST` mode, both services support it) or,
     if the emulator is unavailable in CI, an in-memory fake doc-ref exercising the same `run_transactional_update`
     transactional path (fake must mimic get/transaction.update/set semantics — see `run_transactional_update`).
   - Seed status `"processing"`.
   - `details = _build_failure_details(TransientError("weaviate timeout"), "embeddings_complete")`
     (and a second case with a `ValueError` → `retryable False`).
   - Call `rag_api_main.run_transactional_update(db, doc_ref, "failed", details, logger, user_id)`.
   - Assert persisted main doc: `error == "weaviate timeout"` (NOT "Processing failed"), `error_stage ==
     "embeddings_complete"` (NOT None), `retryable` equals the worker's derived value.
   - Assert `processing/summary`: `error.message == error`, `error.stage == error_stage`, `error.code == "UNKNOWN"`.
3. `test_failure_stage_tracks_pipeline_position` — representative stages only (per plan §1.2): simulate an early-stage
   failure (before tagging) → payload `stage == "starting"` or `"text_retrieved"`; a late-stage failure → `"embeddings_complete"`
   or later; and an unknown-stage failure → `"processing"`. Implemented by unit-driving `process_document`'s tracker
   through stubbed step methods raising at chosen points, or — if driving the full method is too heavy under stubs — by a
   targeted test that the tracker local exists and feeds `_build_failure_details` (AST or call-through). Prefer the
   functional route; fall back to AST only if the stub cost is prohibitive.
4. `test_retryable_derivation_matches_classify_error` — for a representative set of exceptions
   (TransientError, PermanentError, `httpx.ConnectError`, `httpx.HTTPStatusError(429/500)`, `httpx.HTTPStatusError(404)`,
   bare `ValueError`), assert `payload["retryable"] == classify_error(exc)` — the derivation can never silently diverge
   from ACK/NACK behavior.

The contract test must fail if either side's keys drift: (1) pins the worker key set; (2) exercises the real API read
keys — if someone renames `error_message` on either side, assertion 2 fails.

### 2.2 Worker unit tests

Add to `apps/ai-server/rag-worker-service/tests/unit/test_failure_payload.py` (new):
- key-set and value checks on `_build_failure_details` (duplicate coverage cheap and local to the worker suite);
- `classify_error` → retryable mapping table;
- legacy `error` key equals `error_message`.

### 2.3 Regression sanity

- Existing worker unit suite (`tests/unit`) must still pass — changes are additive (new helper, one local in
  `process_document`, handler payload swap).
- rag-api suite untouched; no API code changes.

## 3. Implementation steps (ordered)

1. **Worker**: add `_build_failure_details` to `rag-worker-service/main.py` (place near `classify_error`).
2. **Worker**: add `current_stage` tracker + assignment points in `process_document` (convention comment included);
   rewrite the exception handler to log `stage` and publish via `_build_failure_details`.
3. **Worker tests**: `rag-worker-service/tests/unit/test_failure_payload.py` (§2.2). Run worker pytest suite.
4. **Contract test**: `apps/ai-server/tests/integration/test_worker_failure_contract.py` (§2.1). Resolve the
   import/stub plumbing for worker code inside the shared tests tree (new conftest in that dir if needed, reusing
   patterns from `rag-worker-service/tests/conftest.py`; prefer importing that conftest's stub set over duplicating).
   Decide emulator vs fake per what the CI/dev stack already provides (`FIRESTORE_EMULATOR_HOST` branch exists in both
   services; the existing `tests/integration` fixtures show the house pattern — check `tests/fixtures/` for an
   existing emulator harness before writing a fake).
5. **Verify** acceptance end-to-end locally: run worker suite + contract test suite; confirm all four acceptance
   bullets map to passing tests (1→§2.1.1/§2.2, 2→§2.1.2, 3→§2.1.2, 4→§2.1).

## 4. Files touched

| File | Change |
|---|---|
| `apps/ai-server/rag-worker-service/main.py` | add `_build_failure_details`; stage tracker in `process_document`; handler payload swap |
| `apps/ai-server/rag-worker-service/tests/unit/test_failure_payload.py` | new unit tests |
| `apps/ai-server/tests/integration/test_worker_failure_contract.py` | new contract test (worker→rag-api failure seam) |
| `apps/ai-server/tests/integration/conftest.py` (only if absent/needed) | stub plumbing for importing worker code |

No changes to: rag-api (any file), `models/resource.py`, stale-lease sweep, ACK/NACK logic, frontend.

## 5. Risks / mitigations (restated for implementers)

- Unknown topic consumers → legacy `error` key retained.
- Stage-tracker drift → "set before await" convention + representative-stage test.
- `retryable=false` for unclassified errors → intended conservatism; manual reprocess via `POST /process` unaffected;
  do NOT widen `classify_error` in this change.
- Contract test ossification → intentional (drift guard); adding a payload key means touching the test.
<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>