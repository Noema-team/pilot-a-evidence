I've inspected the worker publisher, the API's failed branch, the existing contract-test infrastructure, and both services' test conventions. The repository evidence confirms the authoritative definition exactly: the worker's handler publishes `{"error": str(e)}` while `run_transactional_update` reads `error_message`/`stage`/`retryable`; the sweep, enqueue paths, and `Resource` model already speak the persisted schema; and the integration test directory plus both emulator/stub conftests give everything needed for a hermetic seam test. One structural finding shaped the design: `rag-worker-service/main.py` cannot be imported by the shared integration suite without duplicating its heavy stub table (and both services name their module `main`), so the failure-payload construction gets a tiny dependency-free module of its own — which is also what makes "import both sides, don't restate the contract" achievable.

The full design follows in the artifact.

<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path=".sle/work/wi-define-108-a8/design.md">>>
# Design — rag-worker → rag-api failure payload contract alignment

Work item: `wi-define-108-a8` (authoritative definition `definition:obj-108`, sha256 `71f1c39c…`)
Step: design · Planning depth: minimal

---

## 1. Goal

A failed RAG processing job must persist the worker's **actual error message**, the **failing pipeline stage**, and a **deliberately derived retryable flag**. Today every worker-originated failure persists the fallback string `"Processing failed"`, `error_stage: null`, and a fabricated `retryable: true`, because the worker publishes `{"error": str(e)}` while rag-api's failed branch reads `error_message` / `stage` / `retryable`. The fix aligns the worker to rag-api's existing contract, locked in by a contract test on the worker→rag-api failure path.

## 2. Binding constraints (from the authoritative definition)

| # | Constraint | Design response |
|---|---|---|
| C1 (must) | Worker aligns to rag-api's contract; **no changes to rag-api's reads or persisted schema** | §4 D1: zero diffs in `rag-api-service/` |
| C2 (must_not) | No Firestore migration, field rename, or backfill; `error` / `error_stage` / `retryable` keep names and semantics | No schema change anywhere; §6 |
| C3 (must) | Every worker failure payload carries `retryable` explicitly; the API's `details.get("retryable", True)` fallback must not be operative for worker failures | §4 D4 |
| C4 (prefer) | Retain legacy `error` key alongside `error_message` | §4 D2 |
| C5 (prefer_not) | No structured error-code taxonomy | Worker sends no `error_code`; summary `error.code` stays `"UNKNOWN"` |

## 3. Current state (verified against the tree)

**Producer** — `apps/ai-server/rag-worker-service/main.py`, `process_document` exception handler:

```python
await self._publish_status_update(user_id, course_id, resource_id, "failed", {"error": str(e)}, job_id)
```

`process_document` is one large `try` block; nothing tracks which pipeline step was executing, so no stage can be reported (F3, F9).

**Consumer** — `apps/ai-server/rag-api-service/main.py`, `run_transactional_update`, failed branch:

```python
main_update["error"]       = details.get("error_message", "Processing failed")
main_update["error_stage"] = details.get("stage")
main_update["retryable"]   = details.get("retryable", True)
...
summary_update["error"] = {"code": details.get("error_code", "UNKNOWN"),
                           "message": details.get("error_message", "Processing failed"),
                           "stage": details.get("stage")}
summary_update["stage"] = details.get("stage", "unknown")
```

**Already consistent with the persisted schema (untouched):** the worker's stale-lease sweep `_fail_if_still_stale` (writes `error` / `error_stage:"processing"` / `retryable:True` directly to Firestore), rag-api's enqueue-failure paths (`POST /process`, `POST /resources` → `error_stage:"enqueue"`), `models/resource.py` (`retryable: bool = True`), and `ResourceResponse` (exposes `error`, `error_stage`).

**Retry machinery (untouched):** `classify_error()` in worker `main.py` (TransientError/PermanentError + httpx type/status heuristics; unknown → permanent) and `run_worker`'s ACK/NACK logic.

**Test infrastructure available:** `apps/ai-server/tests/integration/test_api_contracts.py` (fixture- and AST-based contract tests, `_get_agent_graph_shapes` precedent), `tests/integration/conftest.py` (mocks rag-api's cloud deps, puts `rag-api-service` on `sys.path`), `rag-worker-service/tests/conftest.py` (stub table that lets worker `main` import hermetically), and the `FakeTx/FakeSnap/FakeRef/FakeDb` transaction fakes in `rag-worker-service/tests/unit/test_processing_lease.py`.

### Two implementation-blocking observations

1. **`main` name collision + heavy worker imports.** Both services have a top-level module `main`. Worker `main.py` imports langchain, openai, spacy, sklearn, tiktoken, langfuse at module level and executes module-level GCP/Pub/Sub setup (`os.environ["GCP_PROJECT"]`, `service_account.Credentials.from_service_account_file`). The shared integration conftest mocks rag-api's deps but not the worker's. Importing worker `main` from `tests/integration` would require duplicating the worker stub table into a shared conftest and cross-contaminating the mock tables of the other integration suites.
2. **`@firestore.transactional` under mocks.** With `firebase_admin.firestore` mocked, `firestore.transactional` is a `MagicMock`; decorating with it destroys the function. Any test driving `run_transactional_update` must monkeypatch `transactional` to an identity decorator and supply fake transaction objects — exactly the pattern `test_processing_lease.py` already established.

Both are resolved by D2 (extract a dependency-free contract module) and §8 T3 (identity-decorator monkeypatch + fakes).

## 4. Design decisions

### D1 — The worker aligns to the API; rag-api is frozen

`run_transactional_update`'s failed branch is already the contract the definition mandates (requirement R3: persist worker-provided values unchanged; subdoc carries the same message and stage). **No file under `apps/ai-server/rag-api-service/` changes.** The API side is pinned by the contract test, not edited. This satisfies C1/C2 by construction and keeps the three already-consistent write paths and both response models untouched.

### D2 — Failure payload construction becomes a named, dependency-free unit

New file `apps/ai-server/rag-worker-service/failure_contract.py`:

```python
"""Worker → rag-api failure payload contract.

Single source of truth for the `details` dict the worker publishes with
status "failed" and rag-api's run_transactional_update failed branch reads.
Kept dependency-free (stdlib only) so the cross-service contract test can
import it without stubbing the worker's ML/cloud dependency graph.
"""

# Safe value when the failing stage is genuinely unknown (failure before the
# first stage transition). Same value the stale-lease sweep persists, so
# error_stage never regresses to null.
UNKNOWN_STAGE = "processing"


def build_failure_details(*, error_message: str, stage: str, retryable: bool) -> dict:
    """Build the failed-status payload.

    Key set is contract: error_message/stage/retryable are read by rag-api's
    failed branch; the legacy `error` key is retained for any unknown consumer
    of the status topic (F11 hedge) and for log tooling.
    """
    return {
        "error_message": error_message,
        "stage": stage,
        "retryable": retryable,
        # Legacy key, deliberately retained (C4). Equal to error_message.
        "error": error_message,
    }
```

Rationale:
- The contract test **imports** the builder instead of restating the dict in a fixture (definition's test strategy: "import both sides rather than restate the contract").
- The key set is pinned in exactly one place; the drift guard (§8 T4/T5) fails the build if either side drifts.
- Dependency-free ⇒ importable from `tests/integration` with **no** stub table and no `main` name collision (resolves observation 1). `classify_error` deliberately stays in worker `main.py` (it is retry machinery, used by `run_worker`; moving it would widen the diff) — the builder only *shapes* the payload, it does not classify.

`process_document`'s handler becomes:

```python
except Exception as e:
    metrics.error_message, metrics.end_time = str(e), time.time()
    self.logger.error("document_processing_failed", ..., error=str(e), stage=current_stage)
    failure_details = build_failure_details(
        error_message=str(e),
        stage=current_stage,
        retryable=classify_error(e),
    )
    await self._publish_status_update(user_id, course_id, resource_id, "failed", failure_details, job_id)
```

Notes:
- `_publish_status_update` mutates the passed dict (`details['jobId'] = job_id`); the builder returns a fresh dict per call, so enrichment is safe and the builder's return value (the thing the drift guard pins) is the pre-enrichment 4-key dict.
- Empty `str(e)` edge: an exception with an empty message persists `error: ""`. That is still the *actual* message; adding a `type(e).__name__` fallback is scope creep and is **not** done. Recorded as a known edge (§9).

### D3 — Stage tracker: set-before-await, step-in-flight naming

A local `current_stage` in `process_document`, initialized to `failure_contract.UNKNOWN_STAGE` (`"processing"`), assigned **immediately before each pipeline-step await**, and read by the exception handler.

Semantics: the tracker names the **step in flight**, using that step's progress-vocabulary label — i.e. the label that the step's *completion* publishes. Reading `error_stage: "chunking_complete"` means "failed during the chunking step". The vocabulary is not widened (C1-adjacent; the definition pins the vocabulary), so steps that publish no own transition (old-vector deletion, Weaviate storage, metadata save, final publish) report the enclosing stage.

Assignment map (the convention: *set the tracker immediately before the await*):

| Pipeline step (await) in `process_document` | Tracker value set before it | Failure there reports |
|---|---|---|
| `_validate_processing_request` | — (init) | `"processing"` (genuinely unknown: before first transition) |
| `_publish_status_update(... "starting" ...)` | `"starting"` | `"starting"` |
| `_get_extracted_text` (incl. PDF extraction) | `"text_retrieved"` | `"text_retrieved"` |
| `content_tagger.generate_tags` | `"tagging_complete"` | `"tagging_complete"` |
| `generate_document_summary` + main-doc `update()` | `"summary_generated"` | `"summary_generated"` |
| `_create_enhanced_chunks` | `"chunking_complete"` | `"chunking_complete"` |
| `_generate_embeddings_with_openrouter` | `"embeddings_complete"` | `"embeddings_complete"` |
| `delete_old_vectors_via_service`, `store_chunks_via_service`, `_save_processing_metadata_to_subcollection`, final `"completed"` publish | (no new assignment) | `"embeddings_complete"` (enclosing stage) |

Post-`"completed"` steps (`_update_user_usage`, `_generate_resource_map`) swallow their own exceptions today and cannot fail the job, so no `"completed"` failure stage exists — consistent with the definition's vocabulary, which omits it.

Rejected alternative: deriving the tracker from the *published* progress events (tracker = last published stage). Rejected because a failure during text extraction would then report `"starting"`, which is strictly less useful for support than "failed in the text-retrieval step", and because it would leave the vector-storage window reporting a stage two transitions stale.

Drift risk (a future step added without a tracker assignment) is mitigated by the convention, the AST wiring guard (§8 T5), and representative early/late-stage runtime tests (§8 T2).

### D4 — `retryable` is derived from `classify_error(e)`, never defaulted

Mapping (requirement R4, binding):

| Exception class at failure time | `classify_error` | persisted `retryable` |
|---|---|---|
| `TransientError`, `httpx.ConnectError/ConnectTimeout/ReadTimeout/WriteTimeout/PoolTimeout`, `ConnectionError`, `TimeoutError`, `asyncio.TimeoutError` | transient | `True` |
| `httpx.HTTPStatusError` with status 429/500/502/503/504 | transient | `True` |
| `httpx.HTTPStatusError` with other 4xx/5xx | permanent | `False` |
| `PermanentError` | permanent | `False` |
| **unclassified-unknown** (e.g. `ValueError`, `RuntimeError`, `PermissionError`) | permanent (conservative default) | `False` |

Deliberate behavior change: unclassified-unknown failures previously persisted `retryable: true` via the API's silent default; they now persist `false` — the conservatism `classify_error` was written for. Manual reprocess via `POST /process` is unaffected. The stale-lease sweep keeps its direct `retryable: true` write (a dead worker is a transient condition) and is **not** touched (non-goal).

Mechanics note for the implementer (informational, no scope change): `process_document` currently swallows pipeline exceptions and returns metrics, so `run_worker`'s ACK/NACK branch fires only for out-of-band errors (payload parse, claim). The D4 mapping is mandated by the definition regardless; retry/ACK mechanics are a non-goal and are not modified.

After this change the API's `details.get("retryable", True)` / `"Processing failed"` fallbacks become dead-in-practice for worker failures (no Pub/Sub failure publisher omits the keys) but remain as defensive code for the API's contract — exactly what C3 requires ("must not be the operative mechanism", not "must be deleted").

### D5 — Contract test architecture: three layers, each in its natural home

The seam is covered by (T1–T2) worker-side unit tests, (T3) the cross-service contract test, and (T4–T5) AST drift guards. No CI/workflow changes: files land in directories the existing suites already pick up.

### D6 — Nothing else moves

`_publish_status_update`, `run_worker`, heartbeat/sweep, lease mechanics, `Resource`/`ResourceResponse`, summary `error.code` default (`"UNKNOWN"`), and all frontend surfaces are unchanged.

## 5. Data flow (before → after)

```
BEFORE
  process_document except
    └─ details = {"error": str(e)}
         └─ Pub/Sub rag-status-updates
              └─ rag-api run_transactional_update("failed", details)
                   ├─ main.error       = "Processing failed"   ← fallback
                   ├─ main.error_stage = None                  ← missing key
                   ├─ main.retryable   = True                  ← silent default
                   └─ processing/summary.error = {code:"UNKNOWN",
                      message:"Processing failed", stage:None}

AFTER
  process_document (current_stage tracker set before each step await)
    └─ except: details = build_failure_details(str(e), current_stage, classify_error(e))
         = {"error_message": msg, "stage": stage, "retryable": <bool>, "error": msg}
         └─ Pub/Sub rag-status-updates
              └─ rag-api run_transactional_update("failed", details)   [UNCHANGED]
                   ├─ main.error       = msg
                   ├─ main.error_stage = stage
                   ├─ main.retryable   = <derived bool>
                   ├─ summary.stage = stage
                   └─ processing/summary.error = {code:"UNKNOWN", message:msg, stage:stage}
```

Worked example — a real failure path (`store_chunks_via_service` partial-write `RuntimeError`, unclassified → permanent):

```json
{"error_message": "partial vector write: 40/41 chunks stored, 1 failed — refusing to mark the resource searchable on a partial index",
 "stage": "embeddings_complete",
 "retryable": false,
 "error": "partial vector write: 40/41 chunks stored, 1 failed — …"}
```

## 6. Component changes (file-by-file)

| File | Change |
|---|---|
| `apps/ai-server/rag-worker-service/failure_contract.py` | **NEW.** `UNKNOWN_STAGE = "processing"`, `build_failure_details(...)`. Stdlib-only. |
| `apps/ai-server/rag-worker-service/main.py` | Import from `failure_contract`. `process_document`: init `current_stage = UNKNOWN_STAGE`; tracker assignments per §4 D3 map; exception handler builds payload via `build_failure_details(str(e), current_stage, classify_error(e))` and logs `stage=current_stage`. **Nothing else** — `_publish_status_update`, `run_worker`, sweep, leases untouched. |
| `apps/ai-server/rag-api-service/**` | **NO CHANGES** (D1). |
| `apps/ai-server/tests/integration/test_worker_failure_contract.py` | **NEW.** Cross-service contract test + AST drift guards (§8 T3–T5). Fakes defined in-module (single consumer today; promote to a shared helper only if a second appears). |
| `apps/ai-server/rag-worker-service/tests/unit/test_failure_payload.py` | **NEW.** Builder key-set/value tests, `classify_error` mapping tests, stage-tracker behavior tests via `process_document` with monkeypatched steps (§8 T1–T2). Uses the existing worker test conftest stub table; `asyncio_mode = auto` already set. |

## 7. Contract specification (the pinned seam)

| Payload key | Producer | Consumer (failed branch) | Persisted as | Notes |
|---|---|---|---|---|
| `error_message` | worker: `str(e)` | `details.get("error_message", "Processing failed")` | `main.error`; `summary.error.message` | actual exception message |
| `stage` | worker tracker (D3) | `details.get("stage")` / `details.get("stage", "unknown")` | `main.error_stage`; `summary.error.stage`; `summary.stage` | vocabulary ∪ `"processing"`; never null |
| `retryable` | worker: `classify_error(e)` (D4) | `details.get("retryable", True)` | `main.retryable` | fallback retained but never operative for worker failures (C3) |
| `error` | worker (legacy hedge, C4) | — none in failed branch | — | equal to `error_message`; for unknown topic consumers / log tooling |
| `error_code` | — worker deliberately omits (C5) | `details.get("error_code", "UNKNOWN")` | `summary.error.code` | stays `"UNKNOWN"` |
| `jobId` | `_publish_status_update` enrichment | processing branch only | `summary.job_id` | unchanged; not part of the failure contract |
| `progress` | — omitted on failure | `details.get("progress", 0)` | `summary.progress` | `0` on failure — pre-existing behavior, unchanged |

## 8. Test plan

### T1 — Builder unit tests (`rag-worker-service/tests/unit/test_failure_payload.py`)

- `build_failure_details` returns exactly `{"error_message", "stage", "retryable", "error"}` (exact-set assertion — intentional ossification; adding a key means touching this test).
- `error == error_message` (legacy-key parity).
- Values pass through verbatim (bool not coerced, message not truncated).
- `UNKNOWN_STAGE == "processing"`.

### T2 — `classify_error` mapping + stage-tracker behavior (same file)

- `classify_error` mapping table of §4 D4 (TransientError→True, PermanentError→False, `httpx.ConnectError`→True, `HTTPStatusError` 500→True / 404→False, `ValueError`→False).
- Stage tracker, via `process_document` run against a processor built with `object.__new__(EnhancedDocumentProcessor)` and minimal attributes (`langfuse=None`, `db=MagicMock()`, `embedding_cost_per_token=0.0`), with `_publish_status_update` monkeypatched to capture `(status, details)` and pipeline steps monkeypatched:
  - **Early failure:** `_validate_processing_request` raises `ValueError("boom")` → captured failure details: `error_message=="boom"`, `stage=="processing"`, `retryable is False`.
  - **Mid failure:** `_get_extracted_text` raises `TransientError("gs down")` → `stage=="text_retrieved"`, `retryable is True`.
  - **Late failure:** steps patched through embeddings (`_generate_embeddings_with_openrouter` → `[[0.1]]`), `store_chunks_via_service` raises `RuntimeError("partial vector write")` → `stage=="embeddings_complete"`, `retryable is False`.
  - Payload published with status `"failed"`; the legacy `error` key equals `error_message` in the captured payload.

### T3 — Cross-service contract test (`apps/ai-server/tests/integration/test_worker_failure_contract.py`)

Setup: the existing integration `conftest.py` already mocks rag-api's cloud deps and puts `rag-api-service` on `sys.path` (resolves observation 2 partially); the test additionally:
- imports `failure_contract` from `rag-worker-service` via `importlib.util.spec_from_file_location` (unique module name — no `main` collision, no stubs needed);
- monkeypatches `rag_api_main.firestore.transactional` to an identity decorator (the `test_processing_lease.py` `_tx_identity` pattern);
- uses in-module `FakeTx/FakeSnap/FakeRef/FakeDb` fakes (adapted from `test_processing_lease.py`), seeding the doc with `status: "processing"` so `processing → failed` is an allowed transition.

Cases:
1. **Verbatim persistence:** `details = build_failure_details(error_message="weaviate timeout while embedding chunk 7", stage="embeddings_complete", retryable=False)` → `run_transactional_update(db, doc_ref, "failed", details, logger_stub, user_id)` → assert `doc["error"] == details["error_message"]`, `doc["error_stage"] == details["stage"]`, `doc["retryable"] is details["retryable"]`, `doc["status"] == "failed"`.
2. **Subdocument parity:** `processing/summary` write asserts `error.message == details["error_message"]`, `error.stage == details["stage"]`, `error.code == "UNKNOWN"`, `stage == details["stage"]`.
3. **Fallback regression guard:** persisted `error != "Processing failed"` and `error_stage is not None` (explicit negatives documenting the original bug).
4. **Transient variant:** same flow with `retryable=True` (e.g. message from an `httpx.ConnectError`-class failure) → persisted `retryable is True`.

### T4 — API-side key drift guard (AST, in the same file)

Parse `rag-api-service/main.py`; within `run_transactional_update`, scope to `If` nodes whose test is `new_status == "failed"`; collect first-arg constants of `details.get(...)` calls. Assert:

```
{"error_message", "stage", "retryable"} ⊆ collected
collected ⊆ {"error_message", "stage", "retryable", "error_code"}
```

(i.e. the API still consumes all three contract keys, and any *new* key it starts reading in the failed branch must either exist in the worker payload or be the documented optional `error_code` — otherwise the build fails.)

### T5 — Worker-side wiring guard (AST, in the same file)

Parse `rag-worker-service/main.py`; within `process_document`:
- the exception handler contains a call to `build_failure_details` and no inline dict literal carrying an `"error"` key (the old `{"error": str(e)}` cannot silently return);
- the handler's `build_failure_details` call references `classify_error` (retryable is derived, not hardcoded);
- `current_stage` assignments: ≥ 6, initialized to `"processing"`, and every assigned constant ∈ vocabulary ∪ `{"processing"}`, with `{"starting", "text_retrieved", "embeddings_complete"}` present (representative early/late pinning without ossifying every line).

### T6 — Suite placement

- T1/T2 run under `rag-worker-service` pytest (existing conftest stub table, `asyncio_mode=auto`).
- T3–T5 run under the existing `apps/ai-server/tests/integration` suite (`./dev/run integration`) — no workflow or CI-config changes.

## 9. Acceptance criteria mapping

| Acceptance (from definition) | How met / verified |
|---|---|
| A1: worker's failed status message contains `error_message`, `stage`, `retryable` — none relying on API fallbacks | D2/D3/D4; T1, T2, T5 |
| A2: persisted `error` = actual message (not `"Processing failed"`), `error_stage` = failing stage (not None), `retryable` = derived value | D1 + D2–D4; T3 case 1/3/4 |
| A3: `processing/summary` error subdocument carries the same message and stage | unchanged API failed branch fed real keys; T3 case 2 |
| A4: contract test exists, passes, and fails if either side's payload keys drift | T3–T5 (runtime seam test + both AST drift guards) |

## 10. Risks and tradeoffs

- **Unknown consumers of the status topic** reading the old key set — mitigated by retaining `error` (C4); residual risk accepted as low. Dropping the duplicate later is trivial cleanup if an audit confirms worker→API is the only edge.
- **Stage-tracker drift** as the pipeline evolves — mitigated by the set-before-await convention, T5's AST guard, and T2's representative early/late assertions.
- **`retryable=false` for unclassified-unknown** failures reduces auto-retry affordances for genuinely-transient-but-unrecognized errors — accepted per the definition; widening `classify_error` is out of scope; `POST /process` manual reprocess remains.
- **Contract test ossifies the payload** — intentional; that is the drift guard working. Adding a key later means touching T1/T4, which is the point.
- **Empty `str(e)`** persists `error: ""` (still the actual message; no fallback added — recorded, not fixed).
- **Test-infrastructure fragility** (mocked `firestore.transactional`, `main` name collision) — resolved by design (D2 dependency-free module; T3 identity-decorator monkeypatch + fakes) rather than by duplicating stub tables into shared conftests.

## 11. Out of scope (restated from the definition)

- Stale-lease sweep's direct failure write (already consistent).
- Retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals — only the *reporting* of retryability changes.
- Frontend/mobile changes (`ResourceResponse` already exposes `error` / `error_stage`).
- Structured error codes / failure taxonomy (`summary.error.code` stays `"UNKNOWN"` unless a code is actually sent).
- Companion D3 issue scope (unavailable here) and reconciling with the D4 deviation note in `plans/upload-flow.md` (file absent from the tree) — deferred.

## 12. Implementation conventions for the implementer

1. `failure_contract.py` is the **only** place that spells the failure payload keys; `process_document`'s handler must not inline a dict.
2. Set `current_stage` **immediately before** the await of each pipeline step, per the §4 D3 map; never assign it after an await.
3. Do not touch `rag-api-service/` — if a test seems to require an API change, stop; the design says the API is already correct.
4. The drift guards' exact-set assertions are deliberate; do not soften them into subset checks.
5. Branch/PR flow per `AGENTS.md`: this is a cross-service contract change → feature path with phase branches; PR targets the feature branch, never `main`.
<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>