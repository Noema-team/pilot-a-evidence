# Course Schema V2 Migration

## Purpose

The current course document is functional but contains a compatibility split:
client fields use camelCase while several backend graph fields use legacy
snake_case. The Phase 1–4 fixes make current clients interoperable, but they
do not create one canonical persisted schema.

This document defines the long-term target. It is a separate migration from
the incremental compatibility work and must not be implemented as an
uncoordinated field rename.

## Canonical Firestore Shape

```ts
users/{userId}/courses/{courseId} = {
  name: string,
  description: string | null,
  icon: string,                  // kebab-case, e.g. "book-open"
  color: string,                 // #RRGGBB

  userId: string,
  createdAt: Timestamp,
  updatedAt: Timestamp,
  isArchived: boolean,
  isStarred: boolean,

  connectedResources: {
    resources: string[],
    groups: string[],
  },

  resolved: {
    resourceIds: string[],
    resourceCount: number,
    updatedAt: Timestamp,
  },

  maxResources: number,
  softLimitThreshold: number,
  schemaVersion: 2,
}
```

`courseId` remains the Firestore document ID and is not duplicated unless an
external API specifically requires it.

## Ownership

- Clients may create course metadata and initialize empty relationship arrays.
- Relationship mutations go through one backend course/resource service.
- The Functions resolver exclusively owns `resolved`.
- Clients never write `resolved`, `resourceCount`, or relationship-derived
  fields after creation.
- Every course mutation updates `updatedAt`.
- Python services may use snake_case internal attributes, but convert to and
  from the canonical Firestore shape at the boundary.
- Firestore rules prevent clients from changing server-owned fields.

## Architecture Target

```text
Mobile/Web -> Course API -> Firestore
                         |
                         +-> Cloud Function derives resolved
```

Mobile currently writes course documents directly to Firestore. Moving course
mutations behind the Course API is the preferred end state because it gives
the backend one validation and ownership boundary. The migration must preserve
mobile functionality until that API path is available.

## Migration Sequence

1. Add shared V2 contract types and validation for web, mobile, Python, and
   Functions.
2. Add boundary adapters so every reader accepts V2 and legacy documents.
3. Update Functions and backend writers to dual-write V2 plus legacy fields.
4. Add an idempotent backfill job for existing course documents:
   - `connected_resources` -> `connectedResources`
   - `_resolved` -> `resolved`
   - `resource_ids` -> `resourceIds`
   - `resource_count` -> `resourceCount`
   - `max_resources` -> `maxResources`
   - `soft_limit_threshold` -> `softLimitThreshold`
   - nested `updated_at` -> `updatedAt`
   - set `schemaVersion: 2`
5. Deploy V2-first readers with legacy fallback and monitor fallback usage.
6. Switch all writers to V2-only after the backfill is complete and stable.
7. Remove legacy readers/writers after one defined release window.
8. Add rules that reject client writes to server-owned V2 fields.

The backfill must be idempotent, resumable, and observable. It must not delete
legacy fields until all deployed readers have moved to V2.

## Required Verification

- V2 documents load identically in mobile, web, rag-api, and agent-graph.
- Legacy-only documents continue loading during the migration window.
- Mixed documents prefer V2 values deterministically.
- Resource and group relationship updates keep `resolved` accurate.
- Archived courses remain excluded from user-facing search and listings.
- Client attempts to modify `resolved` or relationship-derived fields are
  rejected by rules/API validation.
- Backfill can be safely re-run and reports migrated, skipped, and failed
  documents.

## Non-Goals

- Do not rename fields in the current Phase 4 PR.
- Do not maintain dual naming indefinitely.
- Do not make Python internal naming dictate the Firestore contract.
- Do not migrate unrelated resource, group, chat, or processing documents as
  part of the course migration.

## Current State

- Phases 1–4 are merged and make current clients interoperable.
- Top-level timestamps currently use a compatibility dual-write.
- Legacy graph fields remain the persisted backend contract.
- This document is the design baseline for a future Course Schema V2 project.
