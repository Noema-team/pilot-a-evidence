# Cycle Charter — rag-worker → rag-api failure payload contract alignment

## Scope
Align the rag-worker's failed-status payload with rag-api's failed-branch contract so a failed RAG processing job persists the worker's actual error message, the failing pipeline stage, and a deliberately derived retryable flag.

In scope:
- `apps/ai-server/rag-worker-service/main.py`: `process_document`'s exception handler publishes `error_message` (actual exception message), `stage` (failing pipeline stage, tracked through the pipeline), and `retryable` (derived from `classify_error(e)`) in the failed-status `details`. The legacy `error` key is retained alongside `error_message` as a compatibility hedge.
- `apps/ai-server/rag-worker-service/main.py`: a local stage tracker inside `process_document`, set immediately before each pipeline step, reusing the existing progress-stage vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown.
- rag-api's failed branch in `run_transactional_update` persists the worker-provided values unchanged (`error` ← payload `error_message`, `error_stage` ← payload `stage`, `retryable` ← payload `retryable`); the processing/summary error subdocument carries the same message and stage with `error_code` remaining `"UNKNOWN"` unless a code is actually sent. Any API-side change is limited to honoring worker-provided values — no reader or schema changes.
- A contract test (in `apps/ai-server/tests/integration/`, following the existing `test_api_contracts.py` patterns, using the Firestore emulator or fakes) that exercises the worker's failure-payload construction through rag-api's failed-branch persistence and asserts the persisted `error`, `error_stage`, and `retryable` equal the worker's values — plus a payload key-set drift guard so a future edit to either side's keys fails the build. Coverage must include at least an early-stage failure and a late-stage failure.

Out of scope (see Boundaries).

## Purpose
Every worker-originated failure currently persists `error` as the fallback "Processing failed", `error_stage` as null, and `retryable` as the silent default `true`, because the worker publishes `{"error": str(e)}` while rag-api's failed branch reads `error_message`/`stage`/`retryable`. Users and support cannot disambiguate failures, and retryability is fabricated rather than derived.

The fix direction is worker-side alignment to `error_message`/`stage`: the persisted fields (`error`, `error_stage`, `retryable`) are the established schema written identically by the stale-lease sweep, rag-api's enqueue-failure paths, and exposed by `Resource`/`ResourceResponse` — the worker's status publisher is the only writer that doesn't speak it. Aligning the worker requires no migration, rename, or backfill.

The retryable derivation is explicit and aligned with the worker's ACK/NACK behavior: `classify_error()` → transient ⇒ `retryable: true` (Pub/Sub will redeliver); permanent (including unclassified-unknown, per `classify_error`'s conservative default) ⇒ `retryable: false` (acked; manual reprocess via `POST /process` remains). This is a deliberate behavior change for unclassified-unknown errors (previously silently `true`, now `false`). The stale-lease sweep's separate `retryable: true` write stays correct: a dead worker is a transient condition.

## Requirements
1. The worker's failed status payload must include `error_message` (the actual exception message), `stage` (the pipeline stage executing at failure time), and `retryable` (deliberately derived) — never relying on rag-api's fallback defaults for these keys.
2. The worker must track the currently executing pipeline stage through `process_document` (set immediately before each pipeline step) so the failure handler reports the true failing stage; stage names reuse the existing progress-stage vocabulary, with `"processing"` as the safe value when the stage is genuinely unknown.
3. The worker retains the legacy `error` key in the failure payload alongside `error_message` for continuity with any unknown consumers of the status topic.
4. rag-api's failed branch must persist worker-provided values unchanged: main document `error` ← payload `error_message`, `error_stage` ← payload `stage`, `retryable` ← payload `retryable`; the processing/summary error subdocument carries the same message and stage.
5. The retryable derivation must be explicit and aligned with the worker's ACK/NACK behavior: `classify_error()` transient ⇒ true; permanent (including unclassified-unknown) ⇒ false.
6. A contract test must cover the worker failure → rag-api persistence path: it must exercise the worker's failure-payload construction and rag-api's failed-branch persistence (via the Firestore emulator or fakes) and assert the persisted `error`, `error_stage`, and `retryable` equal the worker's values; it must fail if either side's payload keys drift.

## Boundaries
Must not / will not change:
- rag-api's reads of the failure payload beyond honoring worker-provided values; the persisted schema field names and semantics (`error`, `error_stage`, `retryable`) stay exactly as they are. No Firestore migration, field rename, or backfill of existing documents.
- The stale-lease sweep's direct failure write (`_fail_if_still_stale`) — it already persists `error`/`error_stage`/`retryable` consistently with this contract.
- Retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals — only the reporting of retryability in the payload changes.
- Frontend or mobile changes — `ResourceResponse` already exposes `error` and `error_stage` to clients.
- No structured error-code taxonomy: the processing/summary error `code` remains `"UNKNOWN"` unless a code is actually sent.

## Version bump
None. The change is confined to service implementation plus a new test; no user-facing package versions, API version, or schema version changes. (`schema_version: 2` on the resource document is untouched; the persisted schema is unchanged by design.)

## Deferred items
- The companion D3 issue referenced by the Objective: its content is not available in this context; anything it covers beyond this worker→rag-api failure payload alignment is deferred.
- Reconciling this analysis with the original D4 deviation note in `plans/upload-flow.md` (that file is not present in the current tree; the reference comes from the Objective text).
- Dropping the legacy `error` duplicate key from the worker's failure payload — pending an audit confirming the worker is the only publisher and rag-api the only consumer of the status topic.
- Widening `classify_error` to recognize more transient-but-unrecognized failure modes (accepted residual risk: some genuinely transient unrecognized errors will persist `retryable: false`; manual reprocess via `POST /process` remains).
- Any structured error-code taxonomy for failure payloads.