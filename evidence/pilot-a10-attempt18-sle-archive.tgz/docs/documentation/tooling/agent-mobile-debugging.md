# Agent Mobile Debugging — driving the app on a device from a session

**Audience:** an agent (opencode/Claude session) working on `apps/mobile`, with
the user's phone connected to the dev machine. Also fine for a careful human —
but the target reader is an agent that can run shell commands.

**Outcome:** the agent can launch the app, watch its logs, drive the UI, take
screenshots as *data* (not bug reports), reproduce a failure, fix code, and
hot-reload — closing the loop without the user relaying anything.

Prerequisites and user-facing workflow: [`apps/mobile/docs/DEVICE-WORKFLOW.md`](../../../apps/mobile/docs/DEVICE-WORKFLOW.md)

---

## Ground rules

1. **The user's phone is their device.** Tap/type only what the current task
   requires. No app installs, settings changes, or file pushes beyond the app
   under test without saying so first.
2. **Never factory-reset, clear app data, or pull personal files.** `adb shell
   input`, `screencap`, `logcat`, and `am` on the target package are the scope.
3. **Logs may contain the user's data.** Treat captured logs/screenshots as
   sensitive: keep them in the working tree or `/tmp`, never paste tokens.
4. If the device disappears (`adb devices` empty) stop and ask — don't spin.

## Step 0 — preflight

```bash
adb devices -l                 # exactly one device, state "device" (not "unauthorized")
flutter devices                # toolchain sees it too
adb reverse --list             # note existing port mappings
```

If `unauthorized`: the phone is showing a trust dialog — ask the user to accept
it. Do not retry in a loop.

## Step 1 — wire the backend

Two connections: the HTTP gateway (via `adb reverse`) and Firebase emulators
(via dart-defines at launch — see Step 2). Reverse mappings do not survive
reboots/replugs:

```bash
# hermetic stack (free, deterministic, recommended default)
./dev/run env up --profile fidelity && ./dev/run seed
adb reverse tcp:13001 tcp:13001
```

The app's Backend URL is set in-app (Dashboard → API Settings →
`http://localhost:13001`). Two traps: only **Save** persists it (dismiss
discards), and it's read at client construction — **restart the app** after
changing it.

Firebase needs the emulator flavor at launch (Step 2):
`--dart-define=USE_EMULATOR=true --dart-define=EMULATOR_HOST=<host-LAN-IP>`.
Never `localhost`/`127.0.0.1` for EMULATOR_HOST — the Firebase Android SDK
remaps both to `10.0.2.2` (AVD-only) and every emulator call silently fails.
Watch the log line `Mapping ... Emulator host` — if you see it, the host is
wrong.

Emulator failure modes you will hit (fixes verified live):

| Symptom | Cause | Fix |
|---|---|---|
| `too_many_pings` / `ENHANCE_YOUR_CALM`, streams close | Firestore emulator vs gRPC keepalives | `docker restart student-platform-test-firebase-emulator-1`, then `dev/run env seed` + `dev/run seed` (restart wipes data) |
| 401 everywhere after stack work | emulator restart revoked ID tokens | sign out + back in on the phone |
| `sign_in_failed` on Google button | device without real Play services (microG) | use email/password (`alice@test.local` / `test-password-alice`) |
| `[firebase_storage/no-bucket]` at startup | emulator FirebaseOptions missing storageBucket | fixed in `bootstrap.dart`; if it returns, the bucket is `student-platform-test.appspot.com` |

## Step 2 — launch with logs streaming

Run in background, log to a file you own:

```bash
cd apps/mobile
nohup flutter run --flavor development --target lib/main_development.dart \
  --dart-define=USE_EMULATOR=true --dart-define=EMULATOR_HOST=<host-LAN-IP> \
  -d <device-id> > /tmp/mobile-run.log 2>&1 &
```

(For the real-project Firebase instead of emulators, drop both dart-defines.)

- First build takes minutes; watch the log until "Flutter run key commands"
  appears (or a Dart VM Service URI is printed) before touching the device.
- **`/tmp/mobile-run.log` is the single source of truth for errors.** Every
  exception, stack trace, and `print` lands there in text form.
- To interact with a *running* session you started this way, note the VM
  Service URI from the log; for a fresh interactive session, use
  `flutter attach -d <device-id>`.

## Step 3 — observe

```bash
tail -f /tmp/mobile-run.log                      # Dart errors + prints
adb logcat -s flutter -d | tail -100            # recent framework output
adb exec-out screencap -p > /tmp/opencode/screen.png   # look, don't ask
adb shell dumpsys window | grep mCurrentFocus   # which screen is actually up
```

**Reading the screen as text** (more reliable than screenshots for driving
the UI — and the only option if the session can't view images):

```bash
adb shell uiautomator dump /sdcard/ui.xml && adb pull /sdcard/ui.xml
# every visible label + its bounds: [x1,y1][x2,y2] — tap the center
```

Caveats learned live: Flutter `TextField`s appear as bare `EditText` nodes
(no label — identify by position); empty text means the field is empty;
autofill/account pickers can hijack the first field tap (dismiss with
`input keyevent 4` and re-tap). Type with `input text "..."`, close the
keyboard with `input keyevent 111` (ESC) — **never** keyevent 4 (BACK) in a
form: it exits the app. Clear a field with `input keyevent 123` (move to
end) then repeated `keyevent 67` (delete).

Two more caveats from the chat-sheet validation (PR #42): `keyevent 111`
(ESC) closes a **modal bottom sheet**, not just the keyboard — with a
sheet open, it dumps the user back to the page behind it. Inside a sheet,
tap neutral space to close only the keyboard. And the uiautomator dump
omits transient widgets — snackbars never appear in it — so use the dump
for tap targets, `screencap` for state assertions.

Read the screenshot before driving the UI — coordinates come from what's on
screen now, not from what you expect.

## Step 4 — drive

```bash
adb shell input tap 540 1200            # tap at coordinates
adb shell input swipe 540 1500 540 500  # scroll up
adb shell input text "what is overfitting"
adb shell am force-stop com.example.verygoodcore.student_app.dev   # cold restart (dev-flavor package; discover via
                                      # `pm list packages | grep student` — it differs per flavor)
```

Get coordinates from a screenshot (view the image, compute pixel positions).
Long-press = `input swipe x y x y 600`.

To find widget keys instead of pixels, read the widget code — `Key('…')`
values in `apps/mobile/lib/` are stable targets for integration tests later.

### Input reliability (learned live — chat-sheet validation, PR #42)

- **Buttons move with the keyboard.** A send button's bounds depend on IME
  state. Re-dump after any keyboard state change and prefer the
  keyboard-closed position — it is the stable target. Tapping a stale
  coordinate misses silently.
- **Typed text is the least reliable input.** `input text` can silently
  fail, and text from earlier attempts lingers in the field. Verify the
  field's content in the uiautomator dump before submitting — a "send did
  nothing" is usually text that never landed.
- **Prefer chips.** Anything that triggers the action directly (suggestion
  chips, buttons) beats type-then-submit; it sidesteps both problems above.

## Step 4b — failure injection and persistence checks

Offline / error-path validation:

- **Airplane mode does NOT cut an adb-reverse'd gateway.** The tunnel
  rides USB, so the app still reaches the gateway and an offline test
  false-passes. Make the gateway unreachable by removing the mapping (the
  network stays up — this isolates the gateway, not the radio):

  ```bash
  adb reverse --remove tcp:13001   # gateway unreachable
  adb reverse tcp:13001 tcp:13001  # restore
  ```

- **Trust the gateway, not the UI.** The hermetic gateway logs requests —
  count them before/after an action that must *not* reach the network (a
  failed send, an offline retry). A flat counter is the real proof.

Restart / persistence validation:

```bash
adb shell am force-stop com.example.verygoodcore.student_app.dev
adb shell monkey -p com.example.verygoodcore.student_app.dev -c android.intent.category.LAUNCHER 1
adb shell run-as com.example.verygoodcore.student_app.dev cat shared_prefs/FlutterSharedPreferences.xml
```

If restore-on-launch replays persisted state (e.g. an unsent message),
watch for **restore races**: restore can run before the state it depends
on (e.g. the auto-selected course) is ready. Make restore reactive to the
dependency appearing, not a run-once side effect.

## Step 5 — the fix loop

1. Failure observed: find the stack trace in `/tmp/mobile-run.log`.
2. Read the throwing code; form a hypothesis; state it before editing.
3. Edit; then hot reload if a session is attached:
   - `flutter attach` sessions accept `r` on stdin; for a nohup'd `flutter
     run` the simplest reliable path is to kill and re-run — build cache makes
     this ~seconds for small changes.
4. Reproduce: same taps, same screen, watch the log.
5. Repeat until the log is clean through the flow, then report with the
   before/after log excerpt.
6. Assert each step through **two independent channels** — log +
   screenshot, a11y dump + gateway request count, prefs file + UI. Any
   single channel (the a11y tree especially) can lie about transient state.

## When not to tap — write a test instead

If a flow needs driving more than twice, or you're re-verifying a regression,
stop hand-driving: add a widget/integration test under `apps/mobile/test/` or
`integration_test/` that encodes the steps. The mobile app currently has no
executable tests (documented gap — see TUNING-GUIDE "Not measured yet"), and
every flow you encode becomes one the whole verification system can see.

Patrol (`patrol` package) extends `integration_test` with native control
(permission dialogs, notifications) when plain Flutter APIs aren't enough.

## Teardown

```bash
adb reverse --remove-all        # if you added mappings
./dev/run env down              # if you started the hermetic stack
```

Leave the phone as you found it. Mention anything you installed or changed.
