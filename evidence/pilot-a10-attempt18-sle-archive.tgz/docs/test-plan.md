# Test Plan: worker failure → rag-api persistence contract

## Scope

Cover the seam the definition pins: the worker's failure-payload construction and rag-api's failed-branch persistence, asserting persisted `error`, `error_stage`, `retryable` (and the `processing/summary` error subdocument) equal the worker's values, with drift guards on both sides' key sets.

## Test infrastructure

- Location: `apps/ai-server/tests/integration/test_failure_payload_contract.py`, alongside the existing `test_api_contracts.py`; reuse `conftest.py` (env defaults + mocked cloud modules).
- Firestore: prefer the hermetic emulator branch (`FIRESTORE_EMULATOR_HOST`, already supported by both services) when the emulator is available in CI; otherwise use the fake transaction/db pattern established by the existing contract tests. The assertions are identical either way.
- Worker import seam: tests call the extracted `build_failure_details(error, stage, job_id)` helper (production code) — they must not restate the payload dict inline. rag-api persistence is driven through `run_transactional_update`'s failed branch (or the extracted `_persist_failure` helper if one is introduced per plan Step 6) — again production code, not a fixture copy.

## Test cases

### Class `TestWorkerFailurePayload`

1. `test_payload_contains_aligned_keys` — `build_failure_details(ValueError("boom"), "summary_generated", "job-1")` returns a dict containing `error_message == "boom"`, `stage == "summary_generated"`, and a boolean `retryable`.
2. `test_payload_retains_legacy_error_key` — legacy `error` key present and equal to `error_message` (compatibility hedge; contract-binds its presence so removal is a deliberate test change).
3. `test_payload_keys_exact_set` — drift guard: the returned dict's key set is exactly `{"error_message", "error", "stage", "retryable", "jobId"}`. Any added/removed key fails the build until the test is updated intentionally.
4. `test_transient_error_is_retryable` — a `TransientError` (and e.g. `httpx.ConnectTimeout`) yields `retryable is True`.
5. `test_permanent_error_is_not_retryable` — a `PermanentError` yields `retryable is False`.
6. `test_unknown_error_is_not_retryable` — an unrecognized exception type (e.g. `KeyError`) yields `retryable is False` (pins the deliberate behavior change vs. the old silent `True` default).
7. `test_http_5xx_is_retryable_4xx_is_not` — `httpx.HTTPStatusError` with a 503 response → `True`; with a 400 response → `False`.
8. `test_job_id_included` — `jobId` present when provided; helper tolerates `None` job_id without crashing.

### Class `TestWorkerStageTracking`

9. `test_early_stage_failure_reports_starting_or_text_stage` — with a stubbed processor where `_get_extracted_text` raises, the failed status payload's `stage` is the stage assigned immediately before that await (early pipeline stage), never `None` and never a late-stage name.
10. `test_late_stage_failure_reports_embeddings_stage` — with a stubbed processor where `store_chunks_via_service` raises, the payload's `stage == "embeddings_complete"`.
11. `test_stage_reuses_progress_vocabulary` — every stage value observable in failure payloads is a member of the existing progress-stage set `{starting, text_retrieved, tagging_complete, summary_generated, chunking_complete, embeddings_complete, processing}` (drift guard against invented stage names).
12. `test_unknown_stage_falls_back_to_processing` — a failure before the first stage assignment (if reachable) reports `"processing"`, not `None`.

(Implementation: subclass or monkeypatch `EnhancedDocumentProcessor` methods to raise; capture `_publish_status_update` calls via a spy — no real Pub/Sub.)

### Class `TestWorkerApiFailurePersistence`

13. `test_worker_failure_persists_actual_message` — build a worker failure payload via `build_failure_details(ValueError("boom: bad pdf"), "chunking_complete", "job-9")`, feed it through rag-api's failed branch against the emulator/fake resource document; assert persisted main-doc `error == "boom: bad pdf"` (not `"Processing failed"`).
14. `test_persisted_error_stage_equals_worker_stage` — persisted `error_stage == "chunking_complete"` (not `None`).
15. `test_persisted_retryable_equals_worker_value` — run the same payload twice, once with a transient-classified error and once with a permanent-classified error; persisted `retryable` equals the worker's derived boolean in both cases (proves the API fallback `True` is not the operative mechanism).
16. `test_processing_summary_error_subdocument_matches` — the `processing/summary` subdocument's error `message` and `stage` equal the worker's `error_message` and `stage`; `error_code == "UNKNOWN"` when no code was sent.
17. `test_end_to_end_stage_and_message_survive_the_seam` — combined case: stubbed processor fails at a known stage with a distinctive message; drive the produced payload through rag-api persistence; assert all three persisted fields match in one scenario (this is the canonical acceptance check).

### Class `TestFailureContractDriftGuards` (static, following the AST/source-inspection pattern of `test_api_contracts.py`)

18. `test_worker_publishes_aligned_keys_only` — inspect the worker's exception-handler source (AST): the failed `_publish_status_update` call routes through `build_failure_details` (or constructs all three keys `error_message`, `stage`, `retryable` inline). A regression to `{"error": str(e)}` alone fails.
19. `test_rag_api_failed_branch_reads_aligned_keys` — inspect rag-api's `run_transactional_update` failed-branch source: it reads `error_message`, `stage`, and `retryable` from details. Renaming either side's keys fails the build.
20. `test_persisted_schema_names_unchanged` — rag-api's failed branch (and/or `ResourceResponse` model fields via the existing cached-field helper) still persists/exposes `error`, `error_stage`, `retryable` — guarding the no-migration constraint.

## Acceptance mapping

- Definition acceptance #1 → tests 1–3, 8, 9–12, 18.
- Acceptance #2 → tests 13–15, 19.
- Acceptance #3 → test 16.
- Acceptance #4 → tests 17, 18–20 (full seam exercised + drift guards).

## Non-goals in testing

- No test of ACK/NACK mechanics, lease expiry, heartbeat intervals, or the sweep (unchanged behavior).
- No test asserting the legacy `error` key is *read* by rag-api — it is ignored there by design.
- No frontend/model fixture changes beyond the static guard on existing field names.