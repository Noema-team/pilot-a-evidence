import json
import os
import sys
import subprocess

import main as rag_api_main

FIXTURES_DIR = os.path.join(os.path.dirname(__file__), "..", "fixtures", "api-contracts")


def load_contract(fixture_name):
    path = os.path.join(FIXTURES_DIR, fixture_name)
    with open(path) as f:
        return json.load(f)


AGENT_GRAPH_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "agent-graph-service")


_RAG_API_MODEL_FIELDS_CACHE = None


def _get_cached_rag_api_model_fields():
    global _RAG_API_MODEL_FIELDS_CACHE
    if _RAG_API_MODEL_FIELDS_CACHE is None:
        _RAG_API_MODEL_FIELDS_CACHE = {
            "ResourceResponse": sorted(rag_api_main.ResourceResponse.model_fields.keys()),
            "ListResourcesResponse": sorted(rag_api_main.ListResourcesResponse.model_fields.keys()),
            "GroupResponse": sorted(rag_api_main.GroupResponse.model_fields.keys()),
            "ListGroupsResponse": sorted(rag_api_main.ListGroupsResponse.model_fields.keys()),
        }
    return _RAG_API_MODEL_FIELDS_CACHE


def _get_agent_graph_shapes():
    main_path = os.path.abspath(os.path.join(AGENT_GRAPH_DIR, "src", "main.py"))
    script = """\
import ast, json, sys

main_py = sys.argv[1]
with open(main_py) as f:
    source = f.read()

tree = ast.parse(source)

allowed_keys = set()
for node in ast.walk(tree):
    if isinstance(node, ast.Assign):
        for t in node.targets:
            if isinstance(t, ast.Name) and t.id == 'ALLOWED_KEYS':
                if isinstance(node.value, ast.Set):
                    allowed_keys = {elt.value for elt in node.value.elts if isinstance(elt, ast.Constant)}

event_types = set()
event_fields = {}
for node in ast.walk(tree):
    if isinstance(node, ast.Dict):
        type_val = None
        for key, value in zip(node.keys, node.values):
            if isinstance(key, ast.Constant) and key.value == 'type':
                if isinstance(value, ast.Constant):
                    type_val = value.value
        if type_val:
            event_types.add(type_val)
            fields = set()
            for key in node.keys:
                if isinstance(key, ast.Constant):
                    fields.add(key.value)
            if type_val not in event_fields:
                event_fields[type_val] = fields
            else:
                event_fields[type_val] |= fields

done_fields = set()
for node in ast.walk(tree):
    if isinstance(node, ast.Subscript):
        if isinstance(node.value, ast.Name) and node.value.id == 'done_event':
            if isinstance(node.slice, ast.Constant):
                done_fields.add(node.slice.value)

thread_fields = set()
for node in ast.walk(tree):
    if isinstance(node, ast.Call):
        if (isinstance(node.func, ast.Attribute)
            and node.func.attr == 'append'
            and isinstance(node.func.value, ast.Name)
            and node.func.value.id == 'results'):
            if node.args and isinstance(node.args[0], ast.Dict):
                for key in node.args[0].keys:
                    if isinstance(key, ast.Constant):
                        thread_fields.add(key.value)

response_fields = set()
for node in ast.walk(tree):
    if isinstance(node, ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id == 'response_payload':
                if isinstance(node.value, ast.Dict):
                    for key in node.value.keys:
                        if isinstance(key, ast.Constant):
                            response_fields.add(key.value)

msg_fields = set()
for node in ast.walk(tree):
    if isinstance(node, ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id == 'msg':
                if isinstance(node.value, ast.Dict):
                    for key in node.value.keys:
                        if isinstance(key, ast.Constant):
                            msg_fields.add(key.value)
for node in ast.walk(tree):
    if isinstance(node, ast.Subscript):
        if isinstance(node.value, ast.Name) and node.value.id == 'msg':
            if isinstance(node.slice, ast.Constant):
                msg_fields.add(node.slice.value)

print(json.dumps({
    'allowed_keys': sorted(allowed_keys),
    'event_types': sorted(event_types),
    'event_fields': {k: sorted(v) for k, v in event_fields.items()},
    'done_event_fields': sorted(done_fields | {'type'}),
    'thread_fields': sorted(thread_fields),
    'chat_response_fields': sorted(response_fields),
    'message_fields': sorted(msg_fields),
}))
"""
    result = subprocess.run(
        [sys.executable, "-c", script, main_path],
        capture_output=True, text=True, timeout=30,
    )
    if result.returncode != 0:
        raise RuntimeError(f"Subprocess failed: {result.stderr}")
    return json.loads(result.stdout.strip())


MOBILE_RESOURCE_FIELDS = {
    "resource_id", "filename", "status", "group_ids", "course_ids",
    "total_pages", "total_chunks", "created_at", "updated_at",
    "storage_url", "error", "error_stage",
}

MOBILE_RESOURCE_OPTIONAL = {
    "group_ids", "course_ids", "total_pages", "total_chunks",
    "storage_url", "error", "error_stage",
}

MOBILE_GROUP_FIELDS = {
    "group_id", "name", "description", "resource_ids",
    "resource_count", "max_resources", "created_at", "updated_at",
}

MOBILE_PAGINATION_FIELDS = {"total", "has_more"}

MOBILE_CHAT_MESSAGE_FIELDS = {
    "message_id", "role", "content", "created_at",
}

MOBILE_CHAT_THREAD_FIELDS = {
    "thread_id", "name", "course_id", "created_at", "updated_at", "message_count",
}

MOBILE_CHAT_RESPONSE_FIELDS = {
    "response", "message_id", "thread_id", "agent_mode", "model", "created_at",
}

MOBILE_UPLOAD_RESULT_FIELDS = {
    "resource_id", "status", "message",
}


class TestResourceResponseContract:
    def test_resource_response_has_all_mobile_required_fields(self):
        fields = set(_get_cached_rag_api_model_fields()["ResourceResponse"])
        missing = MOBILE_RESOURCE_FIELDS - fields
        assert not missing, f"Backend ResourceResponse missing fields: {missing}"

    def test_resource_response_optional_fields_present(self):
        fields = set(_get_cached_rag_api_model_fields()["ResourceResponse"])
        optional_mobile = MOBILE_RESOURCE_OPTIONAL
        assert optional_mobile.issubset(fields), f"Missing optional fields: {optional_mobile - fields}"

    def test_resource_response_status_is_string_field(self):
        fields = _get_cached_rag_api_model_fields()["ResourceResponse"]
        assert "status" in fields

    def test_resource_response_includes_storage_url(self):
        fields = set(_get_cached_rag_api_model_fields()["ResourceResponse"])
        assert "storage_url" in fields, "storage_url must be in ResourceResponse model — mobile requires it"

    def test_resource_response_includes_error_stage(self):
        fields = set(_get_cached_rag_api_model_fields()["ResourceResponse"])
        assert "error_stage" in fields, "error_stage must be in ResourceResponse model — mobile requires it"

    def test_resource_response_contract_fixture_fields_match(self):
        contract = load_contract("resource_response.json")
        backend_fields = set(_get_cached_rag_api_model_fields()["ResourceResponse"])
        expected_fields = set(contract["expected_fields"].keys())
        overlap = expected_fields & backend_fields
        assert len(overlap) >= 10, f"Too few matching fields between fixture and backend: {overlap}"


class TestListResourcesResponseContract:
    def test_list_resources_has_pagination_fields_mobile_expects(self):
        fields = set(_get_cached_rag_api_model_fields()["ListResourcesResponse"])
        missing = MOBILE_PAGINATION_FIELDS - fields
        assert not missing, f"ListResourcesResponse missing pagination fields: {missing}"

    def test_list_resources_includes_has_more(self):
        fields = set(_get_cached_rag_api_model_fields()["ListResourcesResponse"])
        assert "has_more" in fields, "has_more field must be in ListResourcesResponse to match mobile PaginatedResponse expectations"


class TestGroupResponseContract:
    def test_group_response_has_all_mobile_required_fields(self):
        fields = set(_get_cached_rag_api_model_fields()["GroupResponse"])
        missing = MOBILE_GROUP_FIELDS - fields
        assert not missing, f"Backend GroupResponse missing fields: {missing}"

    def test_group_response_max_resources_present(self):
        fields = set(_get_cached_rag_api_model_fields()["GroupResponse"])
        assert "max_resources" in fields


class TestListGroupsResponseContract:
    def test_list_groups_includes_has_more(self):
        fields = set(_get_cached_rag_api_model_fields()["ListGroupsResponse"])
        assert "has_more" in fields, "has_more must be in ListGroupsResponse to match mobile expectations"


class TestSSEChatStreamContract:
    def test_token_event_shape_matches(self):
        shapes = _get_agent_graph_shapes()
        token_fields = set(shapes["event_fields"]["token"])
        assert "type" in token_fields
        assert "content" in token_fields

    def test_done_event_shape_matches_mobile(self):
        shapes = _get_agent_graph_shapes()
        done_fields = set(shapes["done_event_fields"])
        assert "message_id" in done_fields, "Backend done event must include message_id"
        assert "full_response" in done_fields, "Backend done event must include full_response"
        assert "thread_id" in done_fields, "Backend done event must include thread_id"
        assert "type" in done_fields

    def test_error_event_shape_matches_mobile(self):
        shapes = _get_agent_graph_shapes()
        error_fields = set(shapes["event_fields"]["error"])
        assert "error" in error_fields
        assert "type" in error_fields

    def test_source_event_emitted_by_backend(self):
        shapes = _get_agent_graph_shapes()
        event_types = set(shapes["event_types"])
        assert "source" in event_types, "Backend must emit 'source' SSE event type for search citations"

    def test_state_update_also_emitted_for_internal_state(self):
        shapes = _get_agent_graph_shapes()
        event_types = set(shapes["event_types"])
        assert "state_update" in event_types, "Backend emits 'state_update' for internal state alongside 'source'"


class TestChatThreadsContract:
    def test_thread_list_shape_matches(self):
        shapes = _get_agent_graph_shapes()
        backend_fields = set(shapes["thread_fields"])
        missing = MOBILE_CHAT_THREAD_FIELDS - backend_fields
        assert not missing, f"Backend thread object still missing fields: {missing}"

    def test_thread_fields_match_mobile_names(self):
        shapes = _get_agent_graph_shapes()
        backend_fields = set(shapes["thread_fields"])
        assert "name" in backend_fields, "Backend must use 'name' field (not 'title')"
        assert "updated_at" in backend_fields, "Backend must use 'updated_at' field (not 'last_updated')"
        assert "created_at" in backend_fields, "Backend must include 'created_at'"
        assert "message_count" in backend_fields, "Backend must include 'message_count'"


class TestChatMessagesContract:
    def test_message_shape_matches(self):
        shapes = _get_agent_graph_shapes()
        backend_fields = set(shapes["message_fields"])
        missing = MOBILE_CHAT_MESSAGE_FIELDS - backend_fields
        assert not missing, f"Backend message object still missing fields: {missing}"

    def test_message_includes_message_id(self):
        shapes = _get_agent_graph_shapes()
        backend_fields = set(shapes["message_fields"])
        assert "message_id" in backend_fields, "Backend messages must include message_id"

    def test_message_includes_created_at(self):
        shapes = _get_agent_graph_shapes()
        backend_fields = set(shapes["message_fields"])
        assert "created_at" in backend_fields, "Backend messages must include created_at"


class TestChatResponseContract:
    def test_non_streaming_response_shape_matches(self):
        shapes = _get_agent_graph_shapes()
        backend_fields = set(shapes["chat_response_fields"])
        missing = MOBILE_CHAT_RESPONSE_FIELDS - backend_fields
        assert not missing, f"Backend non-streaming response missing fields: {missing}"

    def test_response_uses_flat_response_field(self):
        shapes = _get_agent_graph_shapes()
        backend_fields = set(shapes["chat_response_fields"])
        assert "response" in backend_fields, "Backend must return flat 'response' string, not 'messages' array"


class TestUploadResultContract:
    def test_upload_result_mobile_expected_fields(self):
        contract = load_contract("upload_result_response.json")
        mobile_fields = set(contract["mobile_expected_fields"].keys())
        assert "resource_id" in mobile_fields
        assert "status" in mobile_fields
        assert "message" in mobile_fields


class TestContractFixturesIntegrity:
    def test_all_contract_fixtures_have_required_metadata(self):
        fixtures = [
            "resource_response.json",
            "list_resources_response.json",
            "group_response.json",
            "list_groups_response.json",
            "sse_chat_events.json",
            "chat_response.json",
            "chat_threads_response.json",
            "chat_messages_response.json",
            "upload_result_response.json",
        ]
        for name in fixtures:
            contract = load_contract(name)
            assert "_contract" in contract, f"{name} missing _contract metadata"
            assert "endpoint" in contract["_contract"], f"{name} missing endpoint in _contract"
            assert "mobile_file" in contract["_contract"], f"{name} missing mobile_file in _contract"

    def test_resource_fixture_sample_has_all_expected_fields(self):
        contract = load_contract("resource_response.json")
        sample = contract["sample"]
        expected = set(contract["expected_fields"].keys())
        actual = set(sample.keys())
        assert expected == actual, f"Sample fields don't match expected_fields: missing={expected - actual}, extra={actual - expected}"
