# Autonomous Verification — System Assessment & Build Plan

> **Status:** Proposal
> **Created:** 2026-08-15
> **Goal:** Make build → test → tweak → re-test runnable by an AI agent without a human in the loop.
> **Using it:** [`TUNING-GUIDE.md`](./TUNING-GUIDE.md)
> **Related:** [`EVAL-AND-TUNING-SPEC.md`](./EVAL-AND-TUNING-SPEC.md), [`TESTING-STRATEGY.md`](./TESTING-STRATEGY.md), [`Dev Framework - Docs`](./Documentation/Dev%20Framework%20-%20Docs.md)

---

## 1. What the system actually looks like today

Three clients, one real backend, one shadow backend:

| Component | Role | Tests | Notes |
|---|---|---|---|
| `apps/ai-server/` (10 services) | The real backend | ~650 | 369 of the last ~600 commits. This is the system. |
| `apps/mobile/` (Flutter) | Primary client | **0 executable** | `test/` is `.gitkeep` files + a `pumpApp` helper. |
| `apps/web/` (React + Express) | Second client **and** a second backend | **0** | Has its own `server/services/{chat,flashcard,resources,ocr}.service.ts`, its own Firestore access, and Mistral for OCR — partly duplicating ai-server, partly proxying to it via `server/aiBackendClient.ts`. **Separately maintained; out of scope for this plan** (see §6). |
| `dev/` | Collector + context-pack framework | n/a | Good bones. Observes; does not verify. |

### The backend pipeline, end to end

```
upload (client → Firebase Storage) → POST /api/resources
   → Pub/Sub → rag-worker pdf_processor (7 stages, 1220 lines)
       download → extract → markdown → chunk → embed → weaviate → resource_map
   → resource map in Firestore (sections, keywords, page ranges, flashcard coverage)

chat: gateway → agent-graph LangGraph
   preprocessor → coref → rewrite → classifier → router → agent [→ handoff_router → agent]
   agents: rag_agent | teaching_agent | problem_solving_agent | study_advice_agent

flashcards: flashcard-service
   resource map section → LLM generation (4 card types) → dedup (sentence-transformers)
   → save → SM-2 review → coverage writeback onto the resource map
```

---

## 2. The core finding

**Test coverage is not the blocker. Determinism and environment are.**

The existing ~650 tests are real and useful, but they verify the system with every interesting part replaced by a mock. There is currently **no way to run the actual pipeline** — upload a PDF, get a resource map, ask a question, get a grounded answer — anywhere, by anyone, without a human hand-configuring credentials.

Four concrete reasons:

**2.1 No hermetic environment.** Every service reaches for real Firebase Auth, real Firestore, real Firebase Storage, real GCP Pub/Sub. There is exactly one `FIRESTORE_EMULATOR_HOST` reference in the tree (`tests/integration/test_chat_pipeline.py:35`) and one `PUBSUB_EMULATOR_HOST` (`rag-worker-service/main.py:1644`). Neither is wired into `docker-compose.yml`. The E2E scenario runner (`dev/collectors/integration/`) needs a hand-populated `.env` with a Firebase web API key and a service-account JSON, plus a pre-existing test user (`TEST_USER_UID` is hardcoded to a real UID). An agent in a fresh container cannot run any of it.

**2.2 Every feature you named is LLM-mediated, and nothing pins the LLM.** Coref, rewrite, classification, all four agents, flashcard generation, and embeddings are live network calls. No cassettes, no fakes, no seeded sampling. So the interesting paths are either untested or non-reproducible, and a test-tweak loop over them would be scoring noise.

The good news: this is cheap to fix. `OPENAI_BASE_URL` (`agent-graph-service/src/config.py:5`), `openrouter_base_url` (`flashcard-service/config.py:40`, `rag-worker-service/main.py:231`) are **all env-configurable already**. A record/replay proxy is a one-env-var change per service, not a refactor.

**2.3 No seeded corpus.** The eval spec's Phase 1 opens with "upload 3-5 real documents to the platform via the mobile app or API, note the `resource_id` values." That's a manual bootstrap in the middle of what's supposed to be an automated system. Every eval run and every E2E journey needs a known corpus with stable IDs, created by a script.

**2.4 `dev/run` produces prose, not a verdict.** It emits `.devloop/context-pack.md` for a human or an agent to *read*. There is no machine-checkable pass/fail, no thresholds, no baseline to diff against. An autonomous loop needs an exit code and a structured list of which invariants broke.

---

## 3. Coverage of the three domains you named

### 3.1 AI chat — the types are barely verified, and the mapping has a bug

There are two overlapping notions of "chat type":

| Layer | Values |
|---|---|
| Classifier output (LLM, 6 labels) | `SEARCH`, `REFINE`, `TEACHING_CONCEPTUAL`, `PROBLEM_SOLVING`, `STUDY_ADVICE`, `CHAT` |
| User-selectable `agent_mode` (4) | `search`, `teach`, `solver`, `tutor` |
| Actual agent nodes (4) | `rag_agent`, `teaching_agent`, `problem_solving_agent`, `study_advice_agent` |

What's tested: `router_node`'s pure dispatch and the graph's structure (24 tests, `c0584ac`). That's the deterministic 5% of the routing decision.

What isn't: **the classifier itself** — the LLM call that actually decides which agent a user's question reaches. Zero tests run a real question through it. Routing accuracy is the single highest-leverage metric in the whole system (it's cheap, it's deterministic to *score*, and getting it wrong makes every downstream metric meaningless), and it is currently unmeasured.

Also worth flagging as a likely defect for the first eval run to catch: `CLASSIFICATION_TO_AGENT` maps `"CHAT": "teaching_agent"` (`agent-graph-service/src/agents/router.py:18`). Casual conversation and greetings get handled by the conceptual-teaching agent. There is also no `agent_mode` value that reaches `REFINE` behaviour, and `MODE_TO_AGENT` silently falls through to `rag_agent` on an invalid mode rather than erroring.

Untested beyond routing: agent chaining / handoff, SSE stream interruption, the general-chat (no `course_id`) path, thread ownership at the integration level, cost-tracker firing during a real chat.

### 3.2 Flashcards — the algorithm is tested, the system isn't

Tested: SM-2 scheduling, markdown parsing, models (~20 unit tests). Genuinely good coverage of the pure logic.

Not tested at all:
- **Generation** (`flashcard_generator.py`, LLM, 4 card types with a type-distribution allocator) — no test asserts a generated card is answerable from its section, that cloze cards have exactly one well-formed deletion, or that the requested type distribution is honoured.
- **Duplicate detection** (`duplicate_detector.py`, sentence-transformers embeddings, similarity thresholds) — no test, and the thresholds are unvalidated numbers.
- **The coverage feedback loop** — `flashcard-service/main.py:1130-1144` writes `has_flashcards` / `coverage_status` back onto the resource map. Nothing verifies that generating cards for a section actually flips its status, or that deleting the last card flips it back to `none`. This is the loop that makes the map a *study tool* rather than a table of contents.
- All 13 flashcard endpoints have gateway-level happy-path tests only; zero error-path tests.

### 3.3 Documents — the least tested code is the most important promise

`pdf_processor.py` is 1220 lines across seven stages with retry handling, a circuit breaker, and per-stage status updates. `rag-worker-service` has **three unit test files** (chunking, content tagger, utils). There is **no integration test of the pipeline at all** — nothing that takes a PDF in and asserts a resource map out.

Specifically unverified:
- Structure extraction quality. `ResourceMap.extraction_confidence` is `high|medium|low` and `extraction_method` is `markdown|llm_fallback|heuristic` — self-reported, never validated against ground truth. Nothing checks that a document with 12 headings yields 12 sections, or that the fallback fires when it should.
- Chunk↔section linkage. `Section.chunk_ids` is what makes "study this section" work; nothing asserts chunks land in the right section or that page ranges are right.
- The status machine. Seven stages emit progress a client polls; no test walks a resource through the transitions or verifies a failed stage sets `error_stage` correctly.
- **Retrieval actually working on a known corpus.** The thing the user cares about — "I uploaded this, ask about it, get the right answer" — has no test anywhere.

---

## 4. Proposed architecture

Four layers. Each is only useful once the one below it exists, so build them in order.

```
  L3  Agent loop contract        verdict.json + baselines + budget guard
       ↑
  L2  Quality eval               retrieval / routing / faithfulness — and
                                 document structuring + flashcard quality
       ↑
  L1  Golden journeys            deterministic E2E over the real pipeline
       ↑
  L0  Hermetic environment       emulators + LLM replay + seeded corpus
```

### L0 — Hermetic environment *(the prerequisite; nothing else works without it)*

1. **`docker-compose.test.yml`** — the existing weaviate/postgres/redis containers plus the Firebase Emulator Suite (auth + firestore + storage) and the Pub/Sub emulator. Services already read emulator env vars where the SDKs support them; the rest is wiring.
2. **LLM record/replay proxy** — a small shim that all services point at via the existing `OPENAI_BASE_URL` / `openrouter_base_url` env vars. Two modes: `record` (proxy to OpenRouter, write cassettes keyed by a hash of model + messages) and `replay` (serve from cassette, hard-fail on a miss). Covers chat completions *and* embeddings. **Replay is the default** — an agent loop must not be able to spend money by accident.
3. **Seed script** — `dev/seed`: creates a deterministic test user, uploads a fixture corpus of 3–5 small PDFs with hand-labeled expected structure, waits for processing, asserts stable `resource_id`s. Fixtures live in `tests/fixtures/corpus/` with a `golden-maps/` sibling holding the expected section trees.
4. **`dev/run env up|down|seed|reset`** — one command from clean checkout to a working, populated stack.

*Unlocks: everything. Also makes local development sane again, which matters if you're picking this back up.*

### L1 — Golden journeys *(deterministic, gate merges)*

E2E scenarios over the hermetic stack in replay mode. Extend the existing YAML runner (`dev/collectors/integration/runner.py`) — it already does auth, assertions, and captures; it needs multi-step state passing between requests and polling with timeout.

| ID | Journey | Key assertions |
|---|---|---|
| J1 | Upload → process → map | status walks all 7 stages; resource map matches golden structure; `/content` returns markdown |
| J2 | Group → scoped chat | group two docs, ask a question, cited sources come only from that group |
| J3 | Chat modes | each explicit `agent_mode` reaches the right agent; classifier path routes a labeled query set correctly |
| J4 | Flashcard loop | generate from section → save → review → due-queue respects SM-2 → `coverage_status` flips → delete last card flips it back |
| J5 | Isolation | user B gets 403 on every one of user A's resources, threads, groups, cards |
| J6 | Degradation | weaviate down / Pub/Sub down / LLM 429 → correct error surface, `error_stage` set, no silent corruption |

*Unlocks: an agent can change backend code and know within minutes whether it broke the product.*

### L2 — Quality eval *(non-deterministic, on demand / nightly)*

`EVAL-AND-TUNING-SPEC.md` is a good design and I'd implement it close to as written. Two changes:

**Fix the bootstrap.** The spec's Phase 1 starts with manual document upload. Point it at the L0 seeded corpus instead, so `eval run` works from a clean checkout.

**Add the two dimensions the spec omits** — both of which you named as core:

- **Document structuring quality** (`scorers/structure.py`, deterministic — no LLM, so it can gate CI):
  - section-extraction precision/recall/F1 vs. golden maps
  - heading-hierarchy correctness (parent/child edges)
  - page-range accuracy
  - `extraction_confidence` calibration — does `high` actually correlate with high F1?
  - chunk→section assignment accuracy
- **Flashcard quality** (`scorers/flashcard.py`, mixed):
  - *deterministic:* type distribution vs. requested, cloze well-formedness (exactly one deletion, non-trivial span), duplicate rate within a generated batch
  - *LLM-judge:* is the card answerable from its source section alone? is the answer faithful to the section? is it a meaningful question rather than trivia?

The spec's five chat metrics (recall@k, MRR, routing accuracy, faithfulness, relevance) stay as designed. Routing accuracy first — it's free to score and it's currently the weakest link.

### L3 — Agent loop contract *(what makes it autonomous)*

1. **`.devloop/verdict.json`** — every invariant with `id`, `layer`, `status`, `expected`, `actual`, `owning_files`, `priority`. Plus a process exit code. This is what an agent reads instead of parsing prose.
2. **Committed baselines** — `eval/baselines/*.json` in git, so "did I regress anything?" is a diff, not a memory.
3. **Loop contract** — the agent reads the verdict, picks the highest-priority failure, makes **one** change, re-runs, and must show that invariant fixed and no other invariant regressed. Otherwise revert. Log every iteration to `eval/TUNING-LOG.md` as the spec describes.
4. **Guards** — replay mode by default; live LLM calls require an explicit flag and a spend ceiling; the loop stops after N consecutive failed attempts on the same invariant rather than thrashing.

---

## 5. Build order

| # | Step | Effort | Unlocks |
|---|---|---|---|
| 1 | `docker-compose.test.yml` with emulators — **done: all 12 services green; first bring-up landed 12 fixes (see git log)** | 2–3 d | Anything can run without real GCP |
| 2 | LLM record/replay proxy — **done, 38 tests passing; 33 cassettes recorded, replay verified keyless** | 2 d | Determinism; free CI runs |
| 3 | Fixture corpus + golden maps + `dev/seed` — **corpus + seeder done and verified live; fidelity run complete (6/6 and 8/8 sections), golden maps awaiting hand-promotion from `.devloop/seed-manifest.json`** | 2 d | Known-good ground truth |
| 4 | Journey engine (multi-step, polling, verdict output) — **done, 73 tests passing** | 1–2 d | Journeys become expressible |
| 5 | Journeys J1–J7 — **J1, J3, J4, J5, J7 written; 40/40 PASS under fidelity in keyless replay (incl. the heading-tree and chunk-linkage invariants); 34/40 under fast with the one designed pypdf signal. J2 and J6 added: J2 (group-scoped chat) needed agent-graph-service wired to rag-api-service's existing group-scoping support first — done; J6 (degradation) needed a new `inject:` step type in the journey engine — done, 4/4 PASS live against the hermetic stack, and found+fixed a real bug along the way (Pub/Sub-down resource creation returned 200/"queued" forever with no error — main.py never awaited the publish future). Full-suite verification blocked in this environment by a Pub/Sub emulator delivery bug unrelated to this change — see note below.** | 3–4 d | Core product verified end to end |
| 6 | `verdict.json` + exit codes in `dev/run` — **done, 29 tests passing** | 1 d | Machine-readable loop |
| 7 | Eval: retrieval + routing scorers **done (dataset v1, 20 queries)**; runner unblocked — the stack now runs | 2–3 d | First real quality baseline |
| 8 | Eval: structure + flashcard scorers — **done, deterministic tier complete** | 2–3 d | Your two priority domains measured |
| 9 | Eval: LLM-judge, compare, report — **done: `judge.py` (faithfulness/relevance prompts verbatim from EVAL-AND-TUNING-SPEC.md §3.3.3-3.3.4, plus a new card-answerability judge for flashcards), wired into `dev/run eval --judge`, `--compare`'s per-metric and per-query regression rules, and the report. 304 eval tests pass. Live-verified only for the miss path — this environment has no LLM_UPSTREAM_API_KEY to record real judgments with; see eval/README.md** | 2–3 d | Before/after tuning |
| 10 | Journeys J5–J6, baselines, loop guards | 2–3 d | Safe unattended operation |
| 11 | Flutter SDK in CI + bidirectional contract tests — **done. Two prerequisite bugs found first: mobile CI had never run (`apps/mobile/.github/workflows/` — same invisible-to-GitHub location class as the backend fix in step 1), and `flutter pub get` had never succeeded either (a nonexistent package plus a version-conflict chain in 5 unused dev-dependencies). Fixed both, then wrote the mobile-side contract tests: one per fixture in `apps/ai-server/tests/fixtures/api-contracts/`, reading the same file the backend already asserts against. Found and fixed a real bug this surfaced — the mobile `ResourceStatus` enum was missing 3 of the 6 real backend values, silently coercing "queued" to "pending". 19/19 tests pass; `flutter analyze`'s 277 pre-existing issues are documented, not gated on.** | 2–3 d | Client drift caught automatically |

Roughly 5 focused weeks, and steps 1–6 (about half) already give you a loop worth running.

Step 11 is independent of 1–10 and can run in parallel — it needs the Flutter SDK in CI and the existing `tests/fixtures/api-contracts/` fixtures, not the hermetic stack.

**Do step 1 first even if you do nothing else.** Almost everything currently blocked is blocked on it.

---

## 6. Scope decisions

Settled 2026-08-15.

1. **`apps/web/` is out of scope.** It is maintained separately (not by the repo owner), has been manually tested, and works. It stays as-is: no verification layer is built for it, and no journey covers it. If ai-server contracts change underneath it, that surfaces as a manual finding, not a broken build. **Verification targets `apps/ai-server/` and `apps/mobile/` only.**

2. **Mobile is in the loop.** The contract fixtures in `tests/fixtures/api-contracts/` stay as the mobile↔backend boundary (they caught 12 real mismatches, so the mechanism works) but become bidirectional: the Flutter side parses the same fixtures the backend asserts against, so a backend response change fails a mobile test. Start with model-parsing and API-client unit tests; defer widget tests. This needs the Flutter SDK in CI.

3. **LLM layer uses cassettes**, not a scripted fake. Record/replay is higher fidelity and a changed prompt becomes a cassette miss — a visible signal rather than silent drift. Misses fail loudly; they never fall through to a live call.

4. **Where eval lives.** The spec puts it at `apps/ai-server/eval/`. Since it also scores document structuring and flashcards, and mobile is in scope, lift it to a top-level `eval/` alongside `dev/`. *(Not yet confirmed.)*

---

## 6a. Open — Firestore rules conflict (needs the Firebase console)

Two contradictory rule sets exist for one database (`studentapp-b3d6c`), and
only one can be live:

| File | Says | Deployed by |
|---|---|---|
| `apps/web/firestore.rules` | `allow read, write: if false` on `/{document=**}` — all client access denied, API-only | `apps/web/firebase.json` declares it |
| `apps/mobile/firestore.rules` | Authenticated users may read/write `users/{uid}/courses/{courseId}` | **nothing** — `apps/mobile/firebase.json` is a FlutterFire config with no `firestore` section |

So the only *deployable* rules are the deny-all ones — while
`apps/mobile/lib/courses/course_repository.dart:12` reads
`users/{uid}/courses` **directly from the client**.

Those cannot both be true in a working system. Three possibilities, and the
repo cannot tell which:

1. Deny-all is live → mobile's course list is broken in production.
2. Mobile's rules were deployed by hand → web's API-only security model is not
   in effect, and the live rules match a file nothing deploys.
3. Something else entirely is live → the production security policy is not in
   version control at all, which is the worst case.

**Check the Firebase console** (Firestore → Rules) and reconcile to one file.

Two things to fix while doing it:

- `apps/mobile/firestore.rules` is dead — no config references it — but it
  reads like the mobile security model. Either wire it up or delete it.
- If the permissive rules win, note that `match /users/{userId}/courses/{courseId}`
  does **not** cascade to subcollections, so legacy
  `courses/{cid}/courseResources/{rid}` reads are denied.
- Client-writable course documents mean the resource cap is unenforceable:
  `add_to_courses` reads `max_resources` off the course doc
  (`resource_service.py`), and a client that can write that document can set it
  to anything.

---

## 6b. Resolved — Pub/Sub emulator delivers late, sequentially, sometimes never

Found while seeding the corpus for J2/J6 verification (2026-08-18): each of the
3 fixture documents is published to `vector-process` back to back, but
`rag-worker-service`'s subscriber only ever seems to receive **one at a time**,
roughly 300s apart — matching `dev/seed`'s own per-document processing
timeout, not the actual publish times. Net effect: seeding the full corpus can
take up to 15 minutes instead of seconds, and on at least one run all 3 timed
out with **zero** messages ever delivered. `docker compose restart
pubsub-emulator` + `dev/run env reset` did not reliably fix it. This is a
different failure mode than the previously-documented "stale after subscriber
restart" issue (§dev/env/README) — no restart was involved in the sequential
manifestation.

**Root-caused and fixed 2026-08-18** (`44f771c`, landed in the Pub/Sub PR):
the emulator itself was never at fault. `rag-worker-service` and
`rag-api-service` each open a `pubsub_v1.SubscriberClient()` once at process
start and keep it for the process lifetime; both `up` (containers start,
*then* `seed-emulators.py` creates topics/subscriptions) and `reset` (data
wiped and re-seeded, containers left running) create or recreate those
topics/subscriptions out from under an already-running subscriber, going
stale against the new objects. `dev/env/run` now restarts both services right
after `seed-emulators.py` runs, in both `up` and `reset`. Verified end to
end: a full `down`+`up`+`seed` now ingests all 3 corpus documents in ~7s
(was 15+ minutes or a hang), and the full journey suite ran 43/47 pass live
against the hermetic stack, the one failure being the pre-existing
fast-profile extraction signal already documented elsewhere in this file, not
a regression.

---

## 7. Pre-flight findings (2026-08-15)

Checked before writing step 1. Two of this plan's assumptions were wrong.

| Finding | Consequence |
|---|---|
| `weaviate-service` uses `vectorizer: "none"` and calls `{openrouter_base_url}/embeddings` over plain HTTP (`main.py:347`); every other LLM call is likewise behind a configurable base URL | Cassette proxy pins **all** generation and embedding traffic via env vars alone. No code change. |
| `pubsub_v1.PublisherClient()` honours `PUBSUB_EMULATOR_HOST` natively | Pub/Sub emulator needs no code change. |
| Uploads are read back via `google.cloud.storage` with `gs://` paths (`utils/cloud_storage.py`), not the Firebase SDK | **Firebase Storage emulator won't work.** Using `fake-gcs-server` instead. |
| `rag-api-service/main.py:120` raises if `GOOGLE_APPLICATION_CREDENTIALS` is unset; same in rag-worker and both Node services | Emulator env vars alone don't boot the stack. Needs a generated fake service account **plus** emulator branches. |
| `marker-pdf`'s `create_model_dict()` pulls ~2 GB from HuggingFace; reranker pulls another ~130 MB | Dual profile: `fast` (offline, pypdf, no reranker) for L1, `fidelity` for L2 structure/ranking eval. |
| `marker-pdf`'s fallback to `pypdf` is exception-driven and **silent** (`main.py:~880`) | A failed extraction is indistinguishable from a good one: flat text → near-empty resource map → bad flashcards and retrieval, with processing reported as successful. **Product risk, not just a test one.** First invariant candidate. |

One correction to §2.2 above, found while building step 2: the four **agent**
LLMs are constructed with `streaming=True` (`rag_agent.py:35`, `teaching.py:31`,
`problem_solving.py:31`, `study_advice.py:31`), so those calls reach the wire as
SSE even though the app awaits them with `ainvoke()`. Only coref, rewrite, and
classifier are plain JSON. The proxy records and replays both shapes, and keys
them separately. Separately confirmed: **no prompt contains a timestamp, UUID,
or other volatile value** — the only `datetime.utcnow()` is in the router's trace
dict, which is never sent to a model — so cassette keys are stable across runs.

### Step 1 status

Written and syntax-checked; **never executed** — no Docker daemon was available.
The first `dev/env up` on a real machine should be treated as debugging, not
verification. Known open risks are listed in `dev/env/README.md`
§"Current limitations"; the sharpest is that
`firebase_admin.storage.bucket()` (`rag-worker-service/main.py:745`) was **not**
made emulator-aware, only the plain GCS client next to it.

---

## 8. What I'd tell an agent to do on day one

Not "improve test coverage" — that's how you get 200 more mock-based tests that verify nothing about the product. Instead:

> Get `dev/run env up && dev/seed && dev/run journeys` to pass from a clean checkout, on a machine with no GCP credentials and no OpenAI key.

That single objective forces L0 and most of L1 into existence, and it's objectively verifiable — either the command works on a fresh container or it doesn't.
