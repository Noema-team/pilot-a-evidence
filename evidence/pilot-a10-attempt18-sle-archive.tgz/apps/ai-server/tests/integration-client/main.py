#!/usr/bin/env python3
"""
Integration Test Client for RAG System.

This module provides CLI tools to test various endpoints of a RAG (Retrieval-Augmented Generation)
system backend, including health checks, data ingestion, and interactive chat sessions.

Environment Variables:
    API_GATEWAY_URL: Base URL for the API Gateway (default: http://localhost:3001)
    FIREBASE_ID_TOKEN: Firebase ID token for user authentication
    FIREBASE_APP_ID: Firebase App ID for service account operations
    GOOGLE_APPLICATION_CREDENTIALS: Path to service account JSON file
    SHARED_INTERNAL_TOKEN: Shared secret, for the impersonation-based flows below

Note on the impersonation flows (search / chat-with-citations):
    These authenticate to the gateway with `x-internal-token` plus
    `x-impersonate-user-id`, which the gateway now strips from inbound requests
    unless it is started with ALLOW_INTERNAL_TOKEN_AUTH=true. Set that on your
    local stack, and never in a deployed environment — it lets any caller
    holding the shared token act as any user. Without it these flows get 401.
"""

import ast
import argparse
import json
import logging
import os
import sys
import time
import uuid
from dataclasses import dataclass
from typing import Optional, Dict, Any, Tuple, Iterator, List

import firebase_admin
import requests
from dotenv import load_dotenv
from firebase_admin import auth, firestore

# Load environment variables from .env file
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


# Hardcoded test user IDs
TEST_USER_IDS = [
    "0wgXGXVxphRWDaV1TiN0Js6RRXd2",
]


@dataclass
class Config:
    """Configuration for the integration test client."""
    
    api_gateway_url: str = os.environ.get("API_GATEWAY_URL", "http://localhost:3001")
    langgraph_url: str = os.environ.get("LANGGRAPH_URL", "http://localhost:8003")
    firebase_id_token: Optional[str] = os.environ.get("FIREBASE_ID_TOKEN")
    shared_internal_token: Optional[str] = os.environ.get("SHARED_INTERNAL_TOKEN")
    firebase_web_api_key: Optional[str] = os.environ.get("FIREBASE_WEB_API_KEY")
    weaviate_api_key: Optional[str] = os.environ.get("WEAVIATE_API_KEY")
    
    # Polling configuration
    max_polls: int = 60
    poll_interval: int = 5
    request_timeout: int = 120
    
    def validate_for_ingestion(self) -> bool:
        """Validates config has required fields for ingestion tests."""
        if not self.shared_internal_token:
            logger.error("SHARED_INTERNAL_TOKEN environment variable is not set")
            return False
        # If the API Gateway is not handling the key, the client must provide it.
        # This check is for the "client sends the key" option.
        if not self.weaviate_api_key:
            logger.warning("WEAVIATE_API_KEY environment variable is not set. Ingestion might fail if API Gateway doesn't provide it.")
        return True
    
    def validate_for_chat(self) -> bool:
        """Validates config has required fields for chat tests."""
        if self.firebase_id_token:
            # Using pre-provided token (legacy / manual mode)
            return True
        if self.firebase_web_api_key:
            # We will generate an ID token via Admin SDK + Identity Toolkit
            return True

        logger.error(
            "Neither FIREBASE_ID_TOKEN nor FIREBASE_WEB_API_KEY is set. "
            "Set FIREBASE_WEB_API_KEY to enable live ID token generation."
        )
        return False


CONFIG = Config()


class FirebaseManager:
    """Manages Firebase initialization and token generation."""
    
    _initialized = False
    
    @classmethod
    def initialize(cls) -> bool:
        """Initializes the Firebase Admin SDK if not already done."""
        if cls._initialized:
            return True
        
        if not firebase_admin._apps:
            try:
                firebase_admin.initialize_app()
                logger.info("Firebase Admin SDK initialized successfully")
                cls._initialized = True
                return True
            except Exception as e:
                logger.error(f"Could not initialize Firebase Admin SDK: {e}")
                return False
        
        cls._initialized = True
        return True
    
    @classmethod
    def get_firestore_client(cls):
        """Gets a Firestore client, initializing the app if needed."""
        if not cls.initialize():
            return None
        return firestore.client()
    
    @classmethod
    def generate_token(cls, uid: str) -> Optional[str]:
        """
        Generates an authentication token for testing.
        
        NOTE: The Python Firebase Admin SDK does not support creating App Check tokens.
        This function creates a custom auth token as a workaround for testing.
        
        Args:
            uid: The user ID for whom to create the custom token.
            
        Returns:
            Token string if successful, None otherwise.
        """
        if not CONFIG.validate_for_ingestion():
            return None
        
        if not cls.initialize():
            return None
        
        try:
            logger.warning(
                "Python Firebase Admin SDK doesn't natively support App Check token creation. "
                "Creating custom auth token instead for testing purposes."
            )
            
            custom_token = auth.create_custom_token(uid)
            token_str = (
                custom_token.decode('utf-8') 
                if isinstance(custom_token, bytes) 
                else custom_token
            )
            
            logger.info(f"Custom token generated successfully for UID: {uid}")
            logger.info(
                "For production, consider: "
                "1) Node.js/Go/Java backend for App Check tokens, "
                "2) Client SDKs to generate tokens, "
                "3) Firebase Cloud Functions"
            )
            
            return token_str
            
        except Exception as e:
            logger.error(f"Failed to generate token: {e}")
            return None

    @classmethod
    def get_id_token_for_uid(cls, uid: str) -> Optional[str]:
        """
        Generates a fresh Firebase ID token for the given UID by:
          1. Creating a custom token via Firebase Admin SDK
          2. Exchanging it for an ID token using the Identity Toolkit REST API

        Returns:
            A valid 1-hour ID token as a string, or None on failure.
        """
        if not cls.initialize():
            return None

        api_key = CONFIG.firebase_web_api_key
        if not api_key:
            logger.error("FIREBASE_WEB_API_KEY is not set; cannot generate ID token.")
            return None

        try:
            # Step 1: Create custom token
            custom_token = auth.create_custom_token(uid)
            if isinstance(custom_token, bytes):
                custom_token = custom_token.decode("utf-8")

            # Step 2: Exchange custom token for an ID token
            url = (
                "https://identitytoolkit.googleapis.com/v1/"
                f"accounts:signInWithCustomToken?key={api_key}"
            )
            payload = {
                "token": custom_token,
                "returnSecureToken": True,
            }
            resp = requests.post(url, json=payload, timeout=30)
            resp.raise_for_status()

            data = resp.json()
            id_token = data.get("idToken")

            if id_token:
                logger.info(f"Generated fresh ID token for UID {uid}")
                return id_token

            logger.error(f"Failed to obtain ID token. Response: {data}")
            return None

        except Exception as e:
            logger.error(f"Error generating ID token for UID {uid}: {e}")
            return None


class APIClient:
    """Handles API requests to the gateway."""
    
    def __init__(self, base_url: str, timeout: int = 30):
        self.base_url = base_url
        self.timeout = timeout
    
    def _make_request(
        self, 
        method: str, 
        endpoint: str, 
        headers: Optional[Dict[str, str]] = None,
        json_data: Optional[Dict[str, Any]] = None,
        stream: bool = False
    ) -> Optional[requests.Response]:
        """
        Makes an HTTP request with error handling.
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            headers: Request headers
            json_data: JSON payload for POST requests
            stream: Whether to handle the response as a stream
            
        Returns:
            Response object if successful, None otherwise.
        """
        url = f"{self.base_url}{endpoint}"
        try:
            logger.debug(f"Making {method} request to {url}")
            response = requests.request(
                method,
                url,
                headers=headers,
                json=json_data,
                timeout=self.timeout,
                stream=stream
            )
            return response
        except requests.exceptions.RequestException as e:
            logger.error(f"Request failed: {e}")
            return None
    
    def health_check(self) -> bool:
        """Performs a health check on the API Gateway."""
        response = self._make_request("GET", "/health")
        if response is None:
            return False
        
        success = response.ok
        status = "✅ PASSED" if success else "❌ FAILED"
        logger.info(f"Health check: {status} (Status: {response.status_code})")
        return success
    
    def start_ingestion(
        self,
        user_id: str,
        course_id: str,
        resource_id: str,
        headers: Dict[str, str]
    ) -> Tuple[bool, Optional[str]]:
        """
        Starts the ingestion process.

        Returns:
            A tuple of (success, job_id).
        """
        payload = {
            "resource_path": f"users/{user_id}/courses/{course_id}/courseResources/{resource_id}"
        }
        
        # Ensure Content-Type is set for the new logging format
        headers['Content-Type'] = 'application/json'

        logger.info("Sending ingestion request", extra={
            "url": self.base_url + "/api/process",
            "headers": headers,
            "payload": payload,
        })

        try:
            resp = requests.post(
                self.base_url + "/api/process",
                headers=headers,
                data=json.dumps(payload),
                timeout=self.timeout,
            )
            logger.info("Ingestion response", extra={
                "status_code": resp.status_code,
                "text": resp.text[:500],
            })

            data = resp.json()
            if resp.ok and data.get("status") == "processing_enqueued":
                job_id = data.get("job_id")
                logger.info(f"Ingestion enqueued successfully with job_id: {job_id}")
                return True, job_id
            else:
                logger.error(f"Ingestion failed: {resp.status_code}")
                try:
                    error_details = resp.json()
                    logger.error(f"Server response: {error_details.get('message', resp.text)}")
                except json.JSONDecodeError:
                    logger.error(f"Server response: {resp.text}")
                return False, None

        except requests.RequestException:
            logger.exception("Ingestion request failed")
            return False, None
        except json.JSONDecodeError:
            logger.error(f"Invalid JSON response: {resp.text if 'resp' in locals() else 'No response'}")
            return False, None
    
    def poll_ingestion_status(
        self,
        user_id: str,
        course_id: str,
        resource_id: str,
        headers: Dict[str, str],
        max_polls: int = 60,
        poll_interval: int = 5
    ) -> bool:
        """
        Polls for ingestion completion status.
        
        Returns:
            True if ingestion completed successfully.
        """
        for poll_num in range(max_polls):
            try:
                # Corrected URL to match gateway: /api/status/:user_id/:resource_id?course_id=...
                endpoint = f"/api/status/{user_id}/{resource_id}?course_id={course_id}"
                response = self._make_request(
                    "GET",
                    endpoint,
                    headers=headers
                )
                
                if response is None:
                    logger.warning(f"Poll {poll_num + 1}/{max_polls}: connection failed")
                    time.sleep(poll_interval)
                    continue
                
                if response.ok:
                    status_data = response.json()
                    status = status_data.get("status")
                    details = status_data.get("details", {})
                    logger.info(f"Poll {poll_num + 1}/{max_polls}: status = {status}, stage = {details.get('stage', 'N/A')}")
                    
                    if status == "completed":
                        logger.info("✅ Ingestion completed successfully")
                        return True
                    elif status == "failed":
                        logger.error(f"Ingestion failed: {status_data.get('details')}")
                        return False
                else:
                    logger.warning(f"Poll {poll_num + 1}/{max_polls}: HTTP {response.status_code}")
                
                time.sleep(poll_interval)
                
            except requests.exceptions.RequestException as e:
                logger.warning(f"Poll {poll_num + 1}/{max_polls}: connection error: {e}")
                time.sleep(poll_interval)
        
        logger.error(f"Timeout: ingestion did not complete after {max_polls * poll_interval}s")
        return False
    
    def search(self, query: str, headers: Dict[str, str]) -> Optional[Dict[str, Any]]:
        """Performs a direct search query, bypassing the LLM."""
        payload = {"query": query}
        response = self._make_request(
            "POST",
            "/api/search",
            headers=headers,
            json_data=payload
        )
        
        if response is None or not response.ok:
            logger.error(f"Search failed: HTTP {response.status_code if response else 'error'}")
            return None
        
        try:
            return response.json()
        except json.JSONDecodeError:
            logger.error("Invalid JSON response from search")
            return None

    def get_course_resources_info(self, course_id: str, headers: Dict[str, str]) -> Optional[List[Dict[str, Any]]]:
        """Fetches course resource overview information from the API Gateway."""
        endpoint = f"/api/courses/{course_id}/resources/info"
        response = self._make_request(
            "GET",
            endpoint,
            headers=headers
        )

        if response is None or not response.ok:
            logger.error(f"Failed to fetch course resources info: HTTP {response.status_code if response else 'error'}")
            return None
        
        try:
            return response.json()
        except json.JSONDecodeError:
            logger.error("Invalid JSON response from course resources info endpoint")
            return None

    def get_resource_content(self, resource_id: str, course_id: str, headers: Dict[str, str]) -> Optional[Dict[str, Any]]:
        """Fetches full markdown content for a specific resource."""
        endpoint = f"/api/resources/{resource_id}/content?course_id={course_id}"
        response = self._make_request(
            "GET",
            endpoint,
            headers=headers
        )

        if response is None or not response.ok:
            logger.error(f"Failed to fetch resource content: HTTP {response.status_code if response else 'error'}")
            return None
        
        try:
            return response.json()
        except json.JSONDecodeError:
            logger.error("Invalid JSON response from resource content endpoint")
            return None

    def langgraph_chat(self, messages: List[Dict[str, Any]], user_id: str, course_id: str) -> Optional[Dict[str, Any]]:
        payload = {
            "messages": messages,
            "user_id": user_id,
            "course_id": course_id
        }
        try:
            resp = requests.post(
                self.base_url + "/chat",
                json=payload,
                timeout=self.timeout
            )
            if resp.ok:
                return resp.json()
            else:
                logger.error(f"LangGraph chat failed: {resp.status_code} - {resp.text}")
                return None
        except Exception as e:
            logger.error(f"LangGraph chat request error: {e}")
            return None

    def langgraph_chat_stream(self, messages: List[Dict[str, Any]], user_id: str, course_id: str) -> Optional[Dict[str, Any]]:
        """
        Sends messages to LangGraph streaming endpoint and returns final state.

        Parses Server-Sent Events (SSE) and displays intermediate updates.

        Args:
            messages: Conversation history
            user_id: User identifier
            course_id: Course identifier

        Returns:
            Final ChatState dict or None on error
        """
        payload = {
            "messages": messages,
            "user_id": user_id,
            "course_id": course_id
        }
        try:
            resp = requests.post(
                self.base_url + "/chat/stream",
                json=payload,
                timeout=self.timeout,
                stream=True
            )
            if not resp.ok:
                logger.error(f"LangGraph streaming chat failed: {resp.status_code} - {resp.text}")
                return None

            final_state = None

            # Parse SSE stream
            for line in resp.iter_lines(decode_unicode=True):
                if not line or not line.strip():
                    continue

                # SSE lines start with "data: "
                if not line.startswith("data: "):
                    continue

                data_str = line[len("data: "):].strip()
                if not data_str:
                    continue

                try:
                    event = json.loads(data_str)
                    event_type = event.get("type")
                    event_data = event.get("data")

                    if event_type == "state_update":
                        # Log intermediate state updates
                        if event_data:
                            # Extract node name from the state update (keys are node names)
                            node_names = [k for k in event_data.keys() if k not in ["messages", "user_id", "course_id"]]
                            if node_names:
                                logger.debug(f"Stream update from node: {node_names[0]}")
                        final_state = event_data

                    elif event_type == "done":
                        logger.debug("Stream completed")
                        break

                    elif event_type == "error":
                        error_msg = event_data.get("error", "Unknown error") if event_data else "Unknown error"
                        logger.error(f"Stream error: {error_msg}")
                        return None

                except json.JSONDecodeError as e:
                    logger.warning(f"Failed to decode SSE event: {data_str[:100]}")
                    continue

            return final_state

        except Exception as e:
            logger.error(f"LangGraph streaming chat request error: {e}")
            return None

    def send_chat_message(self, query: str, course_id: str, headers: Dict[str, str], thread_id: Optional[str] = None, focused_content: Optional[str] = None) -> Optional[Iterator[str]]:
        """Sends a message to the full RAG chat flow and streams the response."""
        payload = {
            "query": query,
            "response_mode": "streaming",
            "inputs": {
                "course_id": course_id
            }
        }
        if thread_id:
            payload["thread_id"] = thread_id
        if focused_content:
            payload["focused_content"] = focused_content

        response = self._make_request(
            "POST",
            "/api/chat/messages",
            headers=headers,
            json_data=payload,
            stream=True
        )

        if response is None:
            logger.error("Chat message request failed.")
            return None
        
        if not response.ok:
            logger.error(f"Chat message failed: HTTP {response.status_code}")
            try:
                error_details = response.json()
                logger.error(f"Server response: {error_details.get('message', response.text)}")
            except json.JSONDecodeError:
                logger.error(f"Server response: {response.text}")
            return None
        
        def stream_generator():
            try:
                for chunk in response.iter_content(chunk_size=8192, decode_unicode=True):
                    if chunk:
                        yield chunk
            except requests.exceptions.ChunkedEncodingError as e:
                logger.error(f"Error reading stream: {e}")

        return stream_generator()


# --- Test Functions ---

def test_health_check(args: argparse.Namespace) -> None:
    """Tests the API Gateway's health check endpoint."""
    logger.info("=" * 60)
    logger.info("RUNNING: API Gateway Health Check")
    logger.info("=" * 60)
    
    client = APIClient(CONFIG.api_gateway_url)
    client.health_check()


def test_ingestion_flow(args: argparse.Namespace) -> None:
    """Tests the full asynchronous data ingestion pipeline."""
    logger.info("=" * 60)
    logger.info(
        f"RUNNING: Data Ingestion for User '{args.user_id}', "
        f"Course '{args.course_id}', Resource '{args.resource_id}'"
    )
    logger.info("=" * 60)

    if not CONFIG.validate_for_ingestion():
        return

    # Use the shared internal token for service-to-service authentication
    headers = {
        "x-internal-token": CONFIG.shared_internal_token
    }
    if CONFIG.weaviate_api_key:
        headers["X-Weaviate-Api-Key"] = CONFIG.weaviate_api_key

    # Start ingestion
    client = APIClient(CONFIG.api_gateway_url, timeout=CONFIG.request_timeout)
    success, job_id = client.start_ingestion(args.user_id, args.course_id, args.resource_id, headers)
    if not success:
        logger.error("Ingestion start failed.")
        return

    # After starting, subsequent status checks might require user-level permissions.
    # For this test, we will assume the same service token can be used.
    # If the status endpoint is user-locked, this part will need a user ID token.
    logger.info(f"Polling for ingestion status (job_id: {job_id})...")
    if client.poll_ingestion_status(
        args.user_id,
        args.course_id,
        args.resource_id,
        headers, # Using the same service token
        max_polls=CONFIG.max_polls,
        poll_interval=CONFIG.poll_interval
    ):
        logger.info("✅ PASSED: Ingestion pipeline completed successfully")
    else:
        logger.error("❌ FAILED: Ingestion pipeline did not complete")

def run_search_session(args: argparse.Namespace) -> None:
    """Starts an interactive session to test the direct search flow."""
    if not CONFIG.shared_internal_token:
        logger.error("SHARED_INTERNAL_TOKEN environment variable is not set. Cannot run search test.")
        return
    
    logger.info("=" * 60)
    logger.info("RUNNING: Interactive Direct Search Session (via Impersonation)")
    logger.info("=" * 60)
    logger.info("This tests the /api/search endpoint, bypassing the LLM.")
    logger.info("Type 'exit' or 'quit' to end.")
    
    # The user ID to impersonate.
    uid = TEST_USER_IDS[0]

    # Use the internal S2S authentication method with impersonation.
    headers = {
        "x-internal-token": CONFIG.shared_internal_token,
        "x-impersonate-user-id": uid
    }
    client = APIClient(CONFIG.api_gateway_url, timeout=CONFIG.request_timeout)
    
    while True:
        try:
            query = input("\nYou (search): ").strip()
            if query.lower() in ['exit', 'quit']:
                break
            if not query:
                continue
            
            logger.info(f"Sending search query: {query}")
            result = client.search(query, headers)
            
            if result:
                print("\nSearch Results:")
                print(json.dumps(result, indent=2))
            else:
                logger.error("No response from search endpoint")
                
        except (KeyboardInterrupt, EOFError):
            logger.info("Search session interrupted")
            break
        except Exception as e:
            logger.error(f"Error during search: {e}")
    
    logger.info("Search session ended")


def run_full_chat_session(args: argparse.Namespace) -> None:
    """Starts an interactive chat session using the full RAG flow."""
    # For the test client, we use the explicit impersonation flow.
    # This allows a trusted tool to act on behalf of a user.
    if not CONFIG.shared_internal_token:
        logger.error("SHARED_INTERNAL_TOKEN environment variable is not set. Cannot run chat test.")
        return

    logger.info("=" * 60)
    logger.info("RUNNING: Full RAG Chat Session (via Impersonation)")
    logger.info("=" * 60)
    logger.info("This tests the /api/chat/messages endpoint, including Dify and the LLM.")
    logger.info("Type 'exit' or 'quit' to end.")

    # The user ID to impersonate.
    uid = TEST_USER_IDS[0] 
    
    # Use the internal S2S authentication method with impersonation.
    headers = {
        "x-internal-token": CONFIG.shared_internal_token,
        "x-impersonate-user-id": uid
    }
    client = APIClient(CONFIG.api_gateway_url, timeout=CONFIG.request_timeout)

    # --- Fetch and select a course from Firestore ---
    db = FirebaseManager.get_firestore_client()
    if not db:
        logger.error("Failed to connect to Firestore. Cannot fetch courses.")
        return

    try:
        courses_ref = db.collection('users', uid, 'courses').stream()
        courses = list(courses_ref)
        
        if not courses:
            logger.error(f"No courses found for user {uid}. Please ingest data first.")
            return
        
        print("\nPlease select a course to chat with:")
        for i, course in enumerate(courses, 1):
            course_data = course.to_dict()
            print(f"{i}. {course_data.get('name', '[No Name]')} ({course.id})")
        
        choice_str = input("Enter choice number: ").strip()
        if not choice_str.isdigit():
            logger.error("Invalid input. Please enter a number.")
            return

        choice = int(choice_str) - 1
        if not 0 <= choice < len(courses):
            logger.error("Invalid choice.")
            return
        course_id = courses[choice].id
        course_name = courses[choice].to_dict().get('name', course_id)
        logger.info(f"Selected course: {course_name} ({course_id})")

    except (KeyboardInterrupt, EOFError):
        logger.info("\nCourse selection interrupted.")
        return
    except Exception as e:
        logger.error(f"Error fetching courses from Firestore: {e}")
        return
    # --- End of course selection ---

    # Generate a thread_id for this session
    thread_id = str(uuid.uuid4())
    logger.info(f"Starting new conversation with ID: {thread_id}")

    while True:
        try:
            query = input(f"\nYou (course: {course_name}): ").strip()
            if query.lower() in ['exit', 'quit']:
                break
            if not query:
                continue

            logger.info(f"Sending chat message: '{query}' for course: {course_id}")
            stream = client.send_chat_message(query, course_id, headers, thread_id=thread_id)

            if not stream:
                logger.error("Failed to get a response from the chat endpoint.")
                continue

            # Stream Processing
            print("\nAssistant: ", end="", flush=True)
            
            buffer = ""
            final_state = {}
            full_response_content = ""
            
            for chunk in stream:
                if not chunk:
                    continue
                if isinstance(chunk, bytes):
                    chunk = chunk.decode("utf-8", errors="ignore")
                
                buffer += chunk
                
                while "\n\n" in buffer:
                    line, buffer = buffer.split("\n\n", 1)
                    line = line.strip()
                    if not line:
                        continue
                    
                    if line.startswith("data: "):
                        data_str = line[len("data: "):].strip()
                        if not data_str or data_str == "[DONE]":
                            continue
                        
                        try:
                            data_json = json.loads(data_str)
                            
                            # LangGraph state update
                            if data_json.get("type") == "state_update":
                                state_data = data_json.get("data")
                                if state_data and isinstance(state_data, dict):
                                    for key, value in state_data.items():
                                        final_state[key] = value
                                        if key == "messages": # If messages update, don't print dot
                                            pass
                                        else:
                                            print(".", end="", flush=True) # Progress indicator (e.g., node finished)
                            
                            # Handle token streaming
                            elif data_json.get("type") == "token":
                                token_content = data_json.get("content", "")
                                if token_content:
                                    print(token_content, end="", flush=True)
                                    full_response_content += token_content
                                
                            # Check for Dify format message (streaming tokens)
                            elif data_json.get("event") == "message":
                                answer_chunk = data_json.get("answer", "")
                                if answer_chunk:
                                    full_response_content += answer_chunk
                                    print(answer_chunk, end="", flush=True)
                                    
                            elif data_json.get("type") == "error":
                                logger.error(f"\nStream error: {data_json.get('data')}")
                                
                        except json.JSONDecodeError:
                            continue

            # If we got a LangGraph final state, extract the last message
            if final_state and isinstance(final_state, dict):
                messages = final_state.get("messages", [])
                
                # If not found at top level, check nested node updates (LangGraph style)
                if not messages:
                    for key, val in final_state.items():
                        if isinstance(val, dict) and "messages" in val:
                            # Found messages in a node update
                            node_messages = val["messages"]
                            if node_messages:
                                messages = node_messages
                                # We keep looking in case there are later updates, 
                                # but usually we want the last one.
                                # For now, let's just use the last one we find that isn't empty.

                if messages and len(messages) > 0:
                    print()
                else:
                    print()
                    logger.warning("No messages found in final state")
            elif full_response_content:
                # Dify format response
                print()  # newline after full response
            else:
                print()
                logger.warning("No response content received")

        except (KeyboardInterrupt, EOFError):
            logger.info("\nChat session interrupted.")
            break
        except Exception as e:
            logger.error(f"An error occurred during the chat session: {e}")
            break
    
    logger.info("Full chat session ended.")

def run_chat_with_citations_session(args: argparse.Namespace) -> None:
    """Starts an interactive chat session with clickable/interactive citations."""
    if not CONFIG.shared_internal_token:
        logger.error("SHARED_INTERNAL_TOKEN environment variable is not set. Cannot run chat test.")
        return

    logger.info("=" * 60)
    logger.info("RUNNING: Chat with Interactive Citations")
    logger.info("=" * 60)
    logger.info("Type 'exit' or 'quit' to end.")
    print("Commands:")
    print("  - Just type your question to chat.")
    print("  - Type 'c1', 'c2', etc. to view the full content of a citation.")
    print("  - Type 'f' to ask a clarifying question about the currently focused citation.")

    uid = TEST_USER_IDS[0] 
    headers = {
        "x-internal-token": CONFIG.shared_internal_token,
        "x-impersonate-user-id": uid
    }
    client = APIClient(CONFIG.api_gateway_url, timeout=CONFIG.request_timeout)

    # --- Course Selection ---
    db = FirebaseManager.get_firestore_client()
    if not db:
        return
    try:
        courses_ref = db.collection('users', uid, 'courses').stream()
        courses = list(courses_ref)
        if not courses:
            logger.error("No courses found.")
            return
        
        print("\nSelect a course:")
        for i, course in enumerate(courses, 1):
            print(f"{i}. {course.to_dict().get('name', course.id)}")
        
        choice = int(input("Choice: ").strip()) - 1
        course_id = courses[choice].id
        course_name = courses[choice].to_dict().get('name', course_id)
    except Exception as e:
        logger.error(f"Error: {e}")
        return

    thread_id = str(uuid.uuid4())
    current_citations = []
    focused_citation = None

    while True:
        try:
            prompt_str = f"\nYou (focus: {focused_citation['title'] if focused_citation else 'none'}): "
            user_input = input(prompt_str).strip()
            
            if user_input.lower() in ['exit', 'quit']:
                break
            if not user_input:
                continue

            # Check for citation command (e.g. c1)
            if user_input.lower().startswith('c') and user_input[1:].isdigit():
                idx = int(user_input[1:]) - 1
                if 0 <= idx < len(current_citations):
                    cit = current_citations[idx]
                    logger.info(f"Fetching full content for: {cit['title']}")
                    content_res = client.get_resource_content(cit['resource_id'], course_id, headers)
                    if content_res:
                        print("\n" + "="*40)
                        print(f"FULL CONTENT: {content_res['title']}")
                        print("-" * 40)
                        print(content_res['content'])
                        print("="*40)
                        
                        # Set as focused citation and store its full content
                        focused_citation = cit
                        focused_citation['content'] = content_res['content']
                        print(f"\n[INFO] Citation {idx+1} is now FOCUSED. Subsequent questions will include this context.")
                    continue
                else:
                    print(f"Invalid citation number. Max: {len(current_citations)}")
                    continue

            # Use focused content if available
            focused_content = focused_citation['content'] if focused_citation else None
            
            # Check for focused question command (legacy/explicit)
            if user_input.lower() == 'f':
                if not focused_citation:
                    print("No citation focused. View one first using 'c1'.")
                    continue
                user_input = input(f"Ask about '{focused_citation['title']}': ").strip()
                if not user_input: continue

            # Normal Chat
            logger.info(f"Sending query...")
            stream = client.send_chat_message(user_input, course_id, headers, thread_id=thread_id, focused_content=focused_content)
            
            if not stream:
                continue

            print("\nAssistant: ", end="", flush=True)
            buffer = ""
            final_search_results = None
            final_state = {}
            full_response_content = ""
            progress_shown = False
            
            for chunk in stream:
                if isinstance(chunk, bytes):
                    chunk = chunk.decode("utf-8", errors="ignore")
                buffer += chunk
                while "\n\n" in buffer:
                    line, buffer = buffer.split("\n\n", 1)
                    line = line.strip()
                    if not line:
                        continue
                    
                    if line.startswith("data: "):
                        data_str = line[len("data: "):].strip()
                        if not data_str or data_str == "[DONE]":
                            continue
                        
                        try:
                            data = json.loads(data_str)
                            if data.get("type") == "token":
                                content = data.get("content", "")
                                if content:
                                    # If we were showing progress dots, clear them or move to new line
                                    if progress_shown:
                                        print()
                                        progress_shown = False
                                    
                                    print(content, end="", flush=True)
                                    full_response_content += content
                            elif data.get("type") == "state_update":
                                state_data = data.get("data", {})
                                if state_data and isinstance(state_data, dict):
                                    print(f" [DEBUG] State update keys: {list(state_data.keys())}")
                                    for key, value in state_data.items():
                                        final_state[key] = value
                                        if key == "search_results":
                                            final_search_results = value
                                        
                                        # Print progress dots for non-token updates if we haven't started streaming tokens
                                        if key != "messages" and not full_response_content:
                                            print(".", end="", flush=True)
                                            progress_shown = True
                        except json.JSONDecodeError:
                            continue
            
            print()
            
            # Fallback: If no tokens were streamed but we have a final message
            last_message_content = ""
            if final_state and isinstance(final_state, dict):
                # print(f" [DEBUG] Final state keys: {list(final_state.keys())}")
                messages = final_state.get("messages", [])
                if not messages:
                    # Check nested node updates
                    for key, val in final_state.items():
                        if isinstance(val, dict) and "messages" in val:
                            messages = val["messages"]
                            break
                
                if messages:
                    last_msg = messages[-1]
                    last_message_content = last_msg.get("content", "")

            if not full_response_content and last_message_content:
                print(f"{last_message_content}")

            # Display Citations
            if final_search_results and final_search_results.get("results"):
                current_citations = final_search_results["results"]
                print("\n--- Citations ---")
                for i, res in enumerate(current_citations, 1):
                    title = res.get('title') or res.get('filename') or "Untitled"
                    score = res.get('score', 0.0)
                    content = res.get('content', '')
                    print(f"[{i}] {title} (Score: {score:.2f})")
                    print(f"    Snippet: {content[:100]}...")
            elif not full_response_content and not last_message_content:
                print("\n[WARNING] No response received from Assistant.")
                if final_state:
                    print(f"[DEBUG] Final state keys available: {list(final_state.keys())}")
            
            # If search results are missing but we have citations in text, alert user
            if not current_citations and "[1]" in (full_response_content or last_message_content):
                print("\n[DEBUG] Citations found in text but search_results metadata is missing from the stream.")

        except KeyboardInterrupt:
            break
        except Exception as e:
            logger.error(f"Error: {e}")
            break

def test_course_resources_info(args: argparse.Namespace) -> None:
    """Tests the /api/courses/{courseId}/resources/info endpoint."""
    if not CONFIG.shared_internal_token:
        logger.error("SHARED_INTERNAL_TOKEN environment variable is not set. Cannot run this test.")
        return
    
    logger.info("=" * 60)
    logger.info("RUNNING: Get Course Resources Info")
    logger.info("=" * 60)
    
    # The user ID to impersonate.
    uid = TEST_USER_IDS[0] # Using the first test user for simplicity
    
    # Use the internal S2S authentication method with impersonation.
    headers = {
        "x-internal-token": CONFIG.shared_internal_token,
        "x-impersonate-user-id": uid # The RAG API service uses this header
    }
    client = APIClient(CONFIG.api_gateway_url, timeout=CONFIG.request_timeout)

    # --- Fetch and select a course from Firestore ---
    db = FirebaseManager.get_firestore_client()
    if not db:
        logger.error("Failed to connect to Firestore. Cannot fetch courses.")
        return

    try:
        courses_ref = db.collection('users', uid, 'courses').stream()
        courses = list(courses_ref)
        
        if not courses:
            logger.error(f"No courses found for user {uid}.")
            return
        
        print("\nPlease select a course to fetch resources info from:")
        for i, course in enumerate(courses, 1):
            course_data = course.to_dict()
            print(f"{i}. {course_data.get('name', '[No Name]')} ({course.id})")
        
        choice_str = input("Enter choice number: ").strip()
        if not choice_str.isdigit():
            logger.error("Invalid input. Please enter a number.")
            return

        choice = int(choice_str) - 1
        if not 0 <= choice < len(courses):
            logger.error("Invalid choice.")
            return
        course_id = courses[choice].id
        course_name = courses[choice].to_dict().get('name', course_id)
        logger.info(f"Selected course: {course_name} ({course_id})")

    except (KeyboardInterrupt, EOFError):
        logger.info("\nCourse selection interrupted.")
        return
    except Exception as e:
        logger.error(f"Error fetching courses from Firestore: {e}")
        return
    # --- End of course selection ---

    logger.info(f"Fetching resource info for course '{course_id}'...")
    resources_info = client.get_course_resources_info(course_id, headers)

    if resources_info:
        logger.info("\nCourse Resources Info:")
        print(json.dumps(resources_info, indent=2))
    else:
        logger.error("Failed to retrieve course resources info.")

    logger.info("Get Course Resources Info test ended.")


def run_langgraph_chat_session(args: argparse.Namespace) -> None:
    """Interactive chat session directly with the LangGraph service."""
    # Check if streaming is enabled via environment variable or args
    use_streaming = os.getenv("ENABLE_STREAMING", "true").lower() == "true"
    if hasattr(args, "no_streaming") and args.no_streaming:
        use_streaming = False

    logger.info("=" * 60)
    logger.info(f"RUNNING: LangGraph Chat (direct, no gateway) - {'STREAMING' if use_streaming else 'NON-STREAMING'}")
    logger.info("=" * 60)
    logger.info("Type 'exit' or 'quit' to end.")

    client = APIClient(CONFIG.langgraph_url, timeout=CONFIG.request_timeout)

    # Keep conversation state
    messages = []

    while True:
        try:
            user_input = input("\nYou: ").strip()
            if user_input.lower() in ["exit", "quit"]:
                break
            if not user_input:
                continue

            messages.append({"role": "user", "content": user_input})

            # Use streaming or non-streaming based on configuration
            if use_streaming:
                response = client.langgraph_chat_stream(
                    messages=messages,
                    user_id="test-user",
                    course_id="test-course"
                )
            else:
                response = client.langgraph_chat(
                    messages=messages,
                    user_id="test-user",
                    course_id="test-course"
                )

            if not response:
                logger.error("No response from LangGraph")
                continue

            assistant_msg = response["messages"][-1]
            print("\nAssistant:", assistant_msg["content"])

            messages.append(assistant_msg)

        except (KeyboardInterrupt, EOFError):
            logger.info("\nChat interrupted.")
            break

    logger.info("LangGraph chat session ended.")


def run_ingestion_wizard() -> None:
    """Interactive wizard to select a user, course, and resource for ingestion."""
    db = FirebaseManager.get_firestore_client()
    if not db:
        logger.error("Failed to connect to Firestore")
        return
    
    try:
        # Step 1: Get User ID
        print("\nPlease select a User ID to test with:")
        for i, uid in enumerate(TEST_USER_IDS, 1):
            print(f"{i}. {uid}")
        print(f"{len(TEST_USER_IDS) + 1}. Enter a custom User ID")

        user_id = ""
        try:
            choice = int(input("Enter choice number: ").strip())
            if 1 <= choice <= len(TEST_USER_IDS):
                user_id = TEST_USER_IDS[choice - 1]
            elif choice == len(TEST_USER_IDS) + 1:
                user_id = input("Enter the custom User ID: ").strip()
            else:
                logger.error("Invalid choice")
                return
        except ValueError:
            logger.error("Invalid input. Please enter a number.")
            return

        if not user_id:
            logger.error("User ID cannot be empty")
            return
        
        # Step 2: Select a Course
        courses_ref = db.collection('users', user_id, 'courses').stream()
        courses = list(courses_ref)
        
        if not courses:
            logger.error(f"No courses found for user {user_id}")
            return
        
        print("\nPlease select a course:")
        for i, course in enumerate(courses, 1):
            course_data = course.to_dict()
            print(f"{i}. {course_data.get('name', '[No Name]')} ({course.id})")
        
        choice = int(input("Enter choice number: ")) - 1
        if not 0 <= choice < len(courses):
            logger.error("Invalid choice")
            return
        course_id = courses[choice].id
        
        # Step 3: Select a Resource
        resources_ref = db.collection(
            'users', user_id, 'courses', course_id, 'courseResources'
        ).stream()
        resources = list(resources_ref)
        
        if not resources:
            logger.error(f"No resources found for course {course_id}")
            return
        
        print("\nPlease select a resource to ingest:")
        for i, resource in enumerate(resources, 1):
            resource_data = resource.to_dict()
            print(f"{i}. {resource_data.get('title', '[No Title]')} ({resource.id})")
        
        choice = int(input("Enter choice number: ")) - 1
        if not 0 <= choice < len(resources):
            logger.error("Invalid choice")
            return
        resource_id = resources[choice].id
        
        # Step 4: Run the ingestion test
        args = argparse.Namespace(
            user_id=user_id,
            course_id=course_id,
            resource_id=resource_id
        )
        test_ingestion_flow(args)
        
    except ValueError as e:
        logger.error(f"Invalid input: {e}")
    except Exception as e:
        logger.error(f"Error in ingestion wizard: {e}")


def run_interactive_menu() -> None:
    """Displays the interactive menu and handles user choices."""
    while True:
        print("\n" + "-" * 58)
        print("  Integration Test Client Menu")
        print("-" * 58)
        print("1. Run API Gateway Health Check")
        print("2. Run Ingestion Wizard (needs Service Account)")
        print("3. Run Direct Search Test (bypasses LLM)")
        print("4. Run Full RAG Chat Test (uses LLM)")
        print("5. Get Course Resources Info")
        print("6. Run LangGraph Chat (direct, no gateway)")
        print("7. Run Chat with Interactive Citations")
        print("q. Quit")
        print("-" * 58)
        
        choice = input("Enter your choice: ").strip().lower()
        
        if choice == '1':
            test_health_check(None)
        elif choice == '2':
            run_ingestion_wizard()
        elif choice == '3':
            run_search_session(None)
        elif choice == '4':
            run_full_chat_session(None)
        elif choice == '5':
            test_course_resources_info(None)
        elif choice == '6':
            run_langgraph_chat_session(None)
        elif choice == '7':
            run_chat_with_citations_session(None)
        elif choice == 'q':
            logger.info("Exiting")
            break
        else:
            logger.warning("Invalid choice, please try again")


def main() -> None:
    """Main function to parse arguments or run the interactive menu."""
    if len(sys.argv) > 1:
        parser = argparse.ArgumentParser(
            description="Integration Test Client for the RAG System"
        )
        subparsers = parser.add_subparsers(dest="command", required=True)
        
        # Health check command
        p_health = subparsers.add_parser("test-health", help="Run a health check")
        p_health.set_defaults(func=test_health_check)
        
        # Direct search command (old chat command)
        p_search = subparsers.add_parser("search", help="Start an interactive direct search session (bypasses LLM)")
        p_search.set_defaults(func=run_search_session)
        
        # Full chat command
        p_chat = subparsers.add_parser("full-chat", help="Start an interactive chat session using the full RAG flow")
        p_chat.set_defaults(func=run_full_chat_session)

        # Chat with citations command
        p_cit = subparsers.add_parser("chat-citations", help="Start an interactive chat session with working citations")
        p_cit.set_defaults(func=run_chat_with_citations_session)

        # Get Course Resources Info command
        p_info = subparsers.add_parser("get-resources-info", help="Get info (title and ragDescription) for all resources within a course")
        p_info.set_defaults(func=test_course_resources_info)
        
        # LangGraph chat command
        p_langgraph = subparsers.add_parser(
            "langgraph-chat",
            help="Start an interactive chat directly against the LangGraph agent"
        )
        p_langgraph.set_defaults(func=run_langgraph_chat_session)
        
        # Ingestion command
        p_ingest = subparsers.add_parser("test-ingestion", help="Test the ingestion pipeline")
        p_ingest.add_argument("--user-id", required=True, help="The ID of the user")
        p_ingest.add_argument("--course-id", required=True, help="The ID of the course")
        p_ingest.add_argument("--resource-id", required=True, help="The ID of the resource")
        p_ingest.set_defaults(func=test_ingestion_flow)
        
        args = parser.parse_args()
        args.func(args)
    else:
        run_interactive_menu()


if __name__ == "__main__":
    main()
