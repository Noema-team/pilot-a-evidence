# Student Platform Testing Strategy

## Current State

| System | Real Test Coverage | Test Framework | Status |
|--------|-------------------|---------------|--------|
| **ai-server** (9 backend services) | ~650 tests across 6 Python + 2 Node services | pytest + Jest + Vitest | Unit, integration, cross-service, and contract tests passing in CI. Coverage gates not yet enforced. |
| **mobile** (Flutter app) | 0 executable tests | flutter_test, mocktail, bloc_test, dio_mock_adapter, firebase_auth_mocks | Tooling installed, test directory structure scaffolded, `pumpApp` helper ready. No tests written yet — deferred until Flutter SDK is available in dev/CI. |
| **web** (React app) | 0 tests | none | No test infrastructure. Not yet started. |

The ai-server backend has a functioning test pyramid: unit tests for algorithms/models/logic, integration tests for every service's endpoints, cross-service pipeline tests, and API contract tests that caught 12 real mobile↔backend mismatches. Error paths, per-endpoint auth enforcement, and edge cases remain the primary gaps (see [Audit Findings — Test Coverage & Gap Analysis](Task_Management/Audit%20Findings%20%E2%80%94%20Test%20Coverage%20%26%20Gap%20Analysis.md)).

---

## Guiding Principles

### Test Pyramid

```
        ┌──────────┐
        │   E2E    │   Few, slow, high confidence
        │  Tests   │   Cross-service flows with real infra
       ┌┴──────────┴┐
       │ Integration │   Service-level: TestClient + supertest
       │   Tests     │   Mocked externals, real routing
      ┌┴────────────┴┐
      │   Unit Tests  │   Many, fast, isolated
      │               │   Functions, models, algorithms
      └───────────────┘
```

- **70% unit, 20% integration, 10% E2E** as a rough target
- Every test must be **deterministic** -- no flaky tests
- Tests are the **contract** between backend and frontend
- **P0** = must have before building features against it
- **P1** = should have for confidence
- **P2** = nice to have for completeness

### Naming Conventions

**Backend (Python):**
- Files: `test_<module>.py` (e.g., `test_sm2_algorithm.py`)
- Functions: `test_<thing>_<condition>_<expected>` (e.g., `test_search_with_no_results_returns_empty`)
- Fixtures: `conftest.py` per service, shared fixtures in `tests/conftest.py`

**Backend (Node.js):**
- Files: `<module>.test.ts` (e.g., `server.test.ts`)
- Functions: `describe('<module>')` / `it('should <expected> when <condition>')`

**Mobile (Flutter):**
- Files: `<module>_test.dart` mirroring source path (e.g., `test/resources/models/resource_test.dart`)
- Functions: `test('<thing> <condition> <expected>')` or `group('<module>')` / `test('<expected>')`

### Coverage Targets

| Phase | Target | Gate |
|-------|--------|------|
| After Phase 0-1 (unit tests) | 50% line coverage | CI must pass |
| After Phase 2 (integration) | 70% line coverage | CI must pass |
| After Phase 3 (E2E) | 80% line coverage | Merge gate |

---

## Architecture Context

### Backend Service Map

```
                    ┌─────────────┐
                    │  Frontend   │
                    │  (Mobile)   │
                    └──────┬──────┘
                           │ HTTPS
                    ┌──────▼──────┐
                    │ api-gateway │ :3001  (Express, auth proxy)
                    └──┬───┬──┬───┘
                       │   │  │
            ┌──────────┘   │  └──────────────┐
            ▼              ▼                 ▼
    ┌───────────────┐ ┌──────────┐   ┌──────────────┐
    │ auth-service  │ │ rag-api  │   │ agent-graph  │
    │    :3002      │ │  :8000   │   │   :8003      │
    └───────────────┘ └────┬─────┘   └──────┬───────┘
                           │                │
              ┌────────────┼────────────────┤
              ▼            ▼                ▼
    ┌──────────────┐ ┌───────────┐  ┌──────────────┐
    │ weaviate-svc │ │ rag-worker│  │flashcard-svc │
    │    :8002     │ │ (headless)│  │    :8005¹    │
    └──────┬───────┘ └───────────┘  └──────────────┘
           │
    ┌──────▼───────┐
    │ weaviate-db  │ :8085
    │   + redis    │ :6380
    │   + postgres │ :5433
     │   + tempo    │ :3200
     │   + grafana  │ :3000
     └──────────────┘

¹ flashcard-service internally runs on :8003; docker-compose maps 8005→8003 externally.

     ┌───────────────────────┐
    │ observability-aggregator│ :8004
    │   (postgres + tempo)   │
    └───────────────────────┘
```

### Mobile Provider Dependency Graph

```
SharedPreferences (injected at bootstrap)
  └── ApiConfig
        ├── apiBaseUrl → String
        └── maxFileSizeBytes → int

FirebaseAuth.instance (HARDCODED ⚠️)
  ├── AuthController
  ├── UserRepository (via FirebaseFirestore.instance)
  │     └── UserProfile stream
  ├── CourseRepository (via FirebaseFirestore.instance)
  │     ├── courses stream
  │     └── starredCourses stream
  ├── ResourceApiClient (via Dio, FirebaseAuth)
  │     ├── resources list/detail/status
  │     ├── resource groups CRUD
  │     ├── uploadResource (also uses FirebaseStorage.instance directly)
  │     └── processing resources (polling 3s)
  ├── ChatApiClient (via Dio, FirebaseAuth)
  │     ├── threads list/rename/delete
  │     └── SSE streaming messages
  └── ChatBackendProvider
        └── Custom LLM provider bridging Flutter AI Toolkit ↔ ChatApiClient
```

---

## Cross-System Contract Testing

The mobile app calls backend endpoints through the api-gateway. Contract tests ensure the mobile client's expectations match what the backend actually provides.

### API Contract Surface

| Mobile Client Method | Gateway Route → Backend | Contract |
|---------------------|------------------------|----------|
| `ResourceApiClient.getResources()` | `GET /api/resources` → `rag-api-service GET /resources` | Paginated list with status, groups |
| `ResourceApiClient.getResource()` | `GET /api/resources/:id` → `rag-api-service GET /resources/:id` | Single resource with full metadata |
| `ResourceApiClient.uploadResource()` | `POST /api/resources` → `rag-api-service POST /resources` | Uploads file to Firebase Storage first, then POSTs metadata to backend — two-step contract |
| `ResourceApiClient.deleteResource()` | `DELETE /api/resources/:id` → `rag-api-service DELETE /resources/:id` | 200 with confirmation |
| `ResourceApiClient.getResourceGroups()` | `GET /api/resource-groups` → `rag-api-service GET /resource-groups` | List with capacity info |
| `ResourceApiClient.getResourceContent()` | `GET /api/resources/:id/content` → `rag-api-service GET /resources/:id/content` | Returns markdown content |
| `ChatApiClient.sendMessageStream()` | `POST /api/chat/messages?stream=true` → `agent-graph-service POST /chat/stream` | SSE stream with event types |
| `ChatApiClient.getThreads()` | `GET /api/chat/threads` → `agent-graph-service GET /threads` | List with last message preview |

### Contract Test Strategy

1. **Backend side**: Each service's integration tests assert response shapes match the mobile client's `fromJson` parsers
2. **Mobile side**: API client tests mock HTTP responses and verify models parse correctly
3. **Shared fixtures**: Create `tests/fixtures/api-contracts/` with JSON response schemas that both sides reference
4. **Breaking change detection**: Any backend response format change should fail the mobile API client tests

---

## CI/CD Integration

### GitHub Actions Strategy

**Backend (`apps/ai-server/.github/workflows/test.yml`):**
```yaml
# Per-service unit tests (parallel)
jobs:
  unit-test:
    strategy:
      matrix:
        service:
          - rag-api-service
          - rag-worker-service
          - weaviate-service
          - flashcard-service
          - agent-graph-service
          - observability-aggregator
          - api-gateway
          - auth-service
    steps:
      - run: pytest / jest

  integration-test:
    needs: unit-test
    # Docker Compose infra services + run cross-service tests

  e2e-test:
    needs: integration-test
    # Full stack with integration-client
```

**Mobile (`apps/mobile/.github/workflows/test.yml`):**
```yaml
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: subosito/flutter-action@v2
        with:
          flutter-version: "3.35.x"
      - run: flutter test --coverage
      - uses: codecov/codecov-action@v3
```

### Coverage Gates

| Gate | Threshold | Action |
|------|-----------|--------|
| PR merge | 50% line coverage | Block merge if below |
| Main branch | 70% line coverage | Alert in Slack |
| Release | 80% line coverage | Block release if below |

---

## Execution Order

### Phase 0: Foundation ✅ (`d42e9b2`)
- [x] Validate all test plan entries against actual code
- [x] Fix known backend bugs (duplicate except blocks in problem_solving.py and teaching.py — dead code)
- [x] Add psycopg2 to agent-graph-service requirements.txt
- [x] Add pytest + pytest-asyncio + pytest-cov + httpx to all 6 Python services' requirements.txt
- [x] Configure jest in api-gateway and auth-service (jest.config.ts + deps)
- [x] Install vitest and @testing-library/react in admin-webui
- [x] Fix broken mobile `app_test.dart`, delete counter module
- [x] Add missing mobile test dependencies (`firebase_auth_mocks`, `fake_cloud_firestore`, `firebase_storage_mocks`, `google_sign_in_mocks`, `dio_mock_adapter`)
- [x] Refactor mobile for testability (extract `ResourceApiInterface`, `ChatApiInterface`, `GoogleSignInInterface`; inject Firebase via providers; add `toJson` to 6 models)
- [ ] Get backend Docker Compose running locally → see [LOCAL-SETUP.md](../apps/ai-server/docs/LOCAL-SETUP.md)

### Phase 1: Unit Tests ✅
- [x] Backend: pure-logic unit tests — 108 tests passing (`84792f6`)
  - flashcard-service: SM-2 algorithm, models, markdown parser (20 tests)
  - weaviate-service: relevance policy, chunk UUID, LLM context builder (9 tests)
  - agent-graph-service: state models, router, classifier, utils (45 tests)
  - rag-worker-service: content tagger, error classification, config, chunking (34 tests)
- [x] Backend: remaining Python services — 200 tests passing (`39f0e80`)
  - rag-api-service: models, config, cache, validators, Pydantic models (147 tests)
  - observability-aggregator: TraceAggregator, flush, SpanExporter, ModelConfigUpdate (53 tests)
- [ ] ⏳ Mobile: unit tests for all models (fromJson/toJson round-trips) — **deferred: requires Flutter SDK**
- [ ] ⏳ Mobile: unit tests for repositories with mocked Firebase — **deferred: requires Flutter SDK**
- [ ] ⏳ Mobile: unit tests for API clients with mocked Dio — **deferred: requires Flutter SDK**

### Phase 2: Integration Tests ✅
- [x] Node.js + Python integration tests — 142 tests passing (`ecb3f4d`)
  - auth-service: 17 Jest tests (S2S auth, OIDC, Firebase ID token, App Check)
  - api-gateway: 84 Jest tests (proxy routes, middleware, auth, flashcards, resources)
  - rag-api-service: 41 FastAPI integration tests (all endpoints with mocked Firestore/PubSub)
- [x] Observability-aggregator integration tests — 48 tests passing
  - All 18 endpoints tested
- [x] Weaviate-service integration tests — 15 tests passing
  - All 7 endpoints: health, search, store/batch vectors, delete vectors/all, get chunks
- [x] Agent-graph-service integration tests — 13 tests passing
  - All 7 endpoints: health, chat, chat/stream, threads, messages, search
- [x] Flashcard-service integration tests — 19 tests passing
  - 13 endpoints: health, resource map, generate/review/list/save/update/delete flashcards, due cards, study stats, cram, section study, auth
- [x] Backend: cross-service flows — 27 tests passing
  - Search pipeline (rag-api → weaviate): 17 tests (query forwarding, resource resolution, error propagation, header verification, auth chain)
  - Chat pipeline (agent-graph → rag-api): 10 tests (GatewayClient headers, rag_search tool, course_map tool, impersonation)
- [ ] ⏳ Mobile: Riverpod provider tests with mocked dependencies — **deferred: requires Flutter SDK**
- [ ] ⏳ Mobile: widget tests for key screens — **deferred: requires Flutter SDK**

**Total: 572 tests passing (308 Python unit + 237 Node.js/integration + 27 cross-service)**

### Phase 3: E2E + Contract Tests ✅
- [x] Automate the integration-client for full E2E flows
  - 12 YAML scenarios in `dev/collectors/integration/scenarios/` (health, auth, resources, groups, chat, flashcards, search)
- [x] Add contract tests verifying mobile parsers match backend responses
  - 9 API contract fixture files in `apps/ai-server/tests/fixtures/api-contracts/`
  - 26 contract tests in `apps/ai-server/tests/integration/test_api_contracts.py`
  - **9 contract mismatches detected and resolved** (see Contract Mismatches section below)
- [x] Wire everything into CI
  - `apps/ai-server/.github/workflows/test.yml` — parallel matrix for all services
  - Pipeline: unit tests → integration tests → cross-service + contract tests → deploy trigger

**Total: 598 tests passing (572 previous + 26 contract tests)**

### Contract Mismatches (detected by Phase 3, resolved)

| Endpoint | Issue | Severity | Resolution |
|----------|-------|----------|------------|
| `GET /api/resources` | `ListResourcesResponse` missing `has_more` field | Medium | **Resolved**: Added `has_more` field to model and endpoint |
| `GET /api/resource-groups` | `ListGroupsResponse` missing `has_more` field | Medium | **Resolved**: Added `has_more` field to model and endpoint |
| `GET /api/resources/:id` | `ResourceResponse` missing `storage_url` and `error_stage` fields | High | **Resolved**: Added both fields to model and all 4 construction sites |
| `POST /api/chat/messages` (streaming) | SSE `done` event: backend nests in `data{}`, mobile expects flat `message_id`/`thread_id`/`full_response` | High | **Resolved**: Flattened done event, added `message_id` and `full_response` |
| `POST /api/chat/messages` (streaming) | SSE `error` event: backend nests in `data.error`, mobile reads `event['error']` | High | **Resolved**: Flattened error event to top-level |
| `POST /api/chat/messages` (streaming) | SSE `source` event: backend emits `state_update`, mobile expects `source` | Medium | **Resolved**: Backend now emits `source` event alongside `state_update` when search_results present |
| `GET /api/chat/threads` | Thread shape: backend returns `{thread_id, last_updated, title}`, mobile expects `{thread_id, name, course_id, created_at, updated_at, message_count}` | High | **Resolved**: Backend returns all mobile-expected fields |
| `GET /api/chat/messages` | Message shape: backend returns `{role, content}`, mobile expects `{message_id, role, content, created_at}` | High | **Resolved**: Backend enriches messages with `message_id` and `created_at` |
| `POST /api/chat/messages` (non-streaming) | Response shape: backend returns ChatState, mobile expects `{response, message_id, thread_id, agent_mode, model, created_at}` | High | **Resolved**: Backend transforms response to flat ChatResponse shape |
| `POST /api/chat/messages` | Mobile sends `message`, gateway expects `query` — every request returns 400 | Critical | **Resolved**: Gateway now accepts both; mobile updated to send `query` |
| `POST /api/chat/messages` (streaming) | Mobile sends `stream=true` query param, gateway checks `response_mode` body — streaming never activates | Critical | **Resolved**: Gateway now checks both; mobile sends `response_mode: streaming` |
| `GET /api/resources/:id` | Missing gateway route for singular resource GET | Medium | **Resolved**: Added `GET /api/resources/:resourceId` to gateway |

---

## Detailed Plans

- **Backend**: [apps/ai-server/docs/TESTING-STRATEGY.md](../apps/ai-server/docs/TESTING-STRATEGY.md)
- **Mobile**: [apps/mobile/docs/TESTING-STRATEGY.md](../apps/mobile/docs/TESTING-STRATEGY.md)
- **Local Setup**: [apps/ai-server/docs/LOCAL-SETUP.md](../apps/ai-server/docs/LOCAL-SETUP.md)
