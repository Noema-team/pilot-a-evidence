Investigation is complete; the verified evidence (worker `process_document` failure handler, rag-api `run_transactional_update` failed branch, `Resource`/`ResourceResponse` models, `_fail_if_still_stale`, `classify_error`, existing contract-test infrastructure, and the compose image tags) fully supports the authoritative definition. Producing the contracted charter now.

<<<SLE-OUTPUT>>>
### docs/cycle-charter.md
## Scope

Align the rag-worker's failure status payload with rag-api's existing failed-branch contract, so a failed RAG processing job persists the worker's actual error message, the failing pipeline stage, and a deliberately derived retryable flag — pinned by a contract test on the worker→rag-api failure path.

In scope:

- **`apps/ai-server/rag-worker-service/main.py` — the failure path of `process_document` only:**
  - A stage tracker (a local set immediately before each pipeline step, per the "update-before-await" convention) so the exception handler reports the stage executing at failure time. Stage names reuse the existing progress-update vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown — the same value the stale-lease sweep uses for `error_stage`.
  - The failed status payload published via `_publish_status_update` gains `error_message` (the actual exception message), `stage`, and `retryable` (deliberately derived). The legacy `error` key is retained alongside `error_message` as a compatibility hedge for any unknown consumer of the status topic.
  - `retryable` derivation from the existing `classify_error(e)`: transient-classified → `true`; permanent-classified, including unclassified-unknown (classify_error's conservative default), → `false` — aligned with the worker's actual ACK/NACK behavior in `run_worker`.
- **`apps/ai-server/rag-api-service/main.py` — no functional change.** Its failed branch in `run_transactional_update` already reads `error_message`/`stage`/`retryable` and persists `error`/`error_stage`/`retryable` on the main document plus message/stage (with `error_code` defaulting to `"UNKNOWN"`) in the `processing/summary` error subdocument. That behavior is preserved and pinned by the new test.
- **`apps/ai-server/tests/integration/` — a new contract test** that imports both sides rather than restating the contract in a fixture: builds the failure payload through the worker's code path, feeds it through rag-api's `run_transactional_update` (Firestore emulator or fakes, per the existing hermetic patterns in `test_api_contracts.py` and both services' emulator branches), and asserts the persisted `error`, `error_stage`, and `retryable` equal the worker's values. It includes a key-set drift guard on both the worker's payload keys and rag-api's read keys, and pins the stage-tracker mechanism on representative stages (an early-stage and a late-stage failure).

## Purpose

The worker's exception handler publishes a one-key payload (`{"error": str(e)}`); rag-api's failed branch reads three keys (`error_message`, `stage`, `retryable`). Because of the mismatch, every worker-originated failure currently persists `error` as the fallback `"Processing failed"`, `error_stage` as null, and a fabricated `retryable: true` — and the `processing/summary` error subdocument inherits the same fallbacks with `error_code` always `"UNKNOWN"`. Users and support cannot disambiguate failures, and the persisted retryability does not reflect the worker's real retry behavior.

The worker is the odd one out: the stale-lease sweep (`_fail_if_still_stale`), rag-api's enqueue-failure paths (`/process`, `POST /resources`), the `Resource` model, and `ResourceResponse` all already use the `error`/`error_stage`/`retryable` schema. Aligning the worker to the API's existing contract requires no Firestore migration, no field rename, no backfill, and no reader changes. After the fix, the persisted record tells the truth: the actual error message, the true failing stage, and a retryable flag that mirrors whether Pub/Sub will actually redeliver (transient) or the job was acked with manual reprocess via `POST /process` remaining (permanent).

## Requirements

1. **Failure payload completeness.** When document processing fails, the worker's failed status payload must include `error_message` (the actual exception message), `stage` (the pipeline stage executing at failure time), and `retryable` (deliberately derived). The payload must never rely on rag-api's fallback defaults for these keys.
2. **Stage tracking.** The worker must track the currently executing pipeline stage through `process_document` so the failure handler reports the true failing stage. Stage names reuse the existing progress-stage vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown.
3. **API persistence unchanged.** rag-api's failed branch must persist the worker-provided values unchanged: main document `error` ← payload `error_message`, `error_stage` ← payload `stage`, `retryable` ← payload `retryable`; the `processing/summary` error subdocument must carry the same message and stage. (Verified as already true in the current code; this requirement is preserved behavior, pinned by the contract test — no rag-api code change is anticipated. If implementation discovers otherwise, stop and record a plan deviation.)
4. **Explicit retryable derivation.** Errors classified transient by `classify_error` → `retryable: true`; classified permanent, including unclassified-unknown per `classify_error`'s conservative default, → `retryable: false`. This is aligned with the worker's ACK/NACK decisions in `run_worker`.
5. **Contract test.** A contract test must cover the worker failure → rag-api persistence path: it exercises the worker's failure-payload construction and rag-api's failed-branch persistence (via the Firestore emulator or fakes) and asserts the persisted `error`, `error_stage`, and `retryable` equal the worker's values. It must fail if either side's payload keys drift.

Acceptance criteria for this cycle (all currently unmet):

- A failed job's published status message contains `error_message`, `stage`, and `retryable` — none relying on rag-api's fallback defaults.
- After a failed job, the persisted resource document has `error` = the worker's actual error message (not `"Processing failed"`), `error_stage` = the failing stage (not null), and `retryable` = the worker's derived value.
- The `processing/summary` error subdocument carries the same message and stage as the main document.
- The contract test exists and passes, failing on either side's key drift.

## Boundaries

Binding constraints:

- **Must:** align the worker to rag-api's existing contract — publishing `error_message`/`stage`/`retryable` — rather than changing rag-api's reads or persisted schema.
- **Must not:** require a Firestore migration, field rename, or backfill of existing documents; the persisted fields (`error`, `error_stage`, `retryable`) keep their names and semantics.
- **Must:** every worker-originated failure payload carries `retryable` explicitly; rag-api's `details.get("retryable", True)` fallback must not be the operative mechanism for worker failures.
- **Prefer:** retain the legacy `error` key in the worker's failure payload alongside `error_message`, for continuity with any existing consumers of the status topic and log tooling.
- **Prefer not:** introduce a structured error-code taxonomy (`error_code` values) in this fix.

Non-goals (out of scope):

- Changing the stale-lease sweep's direct failure write — it already persists `error`/`error_stage`/`retryable` consistently with this contract (its `retryable: true` stays correct: a dead worker is a transient condition).
- Changing retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, or heartbeat intervals — only the *reporting* of retryability in the payload changes.
- Frontend or mobile changes — `ResourceResponse` already exposes `error` and `error_stage` to clients.
- Introducing structured error codes or a failure taxonomy — the `processing/summary` `error.code` remains `"UNKNOWN"` unless a code is actually sent.
- Any scope the companion D3 issue covers beyond this worker→rag-api failure payload alignment (its content is unavailable in this context).

Accepted deliberate behavior change: unclassified-unknown exceptions currently persist `retryable: true` (the silent default) but will now persist `false`, matching `classify_error`'s conservative treatment. This prevents infinite retry loops; manual reprocess via `POST /process` is unaffected. Known residual risks, accepted: unknown consumers of the status topic reading the old key set (mitigated by retaining `error`); stage-tracker drift as the pipeline evolves (mitigated by the update-before-await convention and representative-stage test coverage); the contract test ossifying the payload (intentional — that is the drift guard).

## Version bump

- **`apps/ai-server/rag-worker-service`:** patch bump of its image tag in `apps/ai-server/docker-compose.yml`, `student-rag-worker-service:0.1.0` → `student-rag-worker-service:0.1.1`. Rationale: behavior fix confined to failure reporting; no client-facing API shape change (`ResourceResponse` untouched), no schema change, no new runtime dependencies.
- **`apps/ai-server/rag-api-service`:** no bump — no code change to this service in this cycle.
- Tests and fixtures are unversioned.

Note: the compose image tag is the only version reference verified for these services in the repository; if the team tracks service versions elsewhere, apply the same patch-level bump at that location.

## Deferred items

- **Companion D3 issue** referenced by the Objective: its scope is not available in this context; anything it covers beyond this worker→rag-api failure payload alignment is deferred.
- **Reconciliation with the original D4 deviation note in `plans/upload-flow.md`:** that file is not present in the current tree (the reference comes from the Objective text); deferred.
- **Structured error-code taxonomy / failure taxonomy:** the `processing/summary` `error.code` stays `"UNKNOWN"` unless a code is actually sent.
- **Retry/backoff mechanics:** Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals — unchanged; only the reporting of retryability changes.
- **Stale-lease sweep behavior:** no changes; its direct `retryable: true` failure write stays as is.
- **Frontend/mobile work:** none; `ResourceResponse` already exposes `error`/`error_stage`.
- **Dropping the legacy `error` key** from the worker's failure payload: trivial cleanup if a later audit confirms rag-api's status subscriber is the only consumer of the status topic.
<<<END-SLE-OUTPUT>>>