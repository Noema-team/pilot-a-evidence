<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path="docs/cycle-charter.md">>>
**Cycle charter — rag-worker → rag-api failure payload contract alignment**
Run 2aa3a92f-7870-4b0f-9cc8-2cf3447c9a28 · iteration 1 · step scoping.produce
Authoritative source: define-work WorkItem `wi-define-108-a8` (artifact `definition:obj-108`).

## Scope

One bounded change: make the rag-worker's failed status payload speak rag-api's existing failed-branch contract, and pin the seam with a contract test.

Worker side (`apps/ai-server/rag-worker-service/main.py`):

- The failure publish in `process_document`'s exception handler currently sends `details = {"error": str(e)}` via `_publish_status_update`. Replace it with a payload carrying:
  - `error_message` — the actual exception message (`str(e)`);
  - `stage` — the pipeline stage executing at failure time, from a stage tracker maintained through `process_document`;
  - `retryable` — deliberately derived from `classify_error(e)` (transient → true, permanent → false);
  - the legacy `error` key retained alongside `error_message` as a compatibility hedge for unknown consumers of the status topic.
- Stage tracking: a local stage tracker set immediately before each pipeline step in `process_document` (the "set the tracker immediately before the await" convention). Stage names reuse the existing progress-update vocabulary — `starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete` — with `"processing"` as the safe value when the stage is genuinely unknown (the same value the stale-lease sweep writes to `error_stage`, so the field never regresses to null).
- Retryable derivation: reuse `classify_error` exactly as `run_worker` already does for ACK/NACK decisions. No new classification logic; widening `classify_error` is out of scope.

Contract test (`apps/ai-server/tests/integration/`):

- New test inside or alongside the existing suite, following `test_api_contracts.py` conventions: import the real modules on both sides rather than restating the contract in a fixture.
- It must build the worker's failure payload through the worker's code path, feed it through rag-api's `run_transactional_update` failed branch (Firestore emulator mode — both services already have `FIRESTORE_EMULATOR_HOST` branches — or fakes), and assert the persisted `error`, `error_stage`, and `retryable` equal the worker's values.
- It must include a key-set drift guard over both sides' payload keys, so a future key edit on either side fails the build instead of silently re-creating this bug.
- Coverage on representative stages: an early-stage failure and a late-stage failure — enough to catch the tracker being removed or bypassed without ossifying every pipeline step.

Explicitly in-scope-but-unchanged: rag-api's failed-branch code. It already reads `error_message`/`stage`/`retryable` and persists `error`/`error_stage`/`retryable` plus the `processing/summary` error subdocument (code defaulting to `"UNKNOWN"`). The test pins this behavior; no rag-api code change is expected or desired.

## Purpose

A failed RAG processing job must tell the truth. Today every worker-originated failure persists the fallback string `"Processing failed"`, a null `error_stage`, and a fabricated `retryable: true`, because the worker publishes one key (`error`) while rag-api's failed branch reads three (`error_message`, `stage`, `retryable`). Users and support cannot disambiguate failures, and the persisted retryable flag contradicts the worker's actual ACK/NACK behavior for unknown errors.

This cycle aligns the worker to the API — the API side is the established schema, already written consistently by three other paths (the worker's stale-lease sweep, rag-api's `/process` and `POST /resources` enqueue-failure paths) and exposed by `ResourceResponse` and the `Resource` model. Fixing the odd one out requires no migration, no backfill, and no reader changes. The contract test locks the seam so this drift cannot silently recur.

Done means: after a failed job, the persisted document carries the worker's actual error message, the true failing stage, and a retryable value derived the same way the worker's retry decision was made; the `processing/summary` error subdocument carries the same message and stage; and a contract test proves the whole path end to end.

## Requirements

1. **Worker failure payload.** When document processing fails, the worker's failed status payload must include `error_message` (the actual exception message), `stage` (the pipeline stage executing at failure time), and `retryable` (deliberately derived). The payload must never rely on rag-api's fallback defaults (`"Processing failed"`, null stage, `retryable` default true) for these keys.
2. **Stage tracking.** The worker must track the currently executing pipeline stage through `process_document` so the failure handler reports the true failing stage. Stage names must reuse the existing progress-stage vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown. Convention: set the tracker immediately before the await of each step.
3. **API persistence unchanged in behavior.** rag-api's failed branch must persist the worker-provided values unchanged: main document `error` ← payload `error_message`, `error_stage` ← payload `stage`, `retryable` ← payload `retryable`; the `processing/summary` error subdocument must carry the same message and stage (`error.code` remains `"UNKNOWN"` unless a code is actually sent).
4. **Retryable derivation.** Explicit and aligned with the worker's ACK/NACK behavior: errors `classify_error` classifies transient → `retryable: true`; classified permanent (including unclassified-unknown, per `classify_error`'s conservative default) → `retryable: false`. This makes one deliberate behavior change: unclassified-unknown failures persist `retryable: false` where the silent default previously wrote `true`. Accepted; manual reprocess via `POST /process` is unaffected.
5. **Legacy key retained.** The worker's failure payload keeps the legacy `error` key alongside `error_message`, for continuity with any existing consumers of the status topic and existing log tooling.
6. **Contract test.** A test covering the worker failure → rag-api persistence path must exist and pass: it exercises the worker's failure-payload construction through rag-api's failed-branch persistence (Firestore emulator or fakes) and asserts the persisted `error`, `error_stage`, and `retryable` equal the worker's values. It must fail if either side's payload keys drift.

## Boundaries

Must not:

- Change rag-api's reads or persisted schema — the worker aligns to the API, not the reverse.
- Require any Firestore migration, field rename, or backfill of existing documents. Persisted fields `error`, `error_stage`, `retryable` keep their names and semantics; `schema_version` stays 2.
- Leave `retryable` implicitly defaulted for worker failures — the API-side `details.get("retryable", True)` fallback must not be the operative mechanism for worker-originated failures.

Non-goals (out of scope):

- The stale-lease sweep's direct failure write (`_fail_if_still_stale`) — it already persists `error` / `error_stage: "processing"` / `retryable: true` consistently with this contract; a dead worker is a transient condition, so its `retryable: true` stays correct.
- Retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals. Only the *reporting* of retryability in the payload changes.
- Frontend or mobile changes — `ResourceResponse` already exposes `error` and `error_stage` to clients.
- Structured error codes or a failure taxonomy — the `processing/summary` `error.code` remains `"UNKNOWN"` unless a code is actually sent; introducing codes is a preferred-not.
- Widening `classify_error`'s heuristics for unrecognized-but-transient failures.
- Any scope the companion D3 issue covers beyond this payload alignment (its content is unavailable in this context).

Risks accepted by approvers:

- Unknown consumers of the status topic reading the old key set — mitigated by retaining `error`; residual risk accepted as low.
- Stage-tracker drift as the pipeline evolves — mitigated by the set-before-await convention and representative-stage test coverage.
- `retryable: false` for unclassified errors reduces auto-retry affordances for genuinely transient-but-unrecognized failures — accepted; manual reprocess via `POST /process` remains.
- The contract test ossifies the payload — intentional; that is the drift guard doing its job. Adding a key later means touching the test.

## Version bump

- **rag-worker-service:** patch-level behavior fix. The published failure payload gains keys, and `retryable` changes semantics for unknown errors; no public API surface change, no dependency additions anticipated, no config changes.
- **rag-api-service:** no bump — no code change is expected; the cycle only adds a test that pins its existing failed branch.
- **Firestore:** no schema change; `schema_version` remains 2; no migration or backfill.
- No version manifest for these services was verified in the repository; if release tooling assigns versions, treat this as a patch increment on the worker.

## Deferred items

- The companion D3 issue referenced by the Objective: its scope is not available in this context; anything it covers beyond the worker→rag-api failure payload alignment is deferred.
- Reconciling this analysis with the original D4 deviation note in `plans/upload-flow.md` — that file is not present in the current tree; the reference comes from the Objective text.
- Dropping the legacy `error` key from the worker's failure payload, pending an audit confirming the worker is the only publisher and rag-api the only consumer of the status topic. Trivial cleanup once confirmed.
- Widening `classify_error` (new transient heuristics) if unclassified-transient failures prove common in practice.
- A structured error-code taxonomy for the `processing/summary` error subdocument.
- Any frontend/mobile affordances built on `retryable` (e.g., a retry UI), if ever desired.
<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>