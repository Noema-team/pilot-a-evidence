---
tags:
  - TaskManagement
---
# Sidebar structure
#ToDo
Left sidebar: courses overview page (archive, create, star courses), list of starred courses, general chat (with histories from all course chats), flashcards, resource page, profile, settings.

---
# Course page layout
#ToDo
Small buttons: upload resources, manage resources (add/remove existing), star course. Cards: flashcards, timeline progress relevant to course. Bottom: chat.

---
# System instructions
#ToDo
The user should be able to set system instructions for AI agents. Needs decision: same instructions for all agents, or per-agent instructions?

---
