---
tags:
  - Documentation/Internal
---
# Retry Logic & Error Handling

## Why we send full history every request

Even if the frontend already knows the history, sending the full array back in every response is the gold standard for synchronization:

- **Auto-Truncation (Memory Management):** The backend has a setting (`MAX_MESSAGE_HISTORY=20`). When the chat gets long, the backend deletes the oldest messages to save tokens. If we only send the last message, the frontend will keep showing messages the AI has "forgotten."
- **AI Corrections:** The AI pipeline may clean up previous queries (coreference resolution). Syncing the whole history ensures the UI matches the AI's actual context.
- **Simplicity:** Prevents "out of sync" states where frontend and backend have different versions of the truth.

## Failure Handling

### Scenario A: Frontend fails to reach the backend (network error)

Responsibility: 100% Frontend.

- If `fetch()` throws an error or the gateway returns a 503, the frontend should NOT add the message to the official history state. Mark it as "Failed" in the UI and show a "Retry" button.
- Save failed messages in LocalStorage so that after a page refresh the frontend can prompt: "You had a message that failed to send. Want to try again?"

### Scenario B: Backend fails mid-answer (crashes or timeouts)

Responsibility: Both frontend and backend.

- **Backend:** LangGraph Checkpoints are only saved after the AI successfully finishes. If the backend crashes mid-stream, the checkpoint is not updated. This makes retrying safe — the backend sees the conversation as it was before the failure.
- **Frontend:** Detects the failed stream and offers retry using the same `thread_id`.

## Idempotency

If the frontend sends the same message twice (retry), the backend should not treat it as two separate questions. For a chat app, the `thread_id` plus manual "Retry" click is usually sufficient. No special idempotency endpoint needed — re-call `POST /messages` with the same `thread_id`.

## Frontend implementation notes

- Keep a `pendingMessages` list for messages not yet confirmed by the backend.
- Show a "ghost" message or loader while waiting. On error, turn it red with a retry icon.
- The existing API response format already supports this flow.
