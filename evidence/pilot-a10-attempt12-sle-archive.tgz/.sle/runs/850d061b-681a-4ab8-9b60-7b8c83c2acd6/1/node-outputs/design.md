Design investigation is complete — both sides of the seam have been read from source, and the existing contract-test/fake-transaction patterns are confirmed reusable. Emitting the design artifact now.

<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path=".sle/work/wi-design-108/design.md">>>
# Design — rag-worker → rag-api failure payload contract alignment

Cycle: `rag-worker → rag-api: failure payload contract mismatch — failures persist without message or stage`
Step: design · Iteration 1 · Run 850d061b-681a-4ab8-9b60-7b8c83c2acd6

Authoritative scope: WorkItem `wi-define-108-a8`, artifact `definition:obj-108`
(sha256 `71f1c39c…`). Everything below implements exactly that Definition; nothing wider.

---

## 1. Summary

The worker's `process_document` exception handler publishes a failed status with a
one-key payload (`{"error": str(e)}`); rag-api's failed branch in
`run_transactional_update` reads three keys (`error_message`, `stage`,
`retryable`). Every worker-originated failure therefore persists the fallback
string `"Processing failed"`, `error_stage = None`, and a fabricated
`retryable: True` — on the main document and, inherited, in the
`processing/summary` error subdocument (with `error_code` always `"UNKNOWN"`).

The fix is one-sided by design (Definition constraint 1): the worker aligns to
rag-api's existing read contract. rag-api is not touched. The worker gains
(a) a pipeline stage tracker, (b) a named failure-payload builder that emits
`error_message` / `stage` / `retryable` (plus the legacy `error` key as a
compatibility hedge per F11), and (c) a deliberate `retryable` derivation from
the existing `classify_error()`. A cross-service contract test pins the seam:
it drives the worker's real failure-payload construction into rag-api's real
failed-branch persistence over a fake Firestore transaction and fails if either
side's keys drift.

No Firestore migration, no field renames, no backfill (Definition constraint 2).

---

## 2. Verified current behavior (repository evidence, iteration 1)

| # | Fact | Where verified |
|---|------|----------------|
| V1 | Worker failure publish: `await self._publish_status_update(..., "failed", {"error": str(e)}, job_id)` inside `process_document`'s single `except Exception` | `rag-worker-service/main.py`, `process_document` except branch |
| V2 | `process_document` is one large `try`; no stage state exists at failure time. Progress publishes use stage names: `starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`, final `completed` | same, try body |
| V3 | API failed branch: `error ← details.get("error_message", "Processing failed")`, `error_stage ← details.get("stage")`, `retryable ← details.get("retryable", True)`; summary gets `stage ← details.get("stage", "unknown")` and `error = {"code": details.get("error_code","UNKNOWN"), "message": details.get("error_message","Processing failed"), "stage": details.get("stage")}` | `rag-api-service/main.py`, `run_transactional_update` |
| V4 | Allowed transition gate: `"processing": {"completed", "failed"}` — a worker failed-update only lands if the doc is currently `processing` (it is; the worker claimed it in `_claim_resource_if_queued`) | same, `ALLOWED_TRANSITIONS` |
| V5 | Established persisted schema `error` / `error_stage` / `retryable` is written by three other paths: worker stale-lease sweep (`_fail_if_still_stale`, `error_stage="processing"`, `retryable=True`), rag-api enqueue-failure rollback in `POST /process` and `POST /resources` (`error_stage="enqueue"`), and exposed by `ResourceResponse` + `models/resource.py` (`retryable: bool = True`) | all three files read |
| V6 | `classify_error(e) → bool`: `TransientError`/transient types/status 429,5xx → True; `PermanentError`/other 4xx → False; unknown exceptions → **False** (conservative). Used by `run_worker` for ACK/NACK | `rag-worker-service/main.py` |
| V7 | `_publish_status_update` swallows its own exceptions (logs `status_publish_failed`, never re-raises) and injects `details["jobId"]` when `job_id` is set; the failed branch of `run_transactional_update` does not consume `jobId` | worker `main.py` |
| V8 | Contract-test infrastructure exists: fixture- and AST-based static contract tests (`tests/integration/test_api_contracts.py`, incl. `_get_agent_graph_shapes` AST pattern) and a fake-transaction Firestore harness (`rag-worker-service/tests/unit/test_processing_lease.py` `FakeTx/FakeSnap/FakeRef/FakeDb` + `firestore.transactional` monkeypatched to identity) | both test files read |
| V9 | Hermetic import support: `tests/integration/conftest.py` mocks cloud deps and puts `rag-api-service` on `sys.path` (`import main` = rag-api). `rag-worker-service/tests/conftest.py` stubs the worker's heavy deps (langchain, openai, spacy, tiktoken, tenacity, langfuse, firebase_admin, google.*) and sets required env defaults. Neither conftest currently makes the *worker's* `main` importable from `tests/integration` | both conftests read |

Confirmed: F3, F4, F5, F6, F7, F9, F10 of the Definition hold exactly as stated.

---

## 3. Target behavior

### 3.1 Before → after (worker-originated failure, e.g. text retrieval times out)

| Field (persisted by rag-api) | Today | After |
|---|---|---|
| main `error` | `"Processing failed"` (fallback) | actual exception message, e.g. `"weaviate text fetch timeout"` |
| main `error_stage` | `None` | last pipeline milestone reached, e.g. `"starting"` |
| main `retryable` | `True` (silent default) | `classify_error(e)` — `True` for the timeout example |
| `processing/summary.stage` | `"unknown"` | same failing stage, e.g. `"starting"` |
| `processing/summary.error.message` | `"Processing failed"` | actual exception message |
| `processing/summary.error.stage` | `null` | same failing stage |
| `processing/summary.error.code` | `"UNKNOWN"` | `"UNKNOWN"` (unchanged; no error codes sent — non-goal) |

### 3.2 Worker failure payload (single source of truth)

```python
def build_failure_details(error_message: str, stage: str, retryable: bool) -> dict:
    """Single source of truth for the worker's failed-status payload keys.

    rag-api's failed branch (run_transactional_update) reads error_message /
    stage / retryable. The legacy `error` key is retained deliberately
    (Definition F11): it is ignored by rag-api but keeps any unknown consumer
    of the status topic working until an audit says otherwise.
    """
    return {
        "error_message": error_message,   # rag-api failed branch reads this
        "error": error_message,           # legacy alias — hedge for unknown topic consumers
        "stage": stage,                   # failing pipeline stage (progress vocabulary)
        "retryable": retryable,           # deliberately derived, never defaulted
    }
```

Exact key set (pinned by test): `{"error_message", "error", "stage", "retryable"}`.

---

## 4. Architecture

### 4.1 Change surface

| File | Change |
|---|---|
| `apps/ai-server/rag-worker-service/main.py` | **Modify.** Add `build_failure_details`; add stage tracker to `process_document`; rewrite the except-branch payload construction; add `stage` to the failure log event |
| `apps/ai-server/rag-api-service/main.py` | **No change.** Already implements R3 when keys are present (V3) |
| `apps/ai-server/rag-api-service/models/resource.py` | **No change.** `error/error_stage/retryable` schema untouched (constraint 2) |
| `apps/ai-server/rag-worker-service/tests/unit/test_failure_payload.py` | **New.** Worker-side payload + tracker + retryable-derivation tests |
| `apps/ai-server/tests/integration/conftest.py` | **Extend.** Reuse worker stub table; load worker `main` by explicit path under a unique module name |
| `apps/ai-server/tests/integration/test_worker_failure_contract.py` | **New.** The cross-service contract test (centerpiece) + drift guards |

### 4.2 Worker: stage tracker

**Semantics.** The tracker holds *the last pipeline milestone reached*. A
failure inside a step reports the milestone in effect when that step began —
the same stage name the client last saw on the progress timeline. This keeps
reported stages truthful against the fixed progress vocabulary (there is no
"extracting" stage name; reporting the *next* milestone, e.g. `text_retrieved`
for a failure during retrieval, would be false). The safe value when the stage
is genuinely unknown is `"processing"` — the same value the stale-lease sweep
uses for `error_stage` (V5), so `error_stage` never regresses to null.

**Assignment sites (co-located with the existing progress publishes so the
tracker and the client-visible timeline share one source of stage names):**

```python
async def process_document(self, user_id, course_id, resource_id, job_id=None):
    metrics = ProcessingMetrics(start_time=time.time())
    trace = ... if self.langfuse else None
    current_stage = "processing"                    # safe value if we fail before any milestone
    try:
        current_stage = "starting"                  # set before the first await (validation)
        await self._validate_processing_request(...)
        await self._publish_status_update(..., "processing", {"stage": "starting"}, job_id)

        text_content, doc_metadata = await self._get_extracted_text(...)
        current_stage = "text_retrieved"            # ← immediately before the publish with the same literal
        await self._publish_status_update(..., {"stage": "text_retrieved", "progress": 20}, job_id)

        tags, confidence_scores = await self.content_tagger.generate_tags(...)
        current_stage = "tagging_complete"
        await self._publish_status_update(..., {"stage": "tagging_complete", "progress": 40}, job_id)

        summary_data = await self.generate_document_summary(...)
        ... db.update(update_data) ...
        current_stage = "summary_generated"
        await self._publish_status_update(..., {"stage": "summary_generated", "progress": 50}, job_id)

        chunks = await self._create_enhanced_chunks(...)
        current_stage = "chunking_complete"
        await self._publish_status_update(..., {"stage": "chunking_complete", "progress": 60}, job_id)

        vectors = await self._generate_embeddings_with_openrouter(...)
        current_stage = "embeddings_complete"
        await self._publish_status_update(..., {"stage": "embeddings_complete", "progress": 80}, job_id)

        ... delete_old_vectors_via_service / store_chunks_via_service /
            _save_processing_metadata_to_subcollection ...          # failures here report "embeddings_complete"
        await self._publish_status_update(..., "completed", final_details, job_id)
        ...
        return metrics
    except Exception as e:
        metrics.error_message, metrics.end_time = str(e), time.time()
        self.logger.error("document_processing_failed", ..., error=str(e), stage=current_stage)
        failure_details = build_failure_details(
            error_message=str(e),
            stage=current_stage,
            retryable=classify_error(e),
        )
        await self._publish_status_update(user_id, course_id, resource_id, "failed",
                                          failure_details, job_id)
        if trace: trace.update(output={"success": False, "error": str(e)})
        return metrics
```

**Invariant (the drift-prevention convention, per Definition):** *at every
`await`, the tracker holds the stage to report if that await fails.* Each
`current_stage = "X"` line sits immediately before the
`_publish_status_update(... {"stage": "X"} ...)` call using the identical
literal; the pre-try `"processing"` init and the pre-validation
`"starting"` assignment are the two documented special cases. A pipeline step
added without a tracker assignment reports the previous milestone (stale but
never null); the AST guard in §5.3 fails the build if any *published* stage
literal lacks a matching tracker assignment.

Notes:
- The tracker is a plain per-call local — no shared state, no concurrency concerns.
- `generate_document_summary` and the post-completion helpers swallow their own
  exceptions today; their behavior is unchanged.
- Exceptions raised *before* the `try` (metrics/trace construction) propagate to
  `run_worker` exactly as today — no failure payload is published for them now,
  and none will be; out of scope.

### 4.3 Worker: retryable derivation (deliberate, aligned with ACK/NACK)

`retryable = classify_error(e)`:

| Exception class | classify_error | persisted retryable | Pub/Sub outcome |
|---|---|---|---|
| `TransientError`, connect/timeout/connection errors, HTTP 429/500/502/503/504 | True | `true` | NACK → redelivered |
| `PermanentError`, other 4xx | False | `false` | ACK → manual reprocess via `POST /process` |
| Unclassified-unknown (incl. `RuntimeError`, `ValueError`) | False (conservative default, V6) | `false` | ACK → manual reprocess |

**Deliberate behavior change (accepted, per Definition F8):** unclassified
unknown exceptions previously persisted `retryable: true` via the API's silent
default; they now persist `false`, matching the worker's actual ACK (no
redelivery) decision. This prevents infinite retry loops against poison
messages; the manual reprocess path is unaffected. The stale-lease sweep's
separate `retryable: true` write is untouched and stays correct (a dead worker
is a transient condition) — non-goal to change.

### 4.4 rag-api: preservation, not implementation

Requirement R3 is a *preservation* requirement: V3 shows the failed branch
already persists `error_message → error`, `stage → error_stage`,
`retryable → retryable`, and mirrors message+stage into `processing/summary`.
With the worker always sending all three keys, none of the fallbacks
(`"Processing failed"`, `None`, `True`, summary `"unknown"`) can fire for
worker failures. The `details.get("retryable", True)` fallback stays in the
code untouched (constraint: it must not be the *operative* mechanism — it
remains only as dead-defensive code for any future publisher). The legacy
`error` key in the payload is ignored by rag-api (V3: it reads `error_message`,
never `error`) — asserted by the drift guard in §5.3.

### 4.5 End-to-end failure flow (after fix)

```
process_document step raises
  → except: current_stage = last milestone
  → build_failure_details(str(e), current_stage, classify_error(e))
      = {"error_message": M, "error": M, "stage": S, "retryable": R}
  → _publish_status_update(..., "failed", details, job_id)     [Pub/Sub, status topic]
  → rag-api _process_status_message resolves doc path (canonical first)
  → run_transactional_update (status "processing" → "failed" allowed)
      main: status=failed, error=M, error_stage=S, retryable=R
      processing/summary: stage=S, error={code:"UNKNOWN", message:M, stage:S}
  → run_worker: ACK if classify(e)=False, else omit from ack_ids (redelivery)
```

### 4.6 Data/contract invariants

1. Persisted field names are frozen: `error`, `error_stage`, `retryable` (constraint 2).
2. Worker failed-payload key set is frozen: `{error_message, error, stage, retryable}`.
3. rag-api failed-branch read keys are frozen: `{error_message, stage, retryable}`
   (+ `error_code` for the summary subdocument); it must never read `error`.
4. Stage values ⊆ progress vocabulary `{starting, text_retrieved, tagging_complete,
   summary_generated, chunking_complete, embeddings_complete}` ∪ `{processing}` (safe value).
5. `retryable` is always an explicit bool derived from `classify_error` — never a default.

---

## 5. Test design

### 5.1 Strategy

Import both sides; never restate the contract in a fixture (house rule from
`test_service_contracts.py`: do not mock the method whose contract you assert).
The payload *construction* and the *persistence* are exercised through real
code; only the Pub/Sub transport and the Firestore client are faked. The
Firestore-emulator mode (F10) is deliberately **not** used: the fake-transaction
harness (pattern proven in `test_processing_lease.py`) is deterministic, fast,
and needs no docker dependency in unit CI. The emulator branch remains
available as a documented alternative if a future test needs real transactions.

### 5.2 Worker-side tests — `rag-worker-service/tests/unit/test_failure_payload.py` (new)

Environment: existing worker conftest stubs (V9) suffice. The processor is built
without running `_init_services` (whose stubbed `credentials.Certificate` would
raise):

```python
def make_processor():
    p = object.__new__(main.EnhancedDocumentProcessor)
    p.config = main.ProcessingConfig()            # env provided by conftest
    p.logger = main.logger
    p.db = MagicMock()
    p.langfuse = None
    p.openai_client = MagicMock()
    p.httpx_client = MagicMock()
    p.pubsub_publisher = MagicMock()
    p.text_splitter = MagicMock()
    p.tokenizer = MagicMock()
    p.content_tagger = MagicMock()
    return p
```

`_publish_status_update` is replaced on the instance by an async spy recording
`(status, details)` — the transport seam, not the seam under test. Pipeline
steps are monkeypatched to succeed or raise at chosen points.

1. **`TestBuildFailureDetails`** (pure, no mocks): output key set is exactly
   `{error, error_message, stage, retryable}`; `error == error_message`;
   values pass through unchanged. → drift guard (worker side).
2. **`TestRetryableDerivation`**: `TransientError` → `retryable is True`;
   `httpx.ConnectError` → True; `ValueError` → False; unclassified
   `RuntimeError` → False. Asserted through `build_failure_details` +
   `classify_error` composition.
3. **`TestStageTrackerEarlyFailure`**: `_get_extracted_text` raises
   `TransientError("weaviate text fetch timeout")` → recorded failed details:
   `error_message == "weaviate text fetch timeout"`, `stage == "starting"`,
   `retryable is True`.
4. **`TestStageTrackerLateFailure`**: steps up through embeddings succeed
   (stubs return text/`{"overview":…, "bulletPoints":[]}`/`[]`/`[[0.1]]`;
   `db.document().update()` on MagicMock; `delete_old_vectors_via_service → 0`),
   `store_chunks_via_service` raises
   `RuntimeError("partial vector write: 0/1 chunks stored")` → failed details:
   `error_message == "partial vector write: 0/1 chunks stored"`,
   `stage == "embeddings_complete"`, `retryable is False` (pins the accepted
   behavior change from §4.3).
5. **`TestSafeStageValue`** (pure): `build_failure_details(msg, "processing", False)["stage"] == "processing"`.
6. **`TestStageVocabulary`** (AST, house pattern): every stage literal the
   tracker assigns (`current_stage = "X"`) ⊇ every stage literal published in
   `process_document`'s progress updates; both ⊆ the documented vocabulary.
   → catches a future publish added without a tracker assignment.

### 5.3 Cross-service contract test — `tests/integration/test_worker_failure_contract.py` (new)

**conftest extension** (`tests/integration/conftest.py`), after the existing
rag-api setup:

```python
# 1. Reuse the worker's stub table verbatim (no duplicated stub dict to drift):
_worker_conftest = os.path.join(ROOT, "rag-worker-service", "tests", "conftest.py")
exec(compile(open(_worker_conftest).read(), _worker_conftest, "exec"),
     {"__name__": "rag_worker_test_conftest", "__file__": _worker_conftest})

# 2. Guarded stubs for anything the worker conftest does not cover and the
#    integration env may lack (sklearn family is imported at worker-module top level):
for name in ("sklearn", "sklearn.feature_extraction", "sklearn.feature_extraction.text"):
    try:
        __import__(name)
    except ImportError:
        sys.modules.setdefault(name, types.ModuleType(name))
sys.modules.setdefault("sklearn.feature_extraction.text",
                       types.ModuleType("sklearn.feature_extraction.text"))
if not hasattr(sys.modules["sklearn.feature_extraction.text"], "TfidfVectorizer"):
    sys.modules["sklearn.feature_extraction.text"].TfidfVectorizer = type(
        "TfidfVectorizer", (), {"__init__": lambda self, **kw: None})

# 3. Load the worker's main.py by explicit path under a UNIQUE module name —
#    never add rag-worker-service to sys.path, or `import main` (used by
#    test_api_contracts.py for rag-api) becomes ambiguous.
def _load_module_from_path(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

rag_worker_main = _load_module_from_path(
    "rag_worker_main",
    os.path.join(ROOT, "rag-worker-service", "main.py"),
)
```

Worker `main` imports cleanly under these stubs: module-level code needs only
`GCP_PROJECT`, `GOOGLE_APPLICATION_CREDENTIALS`, the credentials/pubsub stubs
and a logger — all provided (V9). Heavy imports are lazy (`pypdf`, `marker`),
so they never run.

**Fake Firestore transaction harness** (self-contained in the test file,
modeled on `test_processing_lease.py` but extended with subcollections):

```python
class FakeTx:          # get() returns live doc state; update/set recorded
class FakeSnap:        # exists + to_dict()
class FakeRef:         # document(); .collection("processing").document("summary")
class FakeDb:          # transaction() → FakeTx; document(path) → FakeRef
```

`monkeypatch.setattr(rag_api_main.firestore, "transactional", lambda fn: fn)`
and `SERVER_TIMESTAMP → "TS"`. The resource doc is seeded with
`status: "processing"` so the real `ALLOWED_TRANSITIONS` gate (V4) is exercised
— a regression that broke the transition gate would fail this test too.

**Test classes:**

1. **`TestWorkerFailurePayloadContract`** — imports `rag_worker_main`
   (worker) and `main as rag_api_main` (api):
   - `build_failure_details` key set is exactly
     `{error, error_message, stage, retryable}` → worker-side drift guard.
2. **`TestWorkerToApiFailurePersistence`** — the centerpiece. Two scenarios
   (early-stage transient, late-stage permanent), each:
   1. Run `process_document` on the §5.2 harness **inside this test** and take
      the details dict captured by the publish spy for `status == "failed"` —
      the worker's real payload, produced by the worker's real code path.
   2. Feed that dict, unchanged, to
      `rag_api_main.run_transactional_update(db, doc_ref, "failed", details, logger, user_id)`.
   3. Assert on the recorded main-doc update:
      `error == worker_message` (and `!= "Processing failed"`),
      `error_stage == worker_stage` (and `is not None`),
      `retryable == worker_retryable` (and `isinstance(..., bool)`).
   4. Assert on the recorded `processing/summary` set:
      `stage == worker_stage` (and `!= "unknown"`),
      `error["message"] == worker_message`, `error["stage"] == worker_stage`,
      `error["code"] == "UNKNOWN"`.
   → value-level drift guard on **both** sides: if either side's keys drift,
   the persisted values fall back to `"Processing failed"`/`None`/`True` and
   the assertions fail with a diff that names the drifted key.
3. **`TestApiFailedBranchReadKeys`** — AST guard on
   `rag_api_main.run_transactional_update` (pattern of
   `_get_agent_graph_shapes`): collect all `details.get("X")` literal keys;
   assert `{"error_message", "stage", "retryable", "error_code"} ⊆ keys` and
   `"error" ∉ keys` (rag-api must persist from `error_message`, not the legacy
   alias) → API-side drift guard.
4. **`TestStageVocabularyCrossService`** — AST on the worker source: tracker
   assignments cover the published stage vocabulary (shared guard with §5.2.6,
   run in the integration suite so it protects the seam even if the worker unit
   suite is skipped).

### 5.4 What the tests deliberately do not do

- No mock of `build_failure_details`, `classify_error`, `process_document`'s
  except branch, or `run_transactional_update` — only transports are faked.
- No fixture restating the contract: expected values come from the worker's own
  return path, expected persistence from rag-api's own write.
- No negative control asserting the *buggy* legacy-only payload produces
  fallbacks (that would ossify the bug as expected behavior).

### 5.5 CI wiring

`tests/integration` already runs in the existing integration job with the
mocked-cloud conftest; the additions are pure-Python (no emulator, no docker),
so no new infrastructure is required. If the top-level suite lacks
`asyncio_mode = auto`, async tests carry `@pytest.mark.asyncio` explicitly
(implementation detail, verified at implement step).

---

## 6. Requirements traceability (Definition → design)

| Definition requirement | Design element | Verified by |
|---|---|---|
| R1 payload carries `error_message`/`stage`/`retryable`, never relying on API fallbacks | §4.2 except branch + §4.3 `build_failure_details`; keys always present | §5.2.1, §5.3.1, §5.3.2 |
| R2 stage tracking with progress vocabulary + `"processing"` safe value | §4.2 tracker semantics, assignment sites, invariant | §5.2.3–5.2.6, §5.3.4 |
| R3 rag-api persists worker values unchanged (main doc + summary subdoc) | §4.4 preservation — zero API change | §5.3.2 assertions 3–4 |
| R4 retryable explicit, aligned with ACK/NACK (transient→true, permanent/unknown→false) | §4.3 derivation from `classify_error` | §5.2.2, §5.2.4, §5.3.2 |
| R5 contract test exercising construction → persistence with drift guard | §5.3 cross-service test + key-set/AST/value guards | §5.3.1–5.3.3 |

Constraint compliance: must #1 (worker aligns, API untouched — §4.1), must_not
(no migration/rename/backfill — §4.6.1), must #3 (explicit retryable — §4.3),
prefer (legacy `error` retained — §4.3 payload), prefer_not (no error-code
taxonomy; summary `code` stays `"UNKNOWN"` — §3.1).

---

## 7. Acceptance criteria mapping

| Definition acceptance | How met |
|---|---|
| 1. Failed status message contains error_message (actual), stage (failing), retryable (derived); no fallback reliance | Worker except branch (§4.2) always builds all three via `build_failure_details`; tests §5.2.1/§5.2.3/§5.2.4 and §5.3.1 |
| 2. Persisted: error = actual message (≠ "Processing failed"), error_stage = failing stage (≠ None), retryable = derived | API unchanged + worker keys aligned; proven end-to-end in §5.3.2 assertions 3 |
| 3. processing/summary error subdocument carries same message and stage | API already mirrors when keys present (V3); asserted in §5.3.2 assertion 4 |
| 4. Contract test exists and passes, exercising construction → persistence, failing on either side's key drift | §5.3 (`test_worker_failure_contract.py`) with three independent drift guards |

---

## 8. Risks and mitigations (carried from Definition + design findings)

| Risk | Mitigation |
|---|---|
| Unknown consumers of the status topic read the old `error` key | Legacy `error` key retained in every failure payload (§4.3); dropping it later is trivial cleanup after an audit |
| Stage-tracker drift as the pipeline evolves | Update-colocated-with-publish convention + invariant (§4.2) + AST vocabulary guard (§5.2.6/§5.3.4) |
| `retryable=false` for genuinely transient-but-unrecognized failures reduces auto-retry | Accepted (Definition F8); matches actual ACK behavior; `POST /process` manual reprocess unaffected; widening `classify_error` is out of scope |
| Contract test ossifies the payload | Intentional — it is the drift guard; adding a key means touching the pinned test |
| Worker `main` import fragility in the shared integration env (heavy deps, module-level init) | Reuse of the proven worker stub table + explicit-path module load (§5.3); sklearn guarded stub; no new sys.path entry, so existing `test_api_contracts.py` is unaffected |
| Fake-transaction harness diverges from real Firestore semantics | Pattern already proven by `test_processing_lease.py`; the real transition gate and merge/set semantics of `run_transactional_update` are exercised; emulator mode documented as the escalation path |

## 9. Out of scope (restated, binding)

Stale-lease sweep behavior; retry/backoff mechanics (ACK/NACK policy, leases,
heartbeats — only the *reporting* of retryability changes); frontend/mobile
(`ResourceResponse` already exposes `error`/`error_stage`); structured error
codes (`error_code` stays `"UNKNOWN"` unless actually sent); everything the
companion D3 issue may cover beyond this payload alignment (unavailable here;
deferred); reconciling with the D4 deviation note in `plans/upload-flow.md`
(file not present in the tree).

## 10. Implementation order

1. `rag-worker-service/main.py`: `build_failure_details` + stage tracker +
   except-branch rewrite (+ `stage` in the failure log event).
2. `rag-worker-service/tests/unit/test_failure_payload.py` (worker-side tests).
3. `tests/integration/conftest.py` extension (stub reuse + explicit module load).
4. `tests/integration/test_worker_failure_contract.py` (cross-service contract).
5. Run worker unit suite, rag-api suite (regression: must stay green with zero
   API changes), and the integration suite; update acceptance statuses.
<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>