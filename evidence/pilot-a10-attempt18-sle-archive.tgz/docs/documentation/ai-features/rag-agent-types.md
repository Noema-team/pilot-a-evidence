---
tags:
  - Documentation/Internal
---
# RAG Agent Types

## Multi-agent architecture

The AI uses a multi-agent system where a classifier routes each user message to the most appropriate agent.

### Agent types

- **Teaching agent** — triggered by: "teach me about", "teach me how to", explain-style queries
- **Problem solver agent** — triggered by: "give me the answer", "solve this problem", direct answer requests
- **Search / default agent** — general chat with access to the user's uploaded resources
- **Study advice agent** _(proposed)_ — triggered by: "give me a structured approach to study this", "how should I study X". Helps the user classify information, recommend study methods, and estimate time per task.

### Search agent classifier

The search agent should include a sub-classifier: is the student asking what materials the AI has access to, or are they asking a content question? These require different response strategies.
