"""
Guard: files copied into more than one service must not drift apart.

`algorithms/markdown_parser.py` exists in both rag-worker-service and
flashcard-service because the build context is per-service and neither can
import from a shared directory. That is a deployment constraint, not a licence
for the copies to diverge — and they did.

The two services use disjoint halves of the file: rag-worker uses
`SectionLinker`, flashcard uses `MarkdownParser.extract_section_content`. Both
halves had the same bug (marker-pdf emits emphasis-wrapped headings like
`**Limits**`, which do not match the cleaned heading stored in the map), and
each service fixed only the half it used. So each copy shipped a latent bug in
the half it did not exercise, already fixed a directory away — the flashcard
copy's own comment records that this cost every flashcard generation returning
zero cards.

This test fails the build the moment the copies differ again, which is the only
cheap way to notice. If a future change makes a shared package feasible (one
build context for both services), delete this test along with the duplication.
"""

import hashlib
from pathlib import Path

import pytest

AI_SERVER = Path(__file__).resolve().parents[2]

# published path -> the services that must carry an identical copy
DUPLICATED_FILES = {
    "algorithms/markdown_parser.py": ["rag-worker-service", "flashcard-service"],
}


def _digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


@pytest.mark.parametrize("relative_path,services", DUPLICATED_FILES.items())
def test_duplicated_files_are_identical(relative_path, services):
    paths = [AI_SERVER / service / relative_path for service in services]

    missing = [p for p in paths if not p.exists()]
    assert not missing, f"Expected copies are missing: {[str(p) for p in missing]}"

    digests = {str(p.relative_to(AI_SERVER)): _digest(p) for p in paths}
    unique = set(digests.values())

    assert len(unique) == 1, (
        f"{relative_path} has diverged between services.\n"
        f"{digests}\n\n"
        "These copies must stay byte-identical. Port the change to every copy, "
        "and note that the services use different halves of this file — a fix "
        "that looks irrelevant to one service is the half it does not exercise "
        "yet, which is exactly how the last divergence happened."
    )


def test_no_unexpected_algorithm_duplicates():
    """
    Catch a new duplicate appearing without a decision being made about it.

    Four files used to be copied into both services and were simply dead on one
    side (sm2, flashcard_generator, duplicate_detector in rag-worker;
    tfidf_keywords in flashcard-service). They were deleted rather than synced.
    A new name showing up on both sides means someone copied a directory again.
    """
    worker = {p.name for p in (AI_SERVER / "rag-worker-service/algorithms").glob("*.py")}
    card = {p.name for p in (AI_SERVER / "flashcard-service/algorithms").glob("*.py")}

    shared = (worker & card) - {"__init__.py"}
    declared = {Path(f).name for f in DUPLICATED_FILES}

    assert shared == declared, (
        f"Algorithm files present in both services: {sorted(shared)}\n"
        f"Declared as intentionally duplicated: {sorted(declared)}\n\n"
        "Either delete the copy that is unused, or add it to DUPLICATED_FILES "
        "so this guard keeps the copies in sync."
    )
