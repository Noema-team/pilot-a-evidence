---
tags:
  - Documentation/Internal
---
# AI Chat Error Handling — Failed Message Flow

## Failed message flow

When an AI chat message fails (no contact with backend or no response after three attempts), the frontend must handle persistence and display.

## Save to Firestore

The chat is saved to Firestore with the `threadId` and a `failed` parameter indicating the message did not succeed.

## Display

- The failed chat appears in the UI with a visual failed state (red/error styling).
- It is also visible in historic chats as a failed message without a response.

## Retry flow

When the user retries a failed message:

1. **Not successful:** No change — the message stays in failed state.
2. **Successful:** The backend saves the user message and assistant response in the Firestore document.
3. **Deduplication:** When the frontend sees a failed message followed by an identical successful message and an assistant response, it hides the first (failed) message and only shows the successful exchange.
