# Evaluation & Tuning System — Specification

> **Status:** Draft
> **Created:** 2026-06-21
> **Depends on:** ai-server backend services (rag-api, agent-graph, weaviate), observability-aggregator

---

## 1. Overview

### 1.1 Purpose

The functional test suite (~650 tests) verifies that the system's plumbing works — endpoints respond, data flows, contracts hold. It does **not** measure whether the outputs are *good*. This spec defines a separate evaluation system that measures output quality across five pipeline stages, enabling data-driven tuning of retrieval, routing, and generation.

### 1.2 Problem Statement

When a student asks "Explain gradient descent" and gets a poor answer, the cause could be any of:

- **Retrieval** — the right chunks weren't fetched from Weaviate
- **Faithfulness** — the LLM hallucinated beyond the retrieved context
- **Routing** — the query went to the wrong agent (e.g., `SEARCH` instead of `TEACHING_CONCEPTUAL`)
- **Generation** — correct agent and correct context, but the prompt/model produced a bad answer
- **UX** — accurate answer but too slow, too expensive, or poorly formatted

Without per-stage measurement, tuning is guesswork. This system isolates each stage and provides a score, so the weakest link is always visible.

### 1.3 Non-Goals

- **Not a load test.** Eval runs are sequential, not concurrent. Latency metrics are indicative, not statistically rigorous.
- **Not a functional test.** Eval does not verify status codes, schemas, or plumbing. That's the pytest/jest suite's job.
- **Not automated tuning.** The system measures; the human decides what to change.
- **Not a replacement for user feedback.** `POST /api/chat/feedback` (thumbs up/down) remains the ground truth. Eval is a faster, pre-deploy proxy.

### 1.4 Architecture

```
                    ┌─────────────────────────────────┐
                    │         Eval Dataset             │
                    │  (golden queries + expected      │
                    │   answers + relevant sources)    │
                    └──────────────┬──────────────────┘
                                   │
                    ┌──────────────▼──────────────────┐
                    │         Eval Runner              │
                    │  ──────────────────────────      │
                    │  For each query:                 │
                    │   1. POST /api/search    ────────┼──► Backend (gateway + services)
                    │   2. POST /api/chat/messages ────┼──► Backend (gateway + services)
                    │   3. Capture: chunks, answer,    │
                    │      routing, cost, latency      │
                    └──────────────┬──────────────────┘
                                   │
                    ┌──────────────▼──────────────────┐
                    │         Scorers                  │
                    │  ──────────────────────────      │
                    │  • Retrieval (recall@k, MRR)     │  ◄── pure computation
                    │  • Routing (accuracy, confusion) │  ◄── pure computation
                    │  • Faithfulness (1-5)            │  ◄── LLM-as-judge
                    │  • Relevance (1-5)               │  ◄── LLM-as-judge
                    │  • Cost & latency                │  ◄── captured from response
                    └──────────────┬──────────────────┘
                                   │
                    ┌──────────────▼──────────────────┐
                    │      Run Result (JSON)           │
                    │  Per-query scores + aggregates   │
                    └──────────────┬──────────────────┘
                                   │
              ┌────────────────────┼────────────────────┐
              │                    │                     │
    ┌─────────▼──────────┐  ┌──────▼───────┐  ┌──────────▼──────────┐
    │   Compare Engine    │  │  Report      │  │  Score History      │
    │  Diff two runs,     │  │  Markdown    │  │  Track metrics      │
    │  flag regressions    │  │  table       │  │  across runs        │
    └─────────────────────┘  └──────────────┘  └─────────────────────┘
```

---

## 2. Data Models

### 2.1 Eval Dataset (`dataset.json`)

The golden dataset. Manually curated. Versioned in git.

```json
{
  "schema_version": "1.0",
  "id": "dataset-v1",
  "description": "Initial eval dataset — 3 documents, 30 queries",
  "created_at": "2026-06-21T00:00:00Z",
  "documents": [
    {
      "resource_id": "res-001",
      "filename": "intro_to_machine_learning.pdf",
      "course_id": "course-001",
      "sections": [
        {"section_id": "s1", "title": "Linear Regression"},
        {"section_id": "s2", "title": "Logistic Regression"},
        {"section_id": "s3", "title": "Gradient Descent"},
        {"section_id": "s4", "title": "Neural Networks"}
      ]
    },
    {
      "resource_id": "res-002",
      "filename": "calculus_lecture_notes.pdf",
      "course_id": "course-001",
      "sections": [
        {"section_id": "s1", "title": "Limits"},
        {"section_id": "s2", "title": "Derivatives"},
        {"section_id": "s3", "title": "Integrals"}
      ]
    }
  ],
  "queries": [
    {
      "id": "q001",
      "query": "What is gradient descent and how does it work?",
      "type": "conceptual",
      "expected": {
        "relevant_resource_ids": ["res-001"],
        "relevant_section_ids": ["s3"],
        "expected_agent": "TEACHING_CONCEPTUAL",
        "reference_keywords": ["learning rate", "iterations", "loss function", "minimum"]
      }
    },
    {
      "id": "q002",
      "query": "Solve dy/dx = 2x for x = 3",
      "type": "procedural",
      "expected": {
        "relevant_resource_ids": ["res-002"],
        "relevant_section_ids": ["s2"],
        "expected_agent": "PROBLEM_SOLVING",
        "reference_keywords": ["6", "power rule", "derivative"]
      }
    },
    {
      "id": "q003",
      "query": "What does the textbook say about neural network architectures?",
      "type": "factual",
      "expected": {
        "relevant_resource_ids": ["res-001"],
        "relevant_section_ids": ["s4"],
        "expected_agent": "SEARCH",
        "reference_keywords": ["layers", "activation", "weights"]
      }
    }
  ]
}
```

**Field reference:**

| Field | Type | Required | Description |
|---|---|---|---|
| `query` | string | yes | The student's question, verbatim |
| `type` | enum | yes | `factual` \| `conceptual` \| `procedural` \| `conversational` |
| `relevant_resource_ids` | string[] | yes | Documents that contain the answer. Used for recall@k. |
| `relevant_section_ids` | string[] | no | Specific sections. Used for fine-grained recall. |
| `expected_agent` | enum | yes | `SEARCH` \| `TEACHING_CONCEPTUAL` \| `PROBLEM_SOLVING` \| `STUDY_ADVICE` \| `REFINE` \| `CHAT` |
| `reference_keywords` | string[] | no | Key terms a good answer should mention. Used for quick relevance heuristics. |
| `reference_answer` | string | no | Full reference answer (if available). Used for human review, not automated scoring. |

### 2.2 Run Result (`results/<run-id>.json`)

Output of a single eval run. One file per run.

```json
{
  "schema_version": "1.0",
  "run_id": "run-2026-06-21-baseline",
  "dataset_id": "dataset-v1",
  "label": "baseline",
  "timestamp": "2026-06-21T14:30:00Z",
  "config": {
    "endpoint": "http://localhost:3001",
    "search_config_preset": "balanced",
    "agent_chaining_enabled": true,
    "git_commit": "59829c5",
    "notes": "Initial baseline before any tuning"
  },
  "results": [
    {
      "query_id": "q001",
      "query": "What is gradient descent and how does it work?",
      "retrieval": {
        "top_chunks": [
          {"chunk_id": "ch-abc", "resource_id": "res-001", "score": 0.92, "content_preview": "Gradient descent is an optimization..."},
          {"chunk_id": "ch-def", "resource_id": "res-001", "score": 0.87, "content_preview": "The learning rate controls..."}
        ],
        "retrieved_resource_ids": ["res-001", "res-001"],
        "retrieved_section_ids": ["s3", "s3"],
        "search_latency_ms": 340
      },
      "routing": {
        "classified_agent": "TEACHING_CONCEPTUAL",
        "correct": true
      },
      "generation": {
        "answer": "Gradient descent is an optimization algorithm that...",
        "model": "gpt-4o",
        "tokens_in": 520,
        "tokens_out": 180,
        "generation_latency_ms": 2100,
        "cost_usd": 0.0078
      },
      "scores": {
        "recall_at_5": 1.0,
        "mrr": 1.0,
        "routing_correct": true,
        "faithfulness": 5,
        "relevance": 4,
        "total_latency_ms": 2440,
        "cost_usd": 0.0078
      },
      "judge_notes": {
        "faithfulness": "All claims supported by source context.",
        "relevance": "Good explanation but could include a concrete example."
      }
    }
  ],
  "aggregate_scores": {
    "query_count": 30,
    "mean_recall_at_5": 0.78,
    "mean_mrr": 0.65,
    "routing_accuracy": 0.85,
    "mean_faithfulness": 4.1,
    "mean_relevance": 4.3,
    "mean_total_latency_ms": 2100,
    "p95_total_latency_ms": 4500,
    "total_cost_usd": 0.24
  }
}
```

### 2.3 Comparison Result (`results/<comparison-id>.json`)

```json
{
  "schema_version": "1.0",
  "baseline_run_id": "run-2026-06-21-baseline",
  "candidate_run_id": "run-2026-06-22-prompt-v2",
  "metrics": {
    "mean_recall_at_5":     {"baseline": 0.78, "candidate": 0.82, "delta": 0.04, "direction": "improved"},
    "routing_accuracy":     {"baseline": 0.85, "candidate": 0.85, "delta": 0.00, "direction": "unchanged"},
    "mean_faithfulness":    {"baseline": 4.1,  "candidate": 4.4,  "delta": 0.30, "direction": "improved"},
    "mean_relevance":       {"baseline": 4.3,  "candidate": 4.5,  "delta": 0.20, "direction": "improved"},
    "mean_total_latency_ms":{"baseline": 2100, "candidate": 2300, "delta": 200,  "direction": "regressed"},
    "total_cost_usd":       {"baseline": 0.24, "candidate": 0.26, "delta": 0.02, "direction": "regressed"}
  },
  "per_query_changes": {
    "regressions": [
      {"query_id": "q015", "query": "...", "metric": "faithfulness", "baseline": 5, "candidate": 3}
    ],
    "improvements": [
      {"query_id": "q001", "query": "...", "metric": "relevance", "baseline": 3, "candidate": 5}
    ]
  },
  "verdict": "IMPROVED — 3 metrics improved, 2 regressed (latency/cost within acceptable range). Recommend adopting."
}
```

---

## 3. Components

### 3.1 Eval Dataset

**What:** A versioned JSON file containing curated queries with known-correct expected outcomes.

**Location:** `apps/ai-server/eval/datasets/dataset-v1.json`

**Creation process:**
1. Upload 3-5 real documents (textbooks, lecture notes, exams) to the platform via the mobile app or API
2. Note the `resource_id` values assigned by the system
3. For each document, identify sections (from the generated resource map or manually)
4. Write 30-50 queries covering different types: factual lookup, conceptual explanation, procedural problem-solving, follow-up/refinement, general chat
5. For each query, fill in `expected` fields based on the source material
6. Commit to git

**Maintenance:** The dataset grows over time. When a real user query reveals a failure mode (bad answer in production), add it to the dataset as a regression guard.

### 3.2 Eval Runner

**What:** Executes each dataset query against the backend and captures intermediate results.

**Process per query:**
1. **Retrieval probe:** `POST /api/search` with the query text. Capture top-k chunks, their resource_ids, scores, and latency.
2. **Full pipeline:** `POST /api/chat/messages` (non-streaming) with the query. Capture the answer text, `agent_mode` (routing result), `model`, and response metadata.
3. **Record** all captured data into the run result structure.

**Configuration:**
- `--endpoint`: Gateway URL (default `http://localhost:3001`)
- `--auth-mode`: How to authenticate (`internal-token` for local dev, `firebase-token` for deployed)
- `--timeout`: Per-request timeout (default 60s)
- `--skip-judge`: Skip LLM-as-judge scoring (use for fast retrieval-only runs)

**Dependencies:** `httpx` (HTTP client), `openai` (for judge), existing service models.

### 3.3 Scorers

Five independent scoring functions. Each takes a query result + expected data and returns a score.

#### 3.3.1 Retrieval Scorer (deterministic)

No LLM needed. Pure computation.

| Metric | Formula | Range |
|---|---|---|
| `recall_at_k` | `len(retrieved ∩ expected) / len(expected)` | 0.0 – 1.0 |
| `mrr` | `1 / rank_of_first_relevant_result` | 0.0 – 1.0 |

**Matching:** A retrieved chunk is "relevant" if its `resource_id` is in `expected.relevant_resource_ids`. If `relevant_section_ids` are provided, match on section too.

#### 3.3.2 Routing Scorer (deterministic)

| Metric | Formula | Range |
|---|---|---|
| `routing_correct` | `classified_agent == expected_agent` | `true` / `false` |
| `routing_accuracy` | (aggregate) `correct / total` | 0.0 – 1.0 |

Also produces a confusion matrix across all queries for diagnosing which agents get confused.

#### 3.3.3 Faithfulness Scorer (LLM-as-judge)

Uses GPT-4 (or configured judge model) to check if the answer is grounded in the retrieved context.

**Judge prompt:**
```
You are evaluating the faithfulness of an AI-generated answer for a student
learning platform. Faithfulness means: every claim in the answer is supported
by the provided source context.

Question: {query}

Source context (retrieved document chunks):
{chunks_formatted}

Answer to evaluate:
{answer}

Identify any claims in the answer that are NOT supported by the source
context. A claim is unsupported if it states something not present in the
source material.

Score (1-5):
  5 = Every claim is directly supported by source context
  4 = Mostly supported; one minor unsupported claim
  3 = Some unsupported claims; core answer is grounded
  2 = Several unsupported claims; answer is partially fabricated
  1 = Answer is mostly fabricated or unsupported by context

Respond as JSON:
{"score": <int>, "unsupported_claims": ["<claim 1>", ...], "notes": "<brief>"}
```

#### 3.3.4 Relevance Scorer (LLM-as-judge)

Uses GPT-4 to rate whether the answer actually addresses the question.

**Judge prompt:**
```
You are evaluating the relevance of an AI-generated answer for a student
learning platform. Relevance means: the answer addresses what the student
actually asked, at an appropriate depth and format.

Question: {query}
Query type: {type} (factual | conceptual | procedural | conversational)
Answer: {answer}

Rate how well the answer addresses the student's question. Consider:
  - Does it answer what was asked?
  - Is the depth appropriate for the query type?
  - Is the format suitable? (e.g., step-by-step for procedural)

Score (1-5):
  5 = Perfectly addresses the question; appropriate depth and format
  4 = Good answer; minor gaps in depth or format
  3 = Partially addresses the question; some relevant info missing
  2 = Mostly misses the question or wrong format/depth
  1 = Does not address the question at all

Respond as JSON:
{"score": <int>, "notes": "<brief explanation>"}
```

#### 3.3.5 Cost & Latency (captured)

Not scored by an algorithm — captured from the response metadata.

| Metric | Source | Unit |
|---|---|---|
| `total_latency_ms` | wall clock from request to response | ms |
| `cost_usd` | computed from tokens_in × input_price + tokens_out × output_price | USD |

**Pricing table** maintained in `eval/src/config.py`, updated when model pricing changes.

### 3.4 Comparison Engine

**What:** Diffs two run results and identifies improvements, regressions, and unchanged metrics.

**Logic:**
1. Load baseline and candidate run results
2. For each aggregate metric, compute delta: `candidate - baseline`
3. Classify direction: `improved` / `regressed` / `unchanged`
4. For per-query regressions: flag any query where a score dropped by ≥ 1 point (for 1-5 scales) or ≥ 0.1 (for 0-1 scales)
5. Generate a verdict string summarizing the overall change

**Threshold for regression alert:** configurable per metric. Defaults:
- Faithfulness/relevance: any drop ≥ 1.0 point
- Recall/accuracy: any drop ≥ 0.05
- Latency: any increase ≥ 500ms
- Cost: any increase ≥ 20%

### 3.5 Reporting

**What:** Formats run results and comparisons for human consumption.

**Output formats:**
- **Markdown table** (to terminal or file) — the primary format for quick scanning
- **JSON** (saved to `results/`) — for programmatic access and history tracking

**Report structure:**
```
## Eval Run: baseline (2026-06-21)
Dataset: dataset-v1 (30 queries, 2 documents)
Endpoint: http://localhost:3001
Git commit: 59829c5

### Aggregate Scores
| Metric              | Score | Trend |
|---------------------|-------|-------|
| Recall@5            | 0.78  | —     |
| MRR                 | 0.65  | —     |
| Routing Accuracy    | 85%   | —     |
| Faithfulness (1-5)  | 4.1   | —     |
| Relevance (1-5)     | 4.3   | —     |
| Mean Latency        | 2.1s  | —     |
| Total Cost          | $0.24 | —     |

### Routing Confusion Matrix
                    │  SEARCH  TEACH  SOLVE  ADVICE
  SEARCH            │    8      1      0      0
  TEACHING_CONCEPT  │    0      9      1      0
  PROBLEM_SOLVING   │    0      0      7      0
  STUDY_ADVICE      │    0      0      1      3

### Weakest Queries
  q012: faithfulness=2 (hallucinated formula)
  q007: recall=0.0 (wrong document fetched)
  q023: routing=SOLVE expected=TEACH
```

---

## 4. CLI Interface

```bash
# Run an evaluation
python -m eval.cli run \
  --dataset datasets/dataset-v1.json \
  --endpoint http://localhost:3001 \
  --label "baseline"

# Run retrieval-only (skip LLM generation + judge — fast, cheap)
python -m eval.cli run \
  --dataset datasets/dataset-v1.json \
  --retrieval-only

# Compare two runs
python -m eval.cli compare \
  --baseline results/run-2026-06-21-baseline.json \
  --candidate results/run-2026-06-22-prompt-v2.json

# Show score history for a dataset
python -m eval.cli history --dataset dataset-v1

# List all runs
python -m eval.cli list
```

**Flags:**
| Flag | Default | Description |
|---|---|---|
| `--dataset` | required | Path to dataset JSON |
| `--endpoint` | `http://localhost:3001` | Gateway URL |
| `--auth-mode` | `internal-token` | `internal-token` or `firebase-token` |
| `--label` | timestamp-based | Human-readable run label |
| `--retrieval-only` | false | Skip chat generation + LLM judge |
| `--skip-judge` | false | Skip LLM-as-judge (score retrieval + routing only) |
| `--judge-model` | `gpt-4o` | Model for faithfulness/relevance scoring |
| `--timeout` | 60 | Per-request timeout in seconds |

---

## 5. File Structure

```
apps/ai-server/eval/
├── datasets/
│   ├── dataset-v1.json              # Golden eval dataset (versioned in git)
│   └── README.md                     # How to create and maintain datasets
├── results/                          # Run outputs (git-ignored)
│   └── .gitkeep
├── src/
│   ├── __init__.py
│   ├── models.py                     # Pydantic models: Dataset, RunResult, Scores
│   ├── runner.py                     # Executes queries against backend API
│   ├── scorers.py                    # Retrieval, routing, faithfulness, relevance
│   ├── judge.py                      # LLM-as-judge prompts and API calls
│   ├── compare.py                    # Diff two runs, detect regressions
│   ├── report.py                     # Format results as Markdown tables
│   └── config.py                     # Model pricing, thresholds, defaults
├── cli.py                            # CLI entry point (argparse-based)
├── requirements.txt                  # openai, httpx, rich (terminal formatting)
└── README.md                         # Quick start guide
```

---

## 6. Integration Points

### 6.1 Backend API (read-only)

The eval runner calls two endpoints:
- `POST /api/search` — retrieval probe (returns chunks with scores)
- `POST /api/chat/messages` — full pipeline (returns answer + routing + cost metadata)

No modifications to the backend are required. The runner is a pure consumer.

### 6.2 Observability (cross-reference)

The observability-aggregator already captures per-request traces, token counts, and costs. The eval system's `cost_usd` and `latency_ms` should be cross-checkable against the aggregator's data for the same `trace_id`. This is a future enhancement, not a v1 requirement.

### 6.3 User Feedback (ground truth)

`POST /api/chat/feedback` captures thumbs-up/down from real users. Over time, queries with consistently negative feedback should be added to the eval dataset as regression guards. This is a manual process initially; could be automated later.

### 6.4 CI Pipeline (future)

Phase 3 goal: run `eval run --retrieval-only` on every PR that touches:
- Agent prompts (`agent-graph-service/src/agents/*.py`)
- Search config (`rag-api-service/services/resource_service.py`)
- Relevance policy (`weaviate-service/main.py`)
- Classification logic (`agent-graph-service/src/agents/classifier.py`)

Block merge if recall or routing accuracy drops beyond threshold. LLM-judge runs are too slow/expensive for per-PR CI; they run on-demand or nightly.

---

## 7. Diagnostic Guide

When the eval system shows low scores, here's how to diagnose and fix.

| Score is low | Meaning | Check | Tune |
|---|---|---|---|
| **Recall@5 < 0.7** | Right chunks not being fetched | Are chunks too large/small? Is the embedding model suitable? | Chunk size/overlap in `pdf_processor.py`, `SearchConfig` in `resource_service.py` |
| **MRR < 0.5** | Right chunks fetched but ranked low | Is the reranker working? Is the relevance threshold too strict? | Relevance policy in `weaviate-service/main.py`, reranker model |
| **Routing accuracy < 0.8** | Wrong agent handling the query | Look at the confusion matrix — which agents get confused? | Classification prompt in `classifier.py`, add few-shot examples |
| **Faithfulness < 4.0** | LLM hallucinating beyond context | Read the unsupported claims from the judge | Tighten agent prompt ("only use provided context"), try stronger model |
| **Relevance < 4.0** | Answer doesn't address the question | Is it a retrieval problem (wrong context) or generation problem? | If retrieval is fine: rewrite agent prompt. If retrieval is bad: fix upstream. |
| **Latency > 5s p95** | Too slow | Check which stage is slow (search vs generation) | Reduce `final_chunk_count`, use faster model, disable agent chaining |
| **Cost > $0.01/query** | Too expensive | Check token counts per stage | Use smaller model for classification, reduce chunk count, shorter prompts |

---

## 8. Implementation Phases

### Phase 1: Manual Baseline (2-3 days)

**Goal:** Get a baseline scorecard for the current system.

1. Upload 3 real documents to the platform
2. Write the `models.py` Pydantic schemas (Dataset, RunResult, Scores)
3. Write `runner.py` — calls `/api/search` and `/api/chat/messages`, captures results
4. Write `scorers.py` — retrieval (recall, MRR) and routing (accuracy) only
5. Create `dataset-v1.json` with 30 queries
6. Run against local backend
7. Score faithfulness + relevance **by hand** for the 30 queries (read each answer, rate 1-5)

**Deliverable:** A JSON file with baseline scores. No LLM-judge yet.

### Phase 2: Automated Scoring + Comparison (2-3 days)

**Goal:** Remove manual scoring; enable before/after comparison.

1. Write `judge.py` — LLM-as-judge for faithfulness + relevance
2. Write `compare.py` — diff two runs, flag regressions
3. Write `report.py` — Markdown table output with confusion matrix
4. Write `cli.py` — `run`, `compare`, `history`, `list` commands
5. Run the first comparison: change one prompt, re-run, compare

**Deliverable:** Fully automated eval pipeline. Can run, score, and compare without manual intervention.

### Phase 3: Tuning Iteration (ongoing)

**Goal:** Use the eval system to guide systematic improvement.

1. Identify the weakest metric from the baseline
2. Make ONE change (prompt, config, model, chunk size)
3. Re-run eval
4. Compare against baseline
5. Adopt or revert based on comparison
6. Log the change + result in a tuning journal (`eval/TUNING-LOG.md`)
7. Repeat

**Tuning log format:**
```markdown
## 2026-06-23 — Tightened RAG agent prompt
**Change:** Added "Only use information from the provided context. If the answer is not in the context, say you don't know." to rag_agent.py system prompt.
**Baseline:** faithfulness=4.1, relevance=4.3, recall=0.78
**After:** faithfulness=4.6 (+0.5), relevance=4.2 (-0.1), recall=0.78 (unchanged)
**Verdict:** Adopted. Faithfulness improved significantly; minor relevance regression acceptable.
```

### Phase 4: CI Integration (future, after tuning stabilizes)

**Goal:** Prevent quality regressions in CI.

1. Add eval job to `.github/workflows/test.yml` (retrieval-only, no LLM-judge)
2. Run on PRs touching prompts/configs
3. Block merge if recall or routing accuracy drops beyond threshold
4. Nightly full eval (with LLM-judge) against staging

---

## 9. Success Criteria

The eval system is successful when:

1. **A baseline exists** — dataset-v1 has ≥30 queries, scored across all 5 metrics
2. **Comparison works** — two runs can be diffed with per-query regression detection
3. **Tuning is data-driven** — every prompt/config change is evaluated before/after, logged in the tuning journal
4. **The weakest link is always visible** — the report clearly shows which metric needs attention
5. **Regressions are caught** — a change that improves one metric but breaks another is visible before merge
