# Cycle Charter — rag-worker → rag-api failure payload contract alignment

## Scope

Align the rag-worker's failure status payload with rag-api's failed-branch contract so that a failed RAG processing job persists the worker's actual error message, the failing pipeline stage, and a deliberately derived retryable flag — locked in by a contract test on the worker→rag-api failure path.

Concretely, this cycle changes:

1. **Worker failure payload** (`apps/ai-server/rag-worker-service/main.py`, `process_document` exception handler): the failed status payload published via `_publish_status_update` currently carries only `{"error": str(e)}`. It must carry:
   - `error_message` — the actual exception message;
   - `stage` — the pipeline stage executing at failure time;
   - `retryable` — deliberately derived, never silently defaulted;
   - the legacy `error` key retained alongside `error_message` as a compatibility hedge for unknown consumers of the status topic (F11).

2. **Stage tracking in `process_document`**: a stage tracker (local state) set immediately before each pipeline step, reported by the failure handler. Stage names reuse the existing progress-stage vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown. Convention: set the tracker immediately before the `await`.

3. **retryable derivation in the worker**: `retryable` is set from `classify_error(e)` — transient-classified errors map to `true`; permanent-classified errors, including unclassified-unknown (per `classify_error`'s conservative default), map to `false`. This aligns the persisted record with the worker's actual ACK/NACK behavior in `run_worker`. The API-side `details.get("retryable", True)` fallback must not be the operative mechanism for worker failures.

4. **rag-api failed branch** (`apps/ai-server/rag-api-service/main.py`, `run_transactional_update`): the failed branch already reads `error_message`/`stage`/`retryable` and persists `error`/`error_stage`/`retryable` on the main document plus message/stage (with `error_code` defaulting to `"UNKNOWN"`) into the processing/summary subdocument. It persists the worker-provided values unchanged — no reader or schema changes. Any change here is limited to whatever the contract test requires (expected: none).

5. **Contract test** (in `apps/ai-server/tests/integration/`, following the fixture- and AST-based patterns of `test_api_contracts.py`): a worker failure → rag-api persistence path test that exercises the worker's failure-payload construction and rag-api's failed-branch persistence (via the Firestore emulator or fakes), asserts the persisted `error`, `error_stage`, and `retryable` equal the worker's values, and fails if either side's payload keys drift (key-set drift guard). Coverage pins representative stages — an early-stage failure and a late-stage failure — rather than ossifying every step.

The fix direction is locked: the worker aligns to rag-api's existing contract (`error_message`/`stage`/`retryable`), matching rag-api's persisted fields (`error`/`error_stage`/`retryable`) — because the persisted schema is already consistent across three other write paths (worker stale-lease sweep `_fail_if_still_stale`, rag-api's `/process` and `POST /resources` enqueue-failure paths) and two response models (`ResourceResponse`, `Resource` model with `retryable` defaulting `True`). The worker's status publisher is the only writer that doesn't speak the schema; fix the odd one out.

## Purpose

A failed RAG processing job must persist the worker's actual error message and failing stage so users and support can disambiguate failures; retryable must be sent by the worker or derived deliberately, never silently defaulted.

Today, because of the key mismatch, every worker-originated failure persists `error` as the fallback `"Processing failed"`, `error_stage` as `None`, and `retryable` as the silent default `True` — the processing/summary error subdocument inherits the same fallbacks with `error_code` always `"UNKNOWN"`. Users and support cannot tell what failed, where it failed, or whether it will be retried.

The preferred fix direction — aligning the worker's payload keys to `error_message`/`stage` — is chosen because it avoids a schema migration, field rename, or backfill of existing documents: the persisted field names and semantics stay exactly as they are.

One deliberate behavior change falls out and is accepted: unclassified-unknown exceptions currently persist `retryable: true` (the silent default) but classify as permanent, so they will now persist `false`. That is the conservatism `classify_error` was written for — it prevents infinite retry loops — and the manual reprocess path (`POST /process`) is unaffected. The stale-lease sweep's separate `retryable=true` write stays correct: a dead worker is a transient condition by nature.

The compatibility hedge is deliberate: only rag-api's status subscriber was verified as a consumer of these payloads, so the worker retains the legacy `error` key alongside `error_message` — one redundant string per failure message as insurance against an unknown reader of the shared status topic. If a later audit confirms the worker is the only publisher and rag-api the only consumer, dropping the duplicate is trivial cleanup.

## Requirements

1. When document processing fails, the worker's failed status payload must include `error_message` (the actual exception message), `stage` (the pipeline stage executing at failure time), and `retryable` (deliberately derived) — the payload must never rely on rag-api's fallback defaults for these keys.

2. The worker must track the currently executing pipeline stage through `process_document` so the failure handler reports the true failing stage; stage names must reuse the existing progress-stage vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown.

3. rag-api's failed branch must persist the worker-provided values unchanged: main document `error` ← payload `error_message`, `error_stage` ← payload `stage`, `retryable` ← payload `retryable`; the processing/summary error subdocument must carry the same message and stage.

4. The retryable derivation must be explicit and aligned with the worker's ACK/NACK behavior: errors classified transient by `classify_error` → retryable `true`; classified permanent (including unclassified-unknown, per `classify_error`'s conservative default) → retryable `false`.

5. A contract test must cover the worker failure → rag-api persistence path: it must exercise the worker's failure-payload construction and rag-api's failed-branch persistence (via the Firestore emulator or fakes) and assert the persisted `error`, `error_stage`, and `retryable` equal the worker's values; it must fail if either side's payload keys drift.

Acceptance criteria for this cycle:

- A failed job's status message published by the worker contains `error_message` (actual exception message), `stage` (failing pipeline stage), and `retryable` (deliberately derived) — none relying on rag-api's fallback defaults.
- After a failed job, the persisted resource document has `error` = the worker's actual error message (not `"Processing failed"`), `error_stage` = the failing stage (not `None`), and `retryable` = the worker's derived value.
- The processing/summary error subdocument for the failed job carries the same message and stage as the main document.
- A contract test covering the worker failure → rag-api persistence path exists and passes: it exercises the worker's failure-payload construction through rag-api's failed-branch persistence and asserts the persisted `error`, `error_stage`, and `retryable` equal the worker's values, failing if either side's payload keys drift.

## Boundaries

Hard constraints:

- **Must**: The worker must be aligned to rag-api's existing contract — publishing `error_message`/`stage`/`retryable` — rather than changing rag-api's reads or persisted schema.
- **Must not**: The fix must not require a Firestore migration, field rename, or backfill of existing documents; the persisted fields (`error`, `error_stage`, `retryable`) keep their names and semantics.
- **Must**: Every worker-originated failure payload must carry `retryable` explicitly (deliberately derived); the API-side `details.get("retryable", True)` fallback must not be the operative mechanism for worker failures.
- **Prefer**: Retain the legacy `error` key in the worker's failure payload alongside `error_message`, for continuity with any existing consumers of the status topic and log tooling.
- **Prefer not**: Do not introduce a structured error-code taxonomy (`error_code` values) in this fix.

Out of scope (non-goals):

- Changing the stale-lease sweep's direct failure write — it already persists `error`/`error_stage`/`retryable` consistently with this contract.
- Changing retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, or heartbeat intervals — only the *reporting* of retryability in the payload changes.
- Frontend or mobile changes — `ResourceResponse` already exposes `error` and `error_stage` to clients.
- Introducing structured error codes or a failure taxonomy — the processing/summary `error.code` remains `"UNKNOWN"` unless a code is actually sent.
- Widening `classify_error`'s heuristics — the residual risk that genuinely transient-but-unrecognized failures now persist `retryable: false` is accepted; manual reprocess via `POST /process` remains.

Accepted risks and tradeoffs:

- Unknown consumers of the status topic reading the old key set — mitigated by retaining `error`; residual risk accepted as low.
- Stage-tracker drift as the pipeline evolves — mitigated by the update-before-await convention and representative-stage test coverage.
- `retryable=false` for unclassified errors may reduce auto-retry affordances — accepted as above.
- The contract test ossifies the payload — intentional; that is the drift guard doing its job. Adding a key later means touching the test, which is the point.

## Version bump

- **rag-worker-service**: patch bump — behavioral fix to the failure payload (new keys, stage tracking, derived `retryable`) plus the aligned contract test; no schema, API-surface, or configuration change.
- **rag-api-service**: no code change expected (its failed branch already matches the contract the worker is aligning to); no bump unless the contract test surfaces a defect in the failed branch, in which case the smallest fix that keeps the persisted schema unchanged.
- **Data**: no Firestore migration, field rename, or backfill — existing documents are untouched by design.
- **Tests**: new contract test added under `apps/ai-server/tests/integration/`; no bump attributable to test-only changes.

## Deferred items

- Any scope the companion D3 issue (filed alongside this one per the Objective) covers beyond the worker→rag-api failure payload alignment — its content is unavailable in this context.
- Reconciling this analysis with the original D4 deviation note in `plans/upload-flow.md` — that file is not present in the current tree; the reference comes from the Objective text.
- A structured error-code taxonomy / failure taxonomy (processing/summary `error.code` stays `"UNKNOWN"` unless a code is actually sent).
- Retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals.
- Changes to the stale-lease sweep's failure write.
- Widening `classify_error`'s transient/permanent heuristics.
- Frontend or mobile changes.
- Dropping the legacy `error` key from the worker payload — pending an audit confirming the worker is the only publisher and rag-api the only consumer; trivial cleanup if confirmed.