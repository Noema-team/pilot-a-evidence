# System Overview

This folder documents the architecture, structure, and design rules of the student platform. Load files here when you need to understand how the system works before making changes.

## Pinned — read these first

- `general/overview.md` — cross-cutting concerns: auth, data flow, infra, design rules
- `ai-server/overview.md` — AI server architecture and service breakdown
- `mobile/overview.md` — Flutter mobile app structure
- `web/overview.md` — Next.js web app structure

## Folder structure

```
system-overview/
├── README.md          ← you are here
├── map.md             ← index of all files
├── general/           ← cross-cutting: auth, Firebase, data flow, design rules
├── ai-server/         ← AI server microservices, endpoints, agent types
├── mobile/            ← Flutter app: structure, navigation, state
└── web/               ← Next.js/Express app: routing, components, API
```

## When to load files here

- Before making architectural decisions
- Before adding new services or endpoints
- Before modifying auth, Firestore rules, or data models
- When onboarding to a new part of the codebase
