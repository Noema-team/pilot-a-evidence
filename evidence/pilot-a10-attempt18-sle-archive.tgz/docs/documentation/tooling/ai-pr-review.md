# AI PR review (advisory) — as installed in this repo

Status: live since 2026-08-29 (Phase 3 of `plans/ai-pr-review.md`).
Engine: public [`magtheo/ci-toolkit`](https://github.com/magtheo/ci-toolkit).
This page documents the repo-side wiring; the toolkit README holds
the integration contract.

## What it is

Eligible pull requests get an automatic advisory AI review before a
human looks at them: a structured assessment with blocking-first
findings, inline comments and committable suggestions where the model
provides them. `docs/**`- and `plans/**`-only pull requests, and fork
pull requests, are currently skipped. It is the **AI layer of the Review Model**
(AGENTS.md): CI gates (mechanical truth) → AI first-pass (design
findings) → human (merge authority). It approves nothing, blocks
nothing, and can structurally never do either.

## Wiring in this repo

- `.github/workflows/ai-review.yml` — the caller. Trigger:
  `pull_request_target` (workflow file always from trusted base — a
  PR cannot rewrite its own reviewer). Path skips: `docs/**`,
  `plans/**` (NOT `**.md` — `.ai-review-rubric.md` is policy and its
  changes must be reviewable). Fork PRs skipped (load-bearing guard).
- Both layers pinned to the same immutable ci-toolkit commit
  (`uses:` + required `toolkit_ref`): currently
  `c328fee8c3dc8704fa1f2b84fbfab1ead0860c44`.
- Secret: `LLM_API_KEY` (OpenRouter), mapped explicitly — never
  `inherit`.
- `.ai-review-rubric.md` — repo policy override (monorepo context,
  phase scope discipline, cross-client contracts). Resolved from the
  PR **base** sha; fails closed (200 → policy, 404 → bundled, else →
  hard fail).

## Semantics (what you'll see)

`AI review · Clear` / `· Issues found` / `· Inconclusive` — an
assessment, never an authority signal. Deterministic rules, applied
by the toolkit's parser (never trusted from the model): malformed
output → Inconclusive; any blocking finding → Issues found; a
contradictory `ISSUES_FOUND` label with no validated blocking finding
→ Inconclusive (Clear is unreachable from self-contradictory output).
Details, praise, and metadata sit behind `<details>`.

## Upgrading the reviewer

Deliberate, reviewed: pick the reviewed ci-toolkit commit, replace
the SHA in both places, open the PR — which is itself reviewed by the
*previously pinned* version via the trusted-base trigger before it
can merge. Never `@main`.

## Known limits (keep a second opinion)

Four confirmed miss classes to date (ledger in the plan): caller-config
least-privilege (`secrets: inherit` praise), workflow trust-boundary
reasoning, implementation-vs-documented-contract, and cross-file claim
verification (no repository context yet). The last is the thesis for
Stage 3 (base-context retrieval) in the plan's endorsed evolution.
Relay suspicious diffs through an external reviewer — the miss ledger
was found entirely that way.
