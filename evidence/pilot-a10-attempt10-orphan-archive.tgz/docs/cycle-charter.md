## Scope

Code changes are confined to the rag-worker and the integration test suite; rag-api is pinned, not changed.

- `apps/ai-server/rag-worker-service/main.py`
  - `process_document`: add a local stage tracker set immediately before each pipeline step; the exception handler reports the tracked stage, with `"processing"` as the safe value when the stage is genuinely unknown (e.g. failure before the first transition).
  - Failed status payload (published via `_publish_status_update`): add `error_message` (the actual exception message), `stage` (the tracked stage), and `retryable` (derived from `classify_error(e)`); retain the legacy `error` key alongside `error_message` as the compatibility hedge for unknown consumers of the status topic.
  - A small pure helper for failure-payload construction may be extracted from the except handler so the contract test exercises the real code path rather than restating the payload; the extraction is behavior-neutral.
- `apps/ai-server/rag-api-service/main.py` — no change. `run_transactional_update`'s failed branch already reads `error_message`/`stage`/`retryable`, persists `error`/`error_stage`/`retryable` on the main document, and writes `message`/`stage` (with `error_code` defaulting to `"UNKNOWN"`) into the `processing/summary` subdocument. This cycle pins that behavior with a test instead of editing it.
- `apps/ai-server/tests/integration/` — new worker→rag-api failure-path contract test alongside the existing fixture/AST patterns in `test_api_contracts.py`: construct the failure payload through the worker's code path, run it through rag-api's `run_transactional_update` against the Firestore emulator or fakes (the worker's module-level init may require env stubbing in the test), assert the persisted `error`, `error_stage`, and `retryable` equal the worker's values, and include a key-set drift guard so a future edit to either side's payload keys fails the build. Cover at least an early-stage failure and a late-stage failure.

## Purpose

A failed RAG processing job must persist the worker's actual error message, the failing pipeline stage, and a deliberately derived retryable flag so users and support can disambiguate failures. Today the worker's exception handler publishes `{"error": str(e)}` while rag-api's failed branch reads `error_message`/`stage`/`retryable` — so every worker-originated failure lands in Firestore as the fallback `"Processing failed"`, a null `error_stage`, and a fabricated `retryable: true`, with the `processing/summary` error subdocument inheriting the same fallbacks. This cycle aligns the worker — the odd one out among the four failure writers (worker exception handler, stale-lease sweep, rag-api enqueue-failure paths, `Resource` model) — to rag-api's existing contract: no migration, no reader changes. A contract test locks the seam so the mismatch cannot silently return.

## Requirements

- **Failure payload completeness** — when document processing fails, the worker's failed status payload must include `error_message` (the actual exception message), `stage` (the pipeline stage executing at failure time), and `retryable` (deliberately derived); the payload must never rely on rag-api's fallback defaults for these keys.
- **Stage tracking** — the worker must track the currently executing pipeline stage through `process_document` so the failure handler reports the true failing stage; stage names reuse the existing progress-stage vocabulary (`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`), with `"processing"` as the safe value when the stage is genuinely unknown.
- **Persistence unchanged on the API side** — rag-api's failed branch must persist the worker-provided values unchanged: main document `error` ← payload `error_message`, `error_stage` ← payload `stage`, `retryable` ← payload `retryable`; the `processing/summary` error subdocument must carry the same message and stage.
- **Explicit retryable derivation** — aligned with the worker's ACK/NACK behavior: errors classified transient by `classify_error` → `retryable: true`; classified permanent (including unclassified-unknown, per `classify_error`'s conservative default) → `retryable: false`.
- **Contract test** — a test must cover the worker failure → rag-api persistence path: it exercises the worker's failure-payload construction and rag-api's failed-branch persistence (via the Firestore emulator or fakes) and asserts the persisted `error`, `error_stage`, and `retryable` equal the worker's values; it must fail if either side's payload keys drift.

Acceptance (from the Definition): a failed job's published status carries all three keys with real values; the persisted document has `error` = the actual message (not `"Processing failed"`), `error_stage` = the failing stage (not null), and `retryable` = the derived value; the `processing/summary` error subdocument matches the main document's message and stage; the contract test exists and passes.

## Boundaries

- **Must not**: change rag-api's reads or persisted schema — the worker aligns to the API, not the reverse.
- **Must not**: require a Firestore migration, field rename, or backfill; the persisted fields keep their names and semantics (`error`, `error_stage`, `retryable`); Firestore `schema_version` stays 2.
- **Must**: every worker-originated failure payload carries `retryable` explicitly; rag-api's `details.get("retryable", True)` fallback must not be the operative mechanism for worker failures (the fallback line itself stays for non-worker publishers).
- **Prefer**: retain the legacy `error` key in the worker payload; avoid introducing a structured error-code taxonomy (`error.code` remains `"UNKNOWN"` unless a code is actually sent).
- **Out of scope**: the stale-lease sweep's direct failure write (already contract-consistent; keeps `retryable: true` — a dead worker is transient by nature); retry/backoff mechanics (Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals — only the *reporting* of retryability changes); frontend/mobile changes (`ResourceResponse` already exposes `error`/`error_stage`); widening `classify_error`'s heuristics.

Known behavior change accepted: unclassified-unknown exceptions currently persist `retryable: true` (the silent default) but classify as permanent, so they will now persist `false`; manual reprocess via `POST /process` is unaffected.

## Version bump

- Patch bump for `rag-worker-service` (failure-payload behavior fix). `rag-api-service` has no code change and needs no release.
- No data-schema bump: Firestore `schema_version` remains 2; no migration or backfill.
- No client-facing API version change: `ResourceResponse` fields are untouched, and the status-topic change is additive (legacy `error` key retained).

## Deferred items

- Companion D3 issue referenced by the Objective — its scope is unavailable in this context; anything it covers beyond the worker→rag-api failure payload alignment.
- Reconciling this analysis with the original D4 deviation note in `plans/upload-flow.md` (file not present in the current tree).
- Dropping the legacy `error` key from the worker payload once an audit confirms rag-api's status subscriber is the only consumer of the topic.
- A structured error-code taxonomy / failure taxonomy for the `processing/summary` error subdocument.
- Widening `classify_error`'s transient/permanent heuristics.