<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path=".sle/work/wi-define-108-a8/plan.md">>>
# Implementation Plan — rag-worker → rag-api failure payload contract alignment

Work item: wi-define-108-a8 (authoritative Definition artifact `definition:obj-108`, sha256 `71f1c39c…`)
Step: plan (iteration 1). All repository claims below were verified by reading the named files in the current tree; anything not verified is explicitly marked.

---

## 1. Verified current state (evidence base)

### 1.1 The broken seam (verified)
- `apps/ai-server/rag-worker-service/main.py`, `process_document` exception handler:
  ```python
  except Exception as e:
      metrics.error_message, metrics.end_time = str(e), time.time()
      self.logger.error("document_processing_failed", ...)
      await self._publish_status_update(user_id, course_id, resource_id, "failed", {"error": str(e)}, job_id)
      ...
      return metrics
  ```
  The handler **swallows** the exception and returns `metrics` — it does not re-raise. One-key payload `{"error": str(e)}`.
- `apps/ai-server/rag-api-service/main.py`, `run_transactional_update` failed branch:
  ```python
  main_update["error"] = details.get("error_message", "Processing failed")
  main_update["error_stage"] = details.get("stage")
  main_update["retryable"] = details.get("retryable", True)
  ...
  summary_update["error"] = {
      "code": details.get("error_code", "UNKNOWN"),
      "message": details.get("error_message", "Processing failed"),
      "stage": details.get("stage"),
  }
  ```
  Plus `summary_update["stage"] = details.get("stage", "unknown")` and `["progress"] = details.get("progress", 0)` unconditionally. Extra keys in `details` are ignored — the worker's legacy `error` key costs the API nothing.
- Net effect today (matches F5): every worker-originated failure persists `error="Processing failed"`, `error_stage=None`, `retryable=True`, summary `error.code="UNKNOWN"`.

### 1.2 Established failure schema on the API side (verified — must not change)
- `Resource` model (`rag-api-service/models/resource.py`): `error`, `error_stage`, `retryable: bool = True`.
- `ResourceResponse` (rag-api `main.py`): exposes `error` and `error_stage` (no `retryable` field) — frontend needs no change.
- Other failure writers already consistent: worker's `_fail_if_still_stale` writes `{"status": "failed", "error": "processing lease expired…", "error_stage": "processing", "retryable": True, …}`; rag-api `/process` and `POST /resources` enqueue-failure paths write `error`/`error_stage="enqueue"`. **None of these are touched.**

### 1.3 Worker classification machinery (verified)
- `classify_error(e)` in worker `main.py`: `TransientError`→True; httpx Connect/Timeout errors, `ConnectionError`, `TimeoutError`, `asyncio.TimeoutError`→True; `httpx.HTTPStatusError` with status 429/500/502/503/504→True, other 4xx→False; `PermanentError`→False; **unknown exceptions→False (conservative)**.
- `run_worker` uses `is_transient = classify_error(e)` for ACK/NACK on exceptions raised *outside* `process_document` (claim, payload parse). Because `process_document` swallows its own exceptions, pipeline failures raised inside it flow through `run_worker`'s normal ack path. The retryable flag is therefore derived from the same `classify_error` as the Definition mandates (F8) — one classification source of truth — even though for in-handler failures it is failure *reporting* aligned with that classification, not literally the ACK decision. No behavior change to ACK/NACK is made or needed (non-goal).

### 1.4 Stage vocabulary (verified)
`process_document` publishes progress stages: `starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`, `completed`. There is no stage tracking at failure time. Post-embeddings steps (`delete_old_vectors_via_service`, `store_chunks_via_service`, `_save_processing_metadata_to_subcollection`, `_update_user_usage`, `_generate_resource_map`) have no vocabulary name.

### 1.5 Test & CI infrastructure (verified)
- House cross-service contract-test pattern: `apps/ai-server/tests/integration/test_api_contracts.py` — imports `main as rag_api_main`; `tests/integration/conftest.py` sets `GCP_PROJECT`, `GOOGLE_APPLICATION_CREDENTIALS`, `SHARED_INTERNAL_TOKEN`, MagicMock-stubs `firebase_admin`, `google.cloud*`, `google.oauth2*`, `structlog`, and puts `rag-api-service` on `sys.path`.
- Worker-side fake-Firestore pattern proven against `@firestore.transactional`: `rag-worker-service/tests/unit/test_processing_lease.py` (`FakeTx/FakeSnap/FakeRef/FakeDb` + monkeypatching `firestore.transactional` to identity and `SERVER_TIMESTAMP` to a sentinel).
- Worker's own `tests/conftest.py` shows the full stub set needed to import worker `main.py` without heavy deps: `langchain(.text_splitter/.schema)`, `openai`, `langfuse`, `spacy`, `sklearn.feature_extraction.text`, `tiktoken`, `tenacity`, `google.cloud.firestore_v1.base_query` (with `FieldFilter` — the plain MagicMock parent is **not** sufficient for that from-import), `google.auth(.credentials)`, `google.cloud.storage`.
- CI (`.github/workflows/backend-tests.yml`): the `cross-service-and-contract-tests` job runs an **explicit file list** (`test_search_pipeline.py`, `test_chat_pipeline.py`, `test_shared_algorithms_in_sync.py`, `test_api_contracts.py`). A new file under `tests/integration/` will not run unless added to that command. The `cross` detector already fires for changes to `apps/ai-server/tests/`, `rag-api-service/`, and `rag-worker-service/`, so triggering is already correct. The cross job installs rag-api + agent-graph requirements plus `pytest<9` and `httpx` — **no pytest-asyncio**, and there is no `pytest.ini` at the `apps/ai-server` root, so cross-service tests must be **synchronous**. The worker's own unit leg (`rag-worker-service/tests/unit/`, `asyncio_mode = auto`, pytest-asyncio installed) supports async tests.
- Both mains can be loaded in one process only under distinct module names (both are `main.py`) — use `importlib.util.spec_from_file_location` for the worker module.

---

## 2. Design decisions

**D1 — Worker aligns to the API (per Definition constraint 1, F2).** rag-api's reads and the persisted schema (`error`/`error_stage`/`retryable`) are untouched. No migration, no backfill, no reader change.

**D2 — Payload builder as a pure module-level function.** New in worker `main.py`, placed next to `classify_error`:
```python
def build_failure_details(e: Exception, stage: Optional[str] = None) -> Dict[str, Any]:
    """Build the failed-status payload per the rag-api failed-branch contract.

    Keys are the contract rag-api's run_transactional_update reads:
    error_message / stage / retryable. `error` is retained deliberately
    (legacy key) for any unverified consumer of the status topic (F11 hedge).
    """
    message = str(e) or type(e).__name__
    return {
        "error_message": message,
        "stage": stage or "processing",
        "retryable": classify_error(e),
        "error": message,  # legacy key kept for topic-consumer continuity
    }
```
Rationale: pure + synchronous → directly unit-testable and usable from the synchronous contract test without an event loop; single construction point so the exception handler cannot drift from the contract; empty-message edge falls back to the class name (a bare `raise Exception()` must not publish an empty string).

**D3 — Stage tracker: "set immediately before the await", closed vocabulary.** Local `current_stage = "processing"` initialized **before the try** in `process_document` (covers any failure before the first assignment; matches the sweep's safe value). Assignments immediately before:
| Step (await) | `current_stage` set to |
|---|---|
| `_validate_processing_request` | `"starting"` |
| `_get_extracted_text` | `"text_retrieved"` |
| `content_tagger.generate_tags` | `"tagging_complete"` |
| `generate_document_summary` | `"summary_generated"` |
| `_create_enhanced_chunks` | `"chunking_complete"` |
| `_generate_embeddings_with_openrouter` | `"embeddings_complete"` |
| vector delete / weaviate store / metadata save / usage / map | *(no re-assignment — remains `"embeddings_complete"`)* |

Rationale for the last row: the vocabulary is closed by the Definition; the post-embedding steps are the tail of the vector-storage phase, and keeping the last named stage preserves more information than resetting to `"processing"`. Stage names are past-tense step labels in the existing progress timeline; the convention is "name of the step currently executing", which is exactly what "set the tracker immediately before the await" yields. A future step added without a tracker update reports the stale prior stage — the accepted, documented drift risk, mitigated by the AST guard (D6).

**D4 — Handler change.** Exception handler becomes:
```python
except Exception as e:
    metrics.error_message, metrics.end_time = str(e), time.time()
    self.logger.error("document_processing_failed", user_id=..., course_id=..., resource_id=...,
                      stage=current_stage, retryable=build_failure_details(e, current_stage)["retryable"],
                      error=str(e))
    await self._publish_status_update(user_id, course_id, resource_id, "failed",
                                      build_failure_details(e, current_stage), job_id)
```
(Enriching the log line with stage/retryable is part of the same handler edit — no separate concern.) `_publish_status_update` is otherwise untouched: `jobId` injection, sequence bookkeeping, and lease heartbeat behave as today.

**D5 — retryable derivation (per Definition, F8).** `build_failure_details` derives `retryable = classify_error(e)`: transient→`true`, permanent (incl. unknown)→`false`. **Deliberate behavior change:** unclassified-unknown failures persist `retryable=false` where the silent default used to fabricate `true`. The stale-lease sweep's independent `retryable: true` write stays correct (dead worker = transient) and is not touched. No widening of `classify_error` in this fix.

**D6 — Drift guards.** Three layers, following the house AST-subprocess/static pattern in `test_api_contracts.py`:
1. Exact key-set pin on the builder's output (`{"error_message","stage","retryable","error"}`) — adding/removing a payload key requires touching this test (intentional ossification per Definition).
2. AST scan of rag-api `main.py`: inside `run_transactional_update`, collect every `details.get("<const>")` first-arg; assert `{"error_message","stage","retryable"} ⊆` collected. Catches reader-side key renames.
3. AST scan of worker `main.py`: within `process_document`'s `ExceptHandler`, a call to `build_failure_details` must exist; and for each tracked await (map in D3), the immediately preceding statement in the same block must be an assignment `current_stage = "<stage>"`. Catches the handler being reverted to an inline payload and the tracker being removed/bypassed — representative-stage pinning per the Definition, without ossifying every line of the pipeline.

**D7 — Contract test is synchronous and fake-based.** `run_transactional_update` is already synchronous; fakes (not the emulator) satisfy "via the Firestore emulator or fakes" and keep the test runnable in the cross job, which has neither pytest-asyncio nor emulator services. The worker payload is built by calling the real `build_failure_details` with real exceptions (`httpx.ReadTimeout` is installed in the cross job; plain exceptions need nothing).

**D8 — Import strategy for the cross-service test.** rag-api `main` imports as today via the existing conftest. Worker `main.py` is loaded under a distinct module name (`rag_worker_main`) via `importlib.util.spec_from_file_location`, after registering the worker-conftest stub set idempotently (`if name not in sys.modules`) for modules absent from the cross-job venv: `langchain`, `langchain.text_splitter`, `langchain.schema`, `openai`, `langfuse`, `spacy`, `sklearn`, `sklearn.feature_extraction.text`, `tiktoken`, `tenacity`, `google.cloud.firestore_v1`, `google.cloud.firestore_v1.base_query` (with `FieldFilter`), `google.cloud.storage`, `google.auth`, `google.auth.credentials`. Stubs live in the new test file (not the shared conftest) so no existing test's environment changes. Module-level worker code (`GCP_PROJECT = os.environ["GCP_PROJECT"]`, `SubscriberClient(...)`) is safe under the conftest env vars + MagicMock clients.

---

## 3. Changes (files, in implementation order)

### 3.1 `apps/ai-server/rag-worker-service/main.py` (worker — the fix)
1. Add `build_failure_details(e, stage=None)` at module level, adjacent to `classify_error`, with the D2 body and the D5 rationale in its docstring.
2. In `process_document`: initialize `current_stage = "processing"` immediately before `try:`; insert the six `current_stage = "…"` assignments per the D3 table (each immediately before its tracked `await`); replace the handler's payload with `build_failure_details(e, current_stage)` and enrich the failure log (D4).
3. No changes to `_publish_status_update`, `run_worker`, `_fail_if_still_stale`, claim logic, or retry/lease mechanics.

**Verify:** `python3 -m pytest rag-worker-service/tests/unit/ -v` (existing 34+ tests stay green — the change adds a local and a function; nothing else moves).

### 3.2 `apps/ai-server/rag-worker-service/tests/unit/test_failure_payload.py` (new, worker unit leg)
Runtime tests build a processor cheaply and exercise the real tracker + handler end-to-end:
- Construct via `object.__new__(EnhancedDocumentProcessor)`; set `langfuse = None`; monkeypatch instance step methods (async raisers) and `_publish_status_update` with an async recorder capturing `(status, details, job_id)`. No db needed — failures are injected before any Firestore write in the success path.
- `test_transient_failure_reports_stage_and_retryable`: `_get_extracted_text` raises `httpx.ReadTimeout("upstream read timed out")` → recorded failed-publish details: `error_message == "upstream read timed out"`, `stage == "text_retrieved"`, `retryable is True`, legacy `error == error_message` (early-stage case).
- `test_permanent_failure_reports_stage_and_retryable`: `_generate_embeddings_with_openrouter` raises `ValueError("bad chunk shape")` → `stage == "embeddings_complete"`, `retryable is False` (late-stage case).
- `test_failure_before_first_step_reports_starting`: `_validate_processing_request` raises → `stage == "starting"`.
- Builder unit tests: transient (`httpx.ConnectError`)→True; `PermanentError`→False; unknown custom Exception→False (pins D5's deliberate change); `stage=None`→`"processing"`; stage passthrough; empty `str(e)`→class-name fallback; exact key set `{"error_message","stage","retryable","error"}`.
- AST guards (D6 layer 3): source of `main.py` parsed; except-handler calls `build_failure_details`; each tracked await is immediately preceded by the correct `current_stage` assignment (map from D3).

**Verify:** `python3 -m pytest rag-worker-service/tests/unit/test_failure_payload.py -v`.

### 3.3 `apps/ai-server/tests/integration/test_worker_failure_payload_contract.py` (new, cross-service contract test)
Structure per D7/D8, all synchronous:
- Stub registration helper (D8 list), then load worker module as `rag_worker_main` via importlib; `import main as rag_api_main` for the API side.
- Fake Firestore (pattern lifted from `test_processing_lease.py`): `FakeTx` (records update/set, `get` returns current doc state), `FakeSnap`, `FakeRef` (with `.id`, `.collection().document()` chain for `processing/summary`), `FakeDb`. Monkeypatch `rag_api_main.firestore.transactional = lambda f: f` and `rag_api_main.firestore.SERVER_TIMESTAMP = "SERVER_TIMESTAMP"`. Seed doc `{"status": "processing", "filename": "x.pdf"}` so `processing→failed` is an allowed transition in `ALLOWED_TRANSITIONS`.
- Round-trip tests (build payload via **real worker code**, persist via **real `run_transactional_update`**, assert **persisted** state):
  - transient round trip: `httpx.ReadTimeout("upstream read timed out")` + stage `"text_retrieved"` → persisted main doc `error == "upstream read timed out"` (≠ `"Processing failed"`), `error_stage == "text_retrieved"` (≠ None), `retryable is True`; summary `error.message`/`error.stage` equal the payload's `error_message`/`stage`; `error.code == "UNKNOWN"` (no taxonomy introduced).
  - permanent round trip: `ValueError("Document r1 has neither extracted text nor a valid source URL")` → persisted `retryable is False`, same message/stage equality.
  - unknown-exception round trip: custom `class WeirdError(Exception)` → persisted `retryable is False` (pins the deliberate D5 change end-to-end).
- Drift guards (D6 layers 1–2): exact builder key set; AST of rag-api `main.py` asserting `{"error_message","stage","retryable"} ⊆` `details.get(...)` keys inside `run_transactional_update`; AST of worker `main.py` asserting the handler delegates to `build_failure_details`.
- Class docstring states the contract explicitly (worker publishes `error_message`/`stage`/`retryable` + legacy `error`; api persists `error`/`error_stage`/`retryable` and summary `error.{code,message,stage}`) so a future reader sees why the test fails on drift.

**Verify locally (worker venv):** `python3 -m pytest tests/integration/test_worker_failure_payload_contract.py -v` from `apps/ai-server` (real deps present there make stubs no-ops — the idempotent registration keeps both environments working).

### 3.4 `.github/workflows/backend-tests.yml` (one line, CI wiring)
Add the new file to the `cross-service-and-contract-tests` pytest command:
```
run: python3 -m pytest tests/integration/test_search_pipeline.py tests/integration/test_chat_pipeline.py tests/integration/test_shared_algorithms_in_sync.py tests/integration/test_api_contracts.py tests/integration/test_worker_failure_payload_contract.py -v --tb=short
```
No detector changes needed: `cross` already triggers on `tests/`, `rag-api-service/`, and `rag-worker-service/` edits (verified in `ci-detect-changes.sh`).

### 3.5 Explicitly unchanged
- `rag-api-service/**` — zero edits (D1). `run_transactional_update`, models, endpoints untouched.
- `_fail_if_still_stale`, heartbeat/lease logic, ACK/NACK policy, Pub/Sub wiring.
- Frontend/mobile — `ResourceResponse` already exposes `error`/`error_stage`.
- No new dependencies anywhere; no Firestore migration/backfill.

---

## 4. Acceptance-criteria mapping

| Definition acceptance | Satisfied by |
|---|---|
| Failed status payload carries `error_message`/`stage`/`retryable`, none relying on API fallbacks | 3.1 (D2/D4); pinned by 3.2 builder key-set + runtime tests and 3.3 exact-set guard |
| Persisted `error` = actual message, `error_stage` = failing stage, `retryable` = derived | 3.3 round-trip tests assert persisted values against worker-built payloads for transient/permanent/unknown |
| processing/summary error subdocument carries same message + stage | 3.3 round-trip tests assert summary `error.message`/`error.stage` equality |
| Contract test covers worker failure → rag-api persistence, fails on either side's key drift | 3.3 (round trips + D6 layers 1–2) and 3.2 (layer 3); executes in CI via 3.4 |

---

## 5. Risks & mitigations
- **Worker import weight in the cross job** (stub set must mirror the worker conftest). Mitigation: idempotent `sys.modules` registration in the test file, stub list documented with a pointer to `rag-worker-service/tests/conftest.py`; runtime round-trip verification locally before push.
- **Stage-tracker drift** as the pipeline evolves. Mitigation: update-before-await convention in a code comment at the tracker initialization; AST guard (D6 layer 3) pins representative stages; accepted residual risk per Definition.
- **`retryable=false` for unclassified-unknown** reduces auto-retry affordances. Accepted per Definition F8; manual reprocess via `POST /process` (failed→queued transition verified in `ALLOWED_TRANSITIONS`) unaffected.
- **Exact key-set pin ossifies the payload.** Intentional — it is the drift guard; adding a key means touching the test.
- **F11 residual risk** (unknown status-topic consumers reading old keys). Mitigated by retaining the legacy `error` key; it is inert to rag-api (extra `details` keys are ignored — verified). Dropping it later is trivial cleanup after an audit.
- **Documented nuance (no action):** `process_document` swallows its exceptions, so for in-pipeline failures `retryable` is reporting aligned with `classify_error` (per Definition F8) rather than the literal ACK decision; `run_worker`'s classification continues to govern claim/pull-level errors. This is stated in the builder's docstring to prevent future misreading.

## 6. Out of scope (per Definition nonGoals)
Structured error codes (`error.code` stays `"UNKNOWN"`); retry/backoff, lease, heartbeat, ACK/NACK mechanics; the stale-lease sweep's write; frontend changes; the companion D3 issue's scope; reconciling with the D4 deviation note in `plans/upload-flow.md` (file not present in tree).

## 7. Definition of done checklist
- [ ] `build_failure_details` exists, is used by the `process_document` handler, and carries `error_message`/`stage`/`retryable`/legacy `error`.
- [ ] `current_stage` initialized `"processing"` before `try:` and set immediately before each of the six tracked awaits.
- [ ] Worker unit tests (runtime + builder + AST) pass in `rag-worker-service/tests/unit/`.
- [ ] Cross-service contract test passes with fakes; round trips assert persisted `error`/`error_stage`/`retryable` and summary subdocument equality.
- [ ] `backend-tests.yml` cross job includes the new contract test file.
- [ ] `rag-api-service/` diff is empty; no schema/migration changes; existing test suites green.
<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>