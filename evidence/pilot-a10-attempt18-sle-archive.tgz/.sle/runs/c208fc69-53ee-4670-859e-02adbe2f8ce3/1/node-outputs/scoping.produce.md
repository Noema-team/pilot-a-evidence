<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path="docs/cycle-charter.md">>>
# Cycle Charter

## Scope

Align the rag-worker's failed status payload with rag-api's failed-branch contract for the worker→rag-api failure path only:

- **rag-worker-service (`main.py`)**: in `process_document`, track the currently executing pipeline stage (using the existing progress-stage vocabulary: `starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`, with `"processing"` as the safe fallback). In the exception handler, derive `retryable` from `classify_error(e)` (transient → `True`, permanent/unknown → `False`) and publish a failure payload carrying `error_message` (actual exception message), `stage` (tracked failing stage), `retryable` (derived), and the legacy `error` key retained alongside `error_message` for compatibility.
- **rag-api-service (`main.py`)**: no changes to its reads or persisted schema — its failed branch in `run_transactional_update` continues to read `error_message`/`stage`/`retryable` and persist `error`/`error_stage`/`retryable`, now receiving real values.
- **Tests**: add a worker→rag-api failure-path contract test in `apps/ai-server/tests/integration/` following the existing patterns in `test_api_contracts.py`. It must exercise the worker's failure-payload construction through rag-api's failed-branch persistence (Firestore emulator or fakes), assert the persisted `error`, `error_stage`, and `retryable` equal the worker's values, and guard against key-set drift on either side.

## Purpose

Today every worker-originated RAG processing failure persists as the fallback string `"Processing failed"`, a null `error_stage`, and a silently defaulted `retryable: true`, because the worker publishes `{"error": str(e)}` while rag-api reads `error_message`/`stage`/`retryable`. This cycle closes that contract mismatch so users and support can disambiguate failures: the persisted resource record and the processing/summary error subdocument carry the worker's actual error message, the true failing stage, and a deliberately derived retryable flag that reflects the worker's actual ACK/NACK behavior — with no Firestore migration, field rename, or backfill.

## Requirements

1. The worker's failed status payload must include `error_message` (actual exception message), `stage` (pipeline stage executing at failure time), and `retryable` (deliberately derived) — never relying on rag-api's `details.get(...)` fallback defaults for these keys.
2. `process_document` must track the currently executing stage via a stage tracker set immediately before each pipeline step's `await`; stage names reuse the existing progress vocabulary, with `"processing"` when the stage is genuinely unknown.
3. `retryable` derivation must be explicit and aligned with `classify_error` / ACK-NACK behavior: transient → `true`; permanent, including unclassified-unknown exceptions, → `false`.
4. The legacy `error` key is retained in the worker's failure payload alongside `error_message` for continuity with any unknown consumers of the status topic.
5. rag-api's failed branch persists worker-provided values unchanged: `error` ← `error_message`, `error_stage` ← `stage`, `retryable` ← `retryable`; the processing/summary error subdocument carries the same message and stage (with `error_code` remaining `"UNKNOWN"` unless a code is actually sent).
6. A contract test covering the worker failure → rag-api persistence path exists and passes, asserting persisted `error`, `error_stage`, and `retryable` equal the worker's values, and fails if either side's payload keys drift.

## Boundaries

**In scope:** worker failure-payload construction and stage tracking in `process_document`; the retryable derivation; the worker→rag-api failure-path contract test.

**Out of scope:**
- Changes to rag-api's failed-branch reads, persisted field names (`error`, `error_stage`, `retryable`), or the `Resource`/`ResourceResponse` models.
- Any Firestore migration, field rename, or backfill of existing documents.
- The stale-lease sweep (`_fail_if_still_stale`) — its direct failure write already conforms.
- Retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals, or widening `classify_error`'s heuristics.
- Enqueue-failure paths in rag-api (`/process`, `POST /resources`) — already conformant.
- Structured error-code taxonomy or failure classification codes.
- Frontend or mobile changes.
- Anything the companion D3 issue covers beyond this payload alignment (its content is unavailable in this context).

## Version bump

Minor. Behavior-visible change to persisted failure records (real error message, non-null `error_stage`, `retryable` now `False` for permanent/unclassified errors); no schema migration and no breaking API change.

## Deferred items

- The companion D3 issue referenced by the Objective (content unavailable; anything beyond the worker→rag-api failure payload alignment is out of this cycle).
- Reconciling this analysis with the original D4 deviation note in `plans/upload-flow.md` (file not present in the current tree).
- Auditing/dropping the legacy `error` key once all status-topic consumers are confirmed (trivial follow-up cleanup).
- Widening `classify_error`'s heuristics to reduce `retryable=false` conservatism for unrecognized-but-transient failures.
- Stage-tracker coverage beyond representative early/late-stage failure tests.
<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>