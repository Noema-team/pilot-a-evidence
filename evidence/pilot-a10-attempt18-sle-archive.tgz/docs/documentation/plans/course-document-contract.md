# Course Document Contract — Unification Plan

> **Problem:** three writers (mobile app, web server, backend services + CF
> trigger) write `users/{uid}/courses/{id}` with different field conventions
> and, worse, different *field sets*. Courses created in one client are
> partially invisible to the backend; some backend features read fields that
> no writer produces.
>
> **Status:** planned — field inventory completed 2026-08-24 (source:
> audit of course_repository.dart, courses.service.ts, rag-api-service,
> api-gateway, agent-graph-service, functions/denormalization.ts).
> Work tracked in phases below; update this file as phases land.

## The canonical contract (target state)

One document shape, written identically by every client:

```ts
users/{uid}/courses/{id} = {
  // identity + display — camelCase, owned by whichever client writes
  name: string,
  description: string | null,
  icon: string,            // format decided in phase 4
  color: string,           // format decided in phase 4
  userId: string,
  createdAt: Timestamp,    // canonical: camelCase (both UIs orderBy it)
  updatedAt: Timestamp,    // canonical: camelCase (phase 3 migrates writers)
  isStarred: bool,         // mobile-only UI state
  isArchived: bool,        // backend MUST honor (phase 2)

  // backend graph — snake_case, load-bearing
  connected_resources: { resources: string[], groups: string[] },
  _resolved: { resource_ids: string[], resource_count: int, updated_at: Timestamp },  // CF trigger maintains
  max_resources: int,           // default 20
  soft_limit_threshold: int,   // default 15
}
```

Rules:
- Backend reads only snake_case graph fields + `name` + `isArchived`.
- UI fields are camelCase; backend never reads them.
- No client writes `_resolved` — the CF trigger owns it.

## Known bugs this fixes

| # | Bug | Fixed in |
|---|---|---|
| 1 | Mobile courses lack `connected_resources`/`max_resources` → resource limits and resolved views silently use defaults | Phase 1 |
| 2 | `rag-api /courses/{id}/resources/info` reads `title`/`overview`/`mainTopics` — no writer anywhere; agent course search always empty | Phase 2 |
| 3 | `isArchived` ignored by backend → archived courses still hit RAG/agent search and gateway listings | Phase 2 |
| 4 | Timestamp drift: web writes `updatedAt`, CF trigger + rag-api stamp `updated_at` into the same docs | Phase 3 |
| 5 | `icon`/`color` value formats incompatible between clients | Phase 4 |

## Phase 1 — Mobile writes the full contract (highest value)

**Status: done (PR #12).** Mobile writes `connected_resources` + limits;
`_resolved` is CF-owned as specified. The hermetic stack now runs the real
denormalization CF under a Functions emulator (dev/env/firebase image builds
`apps/ai-server/functions`), which also required loop-guard fixes in the
triggers — their unconditional self-writes re-triggered `onDocumentWritten`
infinitely.

**Scope:** `apps/mobile/lib/courses/course_repository.dart` only.

- `createCourse` initializes `connected_resources`, `max_resources: 20`,
  `soft_limit_threshold: 15` alongside the existing camelCase fields.
- The CF denormalization trigger already backfills `_resolved` on any course
  write — no mobile change needed for it.
- Keep the seed's dual-write (`dev/seed/client.py`) as-is; it already matches.

**Verify:** create a course on the device (hermetic stack), attach a resource
via `POST /resources` with `course_ids`, confirm `_resolved.resource_count`
increments and the limit validation engages.

## Phase 2 — Fix dead/ignored readers

**Status: done.** `resources/info` reads `name`/`description` with
`title`/`overview` legacy fallback (unit-tested both paths); agent-graph
`/search` and the gateway's user-facing processing list skip `isArchived`
courses (the admin metrics endpoint intentionally stays unfiltered —
historical aggregates). Drive-by: the gateway's three firebase-admin
endpoints were 500ing on `admin.apps.length` (CJS interop) — fixed with
`getApps()`.

**Scope:** rag-api-service, agent-graph-service, api-gateway.

- `resources/info` (`rag-api/main.py` ~L984): read `name`/`description`
  (fallback to legacy `title`/`overview` for old docs); stop reading
  `mainTopics` or fall back gracefully.
- Course streams in agent-graph (`src/main.py` ~L751) and the gateway's
  processing list: skip docs with `isArchived == true`.
- Drop dead code paths while there: rag-api `create_course`/`list_courses`
  are unwired (tests only) — either wire or delete in a separate cleanup.

## Phase 3 — Timestamps: camelCase canonical

**Status: implemented on the Phase 3 branch.** Course mutations in the
Functions and rag-api paths dual-write top-level `updatedAt` (canonical) and
`updated_at` (legacy compatibility). The rag-api course model emits both and
reads camelCase first. Web course readers prefer `updatedAt` and fall back to
`updated_at`/`created_at` for older documents. `_resolved.updated_at` and
resource/group timestamps remain unchanged because they are separate snake_case
contracts.

**Scope:** `functions/src/denormalization.ts`, rag-api writers.

- CF trigger and rag-api write `updatedAt` (stop stamping `updated_at` on
  new writes).
- Dual-write both for one release window; old docs carry only snake_case —
  readers fall back to `updated_at` when `updatedAt` is absent.
- Mobile/web already write camelCase — no change.

## Phase 4 — `icon`/`color` format

**Status: implemented on the Phase 4 branch.** The compatibility format is
kebab-case icon names and `#RRGGBB` colors. Mobile writes that format and reads
legacy PascalCase/ARGB values; web normalizes legacy values on read and uses
the same defaults. No persisted field names were changed.

- Mobile `book-open` is already the same icon format used by the web picker;
  web defaults and renderers now normalize legacy `BookOpen` to `book-open`.
- Mobile writes `#RRGGBB` instead of 8-digit ARGB without `#`.
- Both clients continue reading existing legacy values safely.
- Display-only values require no data migration.

## Rollout notes

- Each phase is an independent PR; phases 1–2 are pure additions/reads and
  safe in any order. Phase 3 needs the release-window dual-write.
- Firestore indexes: none new required (no new query shapes).
- Existing production docs: no migration needed for phases 1–2 (readers
  fall back); phase 3 tolerates old docs via read fallback.
