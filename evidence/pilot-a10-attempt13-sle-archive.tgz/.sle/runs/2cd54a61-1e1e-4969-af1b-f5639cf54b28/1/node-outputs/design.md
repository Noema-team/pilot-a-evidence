<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path=".sle/work/wi-define-108-a8/design.md">>>
# Design — rag-worker → rag-api failure payload contract alignment

WorkItem: `wi-define-108-a8` · Step: design · Source of truth: `definition:obj-108` (authoritative, bounds binding)

---

## 1. Problem (verified against the tree)

- `apps/ai-server/rag-worker-service/main.py` — `process_document`'s exception handler publishes
  `await self._publish_status_update(..., "failed", {"error": str(e)}, job_id)`. One key.
- `apps/ai-server/rag-api-service/main.py` — `run_transactional_update` failed branch reads
  `details.get("error_message", "Processing failed")`, `details.get("stage")`, `details.get("retryable", True)`
  and persists `error` / `error_stage` / `retryable` on the main document, plus `message` / `stage`
  (with `error.code` defaulting to `"UNKNOWN"`) into `processing/summary`.
- Consequence (F5): every worker-originated failure persists the fallback string `"Processing failed"`,
  `error_stage: None`, and a fabricated `retryable: true`.
- The persisted schema `error`/`error_stage`/`retryable` is already written correctly by three other paths
  (worker stale-lease sweep `_fail_if_still_stale`, rag-api's `/process` and `POST /resources` enqueue-failure
  branches) and exposed by `models/resource.py` + `ResourceResponse`. The worker's status publisher is the
  only writer off-contract.
- `classify_error()` (worker `main.py`) already classifies every exception transient/permanent and drives
  ACK/NACK in `run_worker`; the worker publishes progress stages `starting`, `text_retrieved`,
  `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete` — but nothing tracks
  which stage was executing at failure time.

**Direction (binding per constraints):** the worker aligns to rag-api's existing read keys
(`error_message`/`stage`/`retryable`). rag-api's reads and the persisted schema do not change. No migration,
no rename, no backfill.

---

## 2. Requirements traced to design elements

| # | Requirement (from Definition) | Design element |
|---|---|---|
| R1 | Failed payload carries `error_message`, `stage`, `retryable`; never relies on API fallbacks | §4.1 `build_failure_payload` — the only failure-payload construction site |
| R2 | Worker tracks the executing stage; vocabulary = existing progress stages + `"processing"` safe value | §4.2 stage tracker with phase→stage mapping table |
| R3 | rag-api persists worker values unchanged: `error ← error_message`, `error_stage ← stage`, `retryable ← retryable`; summary error subdoc carries same message+stage | §5 — zero code change; behavior pinned by contract test |
| R4 | `retryable` derived explicitly from `classify_error`: transient → true, permanent/unknown → false | §4.1 derivation inside `build_failure_payload`, single source with ACK/NACK |
| R5 | Contract test covers worker failure → rag-api persistence, fails on key drift either side | §6 |

---

## 3. Architecture overview

```
rag-worker-service/                      rag-api-service/
  failure_payload.py   (NEW, pure)        main.py
    - ProcessingError /                     run_transactional_update
      TransientError /                      (UNCHANGED — reads
      PermanentError  (moved here)           error_message/stage/retryable)
    - classify_error  (moved here)
    - UNKNOWN_STAGE, PIPELINE_STAGES
    - build_failure_payload(e, stage)
  main.py
    - re-exports moved names (compat)
    - process_document: stage tracker +
      build_failure_payload in handler
    - run_worker: UNCHANGED (classify_error resolves via re-export)
    - stale-lease sweep: UNCHANGED (already on-contract)

apps/ai-server/tests/integration/
  test_worker_failure_payload_contract.py  (NEW — the contract test)
apps/ai-server/rag-worker-service/tests/unit/
  test_failure_stage_tracking.py           (NEW — tracker mechanism tests)
```

Rationale for a new pure module: the shared integration test root (`tests/integration/conftest.py`) can
import rag-api's `main` because it stubs the cloud SDKs, but importing the worker's `main.py` there would
require replicating the worker conftest's ~20-module stub list. Extracting the payload seam into a module
with **no third-party imports except `httpx`** (already installed and unmocked in the shared test env) makes
the contract test import the real worker code hermetically.

---

## 4. Worker-side design

### 4.1 `failure_payload.py` (new module)

```python
"""Worker→rag-api failure payload contract.

Single construction site for the "failed" status payload published to the
rag-status topic. rag-api's run_transactional_update failed branch reads
exactly: error_message, stage, retryable. The legacy "error" key is retained
alongside error_message as a hedge for unknown consumers of the topic (F11).
"""
import asyncio
import httpx

UNKNOWN_STAGE = "processing"
PIPELINE_STAGES = (
    "starting", "text_retrieved", "tagging_complete",
    "summary_generated", "chunking_complete", "embeddings_complete",
)

class ProcessingError(Exception): ...        # moved verbatim from main.py
class TransientError(ProcessingError): ...    # moved verbatim
class PermanentError(ProcessingError): ...    # moved verbatim

def classify_error(e: Exception) -> bool:     # moved verbatim (same body, same semantics)
    ...

def build_failure_payload(e: Exception, stage: str | None) -> dict:
    message = str(e)
    return {
        "error": message,                       # legacy key — retained hedge (F11)
        "error_message": message,               # ← rag-api persists as `error`
        "stage": stage or UNKNOWN_STAGE,        # ← rag-api persists as `error_stage`
        "retryable": classify_error(e),         # ← deliberately derived, never defaulted (R4)
    }
```

Key decisions:

- **`retryable = classify_error(e)`** — the same function that decides ACK/NACK, so the persisted record
  tells the truth: transient → Pub/Sub will redeliver → `true`; permanent/unknown → acked, manual reprocess
  via `POST /process` → `false`. Deliberate behavior change: unclassified-unknown exceptions flip from the
  silent `true` default to `false` (F8 adopted; see §7).
- **`PDFProcessingError.retryable` (worker `exceptions.py`) is deliberately NOT consulted.** That field is
  retryability *metadata* on the legacy pdf-processor exception family and does not flow through
  `process_document`'s call chain; consulting it would introduce a second derivation rule, against the
  Definition's R4 and the no-taxonomy non-goal. Noted as a possible future refinement, out of scope.
- **No `error_code` is sent** — rag-api's summary `error.code` stays `"UNKNOWN"` (non-goal: no taxonomy).
- Names are **moved, not copied**: `main.py` re-exports (`from failure_payload import ProcessingError,
  TransientError, PermanentError, classify_error, build_failure_payload, UNKNOWN_STAGE, PIPELINE_STAGES`)
  so `run_worker`'s `classify_error(e)` call and any external `from main import TransientError` keep working.

### 4.2 Stage tracker in `process_document`

A local `current_stage` in `process_document`, initialized to `UNKNOWN_STAGE` and assigned immediately
before each phase's first await, using the existing progress-stage vocabulary:

| Pipeline phase | Tracker assignment (set immediately before first await of the phase) |
|---|---|
| function entry → before validation | `current_stage = UNKNOWN_STAGE` (`"processing"` — safe default) |
| request validation | `current_stage = "starting"` |
| text retrieval | `current_stage = "text_retrieved"` (before `_get_extracted_text`) |
| tagging | `current_stage = "tagging_complete"` (before `generate_tags`) |
| summary | `current_stage = "summary_generated"` (before `generate_document_summary`) |
| chunking | `current_stage = "chunking_complete"` (before `_create_enhanced_chunks`) |
| embeddings | `current_stage = "embeddings_complete"` (before `_generate_embeddings_with_openrouter`) |
| old-vector delete, chunk store, metadata save, final publish | **no further assignment** — covered by the last milestone `"embeddings_complete"` |

- The vocabulary is binding (constraint): the post-embedding steps have no name in the existing progress
  vocabulary before `"completed"`, so failures there report `"embeddings_complete"` — the last milestone
  reached. Documented limitation, consistent with the milestone semantics clients already see.
- `current_stage` is a local of `process_document` assigned inside `try`, therefore readable in the
  `except` block. Failures before the first assignment (metrics/trace setup) report `"processing"`, matching
  the stale-lease sweep's `error_stage` convention, so the field never regresses to null.
- **Convention (drift guard):** "set the tracker immediately before the await." A future pipeline step added
  without updating the tracker reports a stale stage; the tracker unit tests (§6.5) pin representative early
  and late stages so removal or bypass of the tracker fails the build without ossifying every step.
- Progress `_publish_status_update` calls and their stage literals stay unchanged; tracker assignments
  mirror the adjacent publish literals by convention.

### 4.3 Exception-handler change (exact shape)

```python
        except Exception as e:
            metrics.error_message, metrics.end_time = str(e), time.time()
            self.logger.error(
                "document_processing_failed",
                user_id=user_id, course_id=course_id, resource_id=resource_id,
                error=str(e), stage=current_stage, retryable=classify_error(e),
            )
            await self._publish_status_update(
                user_id, course_id, resource_id, "failed",
                build_failure_payload(e, current_stage), job_id,
            )
            if trace: trace.update(output={"success": False, "error": str(e)})
            return metrics
```

`_publish_status_update` is otherwise untouched (it already injects `jobId` into details and handles
sequence/lease bookkeeping). The worker's `document_processing_failed` log gains `stage` and `retryable`
fields — free observability for the exact values that get persisted.

### 4.4 Compatibility hedge (F11)

Only rag-api's status subscriber is a verified consumer; other tooling may share the topic. The payload
therefore carries both `"error"` and `"error_message"` (same string) — one redundant key per failure
message as insurance. If a later audit confirms rag-api is the only consumer, dropping `"error"` is trivial
cleanup and will be caught by the AST guard (§6.3, G8) at that time — intentionally.

### 4.5 Explicitly unchanged (worker)

- `run_worker` ACK/NACK logic — `classify_error` behavior identical, only re-homed.
- `_fail_if_still_stale` / sweep — already writes `error`/`error_stage`/`retryable` correctly
  (`error_stage: "processing"`, `retryable: true` — correct: a dead worker is transient by nature).
- Pub/Sub ACK/NACK policy, leases, heartbeats — untouched; only the *reporting* of retryability changes.

---

## 5. rag-api side: no code change

`run_transactional_update`'s failed branch already implements R3 exactly:

- `main_update["error"] = details.get("error_message", "Processing failed")`
- `main_update["error_stage"] = details.get("stage")`
- `main_update["retryable"] = details.get("retryable", True)`
- summary: `stage = details.get("stage", "unknown")`; `error = {code: details.get("error_code", "UNKNOWN"),
  message: details.get("error_message", "Processing failed"), stage: details.get("stage")}`

With the worker now sending all three keys, the fallback defaults stop being operative for worker failures
(the `"retryable", True` fallback remains for non-worker publishers, unchanged by design). Transition
validity holds: the doc is `"processing"` when the failure message arrives, and `"processing" → "failed"`
is in `ALLOWED_TRANSITIONS`. rag-api requires **no deploy** for this fix; its behavior is what the contract
test pins.

---

## 6. Test design

### 6.1 Contract test — `apps/ai-server/tests/integration/test_worker_failure_payload_contract.py`

- **Import strategy:** `import main as rag_api_main` (existing conftest supplies stubs + `sys.path`);
  load the worker seam via
  `importlib.util.spec_from_file_location("worker_failure_payload", <tests>/../../rag-worker-service/failure_payload.py)`
  — no stubbing needed, no `main`-name collision, no heavy imports.
- **Persistence harness:** Firestore fakes in the house pattern of
  `rag-worker-service/tests/unit/test_processing_lease.py` (`FakeTx`/`FakeSnap`/`FakeRef`/`FakeDb`), extended
  so main document and `processing/summary` subdocument are separately addressable stores keyed by path
  (`tx.update(ref, data)` and `tx.set(ref, data, merge=...)` write into a per-path dict). Monkeypatch
  `rag_api_main.firestore.transactional` → identity and `rag_api_main.firestore.SERVER_TIMESTAMP` → sentinel
  on the stub module (same technique the worker lease tests use).
- **Path through real code on both sides:** payload built by `worker_failure_payload.build_failure_payload(...)`
  (the exact function `process_document` calls), then fed as `details` into
  `rag_api_main.run_transactional_update(db, doc_ref, "failed", payload, logger, user_id)` with the doc
  seeded at `status: "processing"`.
- **Emulator note:** both services have `FIRESTORE_EMULATOR_HOST` branches, so the same assertions can
  later run against the hermetic stack's emulator; fakes are the committed approach — hermetic, fast,
  no service dependency for a pinned unit-level contract.

### 6.2 Payload fixture matrix

| Case | Exception | Derived `retryable` | Stage |
|---|---|---|---|
| transient | `TransientError("PDF is password protected")` | `True` | `"text_retrieved"` (early) |
| permanent | `PermanentError("unsupported layout")` | `False` | `"embeddings_complete"` (late) |
| unclassified-unknown | `ValueError("...")` | `False` (conservative default) | `"tagging_complete"` |
| httpx-status | `httpx.HTTPStatusError` w/ 503 | `True` | `"embeddings_complete"` |

### 6.3 Test cases

| ID | Test | Assertion |
|---|---|---|
| G1 | payload carries contract keys | `set(payload) ⊇ {"error_message", "stage", "retryable"}`; `"error" in payload` and equals `error_message` (hedge pinned) |
| G2 | retryable derivation | each matrix row's `payload["retryable"] == classify_error(exc)` and matches expected column |
| G3 | main-doc persistence (transient, early stage) | persisted `error == "PDF is password protected"`, `error_stage == "text_retrieved"`, `retryable is True`, `status == "failed"` |
| G4 | main-doc persistence (permanent, late stage) | `error` = actual message, `error_stage == "embeddings_complete"`, `retryable is False` |
| G5 | summary subdoc consistency | `processing/summary`: `stage == payload["stage"]`, `error.message == payload["error_message"]`, `error.stage == payload["stage"]`, `error.code == "UNKNOWN"` |
| G6 | drift guard, worker side | rebuild the G3 scenario with a payload that omits `error_message` (simulating a worker key rename): persisted `error == "Processing failed"` ≠ worker message — documents the fallback and proves G3/G4 are not vacuous (i.e. key drift on either side flips these assertions to failing) |
| G7 | drift guard, API side | rebuild G3 with `details` keyed `"error_message"` but a stub of rag-api reading renamed keys is not needed — the dynamic equivalence in G3/G4 already fails if rag-api's reads drift (persisted values fall back and stop equaling the worker's values) |
| G8 | AST key-set guard (fast diagnosis) | AST-parse `failure_payload.py`: the dict literal in `build_failure_payload` has exactly `{"error", "error_message", "stage", "retryable"}` — mirrors the house AST pattern in `test_api_contracts.py`; renaming/removing a key fails immediately at the payload seam rather than via a downstream equality |

G3–G6 together satisfy the Definition's drift requirement: **worker key rename → G3/G4 fail (fallback
values ≠ worker values); rag-api read rename → G3/G4 fail (same mechanism); tracker/payload drift → G8 +
worker-side tests fail.**

### 6.4 Worker-side tracker tests — `rag-worker-service/tests/unit/test_failure_stage_tracking.py`

Runs under the worker's own conftest (heavy deps stubbed; `asyncio_mode = auto`). Construct
`EnhancedDocumentProcessor` via `object.__new__` (bypass `__init__`), attach the stubbed attributes, then:

- monkeypatch pipeline methods so the failure lands at a chosen step; monkeypatch
  `_publish_status_update` to capture `(status, details)`; `await processor.process_document(...)`:
  - `_get_extracted_text` raises `httpx.ConnectError` → captured failed payload has
    `stage == "text_retrieved"`, `retryable is True`, `error_message == str(exc)`, and legacy `error` key present;
  - `store_chunks_via_service` raises `RuntimeError("partial vector write ...")` → `stage == "embeddings_complete"`,
    `retryable is False` (unclassified → conservative default);
  - `_validate_processing_request` raises `PermissionError` → `stage == "starting"`, `retryable is False`;
  - `_create_enhanced_chunks` raises `TransientError` → `stage == "chunking_complete"`, `retryable is True`;
- assert every observed stage value ∈ `PIPELINE_STAGES ∪ {UNKNOWN_STAGE}`;
- assert `classify_error` imported from `main` is the same object as `failure_payload.classify_error`
  (re-export compatibility, protects `run_worker`).

### 6.5 CI placement

- Shared contract test: `apps/ai-server/tests/integration/` (rootdir already exercised by
  `test_api_contracts.py`; conftest supplies env + stubs; only additions needed are the worker-file
  path resolution and the fakes above).
- Worker tracker tests: `apps/ai-server/rag-worker-service/tests/unit/` (existing pytest rootdir,
  existing conftest stubs, `asyncio_mode = auto`).

---

## 7. Behavior changes & rollout

- **Deploy scope:** rag-worker-service only. rag-api unchanged; no Firestore migration, backfill, or
  client change (`ResourceResponse` already exposes `error`/`error_stage`).
- **Visible changes after a worker-originated failure:**
  - `error` = the actual exception message (was `"Processing failed"`);
  - `error_stage` = the failing milestone (was `None`);
  - `retryable` = `classify_error`-derived (unclassified-unknown now `false`, was silent-default `true`);
  - `processing/summary`: `stage` = failing milestone (was `"unknown"`), `error.message`/`error.stage` = real
    values, `error.code` still `"UNKNOWN"`.
- The `retryable=false`-for-unknown change is the intended conservatism of `classify_error` (prevents
  infinite retry loops); manual reprocess via `POST /process` is unaffected. Widening `classify_error` is
  out of scope.
- Existing already-failed documents are not rewritten.

---

## 8. Risks & tradeoffs (from Definition, with mitigations)

- **Unknown consumers of the status topic reading the old key set** → mitigated by retaining the legacy
  `error` key; residual risk accepted as low.
- **Stage-tracker drift as the pipeline evolves** → mitigated by the update-before-await convention and
  representative early/late-stage tests; intentional non-ossification of every step.
- **`retryable=false` for unrecognized-but-transient failures** → accepted; manual reprocess remains;
  widening classification out of scope.
- **Contract test ossifies the payload** → intentional; it is the drift guard. Adding a key means touching
  G1/G8 — the point.
- **New module must stay dependency-light** → the contract test's hermeticity depends on it; G8's AST guard
  and the module docstring state the constraint (`httpx` + stdlib only).

---

## 9. Acceptance traceability

| Acceptance (Definition) | Satisfied by |
|---|---|
| Failed status payload contains `error_message`/`stage`/`retryable`, none relying on API fallbacks | §4.1, §4.3; tests G1, G2, worker tracker tests |
| Persisted doc: real `error`, non-null `error_stage`, worker-derived `retryable` | §5 + §4; tests G3, G4 |
| `processing/summary` error subdoc carries same message and stage | §5; test G5 |
| Contract test exists and passes; fails on either side's key drift | §6.1–6.3; tests G1–G8 |

## 10. Out of scope / deferred

- Structured error-code taxonomy (`error.code` stays `"UNKNOWN"` unless actually sent).
- Retry/backoff mechanics: ACK/NACK policy, leases, heartbeats, sweep behavior.
- Frontend/mobile changes (`ResourceResponse` already exposes `error`/`error_stage`).
- Companion D3 issue referenced by the Objective — content unavailable here; anything beyond this payload
  alignment is deferred. Reconciling with `plans/upload-flow.md` deviation D4 is likewise deferred (file not
  present in the current tree).
- Dropping the legacy `error` key — possible future cleanup after a consumer audit; blocked on that audit,
  not on this fix.

<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>