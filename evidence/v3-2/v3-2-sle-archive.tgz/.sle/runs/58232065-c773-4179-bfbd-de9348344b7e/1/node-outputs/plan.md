<<<SLE-OUTPUT>>>
<<<SLE-ARTIFACT path="docs/plan.md">>>
# Implementation Plan — rag-worker → rag-api failure payload contract alignment

Run: 58232065-c773-4179-bfbd-de9348344b7e · Iteration 1 · Step: plan
Authoritative scope: WorkItem `wi-define-108-a8` (definition artifact `definition:obj-108`, sha256 `71f1c39c…`). Everything below implements exactly that Definition; no scope is added or dropped.

---

## 1. Problem (verified)

The worker→rag-api failure seam was written against two different contracts and nothing tests it:

| Layer | What it does today (verified) |
|---|---|
| Worker `process_document` exception handler (`apps/ai-server/rag-worker-service/main.py`) | Publishes failed status with `details = {"error": str(e)}` via `_publish_status_update` (Definition F3) |
| rag-api failed branch (`run_transactional_update`, `apps/ai-server/rag-api-service/main.py`) | Reads `details.get("error_message", "Processing failed")`, `details.get("stage")`, `details.get("retryable", True)`; persists `error` / `error_stage` / `retryable` on the main doc, and writes `error = {code: details.get("error_code", "UNKNOWN"), message, stage}` plus top-level `stage` into `processing/summary` (Definition F4) |

Net effect (F5): every worker-originated failure persists `error = "Processing failed"`, `error_stage = None`, `retryable = True` (fabricated default). The `processing/summary` error subdocument inherits the same fallbacks with `error_code` always `"UNKNOWN"`.

The persisted schema `error` / `error_stage` / `retryable` is already spoken by three other write paths (worker stale-lease sweep `_fail_if_still_stale`, rag-api `POST /process` and `POST /resources` enqueue-failure paths) and by both read models (`Resource` dataclass in `rag-api-service/models/resource.py`, `ResourceResponse` in rag-api `main.py`). **The worker's status publisher is the only writer that doesn't speak the schema — so the worker aligns to the API, not the reverse.** No migration, no rename, no backfill, no reader changes.

Additional verified constraint: the worker already classifies every exception via `classify_error()` (TransientError/PermanentError + type/status-code heuristics; unknown → permanent) and uses that classification for ACK/NACK in `run_worker` (F7). The failure handler has no stage tracking today (F9); progress updates already use the stage vocabulary `starting, text_retrieved, tagging_complete, summary_generated, chunking_complete, embeddings_complete, completed`.

## 2. The pinned contract

After this change, the worker's failed-status `details` payload contains exactly:

| Key | Value | rag-api consumption (unchanged code) |
|---|---|---|
| `error_message` | `str(e)` (guarded, see D1) | → main doc `error`; → summary `error.message` |
| `stage` | failing pipeline stage (tracker, see D2) | → main doc `error_stage`; → summary `error.stage` and summary `stage` |
| `retryable` | `classify_error(e)` (see D3) | → main doc `retryable` |
| `error` | `str(e)` — legacy key retained (see D4) | not read by rag-api; hedge for unknown topic consumers |

The `processing/summary` `error.code` stays `"UNKNOWN"` (no structured error taxonomy — non-goal).

## 3. Design decisions

### D1 — Extract a pure failure-payload helper (worker)
Add a module-level function in `rag-worker-service/main.py`, placed next to `classify_error`:

```python
def build_failure_details(exc: Exception, stage: Optional[str] = None) -> Dict[str, Any]:
    """Contract payload for a failed job, aligned with rag-api's failed branch.

    Keys (pinned by tests/integration contract test):
      error_message — actual exception message (rag-api persists it as `error`)
      stage         — failing pipeline stage (rag-api persists it as `error_stage`)
      retryable     — derived from classify_error (transient=True, permanent/unknown=False)
      error         — legacy duplicate of error_message, retained for unknown
                      consumers of the status topic (Definition F11 hedge)
    """
    message = str(exc) or exc.__class__.__name__
    return {
        "error_message": message,
        "stage": stage if stage else "processing",
        "retryable": bool(classify_error(exc)),
        "error": message,
    }
```

Rationale for the `str(exc) or exc.__class__.__name__` guard: some exceptions stringify to `""`; persisting an empty `error` would be worse than the fabricated fallback for support disambiguation. The class name is actual information about the failure. This is a micro-hardening inside the spirit of "the worker's actual error message", not a new behavior.

The helper is pure (no I/O) so the contract test can exercise the worker's real payload construction without importing Pub/Sub or Firestore machinery.

### D2 — Stage tracker in `process_document` (worker)
- Declare `current_stage: str = "starting"` immediately before the main `try` block.
- Convention: **set `current_stage = "<token>"` immediately before the `await` of each named pipeline phase**, where `<token>` is the progress-stage name that phase's completion update already uses (`text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`). Semantics: the tracker holds the phase in flight, named by its progress-completion token — so a failure during tagging reports `tagging_complete`, reading naturally next to the progress timeline clients already see.
- Auxiliary awaits (heartbeat, lease renewal, old-vector cleanup after the last named phase) do **not** touch the tracker; the tracker simply keeps its last value, which stays truthful ("failure after the embeddings phase").
- The exception handler passes `current_stage` to `build_failure_details(e, current_stage)`.
- Fallback: the helper normalizes a falsy stage to `"processing"` — the same safe value the stale-lease sweep uses for `error_stage`, so `error_stage` never regresses to `None`.

Drift risk (a future pipeline step added without updating the tracker) is mitigated by the update-before-await convention plus representative-stage contract coverage (early and late failure — see test plan), not by ossifying every step.

### D3 — retryable derived, never defaulted (worker)
`retryable = classify_error(e)` — the same function that drives ACK/NACK in `run_worker`:
- transient-classified → `True` (Pub/Sub will redeliver);
- permanent-classified, including unclassified-unknown per `classify_error`'s conservative default → `False` (acked; manual reprocess via `POST /process` remains).

Deliberate behavior change: unclassified-unknown exceptions previously persisted `retryable: true` (rag-api's silent default) and will now persist `false`. That is the conservatism `classify_error` was written for; accepted per Definition F8.

### D4 — Legacy `error` key retained (worker)
The payload carries `error` alongside `error_message` (one redundant string per failure message) as insurance for unverified consumers of the `rag-status-updates` topic and existing log tooling (F11). Dropping it later is trivial cleanup after a consumer audit.

### D5 — rag-api: zero code changes
`run_transactional_update`'s failed branch already reads exactly `error_message` / `stage` / `retryable` and persists them unchanged into `error` / `error_stage` / `retryable` and the summary error subdocument (verified in source). The contract is locked by the new test, not by edits. The `details.get(...)` fallbacks remain in the API for non-worker writers; for worker failures they are no longer operative (constraint: must not be the operative mechanism).

### D6 — Stale-lease sweep untouched
`_fail_if_still_stale` already writes `error` / `error_stage="processing"` / `retryable=True` directly and consistently with this contract; a dead worker is a transient condition. Non-goal.

## 4. File change plan

### 4.1 `apps/ai-server/rag-worker-service/main.py` (only production file changed)
1. Add `build_failure_details(exc, stage=None)` near `classify_error` (D1).
2. In `process_document`: add the `current_stage` tracker (D2) — init `"starting"` before the `try`; assign before each named-phase await.
3. In the `process_document` exception handler: replace `details={"error": str(e)}` with `details=build_failure_details(e, current_stage)` in the failed `_publish_status_update` call. Envelope (user_id/course_id/resource_id/status) unchanged.
4. No changes to `classify_error`, `run_worker`, `_fail_if_still_stale`, `_publish_status_update` signature, retry/ACK mechanics, or leases.

### 4.2 `apps/ai-server/tests/integration/test_worker_failure_contract.py` (new)
Cross-service contract test — worker payload construction → rag-api failed-branch persistence with fakes. See `docs/test-plan.md` Suite A for the full specification. Self-contained stubbing at the top of the file (worker deps are stubbed locally, not in the shared conftest, to avoid perturbing existing contract tests); worker `main.py` is loaded via `importlib` under a distinct module name to avoid the `main` name collision with rag-api's module already imported by the suite conftest.

### 4.3 `apps/ai-server/rag-worker-service/tests/integration/test_failure_stage_tracking.py` (new)
Worker-local tests that the tracker reports the true failing stage through the real `process_document` handler with stubbed pipeline steps. See test plan Suite B.

### 4.4 Not changed
`rag-api-service/main.py`, `rag-api-service/models/resource.py`, the stale-lease sweep, Pub/Sub ACK/NACK policy, leases/heartbeats, frontend/mobile, contract fixtures in `tests/fixtures/api-contracts/`.

## 5. Behavior changes & compatibility

- Persisted worker failures change from (`"Processing failed"`, `None`, `True`) to (actual message, actual stage, derived flag). This is the fix.
- `retryable` for unclassified-unknown errors flips `True → False` (D3) — accepted, documented here and in the Definition (F8).
- Unknown topic consumers keep working via the retained `error` key (D4).
- No Firestore migration/backfill; field names and semantics unchanged (constraint honored).
- `summary.error.code` remains `"UNKNOWN"` (no taxonomy — prefer-not honored).

## 6. Out of scope (non-goals, restated from Definition)

- Stale-lease sweep behavior; retry/backoff mechanics (ACK/NACK policy, leases, heartbeats) — only the *reporting* of retryability changes.
- Structured error codes / failure taxonomy.
- Frontend or mobile changes (`ResourceResponse` already exposes `error` / `error_stage`).
- Anything the companion D3 issue covers beyond this payload alignment (content unavailable here; deferred), and reconciling with the D4 deviation note in `plans/upload-flow.md` (file absent from tree).

## 7. Risks & mitigations

| Risk | Mitigation |
|---|---|
| Unknown consumers of the status topic read the old key set | Retain legacy `error` key (D4); residual risk accepted as low |
| Stage-tracker drift as pipeline evolves | Update-before-await convention; representative early/late-stage tests (Suite B) |
| `retryable=false` for genuinely transient-but-unrecognized failures | Accepted; widening `classify_error` is out of scope; `POST /process` manual reprocess unaffected |
| Contract test ossifies the payload | Intentional — it is the drift guard; adding a key means touching the test |
| Worker `main.py` import weight in the integration suite (heavy third-party deps; module name collides with rag-api's `main`) | Load via `importlib` under a distinct name; stub heavy deps locally in the new test file (mirroring `rag-worker-service/tests/conftest.py`'s stub map); no shared-conftest edits. If module-level side effects surface at import, stubs are extended additively — verified at implementation time |
| `firestore.transactional` is a MagicMock in the integration conftest, so calling `run_transactional_update` unpatched would no-op | Patch `rag_api_main.firestore.transactional` to an identity decorator and `SERVER_TIMESTAMP` to a sentinel per test — the exact pattern already proven in `rag-worker-service/tests/unit/test_processing_lease.py` (`_tx_identity`) |

## 8. Implementation order & verification gates

1. **Worker helper** — add `build_failure_details`; unit-check it in isolation (pure function). Gate: `pytest rag-worker-service` still green.
2. **Stage tracker + handler wiring** — tracker assignments before each named-phase await; handler calls the helper. Gate: worker unit suite green.
3. **Suite B** (worker tracker tests) — proves stage/retryable/message through the real handler. Gate: new tests pass.
4. **Suite A** (cross-service contract test) — worker helper output fed through real `run_transactional_update` with fakes. Gate: new tests pass; existing `tests/integration/test_api_contracts.py` untouched and green.
5. **Full verification** — run all three suites (commands in test plan). Gate: all green; acceptance map below fully covered.

## 9. Acceptance criteria mapping

| Acceptance (Definition) | Covered by |
|---|---|
| Failed status payload carries `error_message` / `stage` / `retryable`, none relying on API fallbacks | D1–D3; Suite A TC-A1/TC-A2/TC-A4; Suite B TC-B1–B4 |
| Persisted `error` = actual message (not "Processing failed"), `error_stage` = failing stage (not None), `retryable` = derived | Suite A TC-A1, TC-A2, TC-A3 |
| Summary error subdocument carries same message and stage | Suite A TC-A1 (asserts summary `error.message`, `error.stage`, `code == "UNKNOWN"`) |
| Contract test exists, passes, exercises worker construction → rag-api persistence, fails on key drift on either side | Suite A TC-A1 + TC-A5 (worker key-set equality) + persisted-equality assertions (API read drift) |
<<<END-SLE-ARTIFACT>>>
<<<SLE-ARTIFACT path="docs/test-plan.md">>>
# Test Plan — worker failure payload → rag-api persistence contract

Run: 58232065-c773-4179-bfbd-de9348344b7e · Companion to `docs/plan.md`

## 1. Strategy

Two new suites plus existing regression coverage. The contract test **imports both sides rather than restating the contract in a fixture**: it builds the failure payload through the worker's real code path and feeds it through rag-api's real `run_transactional_update`, asserting the persisted `error`, `error_stage`, and `retryable`. Fakes (not the Firestore emulator) are the primary mechanism — hermetic, fast, no emulator binary in CI, and the established house pattern (`rag-worker-service/tests/unit/test_processing_lease.py` fakes). Both services' `FIRESTORE_EMULATOR_HOST` branches remain available for a manual hermetic run if ever needed; they are not required for this plan.

## 2. Infrastructure

### 2.1 Fakes (defined locally in Suite A's file, modeled on `test_processing_lease.py`)
- `FakeTx` — records `update(ref, data)` and `set(ref, data, merge=...)` writes as tuples; `get()` semantics via the ref.
- `FakeSnap` — `exists=True`, `to_dict()` returns seeded doc state.
- `FakeRef` — `.id` attribute (read by `run_transactional_update`'s logging), `get(transaction=None)`, `collection(name)` → `FakeCollection.document(name)` chain so `doc_ref.collection("processing").document("summary")` resolves to a distinct recorded ref.
- `FakeDb` — `transaction()` returns the `FakeTx`; `document(path)` returns the seeded `FakeRef`.
- Stub logger: `types.SimpleNamespace(info=..., warning=...)` (structlog is MagicMock'd by the suite conftest; a stub keeps assertions independent of it).

### 2.2 Monkeypatches (per test, the proven `_tx_identity` pattern)
- `rag_api_main.firestore.transactional` → identity decorator (otherwise the MagicMock'd decorator no-ops the inner function and nothing is written).
- `rag_api_main.firestore.SERVER_TIMESTAMP` → sentinel string `"TS"`.
- Seeded doc state: `{"status": "processing", "filename": "x.pdf", ...}` so the `processing → failed` transition is allowed by `ALLOWED_TRANSITIONS` (a wrong seed hits the `new_status == current_status` early return or the invalid-transition no-op — both would silently produce zero writes and fail the assertions, which is itself a useful guard).

### 2.3 Importing the worker side from the integration suite
The integration conftest puts rag-api on `sys.path` as module `main`; the worker's module is also named `main` and pulls heavier deps. Suite A therefore:
- loads `rag-worker-service/main.py` via `importlib.util.spec_from_file_location("rag_worker_main", ...)` (no `sys.modules["main"]` collision);
- stubs missing heavy third-party deps locally at the top of the test file (openai, langfuse, langchain, spacy, tiktoken, tenacity — mirroring `rag-worker-service/tests/conftest.py`'s stub map, guarded by "only if not already in `sys.modules`");
- uses only the worker's pure surface: `classify_error` and `build_failure_details`.
Shared `tests/integration/conftest.py` is **not** modified, so existing contract tests are unaffected. If worker `main.py` exhibits import-time side effects beyond the stub map, extend the stubs additively (verify at implementation time — exact import-time behavior of worker `main.py` was not fully re-verified in this pass).

## 3. Suite A — cross-service contract test (new)
File: `apps/ai-server/tests/integration/test_worker_failure_contract.py`

Shared driver: `persist(worker_details)` → seeds a FakeDb with `status: "processing"`, calls the real `rag_api_main.run_transactional_update(db, ref, "failed", worker_details, stub_logger, "u1")`, returns `(tx, resource_ref, summary_ref)` where writes are separated by recorded ref.

| ID | Case | Given / When / Then |
|---|---|---|
| TC-A1 | Transient failure end-to-end (the acceptance path) | Worker: `build_failure_details(TransientError("Embedding timeout after 3 attempts"), "embeddings_complete")` → feed dict as `details` → persist. Then: main doc `error == "Embedding timeout"`, `error_stage == "embeddings_complete"`, `retryable is True`, `status == "failed"`; summary doc `error.message == "Embedding timeout"`, `error.stage == "embeddings_complete"`, `error.code == "UNKNOWN"`, top-level `stage == "embeddings_complete"`. |
| TC-A2 | Permanent failure | `build_failure_details(PermanentError("Invalid PDF structure"), "text_retrieved")` → persisted `retryable is False`, `error`/`error_stage` equal worker values. |
| TC-A3 | Unclassified-unknown exception (pins the deliberate behavior change) | `build_failure_details(RuntimeError("boom"), "chunking_complete")` → `classify_error` → `False` → persisted `retryable is False`; asserts the silent `True` default is no longer operative. |
| TC-A4 | Empty-message guard | `build_failure_details(Exception())` → `error_message == "Exception"` (class-name fallback, never an empty string). |
| TC-A5 | Worker payload key-set drift guard | `set(build_failure_details(e, "s").keys()) == {"error_message", "stage", "retryable", "error"}` — exact equality; any key added/removed/renamed on the worker side fails the build. |
| TC-A6 | API read-key drift guard (implicit in TC-A1/A2, made explicit) | Assert persisted main-doc write contains `error`, `error_stage`, `retryable` and that `error != "Processing failed"` — if rag-api renames any `details.get(...)` read, the fallback string or `None` appears and the equality assertions fail. |

Note: Pub/Sub envelope parsing (`_process_status_message`) is unchanged code and out of the broken seam; the contract targets payload keys ↔ persisted fields, per the Definition.

## 4. Suite B — worker stage-tracker tests (new)
File: `apps/ai-server/rag-worker-service/tests/integration/` (`test_failure_stage_tracking.py`; the worker's pytest.ini already runs `tests/` with `asyncio_mode = auto`).

Mechanism: drive the real `process_document` with monkeypatched pipeline collaborators so a stubbed step raises; capture the `details` dict passed to `_publish_status_update` via monkeypatch; assert payload contents. The exact collaborator names for "an early text-extraction step" and "the embeddings step" are taken from `main.py` at implementation time (function internals were not re-verified in this pass; the tracker convention, stage vocabulary, and handler location are pinned by the Definition F3/F7/F9).

| ID | Case | Then |
|---|---|---|
| TC-B1 | Early-stage failure (first named pipeline step raises `TransientError`) | captured `details["stage"]` is that step's progress token (e.g. `text_retrieved`), `retryable is True`, `error_message == str(exc)`, legacy `error` key present and equal |
| TC-B2 | Late-stage failure (embeddings step raises `PermanentError`) | `details["stage"] == "embeddings_complete"`, `retryable is False` |
| TC-B3 | Unknown exception type mid-pipeline | `retryable is False` (classify_error conservative default) |
| TC-B4 | Failure before any named step | `details["stage"] == "starting"` (tracker init); helper-level falsy-stage fallback to `"processing"` is covered in Suite A (D1/D2) |
| TC-B5 | Payload built by the helper | captured details key set matches TC-A5's set — proves the handler routes through `build_failure_details`, not an inline dict |

## 5. Existing coverage leveraged (unchanged, listed as guards)
- `rag-worker-service/tests/unit/test_processing_lease.py::test_genuinely_stale_lease_is_failed` — sweep still persists `retryable is True` (D6 non-regression).
- `rag-api-service/tests/unit/test_models_resource.py` — `Resource` model `error`/`error_stage`/`retryable` defaults.
- `tests/integration/test_api_contracts.py` — `ResourceResponse` still exposes `error`/`error_stage` to clients (no API-side change to break it).

## 6. Drift-guard specification (what fails, and why)
- Worker adds/renames/removes a payload key → TC-A5 exact key-set equality fails.
- Worker stops deriving `retryable` (hardcodes or omits) → TC-A1/A2/A3 value assertions fail.
- Worker tracker removed/bypassed → TC-B1/B2 stage assertions fail.
- rag-api renames a `details.get(...)` read key → persisted value becomes the fallback (`"Processing failed"` / `None` / `True`) → TC-A1/A2/A6 equality assertions fail.
- rag-api changes summary error subdocument shape → TC-A1 summary assertions fail.

## 7. Run commands
```
cd apps/ai-server/rag-worker-service && pytest            # Suites B + existing worker units
cd apps/ai-server/rag-api-service && pytest               # existing API units (must stay green)
cd apps/ai-server && pytest tests/integration -q          # Suite A + existing contract tests
```
All three green = step done. No emulator, credentials, or network required.

## 8. Acceptance ↔ test traceability

| Acceptance criterion | Tests |
|---|---|
| Payload carries error_message/stage/retryable, no fallback reliance | TC-A1, TC-A3, TC-A5, TC-B1–B5 |
| Persisted error/error_stage/retryable equal worker values | TC-A1, TC-A2, TC-A3, TC-A6 |
| Summary subdocument carries same message and stage | TC-A1 |
| Contract test exists, passes, fails on either side's key drift | TC-A5, TC-A6 (+ TC-B5) |

## 9. Limitations & notes
- Fakes exercise `run_transactional_update`'s logic, not Firestore's transaction semantics (snapshot isolation is approximated by the single-tx fake, as in the existing worker fakes). Sufficient for the payload-key seam this Definition targets.
- Suite B pins representative stages only (early + late), per the Definition's explicit choice not to ossify every pipeline step.
- Worker `main.py` import-time behavior under the integration stub set is to be confirmed during implementation (§2.3); any gap is closed with additive local stubs, never shared-conftest edits.
<<<END-SLE-ARTIFACT>>>
<<<END-SLE-OUTPUT>>>