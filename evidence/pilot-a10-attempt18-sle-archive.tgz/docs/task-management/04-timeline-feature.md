---
tags:
  - TaskManagement
---

Timeline implementation tasks. Design: `apps/ai-server/docs/architecture/timeline-and-flashcards/design-specification.md` (v2.3 — derived timeline: path + position, no stored schedule). Plan (phases, decisions, recon reality map): `docs/superpowers/plans/2026-08-24-timeline-implementation.md`. Cards ordered by dependency, top to bottom.

# Canonical unit progress + grounded today_chunk (spec v2.5)
#Done
Presentation-contract correction, no mechanics change: `GET /exams/:id/progress` now exposes `unit_progress` (completed/total/remaining/fraction — confirmed-events-only unit count: coarse completes a unit, page partials complete when their union covers the full source range, card/work-item units complete only via coarse, voided events don't count, excluded units aren't in total, zero-size units never complete by arithmetic) alongside the unchanged multi-currency analytics; `today_chunk` items now carry stored title, resource_id, source range, deterministically derived remaining_ranges (within the stored unit range; page localization stays approximate until text-anchored) and uniform remaining_count (legacy pages/cards fields kept; grounded in stored Unit docs, nothing generated). ActivityLog/pdf-opens/card-practice/`cards_practiced` classified as observational analytics — never canonical progress. Out-of-range partial completions are clipped before completion/remaining-range derivation (shared `confirmed_ranges_within_unit` helper), so canonical and weighted coverage cannot disagree; zero-size units count as remaining but are never chunk-selected. 28 new tests (derivation + endpoint); rag-api suite 371 green.
---

# Timeline derivation module (Python, multi-currency)
#Done
Pure, zero-I/O derivation in `rag-api-service/services/timeline_derivation.py`: three currencies (pages | cards | work-item), coverage as max(measured, asserted), normalized fraction-of-path pace for mixed paths (native per-currency when homogeneous), coarse (`covered: null`) completions, projection bands with hysteresis on the unrounded value, sparse-data withholding, void handling, unit-boundary chunk snapping. 44 table tests in `tests/unit/test_timeline_derivation.py` (34 concepts ported from the TS prototype + currency suite); full rag-api suite 261 green; TS prototype deleted per plan D2 (gateway suite 84 green after deletion).
---

# Exam, unit & completion storage + CRUD + progress
#Done
rag-api-service owns the domain (plan D1/D3): `models/exam.py` + `services/exam_service.py` with V2 flat storage at `users/{u}/exams/{examId}` (+units, +completions). Authenticated endpoints provide exam CRUD, build-time `PUT /path`, append-only completion/void, derived `GET /progress`, and course ResourceMaps via QueryResolver; api-gateway proxies each route. Rebuilds are rejected after completions until P5 adds safe carry semantics — guard and write are one Firestore transaction; voids use deterministic `void:{eventId}` doc IDs (duplicate voids collide); PATCH clears nullable fields (description, capacity). 13 service + 24 endpoint + 5 gateway proxy tests; rag-api suite 302 green and gateway suite 89 green. Spec §3.2, §5.
---

# Skeleton extraction hardening (3-tier)
#Done
Tier 1/3 were already the MarkdownParser path in `ResourceMapGenerator`; this added tier 2 (`algorithms/skeleton_refiner.py`): thinness detection (>20 pages/section), cheap LLM refinement via OpenRouter (excerpt + sampled headings, JSON-validated, per-level de-overlap, ≥2 sections), confidence now reflects path usability (thin+unrefined = low). Wired into all three generator call sites; refinement failure always falls back. 24 tests in `tests/unit/test_skeleton_refiner.py`. Spec §4.1.
---

# Sensing: ActivityLog + suggested completions
#Done
`POST /timeline/activity` beacons (pdf_open via unit links; card_practice stored from day one with `resource_id`+`section_id`) in user-scoped `users/{u}/timelineActivity/{eventId}`, idempotent by client event id. `GET /exams/:id/completions/suggestions` derives page-unit suggestions on read from a trailing 48h window (unit-link match or resource+page overlap; uncovered span only; one per unit; voided/coarse completions respected; never persisted). Confirm = existing completions endpoint with `origin: confirmed_suggestion` (origin now validated). Card-practice matching + ≥80% exposure rule moved to P6 per plan deviation D-1. 14 engine + 7 endpoint + 2 gateway tests; rag-api 323 green, gateway 91 green. Spec §3.2, §4.4.
---

# Path build: LLM propose → student edit → commit
#ToDo
agent-graph-service (Python FastAPI): new `POST /plan` route, inline prompt, `TIMELINE_PLANNER_MODEL`/`_TEMPERATURE` config convention; ordering/prioritization only, no dates, stateless. rag-api assembles skeleton input; student reviews (reorder/split/exclude/placeholders) and commits via `PUT /path`. Duplicate suggestion at build time, student decides. Spec §4.2, §5. Plan P4.
---

# Split editor: structural ops with completion-carry
#ToDo
Server ops for split/merge/rename/reweight/fill-placeholder; covered ranges re-map by page overlap, straddles flagged for re-confirmation, events append-only. Load-bearing UX surface — MVP-grade polish. Spec §4.3. Plan P5.
---

# Unit ↔ flashcard linking (section overlap)
#ToDo
No decks exist (plan D4): unit page range → overlapping map Sections → cards by `section_id` (coverage already tracked). Overlap lookup endpoint; generate forwards `section_ids` to the existing flashcard-service endpoint — no new generation path. Spec §3.4, §4.6. Plan P6.
---

# Crammer triage
#ToDo
When required pace exceeds capacity: honest projection statement (falls out of the derivation) plus agent-graph trim proposal (units marked cut, never deleted, restorable). Spec §6. Plan P7.
---

# Mobile UI: exam, path & progress screens
#ToDo
Exam setup, path review/edit (split editor), progress view with today's chunk and confirmable suggestions. Mirror-not-controller tone throughout. Depends on all cards above. Plan P8.
---

# Decide to-do/task integration with the path
#ToDo
Open product question (formerly "Gjøremål in timeline"): whether loose student to-dos belong on the exam path or stay a separate surface. Placeholder units already cover the missing-material case — decide before phase 2.
---
