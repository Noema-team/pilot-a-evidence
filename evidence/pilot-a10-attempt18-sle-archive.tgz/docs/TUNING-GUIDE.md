# Tuning Guide — making chat answers good and consistent

> How to use the verification system to actually change what a user experiences.
> For what the system *is*, see [`AUTONOMOUS-VERIFICATION-PLAN.md`](./AUTONOMOUS-VERIFICATION-PLAN.md).

---

## Two roles

Not everyone tuning this system should hold every lever. Split deliberately:

| | Editor role | Maintainer role |
|---|---|---|
| **Owns** | Agent prompts (the `*_SYSTEM_PROMPT` text blocks), `eval/datasets/` entries, `eval/TUNING-LOG.md` | Everything else: cassette recording discipline, baseline promotion, waivers, env/config, retrieval levers |
| **Uses** | [`eval/PLAYBOOK.md`](../eval/PLAYBOOK.md) — the tuning loop, step by step | This document |
| **Never does** | Promote a baseline, hand-edit cassettes, waive a failure, change env vars | — |

Promoting a baseline is a two-person decision by convention: the editor
proposes from a clean `--compare` output, the maintainer does the `cp`.

---

## The one idea

**Quality and consistency are different problems with different fixes.**

- *Quality* is the mean. "Are the answers good?" → `dev/run eval`
- *Consistency* is the variance. "Is the same question answered the same way?" → `dev/run variance`

Most "the AI is unreliable" complaints are a variance problem, and no amount of
prompt-tuning fixes variance. Measure which one you have before you touch
anything.

---

## Five minutes: where am I?

```bash
dev/run env up --profile fidelity      # real extraction; fast uses pypdf and skews structure
dev/run seed                           # ingest the fixture corpus
dev/run eval --judge --judge-cards --label today   # free in replay, ~2 min
```

You get a scorecard. Read it top-down — it is ordered by leverage:

```
Retrieval
  recall@5            1.00     did search find the right documents?
  MRR                 1.00     did it rank them near the top?

Routing
  label accuracy      80%      did the query reach the right agent?
  worst misroutes
    TEACHING_CONCEPTUAL → SEARCH  ×3

Judge
  faithfulness        4.70 / 5   (20/20 scored)   answers grounded in what was retrieved
  relevance           4.85 / 5   (20/20 scored)   answers address what was asked

Structure (vs golden maps)
  mean F1             1.00     the map matches the document's heading tree

Cards (generated + judged)
  generated/judged    6 / 6
  answerable/faithful/meaningful   100%  (6/6 scored on each)

Weakest queries
  q004  routed TEACHING_CONCEPTUAL → SEARCH
```

(`faithfulness 4.70 (20/20 scored)` — the fraction is coverage: on how many
queries that dimension was actually judged. A mean without coverage is how
a broken run hides.)

Then, once, spend a few cents to learn whether you have a variance problem:

```bash
LLM_UPSTREAM_API_KEY=sk-... dev/env/run cassettes record
dev/run variance --repetitions 5
dev/env/run cassettes stop-record
git checkout eval/cassettes     # variance answers are samples, not baselines
```

---

## The levers, ranked

Work top-down. The ordering is not arbitrary — it follows the pipeline, and a
defect upstream makes every downstream measurement meaningless.

```
extraction → chunking → embedding → retrieval → routing → generation
```

### 1. Routing — biggest felt impact per unit of effort

**Symptom:** `routing label accuracy` below ~90%, or a specific pair dominating
`worst misroutes`.

**Why it matters most:** routing decides *what kind* of answer the user gets. A
"help me understand gradient descent" question routed to `SEARCH` returns a
citation dump instead of an explanation. The answer is not wrong — it is the
wrong shape, which users experience as the assistant not listening.

**Levers**
| Lever | Where | Notes |
|---|---|---|
| Classifier prompt | `agent-graph-service/src/agents/classifier.py` | Add few-shot examples for the labels that swap. This is almost always the fix. |
| `CLASSIFIER_TEMPERATURE` | env, default `0` | Already 0. If routing is *unstable* at 0, the prompt is genuinely ambiguous, not random. |
| `CLASSIFICATION_TO_AGENT` | `agents/router.py` | The label→agent map. Note `CHAT → teaching_agent`: greetings get the teaching agent. |
| `CLASSIFIER_MODEL` | env | A stronger model for classification is cheap — it is one short call per message. |

**Read the confusion matrix, not the accuracy.** "80%" is not actionable;
"TEACHING_CONCEPTUAL is being called SEARCH three times out of five" tells you
which two label descriptions are too close together.

### 2. Retrieval — the ceiling on everything downstream

**Symptom:** `recall@5` below ~0.8, `MRR` below ~0.7, or `complete misses > 0`.

If the right chunks never reach the agent, no prompt can rescue the answer. An
agent given the wrong context will confidently answer the wrong question.

**Levers**
| Lever | Where | Effect |
|---|---|---|
| `CHUNK_SIZE` / `CHUNK_OVERLAP` | env, `800`/`100` | Smaller = more precise, more fragments. Larger = more context, blurrier embeddings. |
| `USE_RERANKER` | env | Reranking mostly moves MRR, not recall — it reorders what was already found. |
| `DEFAULT_MIN_SCORE` | env, `-10.0` | Scale is reranker logits (~-10..+10), not 0..1 cosine. Too high silently drops relevant chunks; a complete miss with good chunks in the index usually means this. |
| `RERANK_CANDIDATE_POOL` | env, `30` | How many candidates the reranker gets to reorder. This is the real recall knob at the retrieval stage — the reranker cannot promote a chunk that was never fetched. |
| `DEFAULT_TOP_K` | env, `10` | Floor on candidates fetched; the request's own `limit` and `RERANK_CANDIDATE_POOL` both raise it. |
| `EMBEDDING_MODEL` | env | Changing this invalidates every stored vector — a full reseed. |

**Look at the pattern in the misses, not the count.** The four "math-query
misses" in the original v1 baselines turned out to be a baseline-recording
artifact, not retrieval weakness: both v1 baselines were captured after a
journeys run, J7 deletes a corpus resource without reseeding, and the four
misses were all queries whose relevant document was simply absent from the
index. A clean-stack fast run scores recall 1.0 with zero misses. Don't treat
a miss as real until you've confirmed the relevant document is actually in
the index — that's what the eval's structure-phase preflight now enforces.
If genuine misses do reappear on a clean index, read the pattern (e.g. all
symbolic math) before touching a lever; a repeatable symbolic-retrieval
weakness would point at hybrid keyword+vector search, but that decision needs
clean, representative evidence, not a contaminated baseline.

### 3. Structure extraction — feeds retrieval

**Symptom:** structure `F1` below 1.0, `hierarchy_accuracy` low, or
`chunk_coverage` below 1.0.

A section with no chunks cannot be retrieved or studied. Mis-levelled sections
break "study this chapter".

**Levers:** the `fidelity` profile (marker-pdf) vs `fast` (pypdf); heading
detection in `algorithms/markdown_parser.py`; `SectionLinker` matching rules.

**Never score structure on the `fast` profile.** pypdf produces flat text, so
you would be measuring the harness.

### 4. Generation — prompts and models

Only worth touching once retrieval and routing are healthy. Otherwise you are
tuning how well an agent answers the wrong question with the wrong context.

**Levers:** the four agent prompts (`rag_agent.py`, `teaching.py`,
`problem_solving.py`, `study_advice.py`); per-agent `*_MODEL` and
`*_TEMPERATURE`; `MAX_MESSAGE_HISTORY` (`20`); `ENABLE_AGENT_CHAINING`.

---

## Consistency: the temperature table

Production does **not** run deterministically, and the eval does:

| Stage | Production default | Eval (`.env.test`) |
|---|---|---|
| coref | `0.1` | `0` |
| rewrite | `0.1` | `0` |
| classifier | `0` | `0` |
| rag_agent | `0.1` | `0` |
| teaching | `0.2` | `0` |
| study_advice | **`0.3`** | `0` |

So the same question asked twice in the app can legitimately differ at four
stages, and the scorecard cannot see it. Three independent sources of run-to-run
variance:

1. **Temperature > 0** at coref, rewrite, and the agents.
2. **`ENABLE_AGENT_CHAINING=true`** — agents can hand off, multiplying paths.
   A handoff hop costs retrieval but no completion: the handing-off agent
   decides before it generates, and passes its `search_results` to the agent
   that answers. Turning chaining *off* is a supported configuration, not a
   degraded one — every agent then answers for itself.
3. **`REDIS_ENABLED=true`** — a cached classification from an hour ago vs a
   fresh one. Caching *helps* consistency for repeat queries and *hurts*
   reproducibility after a prompt change.

`dev/run variance` measures the result and tells you which one to blame:

| Reading | Diagnosis | Fix |
|---|---|---|
| routing stability < 0.9 | Same question, different agent — the sharpest form of "inconsistent" | Classifier prompt; few-shot the swapping labels |
| retrieval stability < 0.9 | Search returns different documents for identical input | Suspect the reranker or a score threshold sitting on a tie |
| answer similarity < 0.5, others stable | Wording drifts | Lower agent temperatures |
| all stable | The pipeline is deterministic | Inconsistency users report is likely phrasing → different retrieval, not randomness |

**Decide deliberately whether you want variety.** `STUDY_ADVICE_TEMPERATURE=0.3`
makes advice feel less canned and makes it less repeatable. That is a product
choice, not a bug — but make it on purpose.

---

## The tuning loop

```bash
dev/run eval --judge --judge-cards --label baseline
cp eval/results/<run>.json eval/baselines/baseline.json   # by hand, once you agree it is right

# change ONE thing
$EDITOR apps/ai-server/agent-graph-service/src/agents/classifier.py

# a prompt edit invalidates its cassettes — re-record just what changed
LLM_RECORD_MAX_CALLS=150 LLM_UPSTREAM_API_KEY=sk-... dev/env/run cassettes record
dev/run eval --judge --judge-cards
dev/env/run cassettes stop-record

dev/run eval --judge --judge-cards --compare eval/baselines/baseline.json
```

The current promoted baseline is `eval/baselines/fidelity-v2.json` (judged,
fidelity profile — see TUNING-LOG 2026-08-21); `--compare` it rather than
hand-rolling a new one unless the corpus itself changed.

`--compare` prints a verdict and exits non-zero on a regression:

```
  + routing.label_accuracy        0.8 → 0.95  (+0.15)
    retrieval.mean_recall_at_k    0.7778 → 0.7778  (+0.0)

  IMPROVED — routing.label_accuracy, nothing regressed. Adopt.
```

**Rules that keep the loop honest**

1. **One change at a time.** Two changes and a mixed result tells you nothing.
2. **Only "IMPROVED" is adopted.** "MIXED" means something broke; find out what
   before shipping it.
3. **Small moves are noise.** 20 queries swing 5 points when one query flips.
   Sub-threshold deltas report as `unchanged` on purpose.
4. **Coverage is part of the verdict, not the score.** A candidate that
   judged fewer results than the baseline — or a smaller fraction of what
   it generated (6 scored of 12 generated vs baseline's 6 of 6) — is
   refused as `JUDGE COVERAGE LOST` even when its means look fine.
5. **Log it.** Keep `eval/TUNING-LOG.md`: what you changed, the before/after,
   and the verdict. Six weeks later this is the only record of why a prompt
   looks the way it does.
6. **A failed query is not a zero.** If the scorecard shows failures, fix those
   first — the averages describe only the queries that answered. The same
   rule at the harness level: exit 2 (blocked) means the environment is
   wrong and every number below it is untrustworthy.

---

## The trap

**You can improve these numbers without improving the product.**

The dataset is 20 queries over 3 generated PDFs. Tuning routing from 80% to 95%
*on those twenty* may mean nothing for a student uploading a scanned lecture
handout.

The dataset is the product here, not the metrics. Two habits matter more than
any lever above:

1. **Add real documents.** Scanned pages, multi-column layouts, equation-heavy
   PDFs, non-English material, 300-page textbooks. Whatever your users actually
   upload. Extraction quality on clean generated text tells you nothing about
   extraction quality on a photographed page.

2. **Add every real failure.** `POST /api/chat/feedback` already collects
   thumbs-down from real users and nothing consumes it. Each one is a query that
   demonstrably disappointed someone. Add it to the dataset with the answer it
   should have given, and it becomes a permanent regression guard.

A dataset that grows from real failures gets more valuable over time. One that
stays at 20 synthetic queries gets less valuable as you overfit to it.

---

## Beyond chat

The same loop works for the other things the backend produces — the scorers
already exist in `eval/scorers/`:

| Product | Scorer | Measures |
|---|---|---|
| Chat | `retrieval.py`, `routing.py` | recall@k, MRR, routing accuracy + confusion |
| Documents | `structure.py` | section F1, hierarchy, chunk coverage, confidence calibration |
| Flashcards | `flashcard.py` | cloze well-formedness, duplicate rate, grounding, type mix |

`structure.py` is wired in and runs on every `dev/run eval` (deterministic,
cassette-free — scores produced maps against the golden maps, and its
preflight fails the whole run if a golden-mapped resource is missing from
the stack). `flashcard.py`'s mechanical checks (cloze well-formedness etc.)
still need a harness that runs on generated cards; card *quality* is covered
by `dev/run eval --judge-cards`, which generates flashcards for a few leaf
sections per document and judges them (answerable / faithful / meaningful)
through the same cassette mechanism.

---

## Not measured yet

Be clear about what a green scorecard does not tell you:

- **Truth.** The judge scores faithfulness *to the retrieved chunks* and
  relevance *to the question* (1–5, cassetted, 20/20 on the current
  baseline) — if the corpus itself is wrong, a faithful answer to it is
  still wrong. `keyword recall` remains the blunt proxy for "did it draw
  on the source".
- **Anything above the API.** Journeys and eval stop at the gateway. The mobile
  app has no executable tests.
- **Production infrastructure.** Emulators, not real Firestore/Pub/Sub/Storage.
  Your production Firestore rules are never exercised — the Admin SDK bypasses
  them.
- **Load and concurrency.** Everything is sequential. Replay latencies are not
  production latencies.
- **The live model, day to day.** Cassettes pin behaviour to what was recorded.
  A provider silently updating a model behind the same name is invisible until
  you re-record. `dev/run variance` is the only command that touches the live
  model.

---

## Quick reference

```bash
dev/run env up --profile fidelity   # stack with real extraction
dev/run seed                        # ingest the fixture corpus
dev/run journeys                    # does it work?      → .devloop/verdict.json
dev/run eval                        # is it good?        → eval/results/
dev/run eval --judge --judge-cards  # + LLM-judged quality (replay: free)
dev/run variance                    # is it consistent?  # costs money
dev/run eval --judge --judge-cards --compare eval/baselines/fidelity-v2.json
```

Baselines: `fidelity-v2` (judged, fidelity — the tuning baseline) and
`fast-v2` (fast smoke). `fast-v1`/`fidelity-v1` are marked invalid and
rejected by `--compare`. Promote a new one by hand, once you agree it is
right, and log it in `eval/TUNING-LOG.md`.

| Exit code | Meaning |
|---|---|
| 0 | pass / adoptable |
| 1 | fail — the product is wrong |
| 2 | blocked — the harness is wrong; fix the environment, not the code |

End-to-end walkthrough with record mechanics and preflight rules:
`docs/documentation/tooling/evaluation.md`.
