# Requirements — Worker → rag-api failure payload contract alignment

Authoritative source: WorkItem `wi-define-108-a8` (definition `definition:obj-108`). Scope below is exact and binding.

## 1. Problem statement

When `process_document` in `rag-worker-service/main.py` raises, its exception handler publishes a failed status with `details = {"error": str(e)}`. rag-api's failed branch in `run_transactional_update` reads `details["error_message"]`, `details["stage"]`, and `details["retryable"]`. Because of the key mismatch, every worker-originated failure persists:

- `error` = `"Processing failed"` (API fallback, never the actual message)
- `error_stage` = `None`
- `retryable` = `True` (silent API default, not derived from the worker's ACK/NACK decision)

The `processing/summary` error subdocument inherits the same fallbacks with `error_code = "UNKNOWN"`.

## 2. Must requirements

### R1 — Worker failure payload keys
When document processing fails, the worker's failed status payload must include:

- `error_message` — the actual exception message (`str(e)`),
- `stage` — the pipeline stage executing at failure time,
- `retryable` — deliberately derived, never defaulted.

The payload must never rely on rag-api's fallback defaults (`"Processing failed"`, `None`, `True`) for these keys.

### R2 — Stage tracking in `process_document`
The worker must track the currently executing pipeline stage through `process_document` so the failure handler reports the true failing stage. Stage names must reuse the existing progress-status vocabulary:

`starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`.

`"processing"` is the safe value when the stage is genuinely unknown (e.g. failure before the first transition) — the same value the stale-lease sweep uses for `error_stage`.

### R3 — rag-api persists worker-provided values unchanged
rag-api's failed branch must persist, with no changes to its reads or persisted schema:

- main doc `error` ← payload `error_message`
- main doc `error_stage` ← payload `stage`
- main doc `retryable` ← payload `retryable`
- `processing/summary` `error.message` ← same message; `error.stage` ← same stage (`error.code` remains `"UNKNOWN"` unless a code is actually sent).

### R4 — Explicit retryable derivation aligned with ACK/NACK behavior
`retryable` must be derived from `classify_error(e)`:

- transient-classified → `retryable = true`
- permanent-classified, including unclassified-unknown (classify_error's conservative default) → `retryable = false`

Rationale: a transient error is one Pub/Sub will redeliver; a permanent error was acked and manual reprocess via `POST /process` remains. Deliberate behavior change: unclassified-unknown exceptions move from the silent default `true` to `false`. The stale-lease sweep's separate `retryable: true` write stays unchanged and correct (a dead worker is a transient condition).

### R5 — Contract test on the worker failure → rag-api persistence path
A contract test must:

- exercise the worker's failure-payload construction (through the worker's code path, not a restated fixture),
- feed that payload through rag-api's failed-branch persistence (`run_transactional_update`, via Firestore emulator or fakes),
- assert persisted `error`, `error_stage`, and `retryable` equal the worker's values,
- include a key-set drift guard that fails if either side's payload keys change.

It must cover at least an early-stage failure and a late-stage failure (representative stages), pinning the tracker mechanism without ossifying every step.

## 3. Should / prefer

- **R6 (prefer)** — Retain the legacy `error` key in the worker's failure payload alongside `error_message`, for continuity with any unknown consumers of the status topic and log tooling.
- **R7 (prefer_not)** — Do not introduce a structured error-code taxonomy; `error_code` stays `"UNKNOWN"` unless actually sent.

## 4. Must-not constraints

- No change to rag-api's reads, persisted field names (`error`, `error_stage`, `retryable`), or response models.
- No Firestore migration, field rename, or backfill of existing documents.
- No change to retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals. Only the *reporting* of retryability changes.
- No change to the stale-lease sweep's direct failure write — it already writes `error`/`error_stage`/`retryable` consistently.

## 5. Non-goals

- Structured error codes / failure taxonomy.
- Frontend or mobile changes — `ResourceResponse` already exposes `error` and `error_stage`.
- The stale-lease sweep's behavior.
- Anything the companion D3 issue covers beyond this payload alignment (its content is unavailable here; deferred), and reconciling with the original D4 deviation note in `plans/upload-flow.md` (file not present in the current tree).

## 6. Acceptance criteria

| # | Criterion |
|---|-----------|
| A1 | A failed job's worker-published status details contain `error_message` (actual exception message), `stage` (failing pipeline stage), and `retryable` (deliberately derived) — none relying on rag-api's fallback defaults. |
| A2 | After a failed job, the persisted resource document has `error` = the worker's actual error message (not `"Processing failed"`), `error_stage` = the failing stage (not `None`), and `retryable` = the worker's derived value. |
| A3 | The `processing/summary` error subdocument carries the same message and stage as the main document. |
| A4 | A contract test covering the worker failure → rag-api persistence path exists and passes, exercising failure-payload construction through failed-branch persistence and asserting persisted `error`, `error_stage`, `retryable` equal the worker's values, failing if either side's payload keys drift. |