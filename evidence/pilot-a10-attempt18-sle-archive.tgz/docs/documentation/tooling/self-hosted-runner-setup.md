# Self-Hosted GitHub Actions Runner — Setup Runbook

**Audience:** an agent with root on the local server, executing this end to end.
**Outcome:** all CI jobs for `magtheo/student-platform` run on this server, GitHub-hosted billing drops to $0, and the setup survives reboots and failed jobs.

**Why self-hosted here:** the repo burned through the free Actions allowance in a single day of tuning (torch/CUDA installs × 6 services × 2 events per commit — since fixed by CPU-only torch + path filters in `backend-tests.yml`, see its header). Self-hosted job time is billed at zero minutes, and caches persist between runs.

---

## Conventions used in this document

- Commands prefixed `#` run as root (or via sudo); `$` run as the dedicated runner user.
- **STOP** markers are points where you must obtain something from the human before continuing. Do not improvise past them.
- Every part ends with a **Verify** step. If verification fails, fix before moving on; do not continue a broken state forward.

---

## STOP — inputs required from the human before starting

You cannot complete setup without these. Collect all three first:

1. **Runner registration token** — the human generates it at
   `https://github.com/magtheo/student-platform/settings/actions/runners/new`
   (valid ~1 hour; note the exact download URL shown on that page too, it is version-specific).
2. **Repo write credentials** for Part 5 (a fine-grained PAT with Contents: read/write
   and Pull requests: read/write on `magtheo/student-platform`, or a working `gh auth login`
   as the repo owner). Needed once, to push the `runs-on` change as a PR.
3. **Confirmation the GitHub account's billing is unsuspended** — self-hosted minutes cost
   $0 and do not consume the spending limit, but if Actions on the account is disabled
   entirely (failed payment), even self-hosted jobs will not start. The human should
   confirm https://github.com/settings/billing shows Actions as active, not suspended.

## Security model (read before executing)

- The runner executes arbitrary workflow steps from this **private** repo. That is
  acceptable because only the repo owner pushes to it. The protections that make it safe:
  1. A dedicated unprivileged `github-runner` user **without sudo**. The workflow's
     `Reclaim runner disk` step (`sudo rm -rf ...`) becomes a harmless no-op on this
     runner — that is by design (it targets GitHub-hosted images).
  2. The runner user owns nothing except its work directory.
  3. Repo settings must require approval for outside collaborators (Part 7).
- The runner makes **outbound-only** connections (443 to GitHub). Open no inbound ports.
- Registration is repo-scoped, not org-wide. Keep it that way.

---

## Part 0 — Preflight

```bash
# OS and arch (this runbook assumes Ubuntu/Debian 64-bit; adapt package names elsewhere)
# uname -a

# Disk: runner work dir + pip caches + embedding models need headroom
# df -h /var/lib    # require >= 20 GB free

# RAM: torch imports in unit tests want >= 4 GB total
# free -h

# Outbound reachability (no inbound needed)
# curl -fsS -o /dev/null -w '%{http_code}\n' https://api.github.com   # expect 200
```

**Verify:** all four checks pass. If disk < 20 GB, STOP and ask the human where to place the runner instead.

## Part 1 — Dedicated user

```bash
# useradd --system --home-dir /opt/actions-runner --create-home --shell /usr/sbin/nologin github-runner
# apt-get update
# apt-get install -y curl jq git ca-certificates
```

`nologin` still allows the systemd service to run as this user; it only blocks interactive login.

**Verify:** `# id github-runner` shows the user; shell is `/usr/sbin/nologin`.

## Part 2 — Job dependencies (as the runner user)

Jobs run directly on the host (no container), so the runner user needs Python 3.11,
Node 18, and pip. Install into the user's own space — that containment is the isolation.

```bash
# apt-get install -y python3.11 python3.11-venv python3.11-dev   # if unavailable on this release, use deadsnakes PPA or pyenv — any 3.11 works
# su -s /bin/bash github-runner   # enter as the runner user despite nologin
$ python3.11 -m ensurepip --user 2>/dev/null || python3.11 -m pip --version
$ python3.11 -m pip install --user --upgrade pip

# Node 18, user-level (nvm keeps it inside the runner user's home; no root Node on the server)
$ curl -fsSL https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.1/install.sh | bash
$ export NVM_DIR="$HOME/.nvm" && . "$NVM_DIR/nvm.sh"
$ nvm install 18 && nvm alias default 18
$ exit
```

**Verify (as runner user):** `python3.11 --version` → 3.11.x; `node --version` → v18.x; `git --version` works.

## Part 3 — Download and configure the runner

Use the exact URL shown on the registration page from STOP item 1.

```bash
# mkdir -p /opt/actions-runner && cd /opt/actions-runner
# curl -o actions-runner-linux-x64-<VERSION>.tar.gz -L <DOWNLOAD_URL_FROM_GITHUB>
# tar xzf actions-runner-linux-x64-<VERSION>.tar.gz
# chown -R github-runner:github-runner /opt/actions-runner
# su -s /bin/bash github-runner
$ cd /opt/actions-runner
$ ./config.sh --url https://github.com/magtheo/student-platform \
              --token <REGISTRATION_TOKEN> \
              --name student-platform-ci \
              --labels ci \
              --work _work
```

Notes:
- `--labels ci` adds a custom label on top of the defaults (`self-hosted`, `Linux`, `X64`).
  The workflow will target `runs-on: [self-hosted, ci]` — matching both ensures this server
  is picked deliberately, and a future second machine can opt in by adding the same label.
- If the token expired (they last ~1h), STOP and ask the human for a fresh one; do not retry blindly.

**Verify:** `$ ./config.sh` completed with "Runner Registration Successful!" — the runner appears as
"Idle" at `https://github.com/magtheo/student-platform/settings/actions/runners`.

## Part 4 — Install as a systemd service

```bash
$ exit
# /opt/actions-runner/svc.sh install github-runner
# /opt/actions-runner/svc.sh start
```

**Verify:**
```bash
# systemctl status actions.runner.*.student-platform-ci.service   # active (running), enabled
```
and the runner shows a green "Idle" dot on the GitHub runners page. Reboot is optional to
prove enablement: `systemctl is-enabled actions.runner.*` → `enabled`.

## Part 5 — Point the workflows at this runner (repo change, via PR)

From any clone with repo write access (STOP item 2), create a branch `ci/self-hosted-runner`:

1. **`.github/workflows/backend-tests.yml`** — every job:
   - `runs-on: ubuntu-latest` → `runs-on: [self-hosted, ci]`
2. **Guard the reclaim steps** — the three "Reclaim runner disk" steps delete preinstalled
   toolchains that only exist on GitHub-hosted images. On this server they are no-ops
   (runner user has no sudo), but make that explicit so the workflow stays hybrid-capable
   if hosted runners are ever used again. Add to each reclaim step:
   ```yaml
   if: runner.environment == 'github-hosted'
   ```
3. **`.github/workflows/mobile-tests.yml`** — same `runs-on` change (single `test` job).
4. Commit message: `ci: run all jobs on the self-hosted runner (ci label)`. Push, open a PR
   against `main`. Do not merge yet — Part 6 validates through this PR.

**Verify:** PR created; the Backend Tests run it triggers shows jobs queued (they will wait
for the runner if it is offline — if they queue forever, the runner is not online; recheck Part 4).

## Part 6 — End-to-end validation

1. Watch the PR's checks execute on the server:
   ```bash
   # journalctl -u 'actions.runner.*' -f
   ```
2. On the PR, all jobs must pass. The full matrix runs (workflow edits re-run everything —
   by design, see the `changes` job): 6 unit legs, 5 integration legs, 2 node legs,
   cross-service, verification-tooling.
3. Confirm the run consumed **no billed minutes**: the run's page on GitHub shows the
   runner name (`student-platform-ci`), and
   `https://github.com/settings/billing` usage does not move.
4. Verify the reclaim steps were skipped on this runner: job logs show
   "Reclaim runner disk" with a skip marker, not executed.

**Verify:** PR fully green on the self-hosted runner, zero billed minutes. If any job fails
from missing host deps (most likely: a Python package needing a system library), install it
as root, re-run the failed job from the PR page, and note it in Part 8's maintenance table.

## Part 7 — Security checklist (do not skip)

On `https://github.com/magtheo/student-platform/settings/actions`:
- [ ] Actions → General → Fork pull request workflows: **"Require approval for all
      outside collaborators"** (with a single-owner repo this is belt-and-braces, but set it).
- [ ] Workflow permissions → "Read repository contents and packages permissions" (default,
      least privilege) unless a job needs more.
- [ ] Runners page: the runner is registered at **repository** scope only, label `ci`.
- [ ] On the server: `sudo -l -U github-runner` → "may not run sudo" (or not allowed).

## Part 8 — Maintenance

| What | Cadence | Command / note |
|---|---|---|
| Runner software | automatic | The runner self-updates by default; leave it on. |
| Service health | after any server work | `systemctl status actions.runner.*` — green Idle on the runners page. |
| Work directory growth | monthly | `du -sh /opt/actions-runner/_work` — clear stale build dirs of deleted branches if > 10 GB. Keep `_work/*/_temp` and pip/tool caches: warm caches are the main speed win. |
| pip cache purge | quarterly | as runner user: `python3.11 -m pip cache purge` (then first run re-downloads). |
| Logs | on failure | `/opt/actions-runner/_diag/` (service + worker logs per job). |
| Deprecation window | watch | GitHub emails ~90 days before runner-version cutoffs; update = download new tarball over the directory, `svc.sh stop && config.cmd ... && svc.sh start`. |

## Rollback

1. Remove the runner:
   ```bash
   # /opt/actions-runner/svc.sh stop && /opt/actions-runner/svc.sh uninstall
   # su -s /bin/bash github-runner -c '/opt/actions-runner/config.sh remove --token <TOKEN>'
   ```
   (token from the runners settings page → Remove runner).
2. Revert the Part 5 PR on GitHub (`runs-on: ubuntu-latest`, drop the `if:` guards).
3. Optionally delete the user and directory: `userdel -r github-runner` after confirming
   nothing else uses `/opt/actions-runner`.

---

**Success criteria, restated:** CI green on PRs, jobs physically executing on this server
(journalctl shows them), `https://github.com/settings/billing` Actions usage flat, runner
survives a reboot (systemd enabled).

---

## Addendum 2026-08-27 — as-built after the local-ci-and-workflow feature

The original runbook above describes a single-runner setup as planned.
What is actually running now, and the corrections learned during the
install (each also in `plans/local-ci-and-workflow.md`):

**Corrections to the runbook steps:**

- Part 4: `svc.sh install` MUST be run from the runner root
  (`cd /opt/actions-runner && sudo ./svc.sh install github-runner`) —
  it resolves `./bin` relative to the CWD and fails with "Must run
  from runner root or install is corrupt" otherwise.
- Part 2 host deps: `jq` and `unzip` are required (flutter-action);
  `apt-get install -y jq unzip`.
- Debian 13 has no `actions/setup-python` manifest entry and no py3.11
  apt package: Python 3.11 comes from uv (user-local prebuilt) and is
  copied into EACH runner's `_work/_tool` (runners do not share tool
  caches). This is now automated — see below — and needs no sudo.
- Part 5's `runs-on: [self-hosted, ci]` label design was kept. The
  workflow edits themselves live in the repo's history (PRs #19, #23).

**As-built pool:**

- THREE runners (`student-platform-ci`, `-ci-2`, `-ci-3`) at
  `/opt/actions-runner{,-2,-3}`, one systemd service each, same
  `github-runner` user, label `ci`. Job parallelism = runner count;
  full backend matrix ~13 min pooled vs ~23 min serialized.
- Tool-cache provisioning and corrupt-flutter-cache cleanup are
  automated in `.github/workflows/runner-maintenance.yml` (runs AS the
  runner user — no sudo, re-runnable via workflow_dispatch). Manual
  provisioning scripts are no longer the path; run that workflow.

**CI shape (see the workflow headers for full history):**

- `pull_request` triggers are deliberately filterless in both
  workflows — required status checks must report on every PR;
  path filtering lives inside (`changes` detector, mobile `detect`).
- Required checks on `main`: `backend-summary` + `mobile-summary`
  (always-reporting gates). Approving reviews are optional; one human
  read and the directing human merge decision remain expected. Agents
  must never merge or approve.
- All normal Backend/Mobile jobs — heavy suites, `changes`,
  `verification-tooling`, both summaries, and `deploy-trigger` — run
  on the `[self-hosted, ci]` pool. Jobs queue while the local pool is
  unavailable (24h expiry, then re-run); no GitHub-hosted fast lane is
  used. The privileged advisory reviewer runs separately on the
  disposable `ai-review` lane (Part 9).

**For replicating this stack on another repo:**
`documentation/tooling/new-repo-ci-checklist.md`.

## Part 9 — The ai-review lane: ephemeral privileged runners

### The two trust domains and who trusts what

The repository's CI runs entirely on local hardware, split by
TRUST CLASS (not by job weight):

| lane | runs | executes | secrets | lifetime |
|---|---|---|---|---|
| ci pool (3 persistent runners) | all tests, gates, summaries | PR-CONTROLLED code | none | persistent (warm caches) |
| ai-review lane (1 slot) | only the AI-review job | trusted-base code only | `LLM_API_KEY` | ONE disposable container per job |

Roles:

- **GitHub** — scheduler only; no metered compute and no choke point
  (a billing failure previously starved the whole CI, including
  infrastructure we own — plans/local-ci-and-workflow.md Deviation 4).
- **A pull request** — may run code on either lane (any PR can set
  `runs-on: ai-review` in its own workflow); on the ephemeral lane
  it can only pollute an instance that dies with its job.
- **The root supervisor** (`ai-review-lane.service`) — the one
  trusted actor added: sole holder of the registration credential;
  its only capability is handing out disposable boxes.
- **The AI reviewer** — advisory EVIDENCE, never authority; with
  this design it also cannot be shadowed by a rogue runner, because
  only the supervisor can mint runners and every instance is fresh.
- **Humans** — sole merge authority (unchanged).

Core principle: **trust is not assumed from exclusion ("nobody else
can reach this runner") — it is manufactured from disposability
("anyone can reach it; nothing persists")**. This survives
configuration mistakes, malicious PRs, and future workflow edits.


The `ai` labels ROUTE, they do not AUTHORIZE. Normal CI runs on
`pull_request`, so any PR can modify its own workflow and set
`runs-on: ai-review` — assume PR-controlled code WILL reach this
lane. The boundary is therefore not a dedicated persistent runner
but disposability: every Actions job on this lane gets a freshly
provisioned container, destroyed after one job, never reused.

```text
trusted host supervisor (systemd; holds the registration PAT)
  loop:
    mint registration token          # host side only
    docker run --rm <runner-image>   # fresh filesystem, no host mounts,
      register --ephemeral           #   no docker socket, network egress only
    runner takes EXACTLY ONE job
    container exits -> destroyed
```

Hard requirements (each is load-bearing):

- **Fresh filesystem per job**: disposable container (or equivalent
  clean reprovisioning). `--ephemeral` alone is NOT sufficient if
  the same filesystem/home survives — the compute state itself must
  be new.
- **Credentials stay on the host**: registration token generation
  (PAT or GitHub App) lives in the supervisor service only, never
  in the repo, a job, or the container image.
- **No inheritance from the ci pool**: never mount
  `/opt/actions-runner*`, `_work` dirs, or tool caches.
- **No host control**: no Docker socket, no privileged container,
  no host paths mounted writable; network egress (GitHub, OpenRouter)
  only.
- **One job per instance**: `--ephemeral` + container removal on
  exit; the supervisor loop re-provisions continuously so the lane
  has capacity while the host is awake.
- **Token transport**: the registration token reaches the container
  via the docker client's environment (bare `-e REG_TOKEN`) and
  config.sh via `ACTIONS_RUNNER_INPUT_TOKEN` only — `--token` is
  never used (config.sh argv is world-readable via host
  /proc/<pid>/cmdline under default hidepid=0). Verified by
  acceptance.sh's live scan: zero observations as `github-runner`.
- **Runtime dependencies**: the image carries bash, curl, jq,
  python3, and git — the pinned reviewer executes python and the
  checkout step needs git; `ai-lane-probe.yml`'s reviewer-prereqs
  job exercises exactly this at the pin.
- **Labels**: registration uses `--no-default-labels --labels
  ai-review` — `ai-review` is the ONLY routing label (no
  self-hosted/Linux/X64 defaults).
- **Host acceptance**: the persistent `github-runner` CI user is
  NOT in the docker group and `sudo -u github-runner docker ps`
  fails (see infra/ai-review-lane/README.md); runner tarball sha256
  and base image digest are pinned.
- Fork guard and immutable ci-toolkit pins (both SHA-pinned) remain
  unchanged — this lane replaces the RUNNER trust assumption, not
  the workflow trust model.

The implementation is in-repo and reviewable (PR #64):
`infra/ai-review-lane/` (Dockerfile, entrypoint.sh, supervisor.sh,
systemd unit, README with provisioning steps and the
hard-properties list) plus the executable cleanliness probe
`.github/workflows/ai-lane-probe.yml`.

Validation (from plans/ci-local-runners.md Phase 2):

- A (executable): the probe workflow's two needs-chained jobs land
  on two different instances; the second asserts the first's
  `$HOME/ai-lane-marker` is absent. Runs pre-merge from the PR
  (pull_request, head file) once the host lane is provisioned.
- B: a real `pull_request_target` AI review lands on the lane and
  posts its review with `LLM_API_KEY` mapped (post-merge).
