# AI Server Overview

## Architecture

The AI server is a set of Docker microservices orchestrated with Docker Compose.

## Services

| Service | Language | Role |
|---------|----------|------|
| `api-gateway` | Node.js/TypeScript | Routes requests, handles auth verification hand-off |
| `auth-service` | Node.js/TypeScript | Validates Firebase ID tokens |
| `rag-api-service` | Python FastAPI | AI chat endpoint, LangGraph agent orchestration |
| `rag-worker-service` | Python | Document processing (PDF → Markdown → embeddings) |
| `flashcard-service` | (check codebase) | Flashcard generation |
| `observability-aggregator` | (check codebase) | Logging and observability |

## Key endpoints (via api-gateway)

- `POST /messages` — send a chat message, returns SSE stream
- Document upload triggers are handled via Firebase Storage + Pub/Sub (not a direct HTTP call)

## Agent types

See `docs/documentation/ai-features/rag-agent-types.md` for the multi-agent routing design.

## LangGraph

The RAG API service uses LangGraph for agent orchestration. Checkpoints are saved to Firestore after a successful AI response. If the AI crashes mid-stream, the checkpoint is not updated — making retries safe.
