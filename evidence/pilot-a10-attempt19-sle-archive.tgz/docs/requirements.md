# Requirements — rag-worker → rag-api failure payload contract alignment

Authoritative source: Definition artifact `definition:obj-108` (WorkItem `wi-define-108-a8`, sha256 `71f1c39c97ecea575b1195b63de510fa403dad4fecaa1df0c774d04fae89cac5`). This document restates that bounded scope as implementable, testable requirements. It does not widen, narrow, or reinterpret the Definition; where the Definition is binding, this document is restatement.

## 1. Problem statement

The rag-worker's failure publisher and rag-api's failure consumer were written against different payload contracts, and no test covers the seam.

- The worker's `process_document` exception handler publishes failed status with a one-key payload: `{"error": str(e)}` (Definition F3).
- rag-api's failed branch in `run_transactional_update` reads three keys and persists them (verified in `apps/ai-server/rag-api-service/main.py`):
  - `error` ← `details.get("error_message", "Processing failed")`
  - `error_stage` ← `details.get("stage")`
  - `retryable` ← `details.get("retryable", True)`
  - and writes the `processing/summary` error subdocument as `{code: details.get("error_code", "UNKNOWN"), message: details.get("error_message", "Processing failed"), stage: details.get("stage")}`.
- Because of the key mismatch, every worker-originated failure persists the fallback string `"Processing failed"`, `error_stage: null`, and a fabricated `retryable: true` (Definition F5). The summary error subdocument inherits the same fallbacks with `error_code` always `"UNKNOWN"`.

The persisted failure schema (`error`, `error_stage`, `retryable`) is already consistent across three other write paths — the worker's stale-lease sweep, rag-api's enqueue-failure paths (`/process`, `POST /resources`) — and is exposed by the `Resource` model and `ResourceResponse` (Definition F6; `Resource` fields verified in `apps/ai-server/rag-api-service/models/resource.py`, including `retryable: bool = True`). The worker's status publisher is the only writer that does not speak this contract.

## 2. Scope

### 2.1 In scope
- The worker's failed-status payload keys and values (`error_message`, `stage`, `retryable`, plus the retained legacy `error` key).
- Stage tracking inside `process_document` so the failure handler can report the true failing stage.
- Deliberate derivation of `retryable` from the worker's existing error classification.
- A contract test covering the worker failure → rag-api persistence path, including a key-set drift guard.

### 2.2 Out of scope / non-goals (binding, from Definition)
- Changing the stale-lease sweep's direct failure write (already consistent).
- Changing retry/backoff mechanics: Pub/Sub ACK/NACK policy, processing leases, heartbeat intervals. Only the *reporting* of retryability changes.
- Frontend or mobile changes (`ResourceResponse` already exposes `error` and `error_stage`).
- Introducing structured error codes or a failure taxonomy; `processing/summary` `error.code` remains `"UNKNOWN"` unless a code is actually sent.
- Any scope the companion D3 issue covers beyond this payload alignment (its content is unavailable in this context; deferred).
- Reconciling this analysis with the original D4 deviation note in `plans/upload-flow.md` (that file is not present in the current tree; the reference comes from the Objective text).

## 3. Functional requirements

### FR-1 — Worker failure payload keys
When document processing fails, the worker's failed status payload published via `_publish_status_update` MUST include:
- `error_message` — the actual exception message (`str(e)` of the caught exception);
- `stage` — the pipeline stage executing at failure time, as a non-null string;
- `retryable` — a deliberately derived boolean (see FR-4).

The payload MUST also retain the legacy `error` key, set to the same string as `error_message` (adopted hedge per Definition F11 and the prefer-constraint on consumer continuity).

The payload MUST NOT rely on rag-api's fallback defaults for any of `error_message`, `stage`, or `retryable`: after this change, no worker-originated failure may persist `"Processing failed"`, a null stage, or a defaulted `retryable` because a key was absent.

### FR-2 — Stage tracking in `process_document`
- `process_document` MUST maintain a current-stage tracker (a local variable) that the exception handler reads at failure time.
- The tracker MUST be set immediately before each pipeline step executes (the "set before the await" convention).
- Stage names MUST reuse the existing progress-status vocabulary: `starting`, `text_retrieved`, `tagging_complete`, `summary_generated`, `chunking_complete`, `embeddings_complete`. No new stage names may be invented for failure reporting.
- When the stage is genuinely unknown (e.g., failure before the first transition), the tracker MUST report `"processing"` — the same safe value the stale-lease sweep uses for `error_stage` — so `error_stage` never regresses to null.

### FR-3 — rag-api persistence mapping (unchanged behavior, pinned)
rag-api's failed branch MUST persist worker-provided values unchanged:
- main document: `error` ← payload `error_message`; `error_stage` ← payload `stage`; `retryable` ← payload `retryable`;
- `processing/summary` error subdocument: `message` ← payload `error_message`; `stage` ← payload `stage`; `code` remains `"UNKNOWN"` (the worker sends no `error_code`).

rag-api's reads and persisted schema MUST NOT change (constraint: worker aligns to the API, not vice versa). The API-side fallbacks (`"Processing failed"`, `retryable` default `True`) remain in code for the enqueue-failure paths but MUST NOT be the operative mechanism for worker failures.

### FR-4 — retryable derivation
- The worker MUST set `retryable` from `classify_error(e)` — the same classification that drives ACK/NACK in `run_worker`:
  - errors classified transient → `retryable: true`;
  - errors classified permanent, including unclassified-unknown exceptions (per `classify_error`'s conservative default) → `retryable: false`.
- Every worker-originated failure payload MUST carry `retryable` explicitly; the API-side `details.get("retryable", True)` fallback must never be operative for worker failures.
- The stale-lease sweep's separate `retryable: true` write is unchanged and remains correct (a dead worker is a transient condition).

### FR-5 — Contract test on the worker → rag-api failure path
A contract test MUST exist and pass that:
- exercises the worker's failure-payload construction through its real code path (not a restated fixture), and feeds the resulting payload through rag-api's `run_transactional_update` failed-branch persistence, using the Firestore emulator or fakes;
- asserts the persisted main-document `error`, `error_stage`, and `retryable` equal the worker's payload values, and that the `processing/summary` error subdocument carries the same message and stage;
- includes a key-set drift guard that fails the build if either side's payload keys change (worker publish keys; rag-api read keys);
- pins the stage tracker on representative stages: at least one early-stage failure and one late-stage failure;
- pins the retryable derivation with at least one transient-classified exception (expect `true`) and one permanent-classified exception, plus an unclassified-unknown exception (expect `false`).

### FR-6 — No schema migration
The fix MUST NOT require a Firestore migration, field rename, or backfill of existing documents. The persisted field names `error`, `error_stage`, `retryable` keep their names and semantics.

## 4. Constraints (binding, from Definition)

| Type | Constraint |
|---|---|
| must | Align the worker to rag-api's existing contract (`error_message`/`stage`/`retryable`); do not change rag-api's reads or persisted schema. |
| must_not | No Firestore migration, field rename, or backfill of existing documents. |
| must | Every worker-originated failure payload carries `retryable` explicitly (deliberately derived); the API-side fallback must not be operative for worker failures. |
| prefer | Retain the legacy `error` key in the worker's failure payload alongside `error_message`. |
| prefer_not | Do not introduce a structured error-code taxonomy (`error_code` values) in this fix. |

## 5. Acceptance criteria

| ID | Criterion (from Definition) | Satisfied by |
|---|---|---|
| AC-1 | A failed job's status message published by the worker contains `error_message` (actual exception message), `stage` (failing pipeline stage), and `retryable` (deliberately derived) — none relying on rag-api's fallback defaults. | FR-1, FR-2, FR-4; verified by FR-5 test |
| AC-2 | After a failed job, the persisted resource document has `error` = the worker's actual error message (not `"Processing failed"`), `error_stage` = the failing stage (not null), and `retryable` = the worker's derived value. | FR-3, FR-4; verified by FR-5 test |
| AC-3 | The `processing/summary` error subdocument for the failed job carries the same message and stage as the main document. | FR-3; verified by FR-5 test |
| AC-4 | A contract test covering the worker failure → rag-api persistence path exists and passes, exercising the worker's failure-payload construction through rag-api's failed-branch persistence and asserting the persisted `error`, `error_stage`, and `retryable` equal the worker's values, failing if either side's payload keys drift. | FR-5 |

## 6. Deferred and unknown (preserved, not invented)

- **Companion D3 issue**: referenced by the Objective; its content is not available in this context. Anything it covers beyond the worker→rag-api failure payload alignment is out of scope (Definition F12).
- **`plans/upload-flow.md`**: not present in the current tree; the D4 deviation reference cannot be reconciled here and is deferred.
- **Status-topic consumer audit**: only rag-api's status subscriber is a verified consumer of worker failure payloads (Definition F11, assumed hedge). A full audit of other readers of `rag-status-updates` is deferred; the legacy `error` key is retained as insurance in the meantime.
- **`classify_error` interface shape**: the Definition pins its semantics (transient vs. permanent; unknown → permanent) and its use in `run_worker` ACK/NACK. The exact return shape (boolean/enum/class) is to be confirmed against `apps/ai-server/rag-worker-service/main.py` / `exceptions.py` at build time; the derivation reuses whatever classification the ACK/NACK decision already consumes, mapped transient→`true`, permanent→`false`.

## 7. Verification matrix

| Requirement | Verified by |
|---|---|
| FR-1 | Contract test: worker payload key-set drift guard + value assertions |
| FR-2 | Contract test: early-stage and late-stage failure cases assert reported stage |
| FR-3 | Contract test: persisted main doc + summary subdoc equal worker values; rag-api code unchanged (diff review) |
| FR-4 | Contract test: transient → `true`; permanent → `false`; unknown → `false` |
| FR-5 | The contract test itself (new module under `apps/ai-server/tests/integration/`) |
| FR-6 | No migration artifacts in change set; persisted field names unchanged (diff review + existing `Resource` model tests) |